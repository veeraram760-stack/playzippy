# ARENA STRIKE — Browser Fighting Game

Version 1.1 · Self-contained side-view fighting-game prototype.

## Run it

1. Extract the ZIP folder.
2. Open `arena-strike/index.html` in Chrome, Edge, or Firefox.
3. If your browser blocks local-file assets, double-click `start-local-server.bat` on Windows, or run `python -m http.server 8000` from this folder and visit `http://localhost:8000`.

## How to play

| Action | Keyboard |
|---|---|
| Move left / right | `A` / `D` or arrow keys |
| Move along the arena lane | `S` / Down Arrow |
| Jump | `W` / Up Arrow |
| Attack / combo | `J` |
| Special ability | `K` |
| Dash | `Space` or `Shift` |
| Guard | Hold `L` |
| Pause | Click the pause control |

Touch controls appear on smaller screens.

## Included

- Eight selectable fighters: Thunder, Inferno, Frost, Phantom, Venom, Titan, Aether, and Reaper.
- Four selectable battle locations: Temple of Storms, Volcano Arena, Frozen Peaks, and Cyber Arena. Each location has its own illustrated stage backdrop.
- Side-view, one-on-one combat with a moving CPU opponent, approach/run behavior, attacks, guard, dash, hit reactions, knockback, knockout poses, combo chains, special attacks, particles, health/energy HUD, pause, rematch, and result screens.
- Procedurally articulated 2D/2.5D Canvas fighters with distinct limb poses for idle, running, jumping, attacking, guarding, dashing, taking hits, and knockout.
- Responsive desktop and mobile layouts. No build step, external JavaScript library, server backend, or network connection is required.

## Version 1.1 fixes

- Passes the selected arena into the battle renderer before the first gameplay frame, fixing the battle-screen rendering issue in the previous saved package.
- Adds a safe renderer fallback for the arena selection.
- Makes guard reduce incoming damage for either fighter.
- Ensures special attacks show their impact ring at the hit moment.

## Prototype scope

This is a playable local single-player prototype. The Story, Arcade, Tournament, and Versus buttons currently launch a one-on-one CPU fight. Online multiplayer, account systems, monetization, persistent progression, and full 3D character models are not included. Fighters are drawn as articulated 2D/2.5D Canvas rigs rather than full 3D models.
