'use strict';
(() => {
  const DATA = window.ARENA_DATA;
  const $ = id => document.getElementById(id);
  const canvas = $('gameCanvas');
  const ctx = canvas.getContext('2d');
  const keys = new Set();
  const state = {
    screen:'select', selectedFighter:DATA.fighters[0], selectedArena:DATA.arenas[0], arena:DATA.arenas[0], mode:'story',
    player:null, enemy:null, particles:[], time:0, roundTime:99, paused:false, ended:false,
    lastFrame:0, uiTick:0, playerCombo:0, lastPlayerAttack:0, playerSkillCooldown:0,
    flash:0, round:1, sounds:true
  };
  const rand=(a,b)=>a+Math.random()*(b-a);
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const lerp=(a,b,t)=>a+(b-a)*t;
  const dist=(a,b)=>Math.abs(a.x-b.x);
  const toast=(message)=>{const node=$('toast');node.textContent=message;node.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>node.classList.remove('show'),1900);};

  function renderSelection(){
    $('fighterGrid').innerHTML='';
    DATA.fighters.forEach((f,i)=>{
      const b=document.createElement('button');b.className='fighter-card'+(f.id===state.selectedFighter.id?' selected':'');b.dataset.fighter=f.id;
      b.innerHTML=`<img src="assets/portraits/${f.id}.jpg" alt="${f.name}"/><small>${f.icon}</small><span>${f.name}</span>`;
      b.addEventListener('click',()=>selectFighter(f.id));$('fighterGrid').appendChild(b);
    });
    $('arenaGrid').innerHTML='';
    DATA.arenas.forEach(a=>{
      const b=document.createElement('button');b.className='arena-card'+(a.id===state.selectedArena.id?' selected':'');b.dataset.arena=a.id;
      b.innerHTML=`<img src="assets/arenas/${a.id}.jpg" alt="${a.short}"/><b>${a.short}</b>`;
      b.addEventListener('click',()=>selectArena(a.id));$('arenaGrid').appendChild(b);
    });
    document.querySelectorAll('.mode-button').forEach(b=>b.classList.toggle('selected',b.dataset.mode===state.mode));
    updateFighterPanel();
  }
  function selectFighter(id){
    state.selectedFighter=DATA.fighters.find(f=>f.id===id)||DATA.fighters[0];
    document.querySelectorAll('.fighter-card').forEach(b=>b.classList.toggle('selected',b.dataset.fighter===id));
    updateFighterPanel();
  }
  function selectArena(id){
    state.selectedArena=DATA.arenas.find(a=>a.id===id)||DATA.arenas[0];
    state.arena=state.selectedArena;
    document.querySelectorAll('.arena-card').forEach(b=>b.classList.toggle('selected',b.dataset.arena===id));
    $('selectedSummary').textContent=`${state.selectedFighter.name} · ${state.selectedArena.name} selected`;
    $('showcaseBackdrop').style.backgroundImage=`linear-gradient(90deg,rgba(5,10,20,.24),rgba(5,10,20,.12) 54%,rgba(5,10,20,.88)),url('assets/arenas/${id}.jpg')`;
  }
  function updateFighterPanel(){
    const f=state.selectedFighter;
    $('fighterName').textContent=f.name;$('fighterSubtitle').textContent=f.title;$('fighterRole').textContent=f.role;
    $('fighterElement').textContent=f.element;$('fighterStyle').textContent=f.style;
    const starCount=clamp(Math.round(f.stats.Speed/20),3,5);$('fighterStars').innerHTML='★'.repeat(starCount)+`<i>${'☆'.repeat(5-starCount)}</i>`;
    $('fighterStats').innerHTML=Object.entries(f.stats).slice(0,4).map(([name,val])=>`<div class="stat-row"><span>${name.toUpperCase()}</span><div class="stat-track"><i style="width:${val}%"></i></div><em>${val}</em></div>`).join('');
    $('fighterSkills').innerHTML=f.skills.map((s,i)=>`<div class="skill-chip"><div class="skill-orb">${['⚡','✦','➤','✹'][i]}</div>${s}</div>`).join('');
    $('showcaseCharacter').style.backgroundImage=`url('assets/${f.id==='thunder'?'thunder-feature.jpg':`portraits/${f.id}.jpg`}')`;
    $('showcaseCharacter').style.backgroundSize=f.id==='thunder'?'cover':'auto 88%';
    $('showcaseCharacter').style.backgroundPosition=f.id==='thunder'?'36% 42%':'center center';
    $('showcaseCharacter').style.filter=`drop-shadow(0 0 18px ${f.color}66)`;
    $('selectedSummary').textContent=`${f.name} · ${state.selectedArena.name} selected`;
    document.querySelectorAll('.fighter-card').forEach(b=>b.classList.toggle('selected',b.dataset.fighter===f.id));
  }
  function createActor(fighter,team,x,facing){
    return {fighter,team,x,y:600,depth:1,baseScale:1.03,hp:1000,maxHp:1000,energy:100,phase:rand(0,Math.PI*2),facing,action:'idle',actionT:0,actionDuration:0,attackType:1,attackHit:false,attackCooldown:0,skillCooldown:0,moveVelocity:0,knockback:0,aiThink:0,aiMode:'approach',stun:0,combo:0};
  }
  function startBattle(){
    // Lock the chosen environment into the active match before the first render.
    state.arena=state.selectedArena||DATA.arenas[0];
    let opponent=DATA.fighters[(DATA.fighters.findIndex(f=>f.id===state.selectedFighter.id)+1+Math.floor(Math.random()*7))%DATA.fighters.length];
    if(opponent.id===state.selectedFighter.id)opponent=DATA.fighters.find(f=>f.id!==state.selectedFighter.id);
    state.player=createActor(state.selectedFighter,'player',430,1);
    state.enemy=createActor(opponent,'enemy',1010,-1);
    state.player.y=state.enemy.y=600;state.player.depth=1;state.enemy.depth=1;
    state.particles=[];state.time=0;state.roundTime=99;state.paused=false;state.ended=false;state.playerCombo=0;state.lastPlayerAttack=-5;state.playerSkillCooldown=0;state.flash=0;
    $('playerPortrait').src=`assets/portraits/${state.player.fighter.id}.jpg`;$('enemyPortrait').src=`assets/portraits/${state.enemy.fighter.id}.jpg`;
    $('playerHudName').textContent=state.player.fighter.name;$('enemyHudName').textContent=state.enemy.fighter.name;
    $('playerHudLevel').textContent='LV. 07';$('enemyHudLevel').textContent='LV. 07';$('battleArenaName').textContent=state.selectedArena.name;
    $('combatTip').textContent=DATA.modes[state.mode].tip;
    $('battleCallout').textContent='FIGHT!';$('battleCallout').classList.remove('show');void $('battleCallout').offsetWidth;$('battleCallout').classList.add('show');
    $('comboCounter').classList.remove('active');$('comboValue').textContent='0';
    $('pauseOverlay').classList.add('hidden');$('resultOverlay').classList.add('hidden');
    $('selectScreen').classList.add('hidden');$('battleScreen').classList.remove('hidden');state.screen='battle';
    updateHud();
  }
  function setAction(actor,action,duration,opts={}){
    actor.action=action;actor.actionT=0;actor.actionDuration=duration;actor.attackHit=false;
    if(opts.type)actor.attackType=opts.type;
    if(opts.cooldown!==undefined)actor.attackCooldown=opts.cooldown;
    if(opts.velocity!==undefined)actor.knockback=opts.velocity;
  }
  function addParticle(x,y,color,kind='spark',n=10,force=1){
    for(let i=0;i<n;i++){
      const a=rand(-Math.PI,Math.PI),speed=rand(60,300)*force;
      state.particles.push({x,y,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed-rand(10,90),life:rand(.22,.7),maxLife:.7,size:rand(1.5,4.5),color,kind:kind==='ring'&&i===0?'ring':kind,r:rand(16,55),rot:rand(-1,1),glow:rand(4,13)});
    }
  }
  function showLog(text){const node=document.createElement('div');node.className='log-item';node.textContent=text;$('floatingLog').appendChild(node);setTimeout(()=>node.remove(),1250);}
  function showCallout(text){const node=$('battleCallout');node.textContent=text;node.classList.remove('show');void node.offsetWidth;node.classList.add('show');}
  function sound(type){
    if(!state.sounds)return;
    try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;const ac=sound.ac||(sound.ac=new AC());if(ac.state==='suspended')ac.resume();const o=ac.createOscillator(),g=ac.createGain();o.type=type==='hit'?'triangle':'sawtooth';const now=ac.currentTime;o.frequency.setValueAtTime(type==='hit'?180:type==='skill'?680:320,now);o.frequency.exponentialRampToValueAtTime(type==='hit'?65:type==='skill'?170:110,now+.14);g.gain.setValueAtTime(type==='hit'?.13:.07,now);g.gain.exponentialRampToValueAtTime(.001,now+.18);o.connect(g);g.connect(ac.destination);o.start();o.stop(now+.19);}catch(e){}
  }
  function inRange(attacker,target,range){return Math.abs(attacker.x-target.x)<range&&Math.abs(attacker.y-target.y)<55;}
  function doAttack(actor,isPlayer,type){
    const now=state.time;
    if(actor.hp<=0||actor.attackCooldown>0||['hit','ko'].includes(actor.action))return;
    let attackType=type||1;
    if(isPlayer){
      if(now-state.lastPlayerAttack<.85)state.playerCombo=state.playerCombo%3+1;else state.playerCombo=1;
      attackType=state.playerCombo;state.lastPlayerAttack=now;
      $('comboCounter').classList.add('active');$('comboValue').textContent=String(state.playerCombo);
      if(state.comboHide)clearTimeout(state.comboHide);state.comboHide=setTimeout(()=>$('comboCounter').classList.remove('active'),1600);
    }
    setAction(actor,'attack',attackType===3?.66:.48,{type:attackType});actor.attackCooldown=attackType===3?.72:.48;
    if(isPlayer)sound('swing');
  }
  function doSkill(actor,isPlayer){
    if(actor.hp<=0||actor.skillCooldown>0||['hit','ko'].includes(actor.action))return;
    setAction(actor,'skill',.92);actor.skillCooldown=isPlayer?5.5:7.5;actor.energy=clamp(actor.energy+8,0,100);
    if(isPlayer){state.playerSkillCooldown=5.5;showLog(`${actor.fighter.skills[3].toUpperCase()}!`);sound('skill');}else sound('swing');
  }
  function resolveDamage(attacker,target,damage,isPlayer,heavy=false){
    if(target.hp<=0)return;
    if(target.action==='guard'){
      damage=Math.round(damage*(target.team==='player'?.22:.28));
      target.energy=clamp(target.energy-14,0,100);
      if(target.team==='player')showLog('BLOCKED');
      addParticle(target.x,target.y-100,'#8adfff','spark',7,.45);sound('hit');
      if(target.energy<=0){setAction(target,'hit',.48);target.energy=38;}
      if(target.hp>0&&damage>0)target.hp=clamp(target.hp-damage,0,target.maxHp);
    }else{
      target.hp=clamp(target.hp-damage,0,target.maxHp);target.energy=clamp(target.energy+11,0,100);target.knockback=(attacker.facing||1)*(heavy?250:150);setAction(target,'hit',.28);
      addParticle(target.x-(attacker.facing||1)*15,target.y-105,heavy?attacker.fighter.color:'#ffd17b','spark',heavy?24:13,heavy?1.5:1);state.flash=Math.max(state.flash,heavy?.7:.3);sound('hit');
      if(isPlayer)showLog(heavy?`-${damage} CRITICAL`:`-${damage}`);
      else showLog(`-${damage} HP`);
    }
    if(target.hp<=0){setAction(target,'ko',1.3);target.knockback=(attacker.facing||1)*110;showCallout(isPlayer?'K.O.':'DEFEATED');finishBattle(isPlayer);}
  }
  function resolvePlayerHit(actor,heavy=false){
    const target=state.enemy;if(!target||actor.attackHit)return;actor.attackHit=true;
    const range=heavy?230:150;
    if(inRange(actor,target,range)&&Math.abs(actor.y-target.y)<70){
      const damage=heavy?Math.round(90+actor.fighter.stats.Power*.45):Math.round((actor.attackType===3?72:actor.attackType===2?48:34)*(actor.fighter.stats.Power/90));
      resolveDamage(actor,target,damage,true,heavy);actor.energy=clamp(actor.energy+10,0,100);
    }else if(heavy){addParticle(actor.x+actor.facing*90,actor.y-110,actor.fighter.color,'ring',1,1.4);}
  }
  function resolveEnemyHit(actor,heavy=false){
    const target=state.player;if(!target||actor.attackHit)return;actor.attackHit=true;
    if(inRange(actor,target,heavy?205:138)&&Math.abs(actor.y-target.y)<65){
      const damage=heavy?82:actor.attackType===3?58:actor.attackType===2?43:31;
      resolveDamage(actor,target,damage,false,heavy);
    }
  }
  function triggerPlayer(action){
    if(state.screen!=='battle'||state.paused||state.ended||!state.player)return;
    const p=state.player;
    if(action==='attack'){doAttack(p,true,1);return;}
    if(action==='skill'){doSkill(p,true);return;}
    if(action==='dash'&&p.attackCooldown<=0){setAction(p,'dash',.32,{velocity:p.facing*460});p.energy=clamp(p.energy-8,0,100);addParticle(p.x,p.y-70,p.fighter.color,'line',6,.8);return;}
    if(action==='guard'&&p.hp>0){setAction(p,'guard',.16);return;}
    if(action==='jump'&&p.hp>0&&!['attack','skill','ko'].includes(p.action)){setAction(p,'jump',.66);return;}
  }
  function playerUpdate(dt){
    const p=state.player;if(!p||p.hp<=0)return;
    p.attackCooldown=Math.max(0,p.attackCooldown-dt);p.skillCooldown=Math.max(0,p.skillCooldown-dt);state.playerSkillCooldown=p.skillCooldown;
    if(p.action==='attack'){
      p.actionT+=dt/p.actionDuration;
      const hitAt=p.attackType===3?.52:.43;
      if(p.actionT>=hitAt&&!p.attackHit)resolvePlayerHit(p,false);
      if(p.actionT>=1){p.action='idle';p.actionT=0;}
      p.x=clamp(p.x,100,1340);return;
    }
    if(p.action==='skill'){
      p.actionT+=dt/p.actionDuration;
      if(p.actionT>.53&&!p.attackHit){
        resolvePlayerHit(p,true);
        addParticle(p.x+p.facing*65,p.y-100,p.fighter.color,'ring',1,2);
      }
      if(p.actionT>=1){p.action='idle';p.actionT=0;}return;
    }
    if(p.action==='hit'||p.action==='ko'){
      p.actionT+=dt/(p.actionDuration||.3);p.x+=p.knockback*dt;p.knockback*=Math.pow(.05,dt);
      if(p.action==='hit'&&p.actionT>=1){p.action='idle';p.actionT=0;}
      return;
    }
    if(p.action==='dash'){
      p.actionT+=dt/(p.actionDuration||.32);p.x+=p.knockback*dt;p.knockback*=Math.pow(.06,dt);
      if(p.actionT>=1){p.action='idle';p.knockback=0;}return;
    }
    if(p.action==='jump'){p.actionT+=dt/(p.actionDuration||.66);if(p.actionT>=1){p.action='idle';p.actionT=0;}return;}
    if(keys.has('l')){p.action='guard';p.actionT+=dt;p.moveVelocity=0;return;}else if(p.action==='guard'){p.action='idle';p.actionT=0;}
    if(keys.has('w')||keys.has('arrowup')){triggerPlayer('jump');return;}
    let move=0;if(keys.has('a')||keys.has('arrowleft'))move-=1;if(keys.has('d')||keys.has('arrowright'))move+=1;
    if(move){p.facing=move>0?1:-1;p.x+=move*230*dt;p.action='run';p.actionT+=dt;}else {p.facing=state.enemy&&state.enemy.x>p.x?1:-1;if(p.action!=='idle'){p.action='idle';p.actionT=0;}}
    if(keys.has('s')||keys.has('arrowdown'))p.y=lerp(p.y,635,Math.min(1,dt*5));else p.y=lerp(p.y,600,Math.min(1,dt*5));
    p.x=clamp(p.x,95,1345);
  }
  function enemyUpdate(dt){
    const e=state.enemy,p=state.player;if(!e||!p||e.hp<=0)return;
    e.attackCooldown=Math.max(0,e.attackCooldown-dt);e.skillCooldown=Math.max(0,e.skillCooldown-dt);
    e.facing=p.x>e.x?1:-1;
    if(e.action==='attack'){
      e.actionT+=dt/e.actionDuration;
      const hitAt=e.attackType===3?.52:.44;if(e.actionT>=hitAt&&!e.attackHit)resolveEnemyHit(e,false);
      if(e.actionT>=1){e.action='idle';e.actionT=0;}return;
    }
    if(e.action==='skill'){
      e.actionT+=dt/e.actionDuration;if(e.actionT>.55&&!e.attackHit){e.attackHit=true;resolveEnemyHit(e,true);addParticle(e.x+e.facing*55,e.y-100,e.fighter.color,'ring',1,2);}
      if(e.actionT>=1){e.action='idle';e.actionT=0;}return;
    }
    if(e.action==='hit'||e.action==='ko'){
      e.actionT+=dt/(e.actionDuration||.3);e.x+=e.knockback*dt;e.knockback*=Math.pow(.05,dt);if(e.action==='hit'&&e.actionT>=1){e.action='idle';e.actionT=0;}return;
    }
    if(e.action==='dash'){e.actionT+=dt/(e.actionDuration||.32);e.x+=e.knockback*dt;e.knockback*=Math.pow(.06,dt);if(e.actionT>=1){e.action='idle';e.knockback=0;}return;}
    const dx=p.x-e.x,d=Math.abs(dx);e.aiThink-=dt;
    if(e.aiThink<=0){e.aiThink=rand(.28,.72);e.aiMode=d>175?'approach':Math.random()<.27?'feint':Math.random()<.42?'guard':'attack';}
    if(d>170){e.action='run';e.x+=Math.sign(dx)*((e.fighter.stats.Speed/100)*145+35)*dt;if(Math.random()<.008&&d<370&&e.skillCooldown<=0&&e.fighter.stats.Power>94){doSkill(e,false);}}
    else if(d<125){
      if(e.aiMode==='guard'&&p.action==='attack'){e.action='guard';e.actionT+=dt;}
      else if(e.aiMode==='feint'){e.action='dash';e.actionT=0;e.actionDuration=.26;e.knockback=-Math.sign(dx)*190;e.aiMode='attack';}
      else if(e.attackCooldown<=0){if(e.skillCooldown<=0&&Math.random()<.14)doSkill(e,false);else doAttack(e,false,Math.random()<.22?3:Math.random()<.45?2:1);}
      else{e.action='idle';}
    }else if(d<260){e.action='walk';e.x+=Math.sign(dx)*70*dt;if(e.attackCooldown<=0&&Math.random()<.015)doAttack(e,false,1);}
    else e.action='idle';
    // Slight lane movement prevents the fighters from reading as flat sliding tokens.
    if(Math.random()<.002)e.y=rand(590,635);
    e.x=clamp(e.x,95,1345);
  }
  function particlesUpdate(dt){
    state.particles=state.particles.filter(p=>p.life>0);
    for(const p of state.particles){p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.kind!=='ring')p.vy+=400*dt;p.vx*=Math.pow(.16,dt);p.vy*=Math.pow(.26,dt);p.rot+=dt*3;}
  }
  function finishBattle(won){
    if(state.ended)return;state.ended=true;
    setTimeout(()=>{
      if(state.screen!=='battle')return;
      $('resultOverlay').classList.remove('hidden');
      $('resultKicker').textContent=won?'ARENA COMPLETE':'MATCH OVER';$('resultTitle').textContent=won?'VICTORY':'DEFEAT';$('resultText').textContent=won?'Your fighter controls the arena. A new challenger awaits.':'The rival took this round. Reset and try a different combat rhythm.';
    },650);
  }
  function updateHud(){
    const p=state.player,e=state.enemy;if(!p||!e)return;
    $('playerHpBar').style.width=`${p.hp/p.maxHp*100}%`;$('enemyHpBar').style.width=`${e.hp/e.maxHp*100}%`;
    $('playerEnergyBar').style.width=`${p.energy}%`;$('enemyEnergyBar').style.width=`${e.energy}%`;
    $('playerHpText').textContent=`${Math.ceil(p.hp)} / ${p.maxHp}`;$('enemyHpText').textContent=`${Math.ceil(e.hp)} / ${e.maxHp}`;
    $('roundClock').textContent=String(Math.ceil(state.roundTime)).padStart(2,'0');
  }
  function frame(now){
    const dt=clamp((now-state.lastFrame)/1000||0,.001,.033);state.lastFrame=now;
    if(state.screen==='battle'&&!state.paused){
      state.time+=dt;state.flash=Math.max(0,state.flash-dt*2.5);
      if(!state.ended){
        state.roundTime=Math.max(0,state.roundTime-dt);
        playerUpdate(dt);enemyUpdate(dt);
        if(state.roundTime<=0&&!state.ended){finishBattle(state.player.hp>=state.enemy.hp);}
        if(now-state.uiTick>95){updateHud();state.uiTick=now;}
      } else {
        // Let the final knock-out pose and impact particles finish before the result card appears.
        [state.player,state.enemy].forEach(a=>{if(a&&a.action==='ko')a.actionT=Math.min(1.4,a.actionT+dt/1.3);});
      }
      particlesUpdate(dt);ArenaRenderer.renderGame(ctx,state);
    }
    requestAnimationFrame(frame);
  }

  // Keyboard controls
  window.addEventListener('keydown',e=>{
    const k=e.key.toLowerCase();if([' ','arrowup','arrowdown','arrowleft','arrowright'].includes(k))e.preventDefault();keys.add(k);
    if(state.screen!=='battle'||state.paused)return;
    if(k==='j')triggerPlayer('attack');if(k==='k')triggerPlayer('skill');if(k===' '||k==='shift')triggerPlayer('dash');if(k==='w'&&e.repeat===false)triggerPlayer('jump');
  });
  window.addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));window.addEventListener('blur',()=>keys.clear());

  // Menu actions
  $('fightButton').addEventListener('click',startBattle);
  $('brandHome').addEventListener('click',()=>{if(state.screen==='battle'){state.paused=true;$('pauseOverlay').classList.remove('hidden');}else toast('Arena Strike — choose your fighter.');});
  $('settingsBtn').addEventListener('click',()=>{state.sounds=!state.sounds;toast(`SOUND ${state.sounds?'ON':'OFF'}`);});
  document.querySelectorAll('.mode-button').forEach(b=>b.addEventListener('click',()=>{state.mode=b.dataset.mode;document.querySelectorAll('.mode-button').forEach(x=>x.classList.toggle('selected',x===b));toast(`${DATA.modes[state.mode].label} selected`);}));
  document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.nav-item').forEach(x=>x.classList.toggle('active',x===b));if(b.dataset.nav==='fight'||b.dataset.nav==='fighters'){toast(b.dataset.nav==='fight'?'Choose your fighter and arena.':'Fighter roster selected.');}else toast(`${b.textContent.trim()} unlocks after the first match.`);}));
  $('backToSelect').addEventListener('click',()=>{state.screen='select';state.paused=false;keys.clear();$('battleScreen').classList.add('hidden');$('selectScreen').classList.remove('hidden');});
  $('pauseButton').addEventListener('click',()=>{state.paused=true;keys.clear();$('pauseOverlay').classList.remove('hidden');});
  $('resumeButton').addEventListener('click',()=>{state.paused=false;$('pauseOverlay').classList.add('hidden');});
  $('quitButton').addEventListener('click',()=>{$('pauseOverlay').classList.add('hidden');$('battleScreen').classList.add('hidden');$('selectScreen').classList.remove('hidden');state.screen='select';state.paused=false;});
  $('rematchButton').addEventListener('click',startBattle);
  $('resultBackButton').addEventListener('click',()=>{$('resultOverlay').classList.add('hidden');$('battleScreen').classList.add('hidden');$('selectScreen').classList.remove('hidden');state.screen='select';state.ended=false;});
  document.querySelectorAll('.ability-button').forEach(b=>{
    b.addEventListener('pointerdown',e=>{e.preventDefault();if(b.dataset.action==='guard')keys.add('l');else triggerPlayer(b.dataset.action);});
    ['pointerup','pointercancel','pointerleave'].forEach(type=>b.addEventListener(type,()=>{if(b.dataset.action==='guard')keys.delete('l');}));
  });
  document.querySelectorAll('.mobile-controls [data-key]').forEach(b=>{
    const key=b.dataset.key;
    const down=e=>{e.preventDefault();keys.add(key);if(key==='j')triggerPlayer('attack');if(key==='k')triggerPlayer('skill');if(key===' ')triggerPlayer('dash');if(key==='w')triggerPlayer('jump');};
    const up=e=>{e.preventDefault();keys.delete(key);};
    b.addEventListener('pointerdown',down);b.addEventListener('pointerup',up);b.addEventListener('pointercancel',up);b.addEventListener('pointerleave',up);
  });
  document.addEventListener('contextmenu',e=>{if(state.screen==='battle')e.preventDefault();});
  window.addEventListener('resize',()=>{if(state.screen==='battle')ArenaRenderer.renderGame(ctx,state);});
  renderSelection();
  requestAnimationFrame(frame);
})();
