'use strict';
(() => {
  const TAU = Math.PI * 2;
  const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
  const lerp = (a,b,t) => a+(b-a)*t;
  const easeOut = t => 1-Math.pow(1-t,3);
  const hexRgb = h => {const n=parseInt(h.replace('#',''),16);return [(n>>16)&255,(n>>8)&255,n&255];};

  function gradient(ctx,x1,y1,x2,y2,stops){const g=ctx.createLinearGradient(x1,y1,x2,y2);stops.forEach(s=>g.addColorStop(s[0],s[1]));return g;}
  function glow(ctx,color,blur){ctx.shadowColor=color;ctx.shadowBlur=blur;}
  function noGlow(ctx){ctx.shadowBlur=0;ctx.shadowColor='transparent';}

  function drawTemple(ctx,w,h,t){
    const sky=gradient(ctx,0,0,0,h,[[0,'#08172a'],[.48,'#173d56'],[1,'#1d2633']]);ctx.fillStyle=sky;ctx.fillRect(0,0,w,h);
    // moon and atmospheric haze
    const mx=w*.76,my=h*.18;glow(ctx,'#b9e7ff',48);ctx.fillStyle='#e1f3f9';ctx.beginPath();ctx.arc(mx,my,47,0,TAU);ctx.fill();noGlow(ctx);
    ctx.fillStyle='rgba(117,181,207,.12)';ctx.beginPath();ctx.ellipse(mx-30,my+33,220,55,-.1,0,TAU);ctx.fill();
    // distant cliffs and waterfall ribbons
    ctx.fillStyle='#122f43';ctx.beginPath();ctx.moveTo(0,h*.43);ctx.lineTo(w*.12,h*.28);ctx.lineTo(w*.23,h*.45);ctx.lineTo(w*.34,h*.31);ctx.lineTo(w*.48,h*.48);ctx.lineTo(w*.61,h*.27);ctx.lineTo(w*.74,h*.43);ctx.lineTo(w*.89,h*.3);ctx.lineTo(w,h*.43);ctx.lineTo(w,h*.71);ctx.lineTo(0,h*.71);ctx.closePath();ctx.fill();
    ctx.fillStyle='rgba(106,185,217,.43)';for(let i=0;i<7;i++){const x=w*(.07+i*.13);ctx.fillRect(x,h*.39+(i%2)*12,8,h*.19);ctx.fillStyle='rgba(210,245,255,.16)';ctx.fillRect(x+2,h*.4,2,h*.2);ctx.fillStyle='rgba(106,185,217,.43)';}
    // pagoda silhouette
    const px=w*.72,py=h*.43;ctx.save();ctx.translate(px,py);ctx.fillStyle='#0a1726';
    for(let floor=0;floor<3;floor++){const y=-floor*42;ctx.fillRect(-52,y-18,104,26);ctx.beginPath();ctx.moveTo(-72,y-18);ctx.lineTo(-49,y-31);ctx.lineTo(0,y-41);ctx.lineTo(49,y-31);ctx.lineTo(72,y-18);ctx.closePath();ctx.fill();ctx.fillRect(-7,y-65,14,24);}
    ctx.fillRect(-9,-151,18,22);ctx.beginPath();ctx.moveTo(-15,-151);ctx.lineTo(0,-173);ctx.lineTo(15,-151);ctx.fill();ctx.fillStyle='#e6a44e';glow(ctx,'#ff9b36',12);ctx.fillRect(-3,-87,6,7);ctx.fillRect(-3,-45,6,7);noGlow(ctx);ctx.restore();
    // trees and torches
    for(let i=0;i<9;i++){const x=(i*173+43)%w,y=h*.54+(i%3)*9;ctx.fillStyle=i%2?'#142d32':'#1b2932';ctx.fillRect(x-5,y-70,10,100);ctx.fillStyle=i%2?'#71384a':'#a84e43';for(let j=0;j<16;j++){const a=j*2.4,r=16+(j%4)*8;ctx.beginPath();ctx.ellipse(x+Math.cos(a)*r,y-77+Math.sin(a)*r*.6,10,5,a,0,TAU);ctx.fill();}}
    // lanterns
    for(let i=0;i<5;i++){const x=w*(.12+i*.2),y=h*.35+((i%2)*22);ctx.fillStyle='#101827';ctx.fillRect(x-8,y,16,29);glow(ctx,'#ffae50',16);ctx.fillStyle='#ffb34e';ctx.fillRect(x-4,y+5,8,18);noGlow(ctx);}
    drawStonePlatform(ctx,w,h,t,['#253b49','#52616a','#14222f']);
  }
  function drawVolcano(ctx,w,h,t){
    ctx.fillStyle=gradient(ctx,0,0,0,h,[[0,'#1d1424'],[.55,'#68272a'],[1,'#181b24']]);ctx.fillRect(0,0,w,h);
    for(let i=0;i<4;i++){const x=w*(.12+i*.27),base=h*.66;ctx.fillStyle=['#30222a','#42242a','#552c2b','#301d2a'][i];ctx.beginPath();ctx.moveTo(x-240,base);ctx.lineTo(x-95,base-180-(i%2)*25);ctx.lineTo(x-20,base-115);ctx.lineTo(x+35,base-245-(i%2)*20);ctx.lineTo(x+180,base);ctx.closePath();ctx.fill();ctx.strokeStyle='#ad4425';ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(x-95,base-180);ctx.lineTo(x-20,base-115);ctx.lineTo(x+35,base-245);ctx.stroke();}
    ctx.fillStyle='#ff7b2e';glow(ctx,'#ff5c23',35);ctx.beginPath();ctx.ellipse(w*.52,h*.65,w*.62,40,0,0,TAU);ctx.fill();noGlow(ctx);ctx.fillStyle='#ffca54';ctx.beginPath();ctx.ellipse(w*.52,h*.65,w*.4,11,0,0,TAU);ctx.fill();
    for(let i=0;i<22;i++){const x=((i*83+Math.sin(t*.8+i)*70)%w+w)%w,y=(h*.2+(i*47+t*25)% (h*.48));ctx.fillStyle=i%2?'#ffbf69':'#ff5c31';ctx.globalAlpha=.45+Math.sin(t*2+i)*.3;ctx.beginPath();ctx.arc(x,y,1.5+(i%3),0,TAU);ctx.fill();}ctx.globalAlpha=1;
    drawStonePlatform(ctx,w,h,t,['#2b2329','#59403b','#241c22']);
  }
  function drawFrozen(ctx,w,h,t){
    ctx.fillStyle=gradient(ctx,0,0,0,h,[[0,'#0e243a'],[.58,'#5e91ae'],[1,'#162a3b']]);ctx.fillRect(0,0,w,h);
    for(let i=0;i<7;i++){let x=i*w/6;ctx.fillStyle=i%2?'#284c66':'#3b6178';ctx.beginPath();ctx.moveTo(x-150,h*.67);ctx.lineTo(x+20,h*(.17+(i%3)*.1));ctx.lineTo(x+115,h*.67);ctx.closePath();ctx.fill();ctx.fillStyle='#d3eff8';ctx.beginPath();ctx.moveTo(x+20,h*(.17+(i%3)*.1));ctx.lineTo(x-5,h*.42);ctx.lineTo(x+38,h*.39);ctx.closePath();ctx.fill();}
    ctx.fillStyle='rgba(191,239,255,.7)';for(let i=0;i<22;i++){let x=(i*89+t*12)%w,y=(i*37+t*9)%(h*.65);ctx.fillRect(x,y,2,4);}
    drawStonePlatform(ctx,w,h,t,['#253b4d','#8cb6c8','#1b3040']);
  }
  function drawCyber(ctx,w,h,t){
    ctx.fillStyle=gradient(ctx,0,0,0,h,[[0,'#080e29'],[.6,'#222c61'],[1,'#0c1327']]);ctx.fillRect(0,0,w,h);
    for(let i=0;i<14;i++){const x=i*w/13+Math.sin(i*3)*12,bh=h*(.19+(i%5)*.09);ctx.fillStyle=i%2?'#151c43':'#242052';ctx.fillRect(x,h*.6-bh,50,bh);ctx.fillStyle=i%3?'#51c9ff':'#ff56cf';glow(ctx,ctx.fillStyle,6);for(let j=0;j<7;j++)ctx.fillRect(x+7+(j%2)*17,h*.6-bh+12+j*13,5,5);noGlow(ctx);}
    ctx.strokeStyle='rgba(64,219,255,.3)';ctx.lineWidth=2;for(let i=0;i<8;i++){ctx.beginPath();ctx.moveTo(w*.5+i*30,h*.63);ctx.lineTo(w*.5+(i-4)*170,h*.87);ctx.stroke();}
    drawStonePlatform(ctx,w,h,t,['#222b4c','#535c8e','#14182c']);
  }
  function drawStonePlatform(ctx,w,h,t,palette){
    const gy=h*.77;ctx.fillStyle=gradient(ctx,0,gy,0,h,[[0,palette[0]],[.45,palette[1]],[1,palette[2]]]);ctx.fillRect(0,gy,w,h-gy);
    ctx.fillStyle='rgba(2,7,13,.42)';ctx.beginPath();ctx.moveTo(0,gy+16);ctx.lineTo(w*.5,gy-8);ctx.lineTo(w,gy+16);ctx.lineTo(w,h);ctx.lineTo(0,h);ctx.closePath();ctx.fill();
    ctx.strokeStyle='rgba(200,219,226,.19)';ctx.lineWidth=2;for(let i=0;i<12;i++){const x=i*w/11;ctx.beginPath();ctx.moveTo(x,gy);ctx.lineTo(w/2+(x-w/2)*1.5,h);ctx.stroke();}for(let i=0;i<5;i++){const y=gy+Math.pow(i/4,1.7)*(h-gy);ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
    ctx.strokeStyle='rgba(240,205,142,.11)';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(w*.5,gy+65,w*.2,24,0,0,TAU);ctx.stroke();
    for(let i=0;i<16;i++){const x=(i*113+30)%w,y=gy+20+(i*29)%Math.max(40,h-gy-24);ctx.fillStyle='rgba(240,195,135,.2)';ctx.fillRect(x,y,18+(i%4)*7,1.3);}
  }
  function drawBackground(ctx, arena, t, w, h){
    if(arena.id==='volcano')drawVolcano(ctx,w,h,t);else if(arena.id==='frozen')drawFrozen(ctx,w,h,t);else if(arena.id==='cyber')drawCyber(ctx,w,h,t);else drawTemple(ctx,w,h,t);
    // atmospheric foreground silhouettes
    const fog=ctx.createLinearGradient(0,h*.52,0,h*.84);fog.addColorStop(0,'rgba(210,226,232,0)');fog.addColorStop(.65,'rgba(176,205,218,.08)');fog.addColorStop(1,'rgba(3,7,15,.1)');ctx.fillStyle=fog;ctx.fillRect(0,h*.52,w,h*.33);
  }

  function capsule(ctx,x1,y1,x2,y2,r,color,edge){ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle=edge||'rgba(0,0,0,.35)';ctx.lineWidth=r*2+5;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();ctx.strokeStyle=color;ctx.lineWidth=r*2;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();ctx.fillStyle=color;ctx.beginPath();ctx.arc(x2,y2,r,0,TAU);ctx.fill();}
  function drawWeapon(ctx,actor,pose,colors){
    const weapon=actor.fighter.weapon;let hand=pose.handF;ctx.save();ctx.translate(hand[0],hand[1]);ctx.rotate(pose.weaponAngle||-.3);let col=colors.glow;glow(ctx,col,13);ctx.lineCap='round';ctx.lineJoin='round';
    if(weapon==='bow'){
      ctx.strokeStyle=colors.accent;ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(0,-28);ctx.quadraticCurveTo(30,0,0,28);ctx.stroke();ctx.strokeStyle='#f2e7ce';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,-28);ctx.lineTo(0,28);ctx.stroke();
    }else if(weapon==='hammer'){
      ctx.strokeStyle='#604d42';ctx.lineWidth=10;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(0,-62);ctx.stroke();ctx.fillStyle=colors.accent;ctx.strokeStyle='#ead0a0';ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(-18,-77,36,24,6);ctx.fill();ctx.stroke();
    }else if(weapon==='twin'){
      ctx.strokeStyle=colors.accent;ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-5,0);ctx.lineTo(8,-50);ctx.moveTo(12,5);ctx.lineTo(27,-42);ctx.stroke();
    }else if(weapon==='spear'){
      ctx.strokeStyle='#e5eaf1';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(0,17);ctx.lineTo(3,-82);ctx.stroke();ctx.fillStyle=colors.glow;ctx.beginPath();ctx.moveTo(3,-97);ctx.lineTo(-8,-78);ctx.lineTo(14,-78);ctx.closePath();ctx.fill();
    }else{
      ctx.strokeStyle=colors.accent;ctx.lineWidth=8;ctx.beginPath();ctx.moveTo(0,5);ctx.lineTo(2,-37);ctx.stroke();ctx.fillStyle=gradient(ctx,-7,-50,10,-5,[[0,'#ffffff'],[.25,colors.glow],[1,colors.accent]]);ctx.beginPath();ctx.moveTo(-5,-32);ctx.quadraticCurveTo(0,-57,6,-92);ctx.quadraticCurveTo(17,-53,11,-27);ctx.closePath();ctx.fill();ctx.strokeStyle='#fff3cb';ctx.lineWidth=1.5;ctx.stroke();
    }
    noGlow(ctx);ctx.restore();
  }
  function getPose(actor,t){
    const a=actor.action||'idle',u=clamp(actor.actionT||0,0,1),s=Math.sin(t*7+actor.phase),fast=Math.sin(t*16+actor.phase);
    let p={bob:Math.sin(t*4+actor.phase)*2,lean:0,headTilt:0,armB:[-25,-82],elbowB:[-22,-97],handB:[-8,-107],armF:[26,-84],elbowF:[42,-89],handF:[53,-73],legBack:[-17,-30],footBack:[-26,-2],legFront:[14,-26],footFront:[29,-1],weaponAngle:-.3,slash:0};
    if(a==='walk'||a==='run'){
      const v=a==='run'?1.7:1;p.bob=Math.abs(Math.sin(t*12))*5*v;p.lean= a==='run'?.18:.08;
      p.legBack=[-15+Math.sin(t*12)*19,-33+Math.max(0,Math.cos(t*12))*10];p.footBack=[-22+Math.sin(t*12)*25,-2+Math.max(0,Math.cos(t*12))*10];
      p.legFront=[13-Math.sin(t*12)*19,-30+Math.max(0,-Math.cos(t*12))*10];p.footFront=[28-Math.sin(t*12)*24,-2+Math.max(0,-Math.cos(t*12))*10];
      p.armB=[-24,-82];p.elbowB=[-36+Math.sin(t*12)*15,-91];p.handB=[-31+Math.sin(t*12)*21,-77];p.armF=[24,-84];p.elbowF=[36-Math.sin(t*12)*14,-94];p.handF=[34-Math.sin(t*12)*21,-78];
    }
    if(a==='jump'){p.bob=-20-Math.sin(u*Math.PI)*10;p.legBack=[-12,-31];p.footBack=[-27,-48];p.legFront=[13,-30];p.footFront=[35,-46];p.armB=[-24,-88];p.elbowB=[-42,-121];p.handB=[-38,-139];p.armF=[24,-88];p.elbowF=[46,-119];p.handF=[53,-137];p.lean=-.1;}
    if(a==='dash'){p.lean=.45;p.bob=-8;p.armB=[-26,-89];p.elbowB=[-42,-74];p.handB=[-55,-76];p.armF=[24,-97];p.elbowF=[50,-95];p.handF=[67,-95];p.legBack=[-10,-30];p.footBack=[-48,-14];p.legFront=[18,-25];p.footFront=[-3,-5];p.slash=.3;}
    if(a==='guard'){p.lean=.12;p.bob=0;p.armB=[-23,-90];p.elbowB=[-12,-73];p.handB=[5,-75];p.armF=[24,-91];p.elbowF=[42,-77];p.handF=[53,-88];p.legBack=[-15,-29];p.footBack=[-19,-2];p.legFront=[13,-31];p.footFront=[24,-2];}
    if(a==='attack'){
      const strike=actor.attackType||1;
      let wind=clamp(u/.34,0,1),hit=clamp((u-.3)/.28,0,1),recover=clamp((u-.58)/.42,0,1);
      p.lean=lerp(-.19,.30,hit)*(1-recover*.6);p.bob=-Math.sin(u*Math.PI)*6;
      if(strike===1){p.armF=[25,-100];p.elbowF=[44,-109];p.handF=[50,-111];p.weaponAngle=lerp(-1.15,.2,easeOut(hit));p.armB=[-23,-89];p.elbowB=[-35,-82];p.handB=[-43,-67];p.slash=Math.sin(hit*Math.PI)*.95;}
      if(strike===2){p.armF=[25,-105];p.elbowF=[53,-94];p.handF=[67,-76];p.weaponAngle=lerp(-1.55,.38,easeOut(hit));p.armB=[-25,-97];p.elbowB=[-46,-104];p.handB=[-55,-119];p.slash=Math.sin(hit*Math.PI)*1.2;p.headTilt=.2;}
      if(strike>=3){p.armF=[20,-106];p.elbowF=[49,-124];p.handF=[67,-133];p.weaponAngle=lerp(-2.2,.95,easeOut(hit));p.armB=[-22,-104];p.elbowB=[-46,-122];p.handB=[-53,-137];p.slash=Math.sin(hit*Math.PI)*1.45;p.lean=.36;}
      p.legBack=[-14,-29];p.footBack=[-24,-1];p.legFront=[15,-27];p.footFront=[35,-4];
      if(u<.26){p.lean=-.26;p.weaponAngle=-1.8;p.handF=[28,-126];p.elbowF=[43,-113];p.handB=[-36,-116];}
    }
    if(a==='skill'){
      p.lean=.12;p.bob=-Math.sin(u*Math.PI)*23;p.armB=[-24,-110];p.elbowB=[-48,-134];p.handB=[-57,-148];p.armF=[25,-109];p.elbowF=[52,-138];p.handF=[67,-154];p.weaponAngle=-1.3+u*3.1;p.legBack=[-15,-28];p.footBack=[-31,-2];p.legFront=[14,-27];p.footFront=[31,-2];p.slash=Math.sin(u*Math.PI)*1.7;
    }
    if(a==='hit'){p.lean=-.35;p.bob=0;p.headTilt=-.3;p.armB=[-28,-85];p.elbowB=[-45,-66];p.handB=[-53,-52];p.armF=[27,-84];p.elbowF=[44,-67];p.handF=[52,-55];p.legBack=[-10,-31];p.footBack=[-20,-2];p.legFront=[10,-30];p.footFront=[27,-2];}
    if(a==='ko'){p.lean=-1.15;p.bob=28;p.armB=[-30,-71];p.elbowB=[-48,-47];p.handB=[-66,-36];p.armF=[28,-70];p.elbowF=[46,-45];p.handF=[61,-31];p.legBack=[-18,-24];p.footBack=[-28,-7];p.legFront=[15,-14];p.footFront=[38,-6];}
    return p;
  }
  function drawSlash(ctx,actor,pose,colors){
    if(pose.slash<.12)return;
    ctx.save();ctx.translate(actor.x,actor.y-110+pose.bob);ctx.scale(actor.facing||1,1);ctx.rotate(-.2);const a=pose.slash;
    ctx.lineCap='round';glow(ctx,colors.glow,24*a);ctx.strokeStyle=colors.glow;ctx.lineWidth=4+13*a;ctx.beginPath();ctx.arc(14,5,72,-1.15,.86);ctx.stroke();ctx.strokeStyle='#fff8d7';ctx.lineWidth=2+4*a;ctx.beginPath();ctx.arc(14,5,69,-1.08,.72);ctx.stroke();noGlow(ctx);
    for(let i=0;i<10;i++){const ang=-1.2+i*.23;const r=77+Math.sin(i*8+actor.actionT*32)*9;ctx.fillStyle=i%2?'#fff0b1':colors.glow;glow(ctx,colors.glow,9);ctx.beginPath();ctx.arc(Math.cos(ang)*r,Math.sin(ang)*r,1.5+(i%3),0,TAU);ctx.fill();}noGlow(ctx);ctx.restore();
  }
  function drawFighter(ctx,actor,t){
    if(!actor||actor.hp<=0&&actor.action!=='ko')return;
    const f=actor.fighter,p=getPose(actor,t),depth=actor.depth||1,scale=(actor.baseScale||1)*depth;
    const c={skin:f.skin,hair:f.hair,armor:f.armor,accent:f.accent,glow:f.color,dark:f.dark};
    // shadow
    ctx.save();ctx.globalAlpha=.42;ctx.fillStyle='#01040a';ctx.beginPath();ctx.ellipse(actor.x,actor.y+3,44*scale,10*scale,0,0,TAU);ctx.fill();ctx.restore();
    drawSlash(ctx,actor,p,c);
    ctx.save();ctx.translate(actor.x,actor.y+p.bob);ctx.scale((actor.facing||1)*scale,scale);ctx.rotate(p.lean*.13);
    // back leg and boot
    capsule(ctx,-9,-53,p.legBack[0],p.legBack[1],8,c.armor,'#080b11');capsule(ctx,p.legBack[0],p.legBack[1],p.footBack[0],p.footBack[1],6,c.dark,'#080b11');
    ctx.fillStyle=c.accent;ctx.beginPath();ctx.moveTo(p.footBack[0]-9,p.footBack[1]-5);ctx.lineTo(p.footBack[0]+10,p.footBack[1]-5);ctx.lineTo(p.footBack[0]+16,p.footBack[1]+1);ctx.lineTo(p.footBack[0]-11,p.footBack[1]+2);ctx.closePath();ctx.fill();
    // rear arm and cape
    capsule(ctx,-16,-105,p.elbowB[0],p.elbowB[1],8,c.armor,'#090d14');capsule(ctx,p.elbowB[0],p.elbowB[1],p.handB[0],p.handB[1],6,c.skin,'#090d14');
    if(f.id==='thunder'||f.id==='inferno'||f.id==='aether'){
      ctx.fillStyle=f.id==='inferno'?'#8e2b1c':f.id==='aether'?'#f1c35b':'#173e70';ctx.beginPath();ctx.moveTo(-12,-101);ctx.quadraticCurveTo(-40,-76,-36,-23);ctx.lineTo(-22,-6);ctx.quadraticCurveTo(-25,-64,5,-81);ctx.closePath();ctx.fill();
    }
    // torso silhouette
    ctx.fillStyle=c.dark;ctx.beginPath();ctx.moveTo(-17,-110);ctx.lineTo(13,-113);ctx.lineTo(22,-83);ctx.lineTo(14,-53);ctx.lineTo(-14,-52);ctx.lineTo(-23,-80);ctx.closePath();ctx.fill();
    ctx.fillStyle=gradient(ctx,-20,-112,20,-50,[[0,c.accent],[.12,c.armor],[.72,c.dark],[1,'#111927']]);ctx.beginPath();ctx.moveTo(-17,-110);ctx.lineTo(14,-110);ctx.lineTo(20,-84);ctx.lineTo(12,-56);ctx.lineTo(-13,-55);ctx.lineTo(-22,-83);ctx.closePath();ctx.fill();
    ctx.strokeStyle='rgba(255,255,255,.25)';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-12,-104);ctx.lineTo(-3,-65);ctx.lineTo(9,-102);ctx.stroke();
    // chest plate/emblem
    ctx.fillStyle=c.accent;ctx.globalAlpha=.85;ctx.beginPath();ctx.moveTo(-11,-102);ctx.lineTo(11,-102);ctx.lineTo(8,-83);ctx.lineTo(0,-75);ctx.lineTo(-8,-84);ctx.closePath();ctx.fill();ctx.globalAlpha=1;
    ctx.fillStyle=c.glow;glow(ctx,c.glow,8);ctx.beginPath();ctx.arc(0,-91,4,0,TAU);ctx.fill();noGlow(ctx);
    // belt
    ctx.fillStyle='#171923';ctx.fillRect(-17,-62,34,7);ctx.fillStyle=c.accent;ctx.fillRect(-3,-64,7,10);
    // front leg and armor knee
    capsule(ctx,9,-54,p.legFront[0],p.legFront[1],9,c.armor,'#080b11');ctx.fillStyle=c.accent;ctx.beginPath();ctx.arc(p.legFront[0],p.legFront[1],5,0,TAU);ctx.fill();capsule(ctx,p.legFront[0],p.legFront[1],p.footFront[0],p.footFront[1],6,c.dark,'#080b11');ctx.fillStyle=c.accent;ctx.beginPath();ctx.moveTo(p.footFront[0]-7,p.footFront[1]-4);ctx.lineTo(p.footFront[0]+10,p.footFront[1]-4);ctx.lineTo(p.footFront[0]+15,p.footFront[1]+1);ctx.lineTo(p.footFront[0]-12,p.footFront[1]+2);ctx.closePath();ctx.fill();
    // head and neck
    ctx.fillStyle=c.skin;ctx.fillRect(-5,-122,10,15);ctx.beginPath();ctx.ellipse(1,-139,13,17,p.headTilt,0,TAU);ctx.fill();
    // hair / headgear
    ctx.fillStyle=c.hair;ctx.beginPath();ctx.moveTo(-13,-143);ctx.quadraticCurveTo(-15,-164,3,-163);ctx.quadraticCurveTo(18,-160,14,-140);ctx.lineTo(8,-147);ctx.lineTo(3,-151);ctx.lineTo(-4,-145);ctx.closePath();ctx.fill();
    if(f.id==='thunder'){ctx.beginPath();ctx.moveTo(-10,-152);ctx.quadraticCurveTo(-22,-171,-10,-184);ctx.quadraticCurveTo(0,-169,4,-158);ctx.quadraticCurveTo(20,-170,25,-181);ctx.quadraticCurveTo(28,-156,12,-145);ctx.fill();}
    if(f.id==='frost'){ctx.fillStyle='#c9efff';ctx.beginPath();ctx.moveTo(-10,-155);ctx.lineTo(-16,-177);ctx.lineTo(-2,-164);ctx.lineTo(7,-185);ctx.lineTo(10,-161);ctx.lineTo(21,-176);ctx.lineTo(14,-151);ctx.closePath();ctx.fill();}
    if(f.id==='phantom'){ctx.fillStyle='#171326';ctx.beginPath();ctx.moveTo(-17,-141);ctx.lineTo(-14,-171);ctx.lineTo(18,-171);ctx.lineTo(18,-140);ctx.lineTo(8,-150);ctx.lineTo(-7,-150);ctx.closePath();ctx.fill();}
    if(f.id==='titan'){ctx.fillStyle='#32241d';ctx.beginPath();ctx.ellipse(0,-147,13,8,0,Math.PI,TAU);ctx.fill();ctx.fillStyle='#6c4936';ctx.fillRect(-5,-131,12,7);}
    if(f.id==='reaper'){ctx.fillStyle='#222a39';ctx.fillRect(-15,-150,30,15);ctx.fillStyle='#ff4d5f';glow(ctx,'#ff2e58',9);ctx.fillRect(3,-143,8,3);noGlow(ctx);}
    // eye and facial detail
    ctx.fillStyle='#1b1d25';ctx.fillRect(4,-140,4,2);ctx.fillStyle=c.glow;ctx.fillRect(5,-140,3,1);ctx.strokeStyle='rgba(53,29,25,.6)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(0,-129);ctx.lineTo(5,-128);ctx.stroke();
    // front shoulder and arm
    ctx.fillStyle=c.accent;ctx.beginPath();ctx.ellipse(17,-105,12,10,-.3,0,TAU);ctx.fill();capsule(ctx,17,-105,p.elbowF[0],p.elbowF[1],9,c.armor,'#090d14');capsule(ctx,p.elbowF[0],p.elbowF[1],p.handF[0],p.handF[1],6,c.skin,'#090d14');ctx.fillStyle=c.accent;ctx.beginPath();ctx.arc(p.handF[0],p.handF[1],7,0,TAU);ctx.fill();
    // shoulder rune/element glow
    glow(ctx,c.glow,8);ctx.strokeStyle=c.glow;ctx.lineWidth=2;ctx.beginPath();ctx.arc(17,-105,9,-1.2,1.7);ctx.stroke();noGlow(ctx);
    drawWeapon(ctx,actor,p,c);
    // extra fighter-specific decoration
    if(f.id==='venom'){ctx.strokeStyle='#81d975';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-14,-101);ctx.quadraticCurveTo(-35,-88,-28,-65);ctx.stroke();ctx.fillStyle='#8de17a';ctx.beginPath();ctx.ellipse(-27,-83,8,3,-.7,0,TAU);ctx.fill();}
    if(f.id==='aether'){glow(ctx,'#ffd66e',15);ctx.strokeStyle='#ffdf83';ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,-140,22,Math.PI*1.05,Math.PI*1.95);ctx.stroke();noGlow(ctx);}
    if(f.id==='inferno'){glow(ctx,'#ff682e',7);ctx.strokeStyle='#ff7b36';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-8,-97);ctx.lineTo(2,-84);ctx.lineTo(-3,-73);ctx.stroke();noGlow(ctx);}
    ctx.restore();
    // character tag and health bar
    ctx.save();ctx.textAlign='center';ctx.font='bold 15px Barlow Condensed, sans-serif';ctx.fillStyle='#fff';ctx.shadowColor='#000';ctx.shadowBlur=5;ctx.fillText(f.name,actor.x,actor.y-190*scale);ctx.shadowBlur=0;
    const bw=82*scale,bx=actor.x-bw/2,by=actor.y-179*scale;ctx.fillStyle='#111924';ctx.fillRect(bx,by,bw,6*scale);ctx.fillStyle=actor.team==='player'?'#5acbff':'#ff6354';ctx.fillRect(bx,by,bw*clamp(actor.hp/actor.maxHp,0,1),6*scale);ctx.strokeStyle='rgba(255,255,255,.55)';ctx.lineWidth=1;ctx.strokeRect(bx,by,bw,6*scale);ctx.restore();
  }

  function drawParticles(ctx,particles){
    for(const p of particles){const alpha=clamp(p.life/p.maxLife,0,1);ctx.save();ctx.globalAlpha=alpha;ctx.translate(p.x,p.y);ctx.rotate(p.rot||0);ctx.fillStyle=p.color;glow(ctx,p.color,p.glow||4);if(p.kind==='ring'){ctx.strokeStyle=p.color;ctx.lineWidth=3*alpha;ctx.beginPath();ctx.ellipse(0,0,p.r*(1-alpha*.3),p.r*.28,0,0,TAU);ctx.stroke();}else if(p.kind==='line'){ctx.strokeStyle=p.color;ctx.lineWidth=p.size||2;ctx.beginPath();ctx.moveTo(-p.r,0);ctx.lineTo(p.r,0);ctx.stroke();}else{ctx.beginPath();ctx.arc(0,0,Math.max(.5,p.size*alpha),0,TAU);ctx.fill();}noGlow(ctx);ctx.restore();}
  }

  function renderGame(ctx,state){
    const w=ctx.canvas.width,h=ctx.canvas.height,t=state.time||0;ctx.clearRect(0,0,w,h);
    // Fall back safely if the page is loaded from an older saved state.
    const arena=state.arena||state.selectedArena||{id:'temple'};
    drawBackground(ctx,arena,t,w,h);
    // side-view depth lane and subtle speed streaks
    if(state.player&&state.enemy){const fighters=[state.player,state.enemy].sort((a,b)=>a.y-b.y);fighters.forEach(actor=>drawFighter(ctx,actor,t));}
    drawParticles(ctx,state.particles||[]);
    if(state.flash>0){ctx.fillStyle=`rgba(255,245,220,${Math.min(.26,state.flash*.18)})`;ctx.fillRect(0,0,w,h);}
  }

  window.ArenaRenderer={renderGame,drawBackground};
})();
