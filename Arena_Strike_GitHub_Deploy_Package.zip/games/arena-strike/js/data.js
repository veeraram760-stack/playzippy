'use strict';
window.ARENA_DATA = {
  fighters: [
    {id:'thunder',name:'THUNDER',title:'Storm Warrior',role:'STORM WARRIOR · LIGHTNING',element:'⚡ Lightning',style:'Speed / Combo',icon:'⚡',color:'#59c8ff',dark:'#153c75',skin:'#c78a61',hair:'#e2e5e8',armor:'#1f4e82',accent:'#e1b65b',weapon:'sword',stats:{Power:90,Speed:95,Defense:78,Combo:96,Difficulty:70},skills:['Lightning Dash','Storm Combo','Volt Slam','Storm Wrath'],blurb:'An agile storm duelist who turns momentum into devastating chains.'},
    {id:'inferno',name:'INFERNO',title:'Cinder Berserker',role:'CINDER BERSERKER · FIRE',element:'🔥 Fire',style:'Power / Rushdown',icon:'🔥',color:'#ff783a',dark:'#6c2419',skin:'#b97951',hair:'#211719',armor:'#62271f',accent:'#f4a149',weapon:'greatsword',stats:{Power:98,Speed:76,Defense:84,Combo:78,Difficulty:66},skills:['Ember Rush','Molten Break','Flame Wheel','Magma Roar'],blurb:'A relentless powerhouse whose every blow leaves the arena burning.'},
    {id:'frost',name:'FROST',title:'Glacier Oracle',role:'GLACIER ORACLE · ICE',element:'❄ Ice',style:'Control / Counter',icon:'❄',color:'#83dfff',dark:'#2b6799',skin:'#f0d3c5',hair:'#d9f2ff',armor:'#9bc8e4',accent:'#e6f9ff',weapon:'spear',stats:{Power:82,Speed:88,Defense:90,Combo:86,Difficulty:78},skills:['Frost Needle','Crystal Guard','Ice Bloom','Winter Crown'],blurb:'A precise counter fighter who freezes opponents in their tracks.'},
    {id:'phantom',name:'PHANTOM',title:'Void Assassin',role:'VOID ASSASSIN · SHADOW',element:'◉ Shadow',style:'Speed / Evasion',icon:'◉',color:'#bf8bff',dark:'#3e2869',skin:'#b88a75',hair:'#171321',armor:'#302642',accent:'#b46bfa',weapon:'twin',stats:{Power:84,Speed:100,Defense:66,Combo:98,Difficulty:92},skills:['Shadow Step','Nightfall','Echo Strike','Void Requiem'],blurb:'A shadow duelist who disappears between strikes and punishes openings.'},
    {id:'venom',name:'VENOM',title:'Verdant Huntress',role:'VERDANT HUNTRESS · NATURE',element:'🌿 Nature',style:'Traps / Range',icon:'✿',color:'#75d78a',dark:'#245a3e',skin:'#bd8665',hair:'#253b2c',armor:'#31563c',accent:'#98d96f',weapon:'bow',stats:{Power:80,Speed:91,Defense:76,Combo:87,Difficulty:84},skills:['Thorn Volley','Vine Snare','Wild Spiral','Bloom Trap'],blurb:'A mobile ranger who controls space with roots, feints and precision.'},
    {id:'titan',name:'TITAN',title:'Mountain Warden',role:'MOUNTAIN WARDEN · EARTH',element:'⛰ Earth',style:'Tank / Heavy',icon:'⛰',color:'#d9b17b',dark:'#59452d',skin:'#9e6b4a',hair:'#271d18',armor:'#75614b',accent:'#e1c08c',weapon:'hammer',stats:{Power:100,Speed:55,Defense:100,Combo:63,Difficulty:58},skills:['Quake Fist','Stone Wall','Fault Line','World Breaker'],blurb:'An immovable guardian who absorbs pressure and answers with force.'},
    {id:'aether',name:'AETHER',title:'Dawn Paladin',role:'DAWN PALADIN · SOLAR',element:'☼ Solar',style:'Balanced / Burst',icon:'☼',color:'#ffd77a',dark:'#8d6632',skin:'#efc3a1',hair:'#f3e2bd',armor:'#d4a847',accent:'#fff0b5',weapon:'sword',stats:{Power:90,Speed:85,Defense:88,Combo:84,Difficulty:72},skills:['Radiant Arc','Sunstep','Halo Guard','Celestial Fall'],blurb:'A balanced champion whose radiant burst can turn any duel.'},
    {id:'reaper',name:'REAPER',title:'Neon Executioner',role:'NEON EXECUTIONER · TECH',element:'⌾ Tech',style:'Precision / Mix-up',icon:'⌾',color:'#ff6c74',dark:'#552d3b',skin:'#b9816b',hair:'#201d27',armor:'#3b3e53',accent:'#fd626b',weapon:'blade',stats:{Power:86,Speed:93,Defense:79,Combo:91,Difficulty:88},skills:['Target Lock','Pulse Cut','Overdrive','Redline'],blurb:'A machine-enhanced striker built around timing, pressure and mix-ups.'}
  ],
  arenas: [
    {id:'temple',name:'TEMPLE OF STORMS',short:'Temple of Storms',tag:'Moonlit pagoda · Lightning',palette:['#122d46','#315c78','#f0a94b'],description:'A moonlit sanctuary above the waterfalls.'},
    {id:'volcano',name:'VOLCANO ARENA',short:'Volcano Arena',tag:'Lava fortress · Fire',palette:['#311820','#9a3a1d','#ffb13e'],description:'A fractured ring above a river of molten rock.'},
    {id:'frozen',name:'FROZEN PEAKS',short:'Frozen Peaks',tag:'Glacier pass · Ice',palette:['#19354b','#7eb8d5','#d8f4ff'],description:'An ancient bridge suspended between frozen cliffs.'},
    {id:'cyber',name:'CYBER ARENA',short:'Cyber Arena',tag:'Neon district · Tech',palette:['#101936','#344a91','#f45bd3'],description:'A rain-slick rooftop in the neon city.'}
  ],
  modes: {
    story:{label:'STORY MODE',tip:'Defeat the rival and claim the Temple of Storms.'},
    arcade:{label:'ARCADE',tip:'Survive the duel. Your next rival will be tougher.'},
    tournament:{label:'TOURNAMENT',tip:'A focused one-round tournament qualifier.'},
    versus:{label:'VERSUS',tip:'Challenge a CPU rival in a local-style duel.'}
  }
};
