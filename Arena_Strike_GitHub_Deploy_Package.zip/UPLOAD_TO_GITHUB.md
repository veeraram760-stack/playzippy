# Add Arena Strike to PlayZippy

Target repository: https://github.com/veeraram760-stack/playzippy
Target branch: `main`

## Option A — Upload the extracted game files directly

1. Extract this package on your computer.
2. Open your local clone of `playzippy` (or clone the repository first).
3. Copy the `games` folder into the repository root. Keep the path `games/arena-strike/` intact.
4. Commit and push the new `games/arena-strike` folder.
5. The game entry point will be `games/arena-strike/index.html`.

The game is static and does not need `npm install` or a build step. JavaScript files use relative paths, so it can be served from the nested folder.

## Option B — Let GitHub Actions extract the ZIP already uploaded to the repository

1. Extract this package locally.
2. Copy `.github/workflows/extract-arena-strike.yml` into the same path in the repository.
3. Commit and push that workflow file to `main`.
4. The workflow runs on the workflow-file push and extracts the already-uploaded `Arena_Strike_Browser_Game_v1_1.zip` into `games/arena-strike/`, then commits those files.
5. If it does not run automatically, open **Actions → Extract Arena Strike browser game → Run workflow**.

For Option B, ensure GitHub Actions is enabled and the repository allows GitHub Actions to create and approve pull requests / write repository contents. The workflow explicitly requests `contents: write`.

## Play path

Once the repository is served by GitHub Pages or your website host, the game path is:

`/games/arena-strike/`

The repository currently has no root `index.html` visible in its root listing, so adding this folder alone does not automatically add a PlayZippy homepage button. Link to this path from the site's game catalogue when that frontend is present.
