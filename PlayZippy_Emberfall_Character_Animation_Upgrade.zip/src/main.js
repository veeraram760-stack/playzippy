const W = 1280, H = 720;
const $ = (id) => document.getElementById(id);
const canvas = $('game');
const ctx = canvas.getContext('2d', { alpha: false });
const frame = $('canvasFrame');
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const lerp = (a,b,t) => a + (b-a)*t;
const rand = (a,b) => a + Math.random()*(b-a);
const choice = (arr) => arr[Math.floor(Math.random()*arr.length)];
const easeOut = t => 1 - Math.pow(1-t, 3);
const angleDelta = (a,b) => Math.atan2(Math.sin(b-a),Math.cos(b-a));
const angleLerp = (a,b,t) => a + angleDelta(a,b)*t;

const realms = [
  { name:'THE VERDANT HOLLOW', roomNames:['MOSS GATE','ROOTBOUND CHAPEL','THE ROOTBOUND WARDEN'], tag:'REALM I · THE ROOTS', title:'The Verdant Hollow', desc:'A forest swallowed by a living blight. Even the old stones have begun to breathe.', palette:{sky:'#243a31',floor:'#304536',floor2:'#40563d',line:'#68734b',accent:'#a9ba77',glow:'#c6d77e',portal:'#9fc58f',mist:'#91a98a'}, objective:'Break the root seals' },
  { name:'THE ASHEN FOUNDRY', roomNames:['CINDER WALK','THE BROKEN FURNACE','THE ASHEN COLOSSUS'], tag:'REALM II · THE EMBERS', title:'The Ashen Foundry', desc:'A kingdom of black iron and sleeping furnaces, where every breath tastes of old fire.', palette:{sky:'#402a27',floor:'#49362e',floor2:'#5e4435',line:'#89634b',accent:'#df9860',glow:'#f5a46b',portal:'#ed9b69',mist:'#bd806a'}, objective:'Quench the furnace heart' },
  { name:'THE MOONWELL KEEP', roomNames:['SILVER APPROACH','THE FLOODED ARCHIVE','THE HOLLOW CROWN'], tag:'REALM III · THE VEIL', title:'The Moonwell Keep', desc:'A drowned palace caught between moonlight and shadow. The Crown waits below.', palette:{sky:'#2b2f4b',floor:'#3d425f',floor2:'#505677',line:'#8588a8',accent:'#b6b9e2',glow:'#d9ddff',portal:'#b8c7e9',mist:'#98a2ce'}, objective:'Shatter the Hollow Crown' }
];

const images = {};
for (const name of ['hero','thornling','archer','brute','boss','wisp']) {
  const img = new Image(); img.src = name === 'wisp' ? `/art/${name}.svg` : `/art/${name}.webp`; images[name] = img;
}
const realmBackgrounds = ['verdant','ashen','moonwell'].map(name => {
  const img = new Image();
  img.src = `/art/bg-${name}.webp`;
  img.onload = () => { if (typeof game !== 'undefined' && game) buildBackground(); };
  return img;
});

const saveKey = 'playzippy_emberfall_save_v1';
let stored = {};
try { stored = JSON.parse(localStorage.getItem(saveKey) || '{}'); } catch { stored = {}; }
const meta = { bestTime: stored.bestTime || 0, bestKills: stored.bestKills || 0, current: stored.current || null, sound: stored.sound !== false };
let muted = !meta.sound;

const player = {
  x:640,y:520,vx:0,vy:0,r:17,hp:100,maxHp:100,speed:235,damage:23,attackCd:0,attackTime:0,attackDuration:.42,attackAngle:-Math.PI/2,attackApplied:false,attackLunge:0,combo:0,comboTimer:0,
  dashCd:0,dashTime:0,dashVX:0,dashVY:0,jumpCd:0,jumpActive:false,jumpZ:0,jumpVy:0,jumpVX:0,jumpVY:0,landTime:0,animTime:0,facingAngle:0,invuln:0,hurtTime:0,hurtAngle:0,specialCd:0,specialTime:0,level:1,xp:0,xpNeed:100,gold:0,kills:0,damageBonus:0,solarBonus:0,dodgeBonus:0,critBonus:0,regen:0,runTime:0,stepTimer:0,stepSide:0
};
const game = {
  phase:'menu',stage:0,room:0,enemies:[],projectiles:[],particles:[],pickups:[],floaters:[],combatFX:[],afterimages:[],decor:[],portal:null,boss:null,roomCleared:false,roomTime:0,roomKills:0,shake:0,hitStop:0,impactFlash:0,toastTimer:0,toastText:'',rewardOptions:[],pendingTransition:null,sessionStart:0,continued:false,previousFrame:0
};
const input = { keys:new Set(), pointer:{x:640,y:360,down:false,inside:false}, joy:{x:0,y:0,active:false}, attackHeld:false };
const background = document.createElement('canvas'); background.width=W; background.height=H;
const bg = background.getContext('2d');

const relicPool = [
  {id:'sunsteel',name:'Sunsteel Edge',icon:'✦',rarity:'WEAPON · RARE',desc:'Your blade bites deeper. +22% attack damage.',apply:()=>{player.damageBonus+=.22;}},
  {id:'hearth',name:'Hearthstone Core',icon:'♥',rarity:'VITALITY · RARE',desc:'A warm pulse returns. +24 maximum health and heal 24.',apply:()=>{player.maxHp+=24;player.hp=Math.min(player.maxHp,player.hp+24);}},
  {id:'swift',name:'Swift Ember',icon:'➶',rarity:'MOBILITY · UNCOMMON',desc:'Move like a spark. Dodge cooldown reduced by 18%.',apply:()=>{player.dodgeBonus+=.18;}},
  {id:'solar',name:'Solar Lens',icon:'☼',rarity:'ARCANA · RARE',desc:'Your burst burns brighter. +35% solar damage and radius.',apply:()=>{player.solarBonus+=.35;}},
  {id:'hunters',name:'Hunter’s Thread',icon:'⌖',rarity:'PRECISION · UNCOMMON',desc:'Find the gaps. +8% chance to land a critical strike.',apply:()=>{player.critBonus+=.08;}},
  {id:'moss',name:'Mossbound Vow',icon:'❧',rarity:'RECOVERY · UNCOMMON',desc:'The forest lends its strength. Restore 1.5 health each second.',apply:()=>{player.regen+=1.5;}},
  {id:'cinder',name:'Cinder Rhythm',icon:'♫',rarity:'TECHNIQUE · RARE',desc:'A faster blade. Combo strikes recover 13% sooner.',apply:()=>{player.attackHaste=(player.attackHaste||0)+.13;}},
  {id:'ward',name:'Warden’s Sigil',icon:'◇',rarity:'WARDING · RARE',desc:'A sliver of old protection. +12% maximum health.',apply:()=>{player.maxHp=Math.round(player.maxHp*1.12);player.hp=Math.min(player.maxHp,player.hp+12);}}
];

function persist() {
  try { localStorage.setItem(saveKey, JSON.stringify({bestTime:meta.bestTime,bestKills:meta.bestKills,current:meta.current,sound:!muted})); $('saveStatus').textContent='PROGRESS SAVED'; }
  catch { $('saveStatus').textContent='SAVE UNAVAILABLE'; }
}
function snapshotRun() {
  return {stage:game.stage,room:game.room,hp:player.hp,maxHp:player.maxHp,damage:player.damageBonus,solar:player.solarBonus,dodge:player.dodgeBonus,crit:player.critBonus,regen:player.regen,attackHaste:player.attackHaste||0,level:player.level,xp:player.xp,xpNeed:player.xpNeed,gold:player.gold,kills:player.kills,runTime:player.runTime,relics:[...runRelics]};
}
let runRelics = [];
function clearRunSave(){meta.current=null;persist();}
function resetPlayer(){
  Object.assign(player,{x:640,y:515,vx:0,vy:0,r:17,hp:100,maxHp:100,speed:235,damage:23,attackCd:0,attackTime:0,attackDuration:.42,attackAngle:-Math.PI/2,attackApplied:false,attackLunge:0,combo:0,comboTimer:0,dashCd:0,dashTime:0,dashVX:0,dashVY:0,jumpCd:0,jumpActive:false,jumpZ:0,jumpVy:0,jumpVX:0,jumpVY:0,landTime:0,animTime:0,facingAngle:0,invuln:0,hurtTime:0,hurtAngle:0,specialCd:0,specialTime:0,level:1,xp:0,xpNeed:100,gold:0,kills:0,damageBonus:0,solarBonus:0,dodgeBonus:0,critBonus:0,regen:0,runTime:0,attackHaste:0,stepTimer:0,stepSide:0});
  runRelics=[];
}
function startJourney(continueSaved=false){
  resetPlayer();game.stage=0;game.room=0;game.sessionStart=performance.now();game.continued=continueSaved;
  if(continueSaved && meta.current){const s=meta.current;game.stage=clamp(s.stage||0,0,2);game.room=clamp(s.room||0,0,2);Object.assign(player,{hp:s.hp||100,maxHp:s.maxHp||100,damageBonus:s.damage||0,solarBonus:s.solar||0,dodgeBonus:s.dodge||0,critBonus:s.crit||0,regen:s.regen||0,attackHaste:s.attackHaste||0,level:s.level||1,xp:s.xp||0,xpNeed:s.xpNeed||100,gold:s.gold||0,kills:s.kills||0,runTime:s.runTime||0});runRelics=s.relics||[];}
  player.x=640;player.y=520;player.vx=player.vy=0;player.attackCd=0;player.dashCd=0;player.specialCd=0;
  loadEncounter();setPhase('playing');$('chapterPill').textContent=`CHAPTER ${['I','II','III'][game.stage]} · ${realms[game.stage].name}`;showToast(continueSaved?'THE EMBERS REMEMBER YOU':'THE JOURNEY BEGINS',1.9);sound('start');
  updateUI();
}
function setPhase(phase){
  game.phase=phase;
  const overlay=$('overlay');
  if(phase==='playing'){overlay.classList.add('hidden');}
  else {overlay.classList.remove('hidden');$('menuPanel').classList.toggle('hidden',phase!=='menu');$('pausePanel').classList.toggle('hidden',phase!=='paused');$('rewardPanel').classList.toggle('hidden',phase!=='reward');$('endPanel').classList.toggle('hidden',phase!=='victory'&&phase!=='defeat');}
}
function showToast(text,duration=1.4){game.toastText=text;game.toastTimer=duration;$('toast').textContent=text;$('toast').classList.add('show');}
function createRng(seed){let s=seed>>>0;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}

function buildBackground(){
  const p=realms[game.stage].palette;
  const painted=realmBackgrounds[game.stage];
  if(painted && painted.complete && painted.naturalWidth){
    bg.clearRect(0,0,W,H);
    bg.drawImage(painted,0,0,W,H);
    // Keep the combat silhouettes and floating damage text readable over the richer art.
    bg.fillStyle='rgba(7,14,11,.12)'; bg.fillRect(0,0,W,H);
    const vignette=bg.createRadialGradient(640,350,250,640,350,780);
    vignette.addColorStop(0,'rgba(3,8,7,0)'); vignette.addColorStop(.72,'rgba(3,8,7,.08)'); vignette.addColorStop(1,'rgba(3,8,7,.42)');
    bg.fillStyle=vignette; bg.fillRect(0,0,W,H);
    return;
  }
  const randBG=createRng((game.stage+1)*91+game.room*17);
  const sky=bg.createLinearGradient(0,0,0,H);sky.addColorStop(0,p.sky);sky.addColorStop(.62,p.floor);sky.addColorStop(1,'#17231c');bg.fillStyle=sky;bg.fillRect(0,0,W,H);
  // atmospheric light pools
  const halo=bg.createRadialGradient(640,210,20,640,300,590);halo.addColorStop(0,p.glow+'28');halo.addColorStop(1,'transparent');bg.fillStyle=halo;bg.fillRect(0,0,W,H);
  // arena floor, hand-laid irregular stone tiles
  bg.save();bg.beginPath();bg.roundRect(52,65,1176,610,38);bg.clip();
  bg.fillStyle=p.floor;bg.fillRect(52,65,1176,610);
  for(let row=0;row<12;row++){
    for(let col=0;col<17;col++){
      const x=48+col*72+(row%2)*34,y=64+row*53;const w=65+randBG()*9,h=43+randBG()*8;const tone=randBG();
      bg.fillStyle=tone>.66?p.floor2:tone<.13?'#1b3028':p.floor;bg.globalAlpha=.25+randBG()*.18;
      bg.beginPath();bg.roundRect(x+2,y+2,w,h,4+randBG()*7);bg.fill();bg.globalAlpha=1;
      bg.strokeStyle=p.line;bg.globalAlpha=.14;bg.lineWidth=1;bg.stroke();bg.globalAlpha=1;
      if(randBG()>.68){bg.fillStyle=p.accent;bg.globalAlpha=.16;bg.beginPath();bg.ellipse(x+randBG()*w,y+randBG()*h,randBG()*12+3,randBG()*3+1,randBG(),0,TAU);bg.fill();bg.globalAlpha=1;}
    }
  }
  // worn circular dais
  bg.strokeStyle=p.accent;bg.globalAlpha=.18;bg.lineWidth=2;bg.beginPath();bg.ellipse(640,356,280,174,0,0,TAU);bg.stroke();bg.beginPath();bg.ellipse(640,356,251,151,0,0,TAU);bg.stroke();bg.globalAlpha=1;
  for(let i=0;i<12;i++){const a=i/12*TAU;const x=640+Math.cos(a)*264,y=356+Math.sin(a)*160;bg.save();bg.translate(x,y);bg.rotate(a);bg.fillStyle=p.line;bg.globalAlpha=.3;bg.beginPath();bg.roundRect(-12,-5,24,10,2);bg.fill();bg.restore();bg.globalAlpha=1;}
  // edge parapets and broken masonry
  for(let i=0;i<18;i++){let x=70+i*66+randBG()*15;const y=i%2?77:645;bg.fillStyle=i%3===0?'#17231d':p.floor2;bg.globalAlpha=.7;bg.beginPath();bg.roundRect(x,y,38+randBG()*28,21+randBG()*12,5);bg.fill();bg.globalAlpha=1;bg.strokeStyle=p.line;bg.globalAlpha=.35;bg.stroke();bg.globalAlpha=1;}
  // moss, ash or moon flowers / stones
  for(let i=0;i<105;i++){const x=65+randBG()*1150,y=78+randBG()*580;if(x>390&&x<890&&y>190&&y<555&&randBG()>.20)continue;const size=2+randBG()*7;bg.globalAlpha=.18+randBG()*.25;bg.fillStyle=game.stage===0?(randBG()>.5?'#a8c17b':'#758f61'):game.stage===1?(randBG()>.5?'#d9865c':'#695149'):'#a7b3df';bg.beginPath();bg.ellipse(x,y,size,size*.42,randBG()*TAU,0,TAU);bg.fill();bg.globalAlpha=1;}
  // decorative pillars or crystals around the outskirts
  for(let i=0;i<13;i++){const x=100+randBG()*1080,y=90+randBG()*535;if(x>480&&x<800&&y>255&&y<480)continue;const h=18+randBG()*35;bg.fillStyle=game.stage===1?'#483b37':game.stage===2?'#4c5270':'#43513c';bg.beginPath();bg.moveTo(x-10,y);bg.lineTo(x-6,y-h);bg.lineTo(x+5,y-h-5);bg.lineTo(x+13,y-2);bg.closePath();bg.fill();bg.strokeStyle=p.line;bg.globalAlpha=.28;bg.stroke();bg.globalAlpha=1;}
  // region-specific landmarks: living roots, furnace iron, and moonlit water
  if(game.stage===0){
    bg.save();bg.lineCap='round';bg.lineJoin='round';
    for(const side of [0,1]){const x=side?1210:70;bg.strokeStyle='#172b20';bg.lineWidth=34;bg.beginPath();bg.moveTo(x,95);bg.bezierCurveTo(x+(side?-58:58),190,x+(side?30:-30),215,x,300);bg.bezierCurveTo(x+(side?-45:45),382,x+(side?30:-30),430,x+(side?0:0),575);bg.stroke();bg.strokeStyle='#617b4c';bg.globalAlpha=.5;bg.lineWidth=4;bg.beginPath();bg.moveTo(x+(side?-8:8),100);bg.bezierCurveTo(x+(side?-48:48),190,x+(side?26:-26),215,x+(side?-4:4),300);bg.stroke();bg.globalAlpha=1;}
    for(const [x,y,scale] of [[145,130,.85],[1136,155,1],[125,550,1.05],[1143,555,.8]]){bg.save();bg.translate(x,y);bg.scale(scale,scale);bg.fillStyle='#1a2d22';bg.beginPath();bg.moveTo(-8,50);bg.lineTo(-15,-8);bg.lineTo(-33,-28);bg.lineTo(-8,-22);bg.lineTo(0,-62);bg.lineTo(11,-22);bg.lineTo(34,-36);bg.lineTo(17,-3);bg.lineTo(13,50);bg.closePath();bg.fill();bg.strokeStyle='#64784b';bg.globalAlpha=.42;bg.lineWidth=3;bg.stroke();bg.restore();}
    for(let i=0;i<16;i++){const x=115+randBG()*1050,y=100+randBG()*520;if(x>330&&x<950&&y>205&&y<540)continue;bg.fillStyle='#c0d17f';bg.globalAlpha=.34;bg.beginPath();bg.ellipse(x,y,3+randBG()*4,2,randBG()*TAU,0,TAU);bg.fill();bg.globalAlpha=1;}
    bg.restore();
  }else if(game.stage===1){
    bg.save();
    for(const [x,y] of [[105,135],[1175,145],[105,555],[1178,550]]){bg.fillStyle='#211d1c';bg.beginPath();bg.roundRect(x-27,y-42,54,84,7);bg.fill();bg.strokeStyle='#986249';bg.lineWidth=3;bg.stroke();const glow=bg.createRadialGradient(x,y,4,x,y,85);glow.addColorStop(0,'#f59a5c66');glow.addColorStop(1,'transparent');bg.fillStyle=glow;bg.fillRect(x-85,y-85,170,170);bg.fillStyle='#e58a55';bg.globalAlpha=.7;bg.beginPath();bg.moveTo(x,y-25);bg.quadraticCurveTo(x+20,y+1,x,y+16);bg.quadraticCurveTo(x-19,y+1,x,y-25);bg.fill();bg.globalAlpha=1;}
    bg.strokeStyle='#9d533b';bg.lineWidth=5;bg.globalAlpha=.38;for(let i=0;i<8;i++){const x=180+i*135;bg.beginPath();bg.moveTo(x,100);bg.lineTo(x+randBG()*38-19,160+randBG()*80);bg.lineTo(x-14+randBG()*28,210+randBG()*65);bg.stroke();}bg.globalAlpha=1;
    for(let i=0;i<32;i++){const x=80+randBG()*1120,y=85+randBG()*560;bg.fillStyle=randBG()>.5?'#e28c5b':'#ffd18a';bg.globalAlpha=.22+randBG()*.28;bg.beginPath();bg.arc(x,y,1+randBG()*2.2,0,TAU);bg.fill();}bg.globalAlpha=1;bg.restore();
  }else{
    bg.save();
    for(const [x,y,rx,ry] of [[165,250,76,31],[1115,265,83,29],[150,550,58,22],[1118,540,70,27]]){const water=bg.createRadialGradient(x,y,3,x,y,Math.max(rx,ry));water.addColorStop(0,'#9caedb88');water.addColorStop(.55,'#687bb466');water.addColorStop(1,'transparent');bg.fillStyle=water;bg.beginPath();bg.ellipse(x,y,rx,ry,0,0,TAU);bg.fill();bg.strokeStyle='#b2c3e8';bg.globalAlpha=.35;bg.lineWidth=2;bg.beginPath();bg.ellipse(x,y,rx*.72,ry*.58,0,0,TAU);bg.stroke();bg.globalAlpha=1;}
    for(const [x,y] of [[118,180],[1160,175],[120,590],[1160,590]]){bg.fillStyle='#4c5474';bg.beginPath();bg.roundRect(x-14,y-42,28,84,4);bg.fill();bg.fillStyle='#a8b6dc';bg.globalAlpha=.35;bg.fillRect(x-19,y-46,38,7);bg.globalAlpha=1;bg.strokeStyle='#8f9cc6';bg.globalAlpha=.28;bg.strokeRect(x-14,y-42,28,84);bg.globalAlpha=1;}
    bg.strokeStyle='#b8c7eb';bg.globalAlpha=.23;bg.lineWidth=2;for(let i=0;i<9;i++){const x=180+i*115,y=110+(i%3)*8;bg.beginPath();bg.moveTo(x,y);bg.lineTo(x+10,y+12);bg.lineTo(x,y+24);bg.lineTo(x-10,y+12);bg.closePath();bg.stroke();}bg.globalAlpha=1;bg.restore();
  }
  // fine rune marks
  bg.strokeStyle=p.glow;bg.lineWidth=1;bg.globalAlpha=.15;
  for(let i=0;i<7;i++){const x=250+i*130,y=350+(i%2?18:-18);bg.beginPath();bg.moveTo(x,y-10);bg.lineTo(x+8,y);bg.lineTo(x,y+10);bg.lineTo(x-8,y);bg.closePath();bg.stroke();}
  bg.globalAlpha=1;bg.restore();
  // ornamental outer border
  bg.strokeStyle=p.accent;bg.globalAlpha=.25;bg.lineWidth=2;bg.beginPath();bg.roundRect(43,56,1194,628,42);bg.stroke();bg.globalAlpha=1;
  const shade=bg.createLinearGradient(0,0,0,H);shade.addColorStop(0,'rgba(4,10,8,.38)');shade.addColorStop(.25,'transparent');shade.addColorStop(.78,'transparent');shade.addColorStop(1,'rgba(4,10,8,.45)');bg.fillStyle=shade;bg.fillRect(0,0,W,H);
}

function spawnEnemy(kind,x,y,boss=false){
  const base={stalker:{hp:58,speed:80,damage:10,r:19,xp:17},archer:{hp:46,speed:58,damage:9,r:17,xp:20},brute:{hp:132,speed:44,damage:18,r:27,xp:29},wisp:{hp:38,speed:73,damage:8,r:15,xp:18}};
  if(boss){const hp=game.stage===0?900:game.stage===1?1120:1420;const e={kind:'boss',x,y,r:62,hp,maxHp:hp,speed:66,damage:22,xp:220,attackCd:2.6,state:'idle',stateT:0,flash:0,phase:1,seed:rand(0,10),anim:rand(0,TAU),boss:true,chargeVX:0,chargeVY:0,knockVX:0,knockVY:0,hitStun:0,aimX:x,aimY:y};game.enemies.push(e);game.boss=e;return e;}
  const d=base[kind];const stageScale=1+game.stage*.28+(game.room===1?.16:0);const e={kind,x,y,r:d.r,hp:d.hp*stageScale,maxHp:d.hp*stageScale,speed:d.speed*(1+game.stage*.12),damage:d.damage*(1+game.stage*.18),xp:d.xp,attackCd:rand(.4,1.5),state:'idle',stateT:0,flash:0,seed:rand(0,10),anim:rand(0,TAU),chargeVX:0,chargeVY:0,knockVX:0,knockVY:0,hitStun:0,aimX:x,aimY:y};game.enemies.push(e);return e;
}
function spawnAtEdge(kind){const side=Math.floor(rand(0,4));let x,y;if(side===0){x=rand(130,1150);y=rand(115,155);}else if(side===1){x=rand(130,1150);y=rand(575,615);}else if(side===2){x=rand(100,145);y=rand(170,580);}else{x=rand(1135,1180);y=rand(170,580);}return spawnEnemy(kind,x,y);}
function loadEncounter(){
  const p=realms[game.stage];game.enemies=[];game.projectiles=[];game.particles=[];game.pickups=[];game.floaters=[];game.combatFX=[];game.afterimages=[];game.hitStop=0;game.impactFlash=0;game.portal=null;game.boss=null;game.roomCleared=false;game.roomTime=0;game.roomKills=0;player.x=640;player.y=515;player.vx=player.vy=0;player.combo=0;player.comboTimer=0;player.attackTime=0;player.specialTime=0;player.jumpActive=false;player.jumpZ=0;player.jumpVy=0;player.landTime=0;player.invuln=.65;
  buildBackground();
  const isBoss=game.room===2;
  if(isBoss){spawnEnemy('boss',640,290,true);const minions=game.stage===2?3:2;for(let i=0;i<minions;i++)spawnAtEdge(i%2?'wisp':'stalker');$('bossHud').style.display='block';$('objectiveLabel').textContent='DEFEAT THE WARDEN';}
  else {const count=(game.room===0?5:7)+game.stage;const pattern=game.stage===0?['stalker','stalker','archer','stalker','wisp','brute']:game.stage===1?['stalker','archer','brute','wisp','archer','brute','stalker','wisp']:['wisp','archer','brute','stalker','archer','wisp','brute','stalker','archer'];for(let i=0;i<count;i++)spawnAtEdge(pattern[i%pattern.length]);$('bossHud').style.display='none';$('objectiveLabel').textContent='CLEAR THE CORRUPTION';}
  $('locationLabel').textContent=p.name;$('roomLabel').textContent=p.roomNames[game.room];$('chapterPill').textContent=`CHAPTER ${['I','II','III'][game.stage]} · ${p.name}`;$('realmTag').textContent=p.tag;$('realmTitle').textContent=p.title;$('realmDesc').textContent=p.desc;$('objectiveTitle').textContent=p.objective;$('objectiveCopy').textContent=isBoss?'Break the guardian. The ember gate will carry you onward.':'Defeat every guardian in this chamber. Reach the glowing gate when it opens.';
  $('realmArt').dataset.stage=game.stage;$('progressSteps').innerHTML='<span class="step active"></span><span class="step"></span><span class="step"></span>';
  $('bottomHint').textContent=isBoss?'THE GUARDIAN STANDS BETWEEN YOU AND THE NEXT REALM':'DEFEAT THE GUARDIANS TO OPEN THE WAY';updateUI();
}
function openPortal(){
  if(game.roomCleared)return;game.roomCleared=true;$('bossHud').style.display='none';game.portal={x:640,y:151,r:48,pulse:0};$('objectiveLabel').textContent='GATE OPEN · APPROACH';$('bottomHint').textContent='APPROACH THE EMBER GATE AND PRESS E';$('interactionHint').style.display='flex';
  showToast(game.room===2?'THE GUARDIAN HAS FALLEN':'THE CHAMBER IS CLEARED',2);sound('portal');
  for(let i=0;i<34;i++)particle(640,151,choice(['#f0cf93','#9fcca1','#d49c68']),rand(1,4),rand(-2,2),rand(-3,-.2),rand(.5,1.6));
  player.hp=Math.min(player.maxHp,player.hp+Math.max(5,player.maxHp*.07));player.gold+=12+game.stage*7;persistCurrent();updateUI();
}
function persistCurrent(){meta.current=snapshotRun();persist();}
function interactPortal(){if(!game.portal||dist(player,game.portal)>105)return;sound('portal');game.pendingTransition=game.room===2&&game.stage===2?'victory':'next';openReward();}
function openReward(){
  game.rewardOptions=[];const candidates=[...relicPool];while(game.rewardOptions.length<3&&candidates.length){const i=Math.floor(Math.random()*candidates.length);game.rewardOptions.push(candidates.splice(i,1)[0]);}
  const cards=$('rewardCards');cards.innerHTML='';for(const relic of game.rewardOptions){const el=document.createElement('button');el.className='reward-card';el.innerHTML=`<span class="reward-icon">${relic.icon}</span><b>${relic.name}</b><p>${relic.desc}</p><span class="reward-rarity">${relic.rarity}</span>`;el.addEventListener('click',()=>chooseReward(relic));cards.appendChild(el);}
  $('rewardIntro').textContent=game.room===2?'The guardian’s core yields a fragment of its power.':'A quiet ember rises from the chamber floor.';setPhase('reward');
}
function chooseReward(relic){
  relic.apply();runRelics.push(relic);if(runRelics.length>6)runRelics.shift();sound('reward');
  if(game.pendingTransition==='victory'){finishRun(true);return;}
  if(game.room===2){game.stage++;game.room=0;}else game.room++;
  game.pendingTransition=null;loadEncounter();persistCurrent();setPhase('playing');showToast(`${relic.name.toUpperCase()} · BLESSING CLAIMED`,1.8);updateUI();
}
function finishRun(won){
  const time=player.runTime;const secs=Math.floor(time),minutes=Math.floor(secs/60),rest=secs%60;const pretty=`${String(minutes).padStart(2,'0')}:${String(rest).padStart(2,'0')}`;
  $('endSymbol').textContent=won?'✧':'✕';$('endKicker').textContent=won?'THE LIGHT ENDURES':'THE EMBERS FADE';$('endTitle').textContent=won?'The Hollow Crown is broken.':'The dark takes the path.';$('endCopy').textContent=won?'Three realms breathe again. Somewhere, a new hearth is kindled.':'Lyra falls, but the old fire remembers. Rise again and finish what you began.';
  $('runResults').innerHTML=`<div><b>${pretty}</b><small>TIME</small></div><div><b>${player.kills}</b><small>GUARDIANS</small></div><div><b>${player.level}</b><small>LEVEL</small></div><div><b>${player.gold}</b><small>SHARDS</small></div>`;
  if(won){if(!meta.bestTime||time<meta.bestTime)meta.bestTime=time;meta.bestKills=Math.max(meta.bestKills,player.kills);meta.current=null;}else{meta.current=null;}persist();$('continueBtn').disabled=!meta.current;$('continueMeta').textContent=meta.current?'SAVE FOUND':'— NO SAVE —';setPhase(won?'victory':'defeat');sound(won?'victory':'defeat');
}

function particle(x,y,color,size,vx,vy,life=0.6){game.particles.push({x,y,color,size,vx,vy,life,max:life,drag:.94});}
function burst(x,y,color,count=12,scale=1){for(let i=0;i<count;i++){const a=rand(0,TAU),s=rand(40,240)*scale;particle(x,y,color,rand(1.5,4)*scale,Math.cos(a)*s,Math.sin(a)*s,rand(.25,.8));}}
function addCombatFX(type,x,y,options={}){const life=options.life??.34;game.combatFX.push({type,x,y,life,max:life,...options});}
function floater(x,y,text,color='#ffe2a4',size=15){game.floaters.push({x,y,text,color,size,life:.8,max:.8,vy:-36});}
function dropLoot(e){game.pickups.push({x:e.x+rand(-11,11),y:e.y+rand(-11,11),kind:'xp',value:e.boss?e.xp:e.xp*.7,life:16,phase:rand(0,TAU)});if(Math.random()<.48||e.boss)game.pickups.push({x:e.x+rand(-17,17),y:e.y+rand(-17,17),kind:'gold',value:e.boss?28:4+Math.floor(rand(0,5)),life:15,phase:rand(0,TAU)});}
function killEnemy(e){const i=game.enemies.indexOf(e);if(i<0)return;game.enemies.splice(i,1);if(e===game.boss)game.boss=null;player.kills++;game.roomKills++;dropLoot(e);addCombatFX('deathBurst',e.x,e.y,{life:.48,radius:e.boss?112:54,color:e.boss?'#f5cf8a':realms[game.stage].palette.glow});burst(e.x,e.y,e.boss?'#f0c27e':realms[game.stage].palette.glow,e.boss?54:24,e.boss?2.1:1.2);floater(e.x,e.y-18,e.boss?'WARDEN BROKEN':'+'+Math.round(e.xp)+' XP','#e8d59f',e.boss?18:12);game.shake=Math.max(game.shake,e.boss?11:4);sound('kill');if(game.enemies.length===0)openPortal();updateUI();}
function damageEnemy(e,amount,crit=false,sourceX=player.x,sourceY=player.y,combo=1){if(e.hp<=0)return;e.hp-=amount;e.flash=.19;e.stateT=Math.max(e.stateT||0,0);const a=Math.atan2(e.y-sourceY,e.x-sourceX);const force=(e.boss?52:e.kind==='brute'?145:190)*(combo===3?1.35:1)*(crit?1.18:1);e.knockVX+=Math.cos(a)*force;e.knockVY+=Math.sin(a)*force;e.hitStun=Math.max(e.hitStun||0,e.boss?.075:combo===3?.2:.13);game.impactFlash=Math.max(game.impactFlash,crit?.62:.22);const color=crit?'#fff0a3':'#f5d5a0';floater(e.x+rand(-12,12),e.y-e.r,Math.round(amount),crit?'#fff1a5':'#e7d4ae',crit?18:14);addCombatFX('impact',e.x,e.y,{life:crit?.34:.25,angle:a,crit,color});game.hitStop=Math.max(game.hitStop,crit?.075:.052);game.shake=Math.max(game.shake,crit?7:3.8);for(let i=0;i<(crit?16:9);i++){const spread=a+rand(-1.15,1.15),speed=rand(90,310)*(crit?1.25:1);particle(e.x,e.y,choice(crit?['#fff2b0','#f2c875','#fff8df']:['#e9d3a4','#c3aa7b','#f7e4bd']),rand(1.6,3.5),Math.cos(spread)*speed,Math.sin(spread)*speed,rand(.18,.42));}if(e.hp<=0)killEnemy(e);}
function damagePlayer(amount,sourceX,sourceY){if(player.invuln>0||game.phase!=='playing')return;player.hp-=amount;player.invuln=.72;player.hurtTime=.25;game.hitStop=Math.max(game.hitStop,.045);game.impactFlash=Math.max(game.impactFlash,.42);game.shake=14;sound('hurt');burst(player.x,player.y,'#e88769',20,.85);floater(player.x,player.y-27,'-'+Math.round(amount),'#f08e75',18);if(sourceX!==undefined){const a=Math.atan2(player.y-sourceY,player.x-sourceX);player.hurtAngle=a;player.vx+=Math.cos(a)*190;player.vy+=Math.sin(a)*190;addCombatFX('impact',player.x,player.y,{life:.28,angle:a,color:'#ff9b85',crit:true});}if(player.hp<=0){player.hp=0;updateUI();finishRun(false);}updateUI();}

function aimAtPointer(){if(input.pointer.inside){player.attackAngle=Math.atan2(input.pointer.y-player.y,input.pointer.x-player.x);}}
function nearestAngle(){let nearest=null,best=Infinity;for(const e of game.enemies){const d=dist(player,e);if(d<best){best=d;nearest=e;}}if(nearest)player.attackAngle=Math.atan2(nearest.y-player.y,nearest.x-player.x);}
function startAttack(){if(game.phase!=='playing'||player.attackCd>0||player.dashTime>0)return;aimAtPointer();if(!input.pointer.inside)nearestAngle();player.combo=player.comboTimer>0?(player.combo%3)+1:1;player.comboTimer=.78;player.attackDuration=Math.max(.32,.46-(player.attackHaste||0)*.12);player.attackTime=player.attackDuration;player.attackApplied=false;player.attackLunge=0;player.attackCd=Math.max(.25,.40-(player.attackHaste||0)*.28);sound(player.combo===3?'slash3':player.combo===2?'slash2':'slash');}
function useDash(){if(game.phase!=='playing'||player.dashCd>0||player.jumpActive)return;let dx=(input.keys.has('d')||input.keys.has('arrowright')?1:0)-(input.keys.has('a')||input.keys.has('arrowleft')?1:0)+input.joy.x;let dy=(input.keys.has('s')||input.keys.has('arrowdown')?1:0)-(input.keys.has('w')||input.keys.has('arrowup')?1:0)+input.joy.y;let l=Math.hypot(dx,dy);if(l<.1){dx=Math.cos(player.attackAngle);dy=Math.sin(player.attackAngle);l=1;}dx/=l;dy/=l;player.dashVX=dx*690;player.dashVY=dy*690;player.dashTime=.22;player.invuln=.38;player.dashCd=Math.max(.72,1.25-player.dodgeBonus*.75);addCombatFX('dashBurst',player.x,player.y,{life:.26,angle:Math.atan2(dy,dx),color:'#c9f3df'});game.shake=Math.max(game.shake,2);sound('dash');burst(player.x,player.y,'#c9f3df',20,.85);}
function useJump(){
  if(game.phase!=='playing'||player.jumpCd>0||player.jumpActive||player.dashTime>0)return;
  let dx=(input.keys.has('d')||input.keys.has('arrowright')?1:0)-(input.keys.has('a')||input.keys.has('arrowleft')?1:0)+input.joy.x;
  let dy=(input.keys.has('s')||input.keys.has('arrowdown')?1:0)-(input.keys.has('w')||input.keys.has('arrowup')?1:0)+input.joy.y;
  let l=Math.hypot(dx,dy);
  if(l<.1){dx=Math.cos(player.attackAngle);dy=Math.sin(player.attackAngle);l=1;}
  dx/=l;dy/=l;
  player.jumpActive=true;player.jumpZ=0;player.jumpVy=575;player.jumpVX=dx*315;player.jumpVY=dy*315;player.jumpCd=.95;player.invuln=Math.max(player.invuln,.68);player.landTime=0;
  player.facingAngle=angleLerp(player.facingAngle,Math.atan2(dy,dx)+Math.PI/2,.8);
  addCombatFX('jumpTakeoff',player.x,player.y,{life:.24,angle:Math.atan2(dy,dx),color:'#c8f4e7'});
  for(let i=0;i<12;i++)particle(player.x+rand(-12,12),player.y+rand(-6,7),'#d8e9b9',rand(1.5,3.2),rand(-75,75),rand(-35,35),rand(.18,.35));
  sound('jump');
}
function useSpecial(){if(game.phase!=='playing'||player.specialCd>0)return;player.specialCd=Math.max(3.8,8.5-player.solarBonus*2);player.specialTime=.72;const radius=170*(1+player.solarBonus*.35),dmg=38*(1+player.solarBonus);game.shake=16;addCombatFX('solarBurst',player.x,player.y,{life:.72,radius,color:'#ffe7a6'});burst(player.x,player.y,'#ffe4a5',76,1.8);sound('solar');for(const e of [...game.enemies]){const d=dist(player,e);if(d<radius+e.r){damageEnemy(e,dmg*(1-d/(radius*2)),true,player.x,player.y,3);const a=Math.atan2(e.y-player.y,e.x-player.x);e.x+=Math.cos(a)*34;e.y+=Math.sin(a)*34;}}showToast('SOLAR BURST',.9);}
function interact(){if(game.phase==='playing')interactPortal();}

function updatePlayer(dt){
  player.attackCd=Math.max(0,player.attackCd-dt);player.attackTime=Math.max(0,player.attackTime-dt);player.hurtTime=Math.max(0,player.hurtTime-dt);player.comboTimer=Math.max(0,player.comboTimer-dt);player.dashCd=Math.max(0,player.dashCd-dt);player.jumpCd=Math.max(0,player.jumpCd-dt);player.landTime=Math.max(0,player.landTime-dt);player.animTime+=dt;player.specialCd=Math.max(0,player.specialCd-dt);player.specialTime=Math.max(0,player.specialTime-dt);player.invuln=Math.max(0,player.invuln-dt);
  if(player.comboTimer===0&&player.attackTime===0)player.combo=0;
  if(player.regen>0&&player.hp>0)player.hp=Math.min(player.maxHp,player.hp+player.regen*dt);
  if(player.dashTime>0){
    player.dashTime-=dt;player.vx=player.dashVX;player.vy=player.dashVY;player.x+=player.vx*dt;player.y+=player.vy*dt;
    for(let i=0;i<2;i++)particle(player.x+rand(-12,12),player.y+rand(-12,12),'#c9f3df',rand(2,4),rand(-35,35),rand(-28,28),.28);
    if(Math.random()<.72)game.afterimages.push({x:player.x,y:player.y,angle:player.facingAngle,life:.23,max:.23,phase:player.animTime});
  }else if(player.jumpActive){
    player.x+=player.jumpVX*dt;player.y+=player.jumpVY*dt;player.jumpVX*=Math.pow(.22,dt);player.jumpVY*=Math.pow(.22,dt);player.vx=player.jumpVX;player.vy=player.jumpVY;
    player.jumpZ+=player.jumpVy*dt;player.jumpVy-=1680*dt;
    if(Math.random()<.38)particle(player.x+rand(-12,12),player.y+rand(8,17),'#d2e1b4',rand(1.3,2.7),rand(-22,22),rand(-15,12),.22);
    if(player.jumpZ<=0&&player.jumpVy<0){player.jumpZ=0;player.jumpVy=0;player.jumpActive=false;player.landTime=.22;game.shake=Math.max(game.shake,2.5);addCombatFX('landing',player.x,player.y,{life:.34,color:'#d7e5b7'});for(let i=0;i<16;i++){const a=rand(0,TAU),v=rand(28,125);particle(player.x,player.y,'#cbd9ae',rand(1.4,3),Math.cos(a)*v,Math.sin(a)*v*.45,.32);}}
  }else{
    let dx=(input.keys.has('d')||input.keys.has('arrowright')?1:0)-(input.keys.has('a')||input.keys.has('arrowleft')?1:0)+input.joy.x;
    let dy=(input.keys.has('s')||input.keys.has('arrowdown')?1:0)-(input.keys.has('w')||input.keys.has('arrowup')?1:0)+input.joy.y;
    const l=Math.hypot(dx,dy);if(l>1){dx/=l;dy/=l;}const targetX=dx*player.speed,targetY=dy*player.speed;const accel=1-Math.exp(-dt*12);
    player.vx=lerp(player.vx,targetX,accel);player.vy=lerp(player.vy,targetY,accel);
    if(Math.abs(dx)+Math.abs(dy)<.01){player.vx*=Math.pow(.03,dt);player.vy*=Math.pow(.03,dt);}
    player.x+=player.vx*dt;player.y+=player.vy*dt;
    const actualSpeed=Math.hypot(player.vx,player.vy);
    if(actualSpeed>100){player.stepTimer-=dt;if(player.stepTimer<=0){player.stepTimer=clamp(0.19-actualSpeed/1600,.075,.15);player.stepSide^=1;const side=player.stepSide?1:-1;const a=Math.atan2(player.vy,player.vx);const px=player.x-Math.cos(a)*8+Math.cos(a+Math.PI/2)*side*9;const py=player.y-Math.sin(a)*8+Math.sin(a+Math.PI/2)*side*9;for(let i=0;i<3;i++)particle(px,py,realms[game.stage].palette.accent,rand(1,2.5),rand(-18,18),rand(-15,12),.2);}}
  }
  const moveSpeed=Math.hypot(player.vx,player.vy);
  let faceTarget=player.facingAngle;
  if(player.attackTime>0||input.pointer.inside)faceTarget=player.attackAngle+Math.PI/2;
  else if(moveSpeed>48)faceTarget=Math.atan2(player.vy,player.vx)+Math.PI/2;
  player.facingAngle=angleLerp(player.facingAngle,faceTarget,1-Math.exp(-dt*13));
  player.x=clamp(player.x,85,1195);player.y=clamp(player.y,100,632);
  if(player.attackTime>0&&!player.attackApplied){
    const progress=1-player.attackTime/player.attackDuration;
    if(progress>.48){
      player.attackApplied=true;const range=player.combo===3?132:player.combo===2?112:103;const arc=player.combo===3?1.42:player.combo===2?1.2:1.05;
      const hitList=[];
      for(const e of [...game.enemies]){const d=dist(player,e);if(d<range+e.r){const a=Math.atan2(e.y-player.y,e.x-player.x);const diff=Math.atan2(Math.sin(a-player.attackAngle),Math.cos(a-player.attackAngle));if(Math.abs(diff)<arc){const crit=Math.random()<player.critBonus;const amount=player.damage*(1+player.damageBonus)*(player.combo===3?1.72:player.combo===2?1.28:1)*(crit?2.05:1);damageEnemy(e,amount,crit,player.x,player.y,player.combo);const k=Math.atan2(e.y-player.y,e.x-player.x);e.x+=Math.cos(k)*(player.combo===3?38:player.combo===2?25:18);e.y+=Math.sin(k)*(player.combo===3?38:player.combo===2?25:18);hitList.push(e);}}
      }
      player.attackLunge=player.combo===3?16:10;player.x=clamp(player.x+Math.cos(player.attackAngle)*player.attackLunge,85,1195);player.y=clamp(player.y+Math.sin(player.attackAngle)*player.attackLunge,100,632);
      addCombatFX('slash',player.x,player.y,{life:player.combo===3?.32:.27,angle:player.attackAngle,combo:player.combo,color:player.combo===3?'#fff0ad':'#f1d7a0'});
      if(hitList.length){addCombatFX('impactGround',player.x+Math.cos(player.attackAngle)*68,player.y+Math.sin(player.attackAngle)*68,{life:.2,color:'#f5d7a0'});}
      const sparks=player.combo===3?22:player.combo===2?16:12;for(let i=0;i<sparks;i++){const a=player.attackAngle+rand(-arc,arc),speed=rand(110,300);particle(player.x+Math.cos(a)*48,player.y+Math.sin(a)*48,choice(['#fff0bd','#ecc47d','#d8f0cf']),rand(1.4,3.2),Math.cos(a)*speed,Math.sin(a)*speed,.32);}
    }
  }
  if(input.attackHeld&&player.attackCd<=0)startAttack();
}
function updateEnemy(e,dt){
  const dx=player.x-e.x,dy=player.y-e.y,d=Math.max(1,Math.hypot(dx,dy)),nx=dx/d,ny=dy/d;e.attackCd-=dt;e.flash=Math.max(0,e.flash-dt);e.stateT=Math.max(0,e.stateT-dt);e.anim=(e.anim||0)+dt;
  if(e.hitStun>0){e.hitStun=Math.max(0,e.hitStun-dt);e.x+=e.knockVX*dt;e.y+=e.knockVY*dt;e.knockVX*=Math.pow(.035,dt);e.knockVY*=Math.pow(.035,dt);e.x=clamp(e.x,75,1205);e.y=clamp(e.y,85,645);if(e.hitStun>0)return;}
  if(e.kind==='boss'){
    e.seed+=dt;const pct=e.hp/e.maxHp;e.phase=pct<.5?2:1;e.speed=66+(e.phase-1)*19;
    if(e.state==='windup'&&e.stateT<=0){
      if(e.attackPattern==='storm'){
        const count=e.phase===2?14:10;
        for(let i=0;i<count;i++){const a=i/count*TAU;spawnProjectile(e.x,e.y,Math.cos(a)*185,Math.sin(a)*185,11,'#efaa75');}
        e.state='idle';e.attackCd=e.phase===2?1.5:2.1;e.attackPattern='';
      }else{
        e.state='burst';e.stateT=.48;const ta=Math.atan2(e.aimY-e.y,e.aimX-e.x);e.chargeVX=Math.cos(ta)*370;e.chargeVY=Math.sin(ta)*370;addCombatFX('enemyCharge',e.x,e.y,{life:.22,angle:ta,color:'#f08d72'});burst(e.x,e.y,'#f09a70',18,.9);
      }
    }else if(e.state==='burst'){
      e.x+=e.chargeVX*dt;e.y+=e.chargeVY*dt;e.chargeVX*=Math.pow(.14,dt);e.chargeVY*=Math.pow(.14,dt);
      if(e.stateT<=0){e.state='idle';e.attackCd=e.phase===2?1.5:2.1;}
    }else if(e.state==='idle'&&e.attackCd<=0){
      const pattern=Math.floor(rand(0,e.phase===2?3:2));e.state='windup';e.stateT=pattern===0?.92:.78;e.attackPattern=pattern===0?'charge':'storm';e.aimX=player.x;e.aimY=player.y;
      showToast(pattern===0?'WARDEN · ROOT CHARGE':'WARDEN · SHARD STORM',.65);e.attackCd=e.phase===2?1.75:2.6;
    }
    if(e.state==='idle'){e.x+=nx*e.speed*.42*dt;e.y+=ny*e.speed*.42*dt;}
    if(d<e.r+player.r+8&&e.state==='burst')damagePlayer(e.damage,e.x,e.y);
    e.x=clamp(e.x,160,1120);e.y=clamp(e.y,130,590);return;
  }
  if(e.kind==='stalker'){
    e.x+=nx*e.speed*dt;e.y+=ny*e.speed*dt;if(d<e.r+player.r+5&&e.attackCd<=0){damagePlayer(e.damage,e.x,e.y);e.attackCd=.95;}
  }else if(e.kind==='archer'){
    if(d>275){e.x+=nx*e.speed*dt*.8;e.y+=ny*e.speed*dt*.8;}else if(d<195){e.x-=nx*e.speed*dt*.8;e.y-=ny*e.speed*dt*.8;}
    if(e.state==='windup'){if(e.stateT<=0){const a=Math.atan2(e.aimY-e.y,e.aimX-e.x);spawnProjectile(e.x,e.y,Math.cos(a)*260,Math.sin(a)*260,10,'#e7ae77');e.state='idle';e.attackCd=1.8;}}
    else if(e.attackCd<=0){e.state='windup';e.stateT=.64;e.aimX=player.x;e.aimY=player.y;}
  }else if(e.kind==='brute'){
    if(e.state==='charge'){e.x+=e.chargeVX*dt;e.y+=e.chargeVY*dt;e.chargeVX*=Math.pow(.18,dt);e.chargeVY*=Math.pow(.18,dt);if(e.stateT<=0){e.state='idle';e.attackCd=1.9;}}
    else if(e.state==='windup'){if(e.stateT<=0){e.state='charge';e.stateT=.46;const a=Math.atan2(e.aimY-e.y,e.aimX-e.x);e.chargeVX=Math.cos(a)*490;e.chargeVY=Math.sin(a)*490;addCombatFX('enemyCharge',e.x,e.y,{life:.25,angle:a,color:'#f0aa77'});burst(e.x,e.y,'#e9a777',16,.8);}}
    else{if(d>110){e.x+=nx*e.speed*dt;e.y+=ny*e.speed*dt;}if(e.attackCd<=0&&d<360){e.state='windup';e.stateT=.82;e.aimX=player.x;e.aimY=player.y;showToast('BRUTE · CHARGING',.5);}}
    if(d<e.r+player.r+4&&e.attackCd<1.2&&e.state==='charge')damagePlayer(e.damage,e.x,e.y);
  }else if(e.kind==='wisp'){
    const orbit=Math.sin(game.roomTime*2.2+e.seed)*.5;if(d>230){e.x+=nx*e.speed*dt;e.y+=ny*e.speed*dt;}else if(d<150){e.x-=nx*e.speed*dt*.8;e.y-=ny*e.speed*dt*.8;}e.x+=-ny*orbit*22*dt;e.y+=nx*orbit*22*dt;
    if(e.attackCd<=0){const a=Math.atan2(player.y-e.y,player.x-e.x);spawnProjectile(e.x,e.y,Math.cos(a)*150,Math.sin(a)*150,8,'#98cbb5',true);e.attackCd=2.25;}
  }
  e.x=clamp(e.x,75,1205);e.y=clamp(e.y,85,645);
}
function spawnProjectile(x,y,vx,vy,damage,color,homing=false){game.projectiles.push({x,y,vx,vy,damage,color,life:3,r:7,homing,trail:[],age:0});}
function updateProjectiles(dt){for(let i=game.projectiles.length-1;i>=0;i--){const p=game.projectiles[i];p.age+=dt;if(p.homing){const a=Math.atan2(player.y-p.y,player.x-p.x);const speed=Math.hypot(p.vx,p.vy);p.vx=lerp(p.vx,Math.cos(a)*speed,.45*dt);p.vy=lerp(p.vy,Math.sin(a)*speed,.45*dt);}p.trail.push({x:p.x,y:p.y});if(p.trail.length>9)p.trail.shift();p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;if(Math.random()<.8)particle(p.x,p.y,p.color,rand(1,2.5),rand(-12,12),rand(-12,12),.2);if(Math.hypot(p.x-player.x,p.y-player.y)<p.r+player.r&&p.life>0){damagePlayer(p.damage,p.x,p.y);game.projectiles.splice(i,1);continue;}if(p.life<=0||p.x<-50||p.x>W+50||p.y<-50||p.y>H+50)game.projectiles.splice(i,1);}}
function updatePickups(dt){for(let i=game.pickups.length-1;i>=0;i--){const p=game.pickups[i];p.life-=dt;p.phase+=dt*3;const d=dist(player,p);if(d<140){const a=Math.atan2(player.y-p.y,player.x-p.x);const pull=(1-d/140)*260;p.x+=Math.cos(a)*pull*dt;p.y+=Math.sin(a)*pull*dt;}if(d<player.r+14){if(p.kind==='xp'){player.xp+=p.value;while(player.xp>=player.xpNeed){player.xp-=player.xpNeed;player.level++;player.xpNeed=Math.round(player.xpNeed*1.28);player.damage+=2;player.maxHp+=5;player.hp=Math.min(player.maxHp,player.hp+18);floater(player.x,player.y-34,'LEVEL '+player.level+'!','#f5d78c',20);sound('level');}}else{player.gold+=p.value;floater(p.x,p.y,'+'+p.value+' SHARDS','#e6c57f',12);}game.pickups.splice(i,1);updateUI();continue;}if(p.life<=0)game.pickups.splice(i,1);}}
function updateEffects(dt){for(let i=game.particles.length-1;i>=0;i--){const p=game.particles[i];if(p.ring){p.ring.rr+=(p.ring.max/p.ring.life)*dt;p.ring.life-=dt;if(p.ring.life<=0)game.particles.splice(i,1);continue;}p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.pow(p.drag||.93,dt*60);p.vy*=Math.pow(p.drag||.93,dt*60);p.life-=dt;if(p.life<=0)game.particles.splice(i,1);}for(let i=game.floaters.length-1;i>=0;i--){const f=game.floaters[i];f.y+=f.vy*dt;f.life-=dt;if(f.life<=0)game.floaters.splice(i,1);}for(let i=game.combatFX.length-1;i>=0;i--){game.combatFX[i].life-=dt;if(game.combatFX[i].life<=0)game.combatFX.splice(i,1);}for(let i=game.afterimages.length-1;i>=0;i--){game.afterimages[i].life-=dt;if(game.afterimages[i].life<=0)game.afterimages.splice(i,1);}game.impactFlash=Math.max(0,game.impactFlash-dt*3.8);game.shake=Math.max(0,game.shake-dt*34);game.toastTimer=Math.max(0,game.toastTimer-dt);if(game.toastTimer<=0)$('toast').classList.remove('show');}
function updateGame(dt){if(game.phase!=='playing')return;game.roomTime+=dt;player.runTime+=dt;updatePlayer(dt);for(const e of [...game.enemies])updateEnemy(e,dt);updateProjectiles(dt);updatePickups(dt);updateEffects(dt);if(game.portal){game.portal.pulse+=dt;if(dist(player,game.portal)<105)$('interactionHint').style.display='flex';else $('interactionHint').style.display='none';}else $('interactionHint').style.display='none';if(game.boss){$('bossFill').style.width=(game.boss.hp/game.boss.maxHp*100)+'%';$('bossPercent').textContent=Math.ceil(game.boss.hp/game.boss.maxHp*100)+'%';}if(Math.floor(player.runTime)%1===0)updateHUDLight();}
let hudTick=0;function updateHUDLight(){hudTick++;if(hudTick%8===0)updateUI();}

function drawWorld(){ctx.drawImage(background,0,0);const p=realms[game.stage].palette;
  // drifting motes and drifting haze bands
  const t=performance.now()/1000;ctx.save();ctx.globalAlpha=.08;for(let i=0;i<5;i++){const x=(i*287+t*7)%1400-60;const g=ctx.createRadialGradient(x,120+i*120,5,x,120+i*120,220);g.addColorStop(0,p.mist);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(x-220,30+i*100,440,150);}ctx.restore();
  if(game.portal){const q=game.portal;const pulse=.5+Math.sin(q.pulse*3.2)*.08;ctx.save();ctx.translate(q.x,q.y);ctx.scale(pulse,1/pulse);const glow=ctx.createRadialGradient(0,0,8,0,0,95);glow.addColorStop(0,p.portal+'88');glow.addColorStop(.5,p.portal+'30');glow.addColorStop(1,'transparent');ctx.fillStyle=glow;ctx.beginPath();ctx.arc(0,0,100,0,TAU);ctx.fill();ctx.strokeStyle=p.portal;ctx.globalAlpha=.8;ctx.lineWidth=5;ctx.beginPath();ctx.ellipse(0,0,33,47,0,0,TAU);ctx.stroke();ctx.globalAlpha=.5;ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(0,0,49,64,0,0,TAU);ctx.stroke();ctx.fillStyle='#f4daa3';ctx.globalAlpha=.8;ctx.font='12px DM Mono';ctx.textAlign='center';ctx.fillText('GATE',0,4);ctx.restore();for(let i=0;i<3;i++){const a=t*1.1+i*TAU/3;ctx.fillStyle=p.portal;ctx.globalAlpha=.8;ctx.beginPath();ctx.arc(q.x+Math.cos(a)*42,q.y+Math.sin(a)*57,2.5,0,TAU);ctx.fill();ctx.globalAlpha=1;}}
}
function drawSprite(name,x,y,w,h,angle=0,alpha=1,flash=false){const im=images[name];if(!im||!im.complete||!im.naturalWidth)return false;ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.globalAlpha=alpha;if(flash){ctx.shadowColor='#fff0c9';ctx.shadowBlur=20;}ctx.drawImage(im,-w/2,-h/2,w,h);ctx.restore();return true;}
function drawEnemy(e){
  const t=performance.now()/1000;const hit=e.hitStun>0;const bob=hit?0:Math.sin((e.anim||t)*4+e.seed)*2.4;
  ctx.save();ctx.fillStyle='#08100c';ctx.globalAlpha=.42;ctx.beginPath();ctx.ellipse(e.x,e.y+e.r*.64,e.r*(hit?1.22:1.12),e.r*.4,0,0,TAU);ctx.fill();ctx.restore();
  let face=Math.atan2(player.y-e.y,player.x-e.x)+Math.PI/2;
  if(e.state==='charge'||e.state==='burst')face=Math.atan2(e.chargeVY,e.chargeVX)+Math.PI/2;
  else if(e.state==='windup'&&e.kind!=='archer')face=Math.atan2(e.aimY-e.y,e.aimX-e.x)+Math.PI/2;
  const name=e.kind==='stalker'?'thornling':e.kind;const size=e.kind==='boss'?188:e.kind==='brute'?116:e.kind==='archer'?92:e.kind==='wisp'?66:84;const art=images[name];const aspect=art&&art.naturalWidth&&art.naturalHeight?art.naturalWidth/art.naturalHeight:1;
  let squashX=1,squashY=1,tilt=0,lift=0;
  if(e.state==='windup'){const pulse=Math.sin((1-e.stateT/.85)*Math.PI*4);squashX=1+.055*Math.max(0,pulse);squashY=1-.045*Math.max(0,pulse);lift=-Math.max(0,pulse)*3;}
  if(e.state==='charge'||e.state==='burst'){tilt=-.14;squashX=1.12;squashY=.9;}
  if(hit){tilt=.12*Math.sign(e.knockVX||1);squashX=.94;squashY=1.08;}
  const scale=e.kind==='boss'?1.18:1;
  ctx.save();ctx.translate(e.x,e.y+bob+lift);ctx.rotate(face+tilt);ctx.scale(squashX,squashY);ctx.globalAlpha=1;ctx.filter=e.flash>0?'brightness(1.7) saturate(.45)':'none';if(e.flash>0){ctx.shadowColor='#fff1c9';ctx.shadowBlur=28;}if(art&&art.complete&&art.naturalWidth)ctx.drawImage(art,-size*scale*aspect/2,-size*scale/2,size*scale*aspect,size*scale);ctx.restore();
  // Directional wind-up telegraphs tell the player exactly where danger is heading.
  if(e.state==='windup'){
    const pulse=.5+.5*Math.sin(t*15);ctx.save();ctx.lineCap='round';
    if(e.kind==='brute'||(e.kind==='boss'&&e.attackPattern==='charge')){
      const a=Math.atan2(e.aimY-e.y,e.aimX-e.x),len=Math.hypot(e.aimX-e.x,e.aimY-e.y);const tx=e.x+Math.cos(a)*len,ty=e.y+Math.sin(a)*len;
      ctx.globalAlpha=.18+.15*pulse;ctx.strokeStyle='#ff9b77';ctx.lineWidth=e.kind==='boss'?48:27;ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(tx,ty);ctx.stroke();
      ctx.globalAlpha=.8;ctx.strokeStyle='#ffd0a0';ctx.lineWidth=2.2;ctx.setLineDash([9,8]);ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(tx,ty);ctx.stroke();ctx.setLineDash([]);
      ctx.globalAlpha=.5+.4*pulse;ctx.strokeStyle='#ff9b77';ctx.lineWidth=3;ctx.beginPath();ctx.arc(tx,ty,e.kind==='boss'?e.r*.85:34,0,TAU);ctx.stroke();
    }else if(e.kind==='archer'){
      ctx.globalAlpha=.25+.28*pulse;ctx.strokeStyle='#f6c889';ctx.lineWidth=2;ctx.setLineDash([5,7]);ctx.beginPath();ctx.moveTo(e.x,e.y);ctx.lineTo(e.aimX,e.aimY);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#f6c889';ctx.globalAlpha=.6*pulse;ctx.beginPath();ctx.arc(e.aimX,e.aimY,10+7*pulse,0,TAU);ctx.fill();
    }else if(e.kind==='boss'&&e.attackPattern==='storm'){
      ctx.globalAlpha=.18+.18*pulse;ctx.strokeStyle='#ffae86';ctx.lineWidth=3;for(let i=0;i<12;i++){const a=i/12*TAU+t*.12;ctx.beginPath();ctx.moveTo(e.x+Math.cos(a)*e.r*.55,e.y+Math.sin(a)*e.r*.55);ctx.lineTo(e.x+Math.cos(a)*(e.r+100),e.y+Math.sin(a)*(e.r+100));ctx.stroke();}ctx.globalAlpha=.6*pulse;ctx.strokeStyle='#ffd0a2';ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+44+pulse*8,0,TAU);ctx.stroke();
    }
    ctx.globalAlpha=.45+.35*pulse;ctx.strokeStyle=e.kind==='boss'?'#ff9b77':'#efc178';ctx.lineWidth=e.kind==='boss'?3:2;ctx.beginPath();ctx.arc(e.x,e.y,e.r+15+pulse*5,0,TAU);ctx.stroke();ctx.restore();
  }
  if(e.kind!=='boss'&&e.hp<e.maxHp){ctx.save();ctx.fillStyle='rgba(5,10,8,.78)';ctx.fillRect(e.x-e.r,e.y-e.r-17,e.r*2,5);ctx.fillStyle=e.kind==='brute'?'#e18d69':'#b5d58d';ctx.fillRect(e.x-e.r,e.y-e.r-17,e.r*2*clamp(e.hp/e.maxHp,0,1),5);ctx.restore();}
}
function drawHeroRig(x,y,rotation,pose={},alpha=1,ghost=false){
  const time=pose.time??player.animTime;
  const move=clamp(pose.move??0,0,1);
  const attack=pose.attack??-1;
  const combo=pose.combo??1;
  const jump=clamp(pose.jump??0,0,1);
  const dash=clamp(pose.dash??0,0,1);
  const hurt=clamp(pose.hurt??0,0,1);
  const land=clamp(pose.land??0,0,1);
  const facing=rotation;
  const worldFacing=facing-Math.PI/2;
  const flipX=Math.cos(worldFacing)<-.12;
  const aimWorld=pose.aim??worldFacing;
  const aimLocal=flipX?Math.atan2(Math.sin(aimWorld),-Math.cos(aimWorld)):aimWorld;
  const dirX=Math.cos(aimLocal),dirY=Math.sin(aimLocal),perpX=-dirY,perpY=dirX;
  const phase=time*10.5;
  const stride=Math.sin(phase)*move;
  const bounce=Math.abs(Math.cos(phase*2)) * 4.2 * move;
  const jumpTuck=jump;
  const attackP=attack;
  const wind=attackP>=0&&attackP<.28?easeOut(attackP/.28):0;
  const strike=attackP>=.28&&attackP<.78?Math.sin((attackP-.28)/.5*Math.PI):0;
  const recover=attackP>=.78?1-(attackP-.78)/.22:0;
  const moveLean=Math.cos(worldFacing)*move*.13;
  const bodyLean=moveLean+(dash*.10)+(jumpTuck*-.08)+(strike*(combo===3?.25:.14))-(wind*.09)+(hurt*-.12);
  const bob=(bounce*(1-jumpTuck))-(land*2.5);
  const capeSwing=Math.sin(phase*.75)*move*4 + dash*9 + jumpTuck*5;

  // Ground shadow stays attached to the floor while the body rises into a real jump arc.
  if(!ghost){
    ctx.save();ctx.globalAlpha=alpha*(.34-jumpTuck*.13);ctx.fillStyle='#07100c';ctx.shadowColor='#030806';ctx.shadowBlur=18;
    ctx.beginPath();ctx.ellipse(x+dash*4,y+12,26+jumpTuck*9,10+jumpTuck*2,0,0,TAU);ctx.fill();ctx.restore();
  }

  ctx.save();ctx.globalAlpha=alpha;ctx.translate(x,y-(pose.z||0)*.82+bob);if(flipX)ctx.scale(-1,1);ctx.rotate(bodyLean);ctx.scale(1.16+strike*.065+dash*.05-land*.04,1.14-strike*.04-dash*.11+jumpTuck*.10+land*.035);
  if(pose.flash){ctx.filter='brightness(1.65) saturate(.55)';}

  // Hooded cloak and split tails, drawn behind the articulated limbs.
  ctx.save();ctx.translate(0,4);
  const cape=ctx.createLinearGradient(-18,-5,18,33);cape.addColorStop(0,'#244c46');cape.addColorStop(.48,'#183c37');cape.addColorStop(1,'#102b29');
  ctx.fillStyle=cape;ctx.strokeStyle='#6d8660';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(-12,-12);ctx.quadraticCurveTo(-22,-1,-18,12+capeSwing*.18);ctx.lineTo(-21,26+capeSwing);ctx.quadraticCurveTo(-11,24+capeSwing,0,34+capeSwing*1.4);ctx.quadraticCurveTo(9,25+capeSwing,21,28+capeSwing*.6);ctx.lineTo(17,9);ctx.quadraticCurveTo(18,-5,11,-13);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.strokeStyle='#a9b86f';ctx.globalAlpha*=.75;ctx.lineWidth=1.15;ctx.beginPath();ctx.moveTo(-8,-2);ctx.quadraticCurveTo(-4,12,-12,22);ctx.moveTo(5,0);ctx.quadraticCurveTo(8,13,14,22);ctx.stroke();ctx.restore();

  // Legs animate independently: opposite stride, bent knees, foot lift and boot roll.
  const legLift=jumpTuck*18;
  for(const side of [-1,1]){
    const swing=(side===-1?stride:-stride);
    let hipX=side*7,hipY=10;
    let kneeX=side*10+swing*11,kneeY=29-Math.max(0,swing)*4;
    let footX=side*10+swing*23,footY=49-Math.max(0,swing)*11;
    if(jumpTuck>.05){kneeX=side*12+swing*6;kneeY=18+legLift*.10;footX=side*16+swing*9;footY=27+legLift*.32;}
    if(attackP>=0){const plant=attackP<.5?1:1-(attackP-.5)*.6;footX+=side===1?-9*plant:5*plant;footY+=side===1?-7*plant:4*plant;}
    const shinW=side===1?7.6:6.7;
    ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle='#241f20';ctx.lineWidth=10;ctx.beginPath();ctx.moveTo(hipX,hipY);ctx.lineTo(kneeX,kneeY);ctx.stroke();
    const thigh=ctx.createLinearGradient(hipX,hipY,kneeX,kneeY);thigh.addColorStop(0,side===1?'#7d513d':'#684431');thigh.addColorStop(1,'#30282a');ctx.strokeStyle=thigh;ctx.lineWidth=7.2;ctx.beginPath();ctx.moveTo(hipX,hipY);ctx.lineTo(kneeX,kneeY);ctx.stroke();
    ctx.fillStyle='#b18b62';ctx.beginPath();ctx.arc(kneeX,kneeY,3.8,0,TAU);ctx.fill();
    ctx.strokeStyle='#1b2725';ctx.lineWidth=shinW+2;ctx.beginPath();ctx.moveTo(kneeX,kneeY);ctx.lineTo(footX,footY-2);ctx.stroke();
    const shin=ctx.createLinearGradient(kneeX,kneeY,footX,footY);shin.addColorStop(0,'#56625a');shin.addColorStop(.55,'#283b37');shin.addColorStop(1,'#172b29');ctx.strokeStyle=shin;ctx.lineWidth=shinW;ctx.beginPath();ctx.moveTo(kneeX,kneeY);ctx.lineTo(footX,footY-2);ctx.stroke();
    ctx.save();ctx.translate(footX,footY);ctx.rotate(swing*.24+jumpTuck*side*.12);const boot=ctx.createLinearGradient(-7,-4,8,8);boot.addColorStop(0,'#8b6244');boot.addColorStop(.45,'#4a342b');boot.addColorStop(1,'#241f20');ctx.fillStyle=boot;ctx.strokeStyle='#b08b60';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(0,0,7.5,5.3,0,0,TAU);ctx.fill();ctx.stroke();ctx.fillStyle='#d0ad79';ctx.fillRect(-2,-2,4,1.6);ctx.restore();
  }

  // Waist, torso and layered chest armour.
  const torso=ctx.createLinearGradient(-15,-15,15,18);torso.addColorStop(0,'#9a6d49');torso.addColorStop(.28,'#58463b');torso.addColorStop(.72,'#354c45');torso.addColorStop(1,'#1d302e');
  ctx.fillStyle='#172321';ctx.beginPath();ctx.roundRect(-14,-14,28,31,8);ctx.fill();ctx.fillStyle=torso;ctx.strokeStyle='#bd9662';ctx.lineWidth=1.35;ctx.beginPath();ctx.moveTo(-11,-12);ctx.quadraticCurveTo(0,-17,11,-12);ctx.lineTo(13,7);ctx.quadraticCurveTo(0,17,-13,7);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle='#b18a58';ctx.globalAlpha*=.92;ctx.beginPath();ctx.moveTo(-10,-8);ctx.lineTo(0,-13);ctx.lineTo(10,-8);ctx.lineTo(7,1);ctx.lineTo(0,5);ctx.lineTo(-7,1);ctx.closePath();ctx.fill();ctx.fillStyle='#355a50';ctx.beginPath();ctx.moveTo(-8,-7);ctx.lineTo(0,-10);ctx.lineTo(8,-7);ctx.lineTo(5,1);ctx.lineTo(0,3);ctx.lineTo(-5,1);ctx.closePath();ctx.fill();
  ctx.strokeStyle='#d0ad79';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-10,7);ctx.quadraticCurveTo(0,12,10,7);ctx.stroke();ctx.fillStyle='#e3c27e';ctx.beginPath();ctx.roundRect(-3,5,6,5,1.5);ctx.fill();ctx.fillStyle='#83e5cc';ctx.shadowColor='#8fffe2';ctx.shadowBlur=10;ctx.beginPath();ctx.moveTo(0,-8);ctx.lineTo(4,-4);ctx.lineTo(0,1);ctx.lineTo(-4,-4);ctx.closePath();ctx.fill();ctx.shadowBlur=0;
  // Leather belt and asymmetric shoulder guard.
  ctx.fillStyle='#3e2c27';ctx.beginPath();ctx.roundRect(-12,10,24,5,2);ctx.fill();ctx.strokeStyle='#c59a63';ctx.lineWidth=1;ctx.strokeRect(4,10,5,5);
  ctx.fillStyle='#9d754e';ctx.strokeStyle='#d6b37d';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(6,-14);ctx.lineTo(15,-12);ctx.lineTo(14,-3);ctx.lineTo(7,-1);ctx.lineTo(3,-7);ctx.closePath();ctx.fill();ctx.stroke();ctx.strokeStyle='#e0c68c';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(7,-10);ctx.lineTo(12,-7);ctx.stroke();

  // Head and hood are fixed to the spine; hair and braid react to the movement.
  ctx.save();ctx.translate(0,-22-jumpTuck*1.5);ctx.fillStyle='#123330';ctx.strokeStyle='#bb9b69';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,-15);ctx.quadraticCurveTo(18,-14,17,1);ctx.quadraticCurveTo(15,16,0,16);ctx.quadraticCurveTo(-17,13,-17,0);ctx.quadraticCurveTo(-16,-14,0,-15);ctx.fill();ctx.stroke();
  ctx.fillStyle='#c98a66';ctx.beginPath();ctx.ellipse(0,1,9.2,11.5,0,0,TAU);ctx.fill();
  ctx.fillStyle='#452a25';ctx.beginPath();ctx.moveTo(-10,1);ctx.quadraticCurveTo(-14,-14,-2,-17);ctx.quadraticCurveTo(11,-19,13,-5);ctx.lineTo(8,-7);ctx.quadraticCurveTo(1,-12,-4,-6);ctx.lineTo(-9,5);ctx.closePath();ctx.fill();
  ctx.fillStyle='#d69a73';ctx.beginPath();ctx.ellipse(0,2,6.7,8.8,0,0,TAU);ctx.fill();
  ctx.fillStyle='#292324';ctx.beginPath();ctx.ellipse(-3.3,1,1.6,1,0,0,TAU);ctx.ellipse(3.3,1,1.6,1,0,0,TAU);ctx.fill();ctx.strokeStyle='#703f35';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(-1,6);ctx.lineTo(1,6);ctx.stroke();
  ctx.fillStyle='#9d4d35';ctx.beginPath();ctx.moveTo(7,-8);ctx.quadraticCurveTo(18,-3,12,13);ctx.quadraticCurveTo(8,19,4,21);ctx.quadraticCurveTo(11,7,7,-8);ctx.fill();ctx.strokeStyle='#d28b5b';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(10,0);ctx.quadraticCurveTo(16,8,9,15);ctx.stroke();
  ctx.fillStyle='#d5b16e';ctx.beginPath();ctx.moveTo(-15,-7);ctx.lineTo(-10,-14);ctx.lineTo(-5,-12);ctx.strokeStyle='#d5b16e';ctx.lineWidth=2;ctx.stroke();ctx.restore();

  // Off-hand arm swings with the run cycle and lifts to balance a jump.
  const offShoulder={x:-10,y:-7};
  const offElbow={x:-17-stride*9,y:1-stride*6-jumpTuck*9};
  const offHand={x:-13-stride*15,y:10+jumpTuck*-18};
  ctx.lineCap='round';ctx.strokeStyle='#2c2925';ctx.lineWidth=8;ctx.beginPath();ctx.moveTo(offShoulder.x,offShoulder.y);ctx.lineTo(offElbow.x,offElbow.y);ctx.lineTo(offHand.x,offHand.y);ctx.stroke();
  ctx.strokeStyle='#52635a';ctx.lineWidth=5.4;ctx.beginPath();ctx.moveTo(offShoulder.x,offShoulder.y);ctx.lineTo(offElbow.x,offElbow.y);ctx.lineTo(offHand.x,offHand.y);ctx.stroke();
  ctx.fillStyle='#c08c67';ctx.beginPath();ctx.arc(offHand.x,offHand.y,4.2,0,TAU);ctx.fill();
  ctx.fillStyle='#ba9364';ctx.strokeStyle='#d4b47f';ctx.lineWidth=1;ctx.beginPath();ctx.roundRect(-17,-10,7,8,2);ctx.fill();ctx.stroke();

  // Sword arm has its own elbow and wrist pose, so the whole character never spins like a badge.
  const armShoulder={x:dirX>=0?10:-10,y:-7};
  let armElbow={x:armShoulder.x+dirX*8+perpX*5,y:armShoulder.y+dirY*8+perpY*5};
  let armHand={x:armShoulder.x+dirX*16+perpX*4,y:armShoulder.y+dirY*16+perpY*4};
  let bladeAngle=aimLocal-.55;
  if(attackP>=0){
    if(attackP<.28){const n=easeOut(attackP/.28);armElbow={x:armShoulder.x+dirX*(7+2*n)-perpX*4,y:armShoulder.y+dirY*(7+2*n)-perpY*4};armHand={x:armShoulder.x+dirX*(12+3*n)-perpX*12,y:armShoulder.y+dirY*(12+3*n)-perpY*12};bladeAngle=aimLocal+.65;}
    else if(attackP<.78){const n=easeOut((attackP-.28)/.5);const reach=19+7*Math.sin(n*Math.PI);const cross=(combo===2?-1:1)*11*Math.sin(n*Math.PI);armElbow={x:armShoulder.x+dirX*12+perpX*cross*.42,y:armShoulder.y+dirY*12+perpY*cross*.42};armHand={x:armShoulder.x+dirX*reach+perpX*cross,y:armShoulder.y+dirY*reach+perpY*cross};bladeAngle=aimLocal+lerp(.9,-.5,n)*(combo===2?-1:1);}
    else{const n=clamp((attackP-.78)/.22,0,1);armElbow={x:lerp(armShoulder.x+dirX*12,armShoulder.x+dirX*8,n),y:lerp(armShoulder.y+dirY*12,armShoulder.y+dirY*8,n)};armHand={x:lerp(armShoulder.x+dirX*20,armShoulder.x+dirX*15,n),y:lerp(armShoulder.y+dirY*20,armShoulder.y+dirY*15,n)};bladeAngle=lerp(aimLocal-.2,aimLocal-.55,n);}
  }else if(jumpTuck>.05){armElbow={x:armShoulder.x+dirX*8-perpX*4,y:armShoulder.y+dirY*8-perpY*4};armHand={x:armShoulder.x+dirX*14-perpX*8,y:armShoulder.y+dirY*14-perpY*8};bladeAngle=aimLocal-.25;}
  else if(dash>.05){armElbow={x:armShoulder.x+dirX*8,y:armShoulder.y+dirY*8};armHand={x:armShoulder.x+dirX*17,y:armShoulder.y+dirY*17};bladeAngle=aimLocal-.35;}
  else{armElbow={x:armShoulder.x+dirX*(8+stride*1.5)+perpX*4,y:armShoulder.y+dirY*(8+stride*1.5)+perpY*4};armHand={x:armShoulder.x+dirX*(16+stride*2)+perpX*4,y:armShoulder.y+dirY*(16+stride*2)+perpY*4};}
  ctx.strokeStyle='#282623';ctx.lineWidth=9;ctx.beginPath();ctx.moveTo(armShoulder.x,armShoulder.y);ctx.lineTo(armElbow.x,armElbow.y);ctx.lineTo(armHand.x,armHand.y);ctx.stroke();
  const sleeve=ctx.createLinearGradient(10,-7,armHand.x,armHand.y);sleeve.addColorStop(0,'#916447');sleeve.addColorStop(.55,'#435b50');sleeve.addColorStop(1,'#263a35');ctx.strokeStyle=sleeve;ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(armShoulder.x,armShoulder.y);ctx.lineTo(armElbow.x,armElbow.y);ctx.lineTo(armHand.x,armHand.y);ctx.stroke();
  ctx.fillStyle='#d19a72';ctx.beginPath();ctx.arc(armHand.x,armHand.y,4.6,0,TAU);ctx.fill();
  ctx.strokeStyle='#b89465';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(armElbow.x-3,armElbow.y+2);ctx.lineTo(armElbow.x+3,armElbow.y-2);ctx.stroke();

  // Blade hilt and steel are attached to the animated wrist, not a screen-space sticker.
  const swordLen=47+strike*5;const tipX=armHand.x+Math.cos(bladeAngle)*swordLen,tipY=armHand.y+Math.sin(bladeAngle)*swordLen;
  ctx.save();ctx.lineCap='round';ctx.strokeStyle='#5d3a29';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(armHand.x-Math.cos(bladeAngle)*7,armHand.y-Math.sin(bladeAngle)*7);ctx.lineTo(armHand.x+Math.cos(bladeAngle)*8,armHand.y+Math.sin(bladeAngle)*8);ctx.stroke();
  ctx.strokeStyle='#e2c18c';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(armHand.x+Math.cos(bladeAngle+Math.PI/2)*6,armHand.y+Math.sin(bladeAngle+Math.PI/2)*6);ctx.lineTo(armHand.x-Math.cos(bladeAngle+Math.PI/2)*6,armHand.y-Math.sin(bladeAngle+Math.PI/2)*6);ctx.stroke();
  const blade=ctx.createLinearGradient(armHand.x,armHand.y,tipX,tipY);blade.addColorStop(0,'#fff4d1');blade.addColorStop(.42,'#d5efe2');blade.addColorStop(1,'#6bbeb5');ctx.fillStyle=blade;ctx.shadowColor='#9bf5df';ctx.shadowBlur=ghost?0:9;ctx.beginPath();ctx.moveTo(armHand.x+Math.cos(bladeAngle+Math.PI/2)*3,armHand.y+Math.sin(bladeAngle+Math.PI/2)*3);ctx.lineTo(armHand.x+Math.cos(bladeAngle-Math.PI/2)*3,armHand.y+Math.sin(bladeAngle-Math.PI/2)*3);ctx.lineTo(tipX,tipY);ctx.closePath();ctx.fill();ctx.restore();
  ctx.restore();
}

function drawPlayer(){
  const speed=Math.hypot(player.vx,player.vy);
  const moving=clamp(speed/player.speed,0,1);
  const attack=player.attackTime>0?1-player.attackTime/player.attackDuration:-1;
  const jump=player.jumpZ>0?clamp(player.jumpZ/92,0,1):0;
  const dash=player.dashTime>0?clamp(player.dashTime/.22,0,1):0;
  const hurt=player.hurtTime>0?player.hurtTime/.25:0;
  const blink=player.invuln>0&&Math.floor(player.animTime*18)%2===0;
  // Recent dodge ghosts reuse the articulated pose, not the old rotating full-body PNG.
  for(const ghost of game.afterimages){const a=clamp(ghost.life/ghost.max,0,1);drawHeroRig(ghost.x,ghost.y,ghost.angle,{time:ghost.phase||player.animTime,move:.85,dash:.8,aim:player.attackAngle},a*.22,true);}
  drawHeroRig(player.x,player.y,player.facingAngle,{time:player.animTime,move:moving,attack,combo:player.combo||1,jump,dash,hurt,land:player.landTime/.22,z:player.jumpZ,aim:player.attackAngle,flash:player.hurtTime>0},blink?.58:1,false);
  // The slash trail is now a readable consequence of the hand-and-weapon motion.
  if(attack>=0){
    const a=player.attackAngle;const sweep=player.combo===3?2.9:player.combo===2?-2.35:2.25;
    const wind=player.combo===2?1.05:-1.12;let bladeAngle=a+wind;
    if(attack<.28)bladeAngle=a+wind-(player.combo===2?-.18:.18)*(attack/.28);
    else if(attack<.78)bladeAngle=a+wind+sweep*((attack-.28)/.5);
    else bladeAngle=a+wind+sweep*.98+(1-attack)*.45;
    const hx=player.x+Math.cos(a+Math.PI/2)*8,hy=player.y-player.jumpZ*.82+Math.sin(a+Math.PI/2)*8;
    const tipX=hx+Math.cos(bladeAngle)*55,tipY=hy+Math.sin(bladeAngle)*55;
    if(attack>.19&&attack<.86){ctx.save();ctx.globalAlpha=Math.sin((attack-.19)/.67*Math.PI)*.78;ctx.strokeStyle='#fff6cf';ctx.shadowColor='#f4c77d';ctx.shadowBlur=19;ctx.lineWidth=3.3;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(hx,hy);ctx.lineTo(tipX,tipY);ctx.stroke();ctx.restore();}
  }
  if(player.specialTime>0){ctx.save();const pulse=.5+.5*Math.sin(player.animTime*22);ctx.globalAlpha=.14+.12*pulse;const cy=player.y-player.jumpZ*.82;const g=ctx.createRadialGradient(player.x,cy,10,player.x,cy,92);g.addColorStop(0,'#fff5ca');g.addColorStop(.4,'#ffdc88');g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.beginPath();ctx.arc(player.x,cy,92,0,TAU);ctx.fill();ctx.restore();}
}
function drawEffects(){
  for(const p of game.pickups){const bob=Math.sin(p.phase)*4;ctx.save();ctx.translate(p.x,p.y+bob);ctx.shadowColor=p.kind==='xp'?'#b8db9e':'#f1c379';ctx.shadowBlur=14;ctx.fillStyle=p.kind==='xp'?'#a5c68b':'#dfb86f';ctx.beginPath();if(p.kind==='xp'){ctx.moveTo(0,-8);ctx.lineTo(7,0);ctx.lineTo(0,8);ctx.lineTo(-7,0);}else{ctx.arc(0,0,5,0,TAU);}ctx.fill();ctx.restore();}
  for(const p of game.projectiles){ctx.save();if(p.trail?.length>1){ctx.lineCap='round';for(let i=1;i<p.trail.length;i++){const a=i/p.trail.length;ctx.globalAlpha=a*.48;ctx.strokeStyle=p.color;ctx.lineWidth=1+a*7;ctx.shadowColor=p.color;ctx.shadowBlur=10;ctx.beginPath();ctx.moveTo(p.trail[i-1].x,p.trail[i-1].y);ctx.lineTo(p.trail[i].x,p.trail[i].y);ctx.stroke();}}ctx.globalAlpha=1;ctx.fillStyle='#fff4d4';ctx.shadowColor=p.color;ctx.shadowBlur=22;ctx.beginPath();ctx.arc(p.x,p.y,p.r*.72,0,TAU);ctx.fill();ctx.fillStyle=p.color;ctx.globalAlpha=.7;ctx.beginPath();ctx.arc(p.x,p.y,p.r*1.3,0,TAU);ctx.fill();ctx.restore();}
  for(const p of game.particles){if(p.ring){ctx.save();ctx.globalAlpha=clamp(p.ring.life/.36,0,1)*.6;ctx.strokeStyle='#ffe0a2';ctx.lineWidth=5;ctx.beginPath();ctx.arc(p.ring.x,p.ring.y,p.ring.rr,0,TAU);ctx.stroke();ctx.restore();continue;}ctx.save();ctx.globalAlpha=clamp(p.life/p.max,0,1);ctx.fillStyle=p.color;ctx.shadowColor=p.color;ctx.shadowBlur=8;ctx.beginPath();ctx.arc(p.x,p.y,p.size*clamp(p.life/p.max,.25,1),0,TAU);ctx.fill();ctx.restore();}
  for(const f of game.floaters){ctx.save();ctx.globalAlpha=clamp(f.life/f.max,0,1);ctx.fillStyle=f.color;ctx.font=`700 ${f.size}px Barlow Condensed, sans-serif`;ctx.textAlign='center';ctx.shadowColor='#111';ctx.shadowBlur=5;ctx.fillText(f.text,f.x,f.y);ctx.restore();}
}
function drawCombatFX(){
  const t=performance.now()/1000;
  for(const fx of game.combatFX){const p=1-clamp(fx.life/fx.max,0,1),fade=clamp(fx.life/fx.max,0,1);ctx.save();
    if(fx.type==='slash'){
      const combo=fx.combo||1;const sweep=combo===3?2.65:combo===2?2.25:2.05;const radius=combo===3?112:combo===2?98:88;const dir=combo===2?-1:1;const start=fx.angle-dir*(sweep*.58);const end=start+dir*sweep*easeOut(clamp(p,0,1));const alpha=Math.sin(Math.PI*clamp(p,0,1))*.95;
      ctx.translate(fx.x,fx.y);ctx.lineCap='round';ctx.globalAlpha=alpha;const grad=ctx.createLinearGradient(-radius,-radius,radius,radius);grad.addColorStop(0,'#fff9dc');grad.addColorStop(.35,fx.color||'#f0d3a0');grad.addColorStop(.75,'#8ed8d0');grad.addColorStop(1,'#fff3c4');
      ctx.strokeStyle=grad;ctx.shadowColor='#ffdf9b';ctx.shadowBlur=26;ctx.lineWidth=combo===3?16:11;ctx.beginPath();ctx.arc(0,0,radius,start,end,dir<0);ctx.stroke();
      ctx.globalAlpha=alpha*.58;ctx.shadowBlur=10;ctx.strokeStyle='#fff9dd';ctx.lineWidth=combo===3?4:2.8;ctx.beginPath();ctx.arc(0,0,radius-8,start,end,dir<0);ctx.stroke();
      ctx.globalAlpha=alpha*.24;ctx.strokeStyle='#f9dca3';ctx.lineWidth=28;ctx.beginPath();ctx.arc(0,0,radius+5,start,end,dir<0);ctx.stroke();
      const tip=end;const tx=Math.cos(tip)*radius,ty=Math.sin(tip)*radius;ctx.globalAlpha=alpha;ctx.fillStyle='#fffbe4';ctx.shadowBlur=24;ctx.beginPath();ctx.arc(tx,ty,combo===3?8:5,0,TAU);ctx.fill();
      if(combo===3){ctx.globalAlpha=alpha*.42;ctx.strokeStyle='#fff0ad';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,radius+19,start+.18,end-.15,dir<0);ctx.stroke();}
    }else if(fx.type==='impact'||fx.type==='impactGround'){
      const r=lerp(5,fx.type==='impact'?40:28,easeOut(p));const a=fx.angle||0;ctx.translate(fx.x,fx.y);ctx.rotate(a);ctx.globalAlpha=fade;ctx.strokeStyle=fx.color||'#ffe4a8';ctx.shadowColor=fx.color||'#ffe4a8';ctx.shadowBlur=18;ctx.lineWidth=fx.crit?4:2.5;ctx.beginPath();ctx.arc(0,0,r,-1.1,1.1);ctx.stroke();
      if(fx.type==='impact'){for(let i=0;i<9;i++){const ang=i/9*TAU;const len=(fx.crit?28:18)*(1-p*.5);ctx.globalAlpha=fade*(i%2?.75:.45);ctx.lineWidth=i%3===0?3:1.6;ctx.beginPath();ctx.moveTo(Math.cos(ang)*5,Math.sin(ang)*5);ctx.lineTo(Math.cos(ang)*len,Math.sin(ang)*len);ctx.stroke();}}
    }else if(fx.type==='solarBurst'){
      const r=fx.radius*easeOut(p);const alpha=Math.sin(Math.PI*fade);const grd=ctx.createRadialGradient(fx.x,fx.y,Math.max(1,r*.14),fx.x,fx.y,r);grd.addColorStop(0,'rgba(255,248,206,0)');grd.addColorStop(.72,'rgba(255,211,126,0.10)');grd.addColorStop(1,'rgba(255,211,126,0)');ctx.globalAlpha=alpha;ctx.fillStyle=grd;ctx.beginPath();ctx.arc(fx.x,fx.y,r,0,TAU);ctx.fill();
      for(let ring=0;ring<3;ring++){ctx.globalAlpha=alpha*(.65-ring*.13);ctx.strokeStyle=ring===0?'#fff4c9':ring===1?'#ffdb91':'#f2b66e';ctx.lineWidth=ring===0?5:2.5;ctx.shadowColor='#ffd88c';ctx.shadowBlur=20;ctx.beginPath();ctx.arc(fx.x,fx.y,r*(.76+ring*.12),0,TAU);ctx.stroke();}
      for(let i=0;i<24;i++){const a=i/24*TAU+t*.25;const inner=r*.72,outer=r*(.82+.18*Math.sin(t*12+i));ctx.globalAlpha=alpha*.5;ctx.strokeStyle='#fff0ba';ctx.lineWidth=i%3===0?3:1.3;ctx.beginPath();ctx.moveTo(fx.x+Math.cos(a)*inner,fx.y+Math.sin(a)*inner);ctx.lineTo(fx.x+Math.cos(a)*outer,fx.y+Math.sin(a)*outer);ctx.stroke();}
    }else if(fx.type==='deathBurst'){
      const r=fx.radius*easeOut(p);ctx.globalAlpha=fade*.55;ctx.strokeStyle=fx.color;ctx.shadowColor=fx.color;ctx.shadowBlur=26;ctx.lineWidth=fx.radius>80?5:3;ctx.beginPath();ctx.arc(fx.x,fx.y,r,0,TAU);ctx.stroke();ctx.globalAlpha=fade*.16;ctx.fillStyle=fx.color;ctx.beginPath();ctx.arc(fx.x,fx.y,r*.7,0,TAU);ctx.fill();
    }else if(fx.type==='dashBurst'||fx.type==='enemyCharge'){
      const a=fx.angle||0;ctx.translate(fx.x,fx.y);ctx.rotate(a);ctx.globalAlpha=fade*.7;ctx.strokeStyle=fx.color||'#d3f2dc';ctx.shadowColor=fx.color||'#d3f2dc';ctx.shadowBlur=18;ctx.lineCap='round';for(let i=0;i<5;i++){const yy=(i-2)*7;ctx.lineWidth=i===2?3:1.4;ctx.beginPath();ctx.moveTo(-10,yy);ctx.lineTo(36+p*70,yy);ctx.stroke();}
    }else if(fx.type==='jumpTakeoff'||fx.type==='landing'){
      const r=fx.type==='landing'?lerp(7,54,easeOut(p)):lerp(9,34,easeOut(p));
      ctx.globalAlpha=fade*(fx.type==='landing'?.58:.42);ctx.strokeStyle=fx.color||'#d8e9c0';ctx.shadowColor=fx.color||'#d8e9c0';ctx.shadowBlur=12;ctx.lineWidth=fx.type==='landing'?3:2;ctx.beginPath();ctx.ellipse(fx.x,fx.y+5,r,r*.38,0,0,TAU);ctx.stroke();
      if(fx.type==='landing'){ctx.globalAlpha=fade*.32;for(let i=0;i<10;i++){const a=i/10*TAU;ctx.beginPath();ctx.moveTo(fx.x+Math.cos(a)*r*.3,fx.y+Math.sin(a)*r*.12);ctx.lineTo(fx.x+Math.cos(a)*r,fx.y+Math.sin(a)*r*.32);ctx.stroke();}}
    }
    ctx.restore();
  }
}
function draw(){ctx.save();if(game.shake>0){const amp=game.shake;ctx.translate(rand(-amp,amp),rand(-amp,amp));}drawWorld();for(const e of game.enemies)drawEnemy(e);drawEffects();drawPlayer();drawCombatFX();if(game.impactFlash>0){ctx.save();ctx.globalAlpha=game.impactFlash*.12;ctx.fillStyle='#fff3d0';ctx.fillRect(0,0,W,H);ctx.restore();}ctx.restore();}

function updateUI(){
  $('healthFill').style.width=clamp(player.hp/player.maxHp*100,0,100)+'%';$('xpFill').style.width=clamp(player.xp/player.xpNeed*100,0,100)+'%';$('healthText').textContent=`${Math.ceil(player.hp)} / ${player.maxHp}`;$('xpText').textContent=`${Math.floor(player.xp)} / ${player.xpNeed} XP`;$('levelLabel').textContent='LVL '+String(player.level).padStart(2,'0');$('goldLabel').textContent=player.gold;$('killsLabel').textContent=player.kills;$('comboLabel').textContent=player.combo?`×${player.combo}`:'—';
  $('dashCooldown').style.width=(player.dashCd>0?player.dashCd/Math.max(.72,1.25-player.dodgeBonus*.75)*100:0)+'%';$('jumpCooldown').style.width=(player.jumpCd>0?player.jumpCd/.95*100:0)+'%';$('specialCooldown').style.width=(player.specialCd>0?player.specialCd/Math.max(3.8,8.5-player.solarBonus*2)*100:0)+'%';
  $('relicCount').textContent=`${runRelics.length} / 6`;$('relicGrid').innerHTML='';for(let i=0;i<6;i++){const el=document.createElement('div');if(runRelics[i]){el.className='relic-item';el.textContent=runRelics[i].icon;el.title=runRelics[i].name;}else{el.className='relic-empty';el.textContent='+';} $('relicGrid').appendChild(el);} $('relicFoot').textContent=runRelics.length?runRelics.map(r=>r.name).join(' · '):'Ancient blessings alter your playstyle.';
  const stepEls=$('progressSteps').children;for(let i=0;i<3;i++){stepEls[i].className='step '+(i<game.room?'done':i===game.room?'active':'');$('objectiveChecks').children[i].className='check-dot '+(i<game.room?'done':i===game.room?'active':'');}
}
function updateTimer(){const secs=Math.floor(player.runTime),m=Math.floor(secs/60),s=secs%60;$('timerLabel').textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;}

let audio=null;
function initAudio(){if(muted)return;try{audio ||= new (window.AudioContext||window.webkitAudioContext)();if(audio.state==='suspended')audio.resume();}catch{}}
function tone(freq,duration,type='sine',volume=.06,slide=0){if(muted)return;initAudio();if(!audio)return;const o=audio.createOscillator(),g=audio.createGain();o.type=type;o.frequency.setValueAtTime(freq,audio.currentTime);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(20,freq+slide),audio.currentTime+duration);g.gain.setValueAtTime(volume,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+duration);}
function sound(name){if(muted)return;const sets={start:[[220,.12,'sine',.035,120],[330,.22,'triangle',.035,80],[440,.32,'sine',.025,-70]],slash:[[145,.08,'sawtooth',.035,330],[310,.055,'triangle',.018,-90]],slash2:[[175,.085,'sawtooth',.04,390],[420,.07,'triangle',.022,-140]],slash3:[[115,.12,'sawtooth',.05,520],[250,.12,'triangle',.035,240],[610,.08,'sine',.025,-180]],dash:[[300,.19,'sine',.055,560],[780,.1,'triangle',.018,-440]],jump:[[185,.11,'triangle',.035,160],[390,.16,'sine',.022,250]],hurt:[[110,.22,'triangle',.07,-55]],kill:[[330,.08,'triangle',.045,220],[520,.12,'sine',.02,-80]],portal:[[220,.18,'sine',.05,330],[440,.3,'triangle',.035,180]],reward:[[440,.16,'sine',.04,220],[660,.22,'sine',.03,180]],solar:[[95,.2,'sawtooth',.05,680],[210,.32,'sine',.06,880],[540,.22,'triangle',.028,-130]],level:[[520,.12,'sine',.04,160],[780,.17,'sine',.04,190]],victory:[[330,.22,'triangle',.04,220],[440,.27,'sine',.04,220],[660,.55,'sine',.035,320]],defeat:[[220,.4,'triangle',.04,-100],[110,.5,'sine',.035,-40]]};for(const [f,d,t,v,s] of (sets[name]||[]))tone(f,d,t,v,s);}

function loop(now){const dt=clamp((now-game.previousFrame)/1000||0,.001,.033);game.previousFrame=now;if(game.phase==='playing'){if(game.hitStop>0){game.hitStop=Math.max(0,game.hitStop-dt);updateEffects(dt*.45);}else updateGame(dt);}else updateEffects(dt*.55);draw();updateTimer();requestAnimationFrame(loop);}

// Keyboard and pointer input
window.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(['arrowup','arrowdown','arrowleft','arrowright',' '].includes(k))e.preventDefault();input.keys.add(k);if(k==='j'&&!e.repeat)startAttack();if(k===' '&&!e.repeat)useDash();if(k==='shift'&&!e.repeat)useJump();if(k==='q'&&!e.repeat)useSpecial();if(k==='e'&&!e.repeat)interact();if(k==='escape'||k==='p'){if(game.phase==='playing')setPhase('paused');else if(game.phase==='paused')setPhase('playing');}});
window.addEventListener('keyup',e=>input.keys.delete(e.key.toLowerCase()));
function pointerPosition(e){const r=canvas.getBoundingClientRect();input.pointer.x=(e.clientX-r.left)/r.width*W;input.pointer.y=(e.clientY-r.top)/r.height*H;input.pointer.inside=input.pointer.x>=0&&input.pointer.x<=W&&input.pointer.y>=0&&input.pointer.y<=H;}
canvas.addEventListener('pointermove',e=>{pointerPosition(e);if(game.phase==='playing')aimAtPointer();});canvas.addEventListener('pointerenter',e=>{pointerPosition(e);});canvas.addEventListener('pointerleave',()=>{input.pointer.inside=false;});canvas.addEventListener('pointerdown',e=>{if(e.button!==0)return;pointerPosition(e);if(game.phase==='playing'){input.pointer.down=true;input.attackHeld=true;startAttack();}});window.addEventListener('pointerup',()=>{input.pointer.down=false;input.attackHeld=false;});canvas.addEventListener('contextmenu',e=>e.preventDefault());
$('startBtn').addEventListener('click',()=>{initAudio();startJourney(false);});$('continueBtn').addEventListener('click',()=>{if(meta.current){initAudio();startJourney(true);}});$('continueBtn').disabled=!meta.current;$('continueMeta').textContent=meta.current?'SAVE FOUND':'— NO SAVE —';$('resumeBtn').addEventListener('click',()=>setPhase('playing'));$('restartBtn').addEventListener('click',()=>{if(confirm('Restart this journey from the beginning?')){clearRunSave();startJourney(false);}});$('playAgainBtn').addEventListener('click',()=>startJourney(false));$('returnMenuBtn').addEventListener('click',()=>setPhase('menu'));
$('helpBtn').addEventListener('click',()=>$('helpModal').classList.remove('hidden'));$('closeHelp').addEventListener('click',()=>$('helpModal').classList.add('hidden'));$('helpModal').addEventListener('click',e=>{if(e.target===$('helpModal'))$('helpModal').classList.add('hidden');});
$('soundToggle').addEventListener('click',()=>{muted=!muted;meta.sound=!muted;persist();$('soundToggle').textContent=muted?'♪̸':'♪';if(!muted){initAudio();tone(440,.08,'sine',.03,130);}});
$('soundToggle').textContent=muted?'♪̸':'♪';$('fullscreenBtn').addEventListener('click',()=>{if(!document.fullscreenElement)frame.requestFullscreen?.();else document.exitFullscreen?.();});

// Mobile touch controls
const joy=$('joystick'),knob=$('joyKnob');let joyPointer=null,joyCenter=null;
joy.addEventListener('pointerdown',e=>{joyPointer=e.pointerId;joy.setPointerCapture(e.pointerId);const r=joy.getBoundingClientRect();joyCenter={x:r.left+r.width/2,y:r.top+r.height/2};moveJoy(e);});
joy.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)moveJoy(e);});function moveJoy(e){if(!joyCenter)return;let dx=e.clientX-joyCenter.x,dy=e.clientY-joyCenter.y;const len=Math.hypot(dx,dy),max=36;if(len>max){dx=dx/len*max;dy=dy/len*max;}input.joy.x=dx/max;input.joy.y=dy/max;knob.style.left=`calc(50% + ${dx}px)`;knob.style.top=`calc(50% + ${dy}px)`;}
function endJoy(){joyPointer=null;joyCenter=null;input.joy.x=input.joy.y=0;knob.style.left='50%';knob.style.top='50%';}joy.addEventListener('pointerup',endJoy);joy.addEventListener('pointercancel',endJoy);joy.addEventListener('lostpointercapture',endJoy);
$('mobileAttack').addEventListener('pointerdown',e=>{e.preventDefault();if(game.phase==='playing'){nearestAngle();startAttack();input.attackHeld=true;}});$('mobileAttack').addEventListener('pointerup',()=>input.attackHeld=false);$('mobileAttack').addEventListener('pointercancel',()=>input.attackHeld=false);$('mobileDash').addEventListener('pointerdown',e=>{e.preventDefault();useDash();});$('mobileJump').addEventListener('pointerdown',e=>{e.preventDefault();useJump();});$('mobileSpecial').addEventListener('pointerdown',e=>{e.preventDefault();nearestAngle();useSpecial();});

// Keep UI responsive on different device pixel ratios and update HUD safely.
window.addEventListener('resize',()=>{canvas.style.width='100%';});
if('ResizeObserver'in window)new ResizeObserver(()=>{canvas.style.width='100%';}).observe(frame);

// Boot into the title scene with a clean visual, without starting gameplay.
buildBackground();updateUI();setPhase('menu');requestAnimationFrame(loop);
