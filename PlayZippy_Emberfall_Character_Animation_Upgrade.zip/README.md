# Emberfall: The Last Hearth — Character Animation Update 1.3

This release addresses the static rotating-character problem. The hero is no longer rendered as one rotating full-body image. The game now draws an articulated character rig with independently animated legs, knees, boots, arms, wrists, cloak, torso and head.

## Character actions
- Locomotion cycle with alternating leg strides, knee bends, foot lift, arm counter-swing, body bounce and cloak motion.
- Direction-aware facing without spinning the full character: the body stays upright and mirrors for left/right facing; the sword arm aims independently at the target.
- A real jump on **Shift** (mobile jump button): directional horizontal leap, ballistic vertical arc, airborne tucked legs, raised arms, ground shadow separation, landing recovery, dust and a landing ring.
- Dodge remains on **Space** and does not roll the character sprite.
- Three-hit sword combo uses separate arm/weapon poses and synchronized attack arcs, hit-stop and enemy knockback.
- Existing realms, enemy behavior, progression, relics, saves and VFX are preserved.

## Controls
- `WASD` / arrow keys: move
- Mouse 1 / `J`: blade combo
- `Shift`: jump / leap
- `Space`: dodge
- `Q`: Solar Burst
- `E`: interact with gate
- `Esc` / `P`: pause

## Build and validation
Run `npm run build`. The static production site is generated in `dist/`. JavaScript syntax, production build, in-browser title/game startup, Shift jump, attack input and mobile jump control were checked with headless Chromium. No page errors were reported in the runtime check.

No advertising or AdSense integration is included.
