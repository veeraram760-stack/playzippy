# Emberfall 3.0.1 — The Last Hearth (PlayZippy)

This release changes the camera/presentation layer to match the provided reference: an elevated three-quarter arena view with a visible rear wall, receding floor plane, horizontal facing characters, perspective-scaled sprites, and floor shadows. The simulation remains on its existing gameplay plane; rendering uses an oblique projection and mouse targeting is inverse-projected back into the gameplay plane.

## Character rendering
- Lyra keeps the existing authored run, jump, attack-combo, and dodge atlas.
- Thornling, archer, and brute now use separate 4×4 authored animation atlases. The enemy AI state selects idle, run, attack, or hit/recoil frames.
- Enemies are drawn upright and face left/right; the enemy renderer no longer rotates and squashes a single static image to imply animation.
- Depth sorting, sprite sizing, shadows, floor telegraphs, projectiles, and combat effects are projected into the same camera space.

## Controls
- WASD / arrow keys: move
- Mouse / J: attack combo
- Shift: jump
- Space: dodge
- Q: Solar Burst
- E: enter the gate
- Esc: pause

## Build and checks
```bash
npm install --no-audit --no-fund
npm test
npm run build
```

The automated checks cover enemy AI actions, presentation projection, inverse pointer mapping, animation atlas presence/shape, and projected depth sorting. They are not a substitute for extended human playtesting.


## Emberfall 3.0 — The Last Hearth

The Verdant Hollow now unfolds across four chambers: Moss Gate, Rootbound Chapel, Hanging Orchard, and the Rootbound Warden. The later realms keep their existing three-room structure.

### Combat controls
- **WASD / Arrow keys:** move
- **Mouse 1 / J:** four-hit light chain
- **Hold K / right mouse button:** charge Sunbreaker; release to strike
- **F:** grab and throw a nearby foe
- **Shift:** jump; use J in the air for Sky Rend or K for Falling Star
- **Space:** Ember Dodge; a well-timed dodge triggers an automatic counter
- **C:** cycle Solar Nova, Lance, and Rupture
- **Q:** cast the selected Solar aspect
- **E:** enter an open ember gate
- **Esc / P:** pause

The raised terraces and connecting ramps use elevation-aware oblique projection. Root blooms can be detonated for area damage; hearthblooms restore health. The Hanging Orchard hides a root cache. The Verdant Warden has three combat phases, including a late-phase root sweep. Style actions contribute to the run grade.

### Build and tests
`npm test` runs the enemy behavior, 2.5D presentation, combat-data, and chamber-geometry checks. `npm run build` assembles the production site into `dist/`.


## 3.0.1 visual and AI corrections
- Removed the large duplicate control-preview strip below the arena; controls remain available in the Controls dialog.
- Increased enemy pursuit and repositioning so stalkers, archers, brutes, wisps, and the Warden visibly move during active combat.
- Lowered the locomotion animation threshold so side-stepping and close-range repositioning use the run animation instead of appearing idle.
