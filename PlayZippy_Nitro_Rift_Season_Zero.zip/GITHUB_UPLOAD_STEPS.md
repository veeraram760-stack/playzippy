# Upload the PlayZippy Season 1 release

1. Download `PlayZippy_Astra_Reclaimer_Season_1.zip` from this conversation.
2. Open https://github.com/veeraram760-stack/playzippy.
3. Select Add file → Upload files.
4. Upload the ZIP at the repository root (do not extract it first).
5. Commit to `main` with the message `Release PlayZippy Astra Reclaimer Season 1`.
6. Cloudflare Pages will detect the commit. If the deployment remains queued, retry it from Cloudflare Pages → Deployments.

Cloudflare Pages extracts this release ZIP, installs npm dependencies, runs the Vite production build and publishes `dist/`.
