# PlayZippy — Arcade update: Nitro Rift

PlayZippy is a responsive browser-game portal built with React and Vite. This update adds **Nitro Rift: Arena Rivals**, an original top-down kart-combat game designed around short competitive matches, vehicle handling, tactical pickups and local garage progression.

## Flagship game: Nitro Rift

- Three match modes: Knockout (first to 8 takedowns), Gem Rush (first to 25 rift shards) and Last Kart (three lives).
- Three arenas with distinct layouts and environmental behavior: Prism Plaza, Ember Works and Tidebreaker.
- Six karts on the arena at once: the player plus five bot rivals with steering, obstacle avoidance, pickups and combat behavior.
- Skill-based driving: acceleration, braking/reverse, steering, grip, drift, nitro boosts, boost pads, arena boundaries and collision response.
- Four weapon pickups: guided rockets, forward plasma bolts, proximity mines and EMP pulses.
- Shield ability that consumes nitro, hull damage, respawns, knockouts, score positions and end-of-match results.
- Persistent local garage: win/credit-based kart unlocks, engine/handling/armour upgrades, wins and personal stats.
- Desktop keyboard controls and touch controls for mobile. Short procedural sound effects can be muted in-game.

## Other games retained

- Astra Reclaimer — top-down action roguelite with operator skills, waves, bosses and upgrade choices.
- Starfall Assault — arcade space shooter.
- Neon Drift — endless traffic racer.
- Crystal Cascade — match-three puzzle.
- Panda Dash — jungle platform runner.
- Block Master — block placement puzzle.
- Memory Match — card matching.

## Run locally

Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

Vite outputs the production site into `dist/`.

## Nitro Rift controls

- **W / Up:** accelerate
- **S / Down:** brake, then reverse
- **A / Left, D / Right:** steer
- **Space:** drift
- **Shift:** nitro boost
- **J:** fire current weapon
- **E:** spend nitro to activate a short shield
- **H:** open the driver briefing
- Mobile: on-screen steering, gas, brake, drift, boost, fire and shield buttons.

Drive through glowing crates to switch weapons. Use boost pads to refill nitro. Ram opponents at speed, protect your hull, collect rift shards and save credits to upgrade or unlock karts. Progress is saved in localStorage on the current browser/device; it is not synced between devices.

## Deployment

Cloudflare Pages is connected to the `main` branch. The build command extracts the current release ZIP stored at the repository root, installs dependencies and runs `npm run build`, publishing `dist/`.

## Release limitations and testing status

- This is an original game using custom Canvas-drawn art and game logic. It is inspired by broad arcade kart-combat and skill-game conventions, not copied characters, tracks, levels or proprietary assets.
- JSX/JavaScript source syntax has been parsed successfully. A local Vite production build could not be run in this environment because npm dependency installation timed out; the next Cloudflare build must verify bundling and deployment.
- Gameplay requires hands-on testing in current desktop and mobile browsers. Bot drivers are local AI opponents, not online players. There is no server-backed matchmaking, global leaderboard or cross-device cloud save in this release.
- No ad network scripts are enabled. AdSense can be considered only after the site and gameplay meet the owner's quality bar and the site receives any required approval.
- Replace placeholder publisher contact details in the legal pages before a commercial launch.
