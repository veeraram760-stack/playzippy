# PlayZippy Arcade update — Nitro Rift: Arena Rivals

## Why this release exists

The previous catalog contained several short score-chasing prototypes. The goal of this update is to add a more substantial flagship game with a skill loop, combat decisions, varied match objectives and persistent rewards—not simply more menu screens.

## Nitro Rift gameplay

- Added three distinct modes: Knockout, Gem Rush and Last Kart.
- Added three arenas with different obstacle arrangements and hazards/slow zones.
- Added six-kart matches with five local AI rivals.
- Added acceleration, reverse, steering, drift grip, nitro boost, boost pads and obstacle collisions.
- Added four pickup weapons (rocket, plasma, mine and EMP), shield ability, hull health, respawns and takedown feedback.
- Added win/credit-based kart unlocks, permanent garage upgrades and local progression.
- Added desktop keyboard and mobile touch controls, short synthesized sound effects and a sound toggle.

## Existing portal content retained

The previous casual games and Astra Reclaimer remain available as secondary titles. Nitro Rift becomes the first featured game on the homepage.

## Known limits

- AI opponents are local bots; no real-time online multiplayer is present.
- Progress is saved locally with localStorage; no cross-device accounts or global leaderboard are present.
- JSX/JavaScript parsing passes. The local package installation timed out, so the fresh production bundle and Cloudflare deployment still require verification after this release ZIP is uploaded.
- Human playtesting and gameplay balancing are still required. Do not treat successful compilation as proof of fun or retention.
- All advertising remains disabled pending the owner's satisfaction with the games and any required network approval.
