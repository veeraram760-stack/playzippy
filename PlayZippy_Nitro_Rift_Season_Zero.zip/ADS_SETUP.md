# Advertising readiness

Ad slots are placeholders and are disabled. Do not insert network scripts until the publisher account is approved. Before enabling ads, add verified publisher identifiers, the provider's required consent flow, accurate privacy disclosures, and confirm that game layouts comply with ad placement policies.
