import React, { useEffect, useRef, useState } from "react";

const W = 420, H = 680;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

function drawCar(ctx, x, y, color, player = false) {
  ctx.save(); ctx.translate(x, y);
  ctx.shadowColor = player ? "#56e8ff" : "#000"; ctx.shadowBlur = player ? 22 : 8;
  ctx.fillStyle = "#050812";
  ctx.beginPath(); ctx.roundRect(-24, -31, 48, 68, 13); ctx.fill();
  const g = ctx.createLinearGradient(-20, -30, 21, 37); g.addColorStop(0, color); g.addColorStop(.5, player ? "#e7fbff" : color); g.addColorStop(1, color);
  ctx.fillStyle = g; ctx.beginPath(); ctx.roundRect(-20, -37, 40, 72, 12); ctx.fill();
  ctx.shadowBlur = 0;
  ctx.fillStyle = player ? "#173c5e" : "#182331"; ctx.beginPath(); ctx.roundRect(-14, -23, 28, 26, 8); ctx.fill();
  ctx.fillStyle = player ? "#8cf7ff" : "#9ec5db"; ctx.globalAlpha = .75; ctx.beginPath(); ctx.roundRect(-11, -20, 22, 11, 5); ctx.fill(); ctx.globalAlpha = 1;
  ctx.fillStyle = player ? "#b9fbff" : "#ff5d78"; ctx.beginPath(); ctx.roundRect(-15, 25, 9, 5, 2); ctx.roundRect(6, 25, 9, 5, 2); ctx.fill();
  ctx.fillStyle = "#080d18"; ctx.fillRect(-25, -23, 5, 17); ctx.fillRect(20, -23, 5, 17); ctx.fillRect(-25, 14, 5, 15); ctx.fillRect(20, 14, 5, 15);
  if (player) { ctx.strokeStyle = "#b6fbff"; ctx.lineWidth = 1.5; ctx.globalAlpha = .7; ctx.beginPath(); ctx.roundRect(-20, -37, 40, 72, 12); ctx.stroke(); }
  ctx.restore();
}

export default function NeonDrift() {
  const canvas = useRef(null), game = useRef(null);
  const [status, setStatus] = useState("ready"), [score, setScore] = useState(0), [gems, setGems] = useState(0);
  const [best, setBest] = useState(() => Number(localStorage.getItem("pz-neon-best") || 0));

  useEffect(() => {
    const c = canvas.current, ctx = c.getContext("2d");
    const s = game.current = { mode: "ready", x: W / 2, target: W / 2, items: [], particles: [], score: 0, gems: 0, frame: 0, speed: 4, lastSpawn: 0, shake: 0, best: Number(localStorage.getItem("pz-neon-best") || 0) };
    const keys = new Set(); let raf = 0, last = 0;
    const roadX = (y) => 42 + Math.sin(y / 185) * 9;
    const start = () => { s.mode = "playing"; s.items = []; s.particles = []; s.score = 0; s.gems = 0; s.frame = 0; s.speed = 4; s.x = W / 2; s.target = W / 2; s.shake = 0; setScore(0); setGems(0); setStatus("playing"); };
    s.start = start;
    const burst = (x, y, color, n = 14) => { for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, sp = 1 + Math.random() * 4; s.particles.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 25 + Math.random() * 18, color, size: 2 + Math.random() * 4 }); } };
    const draw = (dt) => {
      const t = s.frame; ctx.clearRect(0, 0, W, H);
      const bg = ctx.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, "#08152c"); bg.addColorStop(1, "#06101e"); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      // distant neon skyline
      for (let i = 0; i < 22; i++) { const x = i * 21 - 8, h = 35 + ((i * 47) % 90); ctx.fillStyle = i % 2 ? "#10213b" : "#0b1b32"; ctx.fillRect(x, 175 - h, 17, h); ctx.fillStyle = "#36d9e8"; ctx.globalAlpha = .25; for (let yy = 185 - h; yy < 170; yy += 13) ctx.fillRect(x + 5, yy, 3, 4); ctx.globalAlpha = 1; }
      ctx.fillStyle = "#0a1223"; ctx.beginPath(); ctx.moveTo(roadX(0), 0); ctx.lineTo(W - roadX(0), 0); ctx.lineTo(W - 18, H); ctx.lineTo(18, H); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "#19ddf5"; ctx.shadowColor = "#12dfff"; ctx.shadowBlur = 17; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(roadX(0), 0); ctx.lineTo(18, H); ctx.moveTo(W - roadX(0), 0); ctx.lineTo(W - 18, H); ctx.stroke(); ctx.shadowBlur = 0;
      // lane markers move toward the player
      for (let lane = 1; lane <= 2; lane++) { for (let i = 0; i < 14; i++) { const y = ((i * 62 + (t * s.speed * 2.5) % 62) % H); const curve = roadX(y); const x = lane === 1 ? W / 2 - 62 : W / 2 + 62; ctx.fillStyle = "#b7d6ec"; ctx.globalAlpha = .24 + y / H * .3; ctx.fillRect(x - curve * .12, y, 3, 24); ctx.globalAlpha = 1; } }
      // side streaks
      for (let i = 0; i < 16; i++) { const y = (i * 57 + (t * 5) % 57) % H; ctx.fillStyle = "#234b70"; ctx.fillRect(4, y, 4, 18); ctx.fillRect(W - 8, y, 4, 18); }
      s.items.forEach(o => {
        if (o.type === "gem") { ctx.save(); ctx.translate(o.x, o.y); ctx.rotate(t * .045); ctx.shadowColor = "#5ef9e6"; ctx.shadowBlur = 18; ctx.fillStyle = "#65ffe0"; ctx.beginPath(); ctx.moveTo(0, -12); ctx.lineTo(10, 0); ctx.lineTo(0, 12); ctx.lineTo(-10, 0); ctx.closePath(); ctx.fill(); ctx.fillStyle = "#fff"; ctx.globalAlpha = .65; ctx.fillRect(-2, -6, 3, 6); ctx.restore(); }
        else if (o.type === "barrier") { ctx.fillStyle = "#ff8f5b"; ctx.shadowColor = "#ff5c55"; ctx.shadowBlur = 14; ctx.beginPath(); ctx.roundRect(o.x - 25, o.y - 12, 50, 24, 7); ctx.fill(); ctx.shadowBlur = 0; ctx.fillStyle = "#3e2032"; for (let k = -18; k <= 18; k += 18) ctx.fillRect(o.x + k - 3, o.y - 7, 6, 14); }
        else drawCar(ctx, o.x, o.y, o.color, false);
      });
      s.particles.forEach(p => { ctx.globalAlpha = Math.max(0, p.life / 40); ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1; });
      // player glow
      drawCar(ctx, s.x, 570, "#3ac8ef", true);
      if (s.mode !== "playing") {
        ctx.fillStyle = "#020715a8"; ctx.fillRect(0, 0, W, H);
        ctx.textAlign = "center"; ctx.shadowColor = "#2ee9ff"; ctx.shadowBlur = 24; ctx.fillStyle = "#f1fbff"; ctx.font = "900 35px system-ui"; ctx.fillText(s.mode === "over" ? "RUN OVER" : "NEON DRIFT", W / 2, 270); ctx.shadowBlur = 0;
        ctx.fillStyle = "#9fb8d4"; ctx.font = "600 13px system-ui"; ctx.fillText(s.mode === "over" ? `Score ${Math.floor(s.score)}  ·  ${s.gems} energy cells` : "DODGE • COLLECT • SURVIVE", W / 2, 305);
        ctx.fillStyle = "#58f4df"; ctx.font = "800 14px system-ui"; ctx.fillText(s.mode === "over" ? "TAP PLAY AGAIN" : "TAP TO START", W / 2, 355);
      }
    };
    const loop = (now) => {
      const dt = Math.min(32, now - (last || now)); last = now;
      if (s.mode === "playing") {
        s.frame += dt / 16.67; s.score += dt * .012; s.speed = Math.min(10, 4 + s.score / 500);
        if (keys.has("ArrowLeft") || keys.has("a")) s.target -= 6 * dt / 16.67;
        if (keys.has("ArrowRight") || keys.has("d")) s.target += 6 * dt / 16.67;
        s.target = clamp(s.target, 75, W - 75); s.x += (s.target - s.x) * Math.min(1, dt / 85);
        s.lastSpawn += dt; if (s.lastSpawn > Math.max(420, 900 - s.score * 1.2)) { s.lastSpawn = 0; const r = Math.random(); const type = r < .35 ? "gem" : r < .55 ? "barrier" : "car"; s.items.push({ type, x: 78 + Math.random() * 264, y: -50, color: ["#ff5a72", "#7b76ff", "#ffa24c"][Math.floor(Math.random() * 3)] }); }
        s.items = s.items.filter(o => { o.y += s.speed * dt / 16.67; if (Math.abs(o.x - s.x) < (o.type === "gem" ? 22 : 36) && Math.abs(o.y - 570) < (o.type === "gem" ? 25 : 48)) { if (o.type === "gem") { s.gems++; s.score += 40; burst(o.x, o.y, "#62ffe0", 16); setGems(s.gems); return false; } s.mode = "over"; s.shake = 14; burst(s.x, 570, "#ff7b7b", 30); setStatus("over"); const v = Math.floor(s.score); setScore(v); setBest(b => { const n = Math.max(b, v); localStorage.setItem("pz-neon-best", String(n)); return n; }); return false; } return o.y < H + 60; });
        s.particles = s.particles.filter(p => { p.x += p.vx; p.y += p.vy; p.life--; return p.life > 0; });
        if (Math.floor(s.score) % 5 === 0) setScore(Math.floor(s.score));
      }
      draw(dt); raf = requestAnimationFrame(loop);
    };
    const keyDown = e => { if (["ArrowLeft", "ArrowRight", " "].includes(e.key)) e.preventDefault(); keys.add(e.key.toLowerCase()); if (e.key === " " && s.mode !== "playing") start(); };
    const keyUp = e => keys.delete(e.key.toLowerCase());
    const pointerMove = e => { if (s.mode === "playing") { const r = c.getBoundingClientRect(); s.target = clamp((e.clientX - r.left) * W / r.width, 75, W - 75); } };
    const pointerDown = e => { if (s.mode !== "playing") start(); else pointerMove(e); };
    window.addEventListener("keydown", keyDown); window.addEventListener("keyup", keyUp); c.addEventListener("pointermove", pointerMove); c.addEventListener("pointerdown", pointerDown);
    raf = requestAnimationFrame(loop);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("keydown", keyDown); window.removeEventListener("keyup", keyUp); c.removeEventListener("pointermove", pointerMove); c.removeEventListener("pointerdown", pointerDown); };
  }, []);

  const start = () => game.current?.start?.();
  return <div className="arcade-shell neon-shell">
    <div className="arcade-topline"><div><span className="live-dot"/> ARCADE • ENDLESS RACER</div><div className="arcade-stats"><span>BEST <b>{best.toLocaleString()}</b></span><span>ENERGY <b>{gems}</b></span></div></div>
    <div className="neon-frame"><canvas ref={canvas} width={W} height={H} aria-label="Neon Drift racing game"/><div className="canvas-hud"><span>⚡ {score.toLocaleString()}</span><span>BEST {best.toLocaleString()}</span></div></div>
    <div className="arcade-controls"><button className="touch-control" onPointerDown={e=>{e.preventDefault();game.current.target=Math.max(75,game.current.target-75)}}>←</button><button className="arcade-play" onClick={start}>{status === "playing" ? "RESTART RUN" : status === "over" ? "RACE AGAIN" : "START RACING"}</button><button className="touch-control" onPointerDown={e=>{e.preventDefault();game.current.target=Math.min(W-75,game.current.target+75)}}>→</button></div>
    <p className="arcade-instruction">Steer with <b>← →</b> or <b>A / D</b>. Drag across the track on mobile. Collect cyan energy shards and avoid traffic.</p>
  </div>;
}
