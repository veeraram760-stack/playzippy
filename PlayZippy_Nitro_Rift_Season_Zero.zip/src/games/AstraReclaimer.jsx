import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";

const W = 960;
const H = 600;
const SAVE_KEY = "pz-astra-reclaimer-profile-v1";
const SECTOR_LENGTH = 180;
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const rand = (a, b) => a + Math.random() * (b - a);
const dist2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;
const todayKey = () => new Date().toISOString().slice(0, 10);

const HEROES = [
  { id: "astra", name: "Astra Venn", title: "Rift Scout", icon: "✦", cost: 0, hp: 112, speed: 245, damage: 1, special: "Rift Pulse · clears bullets and blasts nearby enemies", ability: "RIFT PULSE", abilityCd: 18, color: "#8cf7ff" },
  { id: "bront", name: "Bront Kade", title: "Voidbreaker", icon: "⬡", cost: 260, hp: 150, speed: 208, damage: 1.08, special: "Bastion Core · restore hull and become fortified", ability: "BASTION CORE", abilityCd: 21, color: "#ffbd78" },
  { id: "nyx", name: "Nyx Solari", title: "Phase Dancer", icon: "✧", cost: 340, hp: 96, speed: 275, damage: 1.18, special: "Phase Bloom · vanish and unleash a radial volley", ability: "PHASE BLOOM", abilityCd: 17, color: "#c9a6ff" },
  { id: "vega", name: "Vega Rhys", title: "Aether Tactician", icon: "⌘", cost: 520, hp: 108, speed: 232, damage: 1.05, special: "Sentinel Array · deploy three autonomous gun-drones", ability: "SENTINEL ARRAY", abilityCd: 24, color: "#a9e6ff" }
];

const LAB = [
  { id: "vitality", name: "Reinforced Hull", icon: "♥", desc: "+10 starting health per rank", max: 8, base: 80 },
  { id: "might", name: "Pulse Calibration", icon: "✹", desc: "+6% weapon damage per rank", max: 8, base: 100 },
  { id: "magnet", name: "Shard Magnet", icon: "◈", desc: "+16% pickup range per rank", max: 6, base: 90 },
  { id: "armor", name: "Aegis Plating", icon: "⬡", desc: "Reduce incoming damage by 1 per rank", max: 5, base: 140 }
];

const UPGRADES = [
  { id: "pulse", name: "Pulse Amplifier", icon: "✦", desc: "+22% bolt damage", max: 6, tier: "weapon" },
  { id: "twin", name: "Split Chamber", icon: "⋈", desc: "Fire one extra bolt", max: 3, tier: "weapon" },
  { id: "haste", name: "Overclock", icon: "ϟ", desc: "+13% attack speed", max: 6, tier: "core" },
  { id: "blades", name: "Orbit Blades", icon: "✧", desc: "Summon a damaging blade around you", max: 4, tier: "weapon" },
  { id: "drone", name: "Scout Drone", icon: "◇", desc: "A drone joins your fire pattern", max: 3, tier: "weapon" },
  { id: "arc", name: "Chain Arc", icon: "⌁", desc: "Lightning jumps between nearby enemies", max: 4, tier: "weapon" },
  { id: "vitality", name: "Hull Matrix", icon: "♥", desc: "+24 max health and restore 24", max: 5, tier: "core" },
  { id: "armor", name: "Aegis Field", icon: "⬡", desc: "Reduce contact damage by 1", max: 4, tier: "core" },
  { id: "speed", name: "Phase Boots", icon: "➤", desc: "+9% movement speed", max: 5, tier: "core" },
  { id: "magnet", name: "Attractor Field", icon: "◉", desc: "+30% pickup radius", max: 5, tier: "core" },
  { id: "regen", name: "Nanite Repair", icon: "+", desc: "Recover 1 health every 7 seconds", max: 4, tier: "core" },
  { id: "salvage", name: "Salvage Protocol", icon: "▣", desc: "+18% crystal drop chance", max: 4, tier: "core" }
];

const SECTORS = [
  { name: "Glass Dunes", subtitle: "The abandoned relay fields", bg: "#101e35", glow: "#43e7ee", ground: "#19334a", boss: "The Sand Warden", enemy: ["drifter", "skitter", "spitter"] },
  { name: "Verdant Scar", subtitle: "A forest grown through the rift", bg: "#10251f", glow: "#82f2a4", ground: "#1b4439", boss: "Maw of the Canopy", enemy: ["skitter", "brute", "spitter"] },
  { name: "Obsidian Crown", subtitle: "The machine-heart of the breach", bg: "#21152e", glow: "#c49aff", ground: "#392347", boss: "The Crown Engine", enemy: ["brute", "spitter", "phantom"] },
  { name: "Sunken Archive", subtitle: "A drowned library of forbidden signals", bg: "#102b38", glow: "#65d7ff", ground: "#174455", boss: "The Drowned Curator", enemy: ["drifter", "phantom", "spitter", "brute"] },
  { name: "Astral Foundry", subtitle: "The furnace that forged the breach", bg: "#302018", glow: "#ffab67", ground: "#563222", boss: "The Starforged Colossus", enemy: ["skitter", "phantom", "brute", "spitter"] }
];

const EVOLUTIONS = [
  { id: "evo_nova", name: "Nova Lance", icon: "✹", desc: "Pulse bolts become piercing nova shots with explosive impact.", requires: { pulse: 5, twin: 2 }, tier: "evolution", detail: "PULSE + SPLIT CHAMBER" },
  { id: "evo_storm", name: "Storm Conductor", icon: "⌁", desc: "Chain lightning jumps farther, hits more targets and recharges faster.", requires: { arc: 3, drone: 2 }, tier: "evolution", detail: "CHAIN ARC + SCOUT DRONE" },
  { id: "evo_aegis", name: "Aegis Rebirth", icon: "⬡", desc: "Your shield regenerates hull and absorbs a larger share of every hit.", requires: { armor: 3, regen: 2 }, tier: "evolution", detail: "AEGIS FIELD + NANITE REPAIR" },
  { id: "evo_orbit", name: "Solar Orbit", icon: "✧", desc: "Orbit blades become a wider, faster ring of burning edges.", requires: { blades: 3, speed: 2 }, tier: "evolution", detail: "ORBIT BLADES + PHASE BOOTS" }
];

const MILESTONES = [
  { id: "first_boss", title: "Break the Gate", desc: "Defeat your first sector boss in a run", reward: 75, test: r => r.cleared >= 1 },
  { id: "elite_breaker", title: "Elite Breaker", desc: "Hunt down three elite enemies in one run", reward: 110, test: r => r.eliteKills >= 3 },
  { id: "build_architect", title: "Build Architect", desc: "Reach level 12 and assemble a deep build", reward: 130, test: r => r.level >= 12 },
  { id: "rift_conqueror", title: "Rift Conqueror", desc: "Clear all five sectors in one campaign", reward: 300, test: r => r.cleared >= 5 && !r.endless }
];

function freshProfile() {
  return { crystals: 0, runs: 0, bestSector: 0, bestKills: 0, bestLevel: 1, unlocked: ["astra"], hero: "astra", lab: { vitality: 0, might: 0, magnet: 0, armor: 0 }, daily: { date: "", claimed: false, bestKills: 0 }, achievements: [], bestEndless: 0 };
}
function readProfile() {
  try {
    const raw = JSON.parse(localStorage.getItem(SAVE_KEY) || "null");
    if (!raw) return freshProfile();
    return { ...freshProfile(), ...raw, bestEndless: raw.bestEndless || 0, lab: { ...freshProfile().lab, ...(raw.lab || {}) }, daily: { ...freshProfile().daily, ...(raw.daily || {}) } };
  } catch { return freshProfile(); }
}
function persistProfile(profile) { localStorage.setItem(SAVE_KEY, JSON.stringify(profile)); }

function makeRun(profile, heroId, daily = false, endless = false, difficulty = "standard") {
  const hero = HEROES.find(h => h.id === heroId) || HEROES[0];
  const lab = profile.lab || {};
  const health = hero.hp + (lab.vitality || 0) * 10;
  return {
    mode: "playing", sector: 0, time: 0, totalTime: 0, kills: 0, shards: 0, xp: 0, level: 1, xpNeed: 34,
    daily, endless, difficulty, loop: 1, player: { x: W / 2, y: H / 2, hp: health, maxHp: health, speed: hero.speed, damage: hero.damage * (1 + (lab.might || 0) * .06), armor: lab.armor || 0, magnet: 90 + (lab.magnet || 0) * 14, invuln: 0, dashCd: 0, dashTime: 0, abilityCd: 0, abilityTime: 0, armorTime: 0, turretTime: 0, turretCd: .2, fireCd: .2, bladeCd: 0, arcCd: 5, droneCd: 1.2, regenCd: 7, upgrades: {}, evolutions: [], moveX: 0, moveY: 0, facing: 1 },
    enemies: [], shots: [], hostile: [], pickups: [], particles: [], floats: [], boss: null, spawnCd: .2, id: 1, cameraShake: 0, sectorKills: 0, lastHud: 0, selectedUpgrades: [], reward: null, cleared: 0, clock: 0, nextEliteAt: 45, eliteKills: 0
  };
}

function addParticles(r, x, y, color, count = 8, power = 150) {
  for (let i = 0; i < count; i++) { const a = Math.random() * Math.PI * 2, s = rand(power * .28, power); r.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: rand(.22, .62), max: .62, size: rand(2, 5), color }); }
}
function enemyFor(r, elite = false) {
  const set = SECTORS[r.sector].enemy;
  let kind = set[Math.floor(Math.random() * set.length)];
  if (r.time > 75 && Math.random() < .18) kind = "brute";
  if (r.time > 105 && Math.random() < .16) kind = "phantom";
  const stats = {
    drifter: { hp: 24, speed: 72, damage: 9, radius: 13, color: "#f08b72", xp: 7, shard: .22 },
    skitter: { hp: 16, speed: 128, damage: 7, radius: 10, color: "#8ee5b1", xp: 6, shard: .18 },
    spitter: { hp: 35, speed: 52, damage: 8, radius: 14, color: "#b6a3ff", xp: 10, shard: .34, shoot: 2.8 },
    brute: { hp: 100, speed: 37, damage: 18, radius: 21, color: "#ffbe75", xp: 18, shard: .65 },
    phantom: { hp: 48, speed: 92, damage: 12, radius: 15, color: "#ff7dc7", xp: 14, shard: .48 }
  }[kind];
  const angle = Math.random() * Math.PI * 2, edge = Math.random();
  let x, y;
  if (edge < .25) { x = rand(0, W); y = -30; } else if (edge < .5) { x = W + 30; y = rand(0, H); } else if (edge < .75) { x = rand(0, W); y = H + 30; } else { x = -30; y = rand(0, H); }
  const scale = (1 + r.sector * .24 + r.totalTime / 520 + (r.loop - 1) * .34) * (r.difficulty === "veteran" ? 1.28 : r.difficulty === "story" ? .84 : 1);
  const enemy = { id: r.id++, kind, x, y, hp: stats.hp * scale, maxHp: stats.hp * scale, speed: stats.speed * (1 + r.sector * .04), damage: stats.damage * (1 + r.sector * .12) * (r.difficulty === "veteran" ? 1.18 : r.difficulty === "story" ? .86 : 1), radius: stats.radius, color: stats.color, xp: stats.xp, shard: stats.shard, shoot: stats.shoot || 0, shootCd: rand(1, 2.8), hitFlash: 0, slow: 0, wobble: rand(0, Math.PI * 2), elite: false };
  if (elite) { enemy.elite = true; enemy.eliteName = ["Rift Stalker", "Thorn Matriarch", "Null Reaver", "Archive Wraith", "Forge Alpha"][r.sector]; enemy.hp *= 3.2; enemy.maxHp = enemy.hp; enemy.speed *= 1.17; enemy.damage *= 1.35; enemy.radius *= 1.32; enemy.color = "#ffd37b"; enemy.xp *= 4; enemy.shard = 1; }
  return enemy;
}
function spawnBoss(r) {
  const names = SECTORS.map(s => s.boss);
  const colors = SECTORS.map(s => s.glow);
  const hp = 620 * (1 + r.sector * .53 + (r.loop - 1) * .72) * (r.daily ? 1.15 : 1) * (r.difficulty === "veteran" ? 1.35 : r.difficulty === "story" ? .84 : 1);
  r.boss = { x: W / 2, y: 105, hp, maxHp: hp, name: names[r.sector], color: colors[r.sector], phase: 0, shotCd: 1.5, summonCd: 4, spin: 0, pattern: 0, hitFlash: 0, radius: 48 };
  addParticles(r, W / 2, 105, colors[r.sector], 45, 260);
  r.floats.push({ x: W / 2, y: 190, text: `${names[r.sector].toUpperCase()} INCOMING`, color: colors[r.sector], life: 1.7 });
}
function getChoices(r) {
  const up = r.player.upgrades;
  const available = UPGRADES.filter(u => (up[u.id] || 0) < u.max).map(u => ({ ...u, rank: (up[u.id] || 0) + 1 }));
  const evolutions = EVOLUTIONS.filter(e => !r.player.evolutions.includes(e.id) && Object.entries(e.requires).every(([id, rank]) => (up[id] || 0) >= rank)).map(e => ({ ...e, rank: 1 }));
  const shuffled = [...available].sort(() => Math.random() - .5);
  const picks = evolutions.length ? [evolutions[Math.floor(Math.random() * evolutions.length)], ...shuffled.slice(0, 2)] : shuffled.slice(0, 3);
  return picks.length ? picks : [UPGRADES[0], UPGRADES[2], UPGRADES[6]].map(u => ({ ...u, rank: (up[u.id] || 0) + 1 }));
}
function getRewardChoices() {
  return [
    { id: "cache", icon: "◈", name: "Rift Cache", desc: "Recover 140 crystals for your workshop.", detail: "+140 CRYSTALS" },
    { id: "repair", icon: "♥", name: "Field Repair", desc: "Restore your hull and reinforce your plating.", detail: "FULL REPAIR" },
    { id: "forge", icon: "✦", name: "Overcharged Core", desc: "Permanently increase this expedition's weapon damage.", detail: "+16% DAMAGE" }
  ].sort(() => Math.random() - .5);
}

function RiftCanvas({ runRef, onMode, onFinish, onHud }) {
  const canvasRef = useRef(null);
  const keys = useRef(new Set());
  const pointer = useRef(null);
  const dashPressed = useRef(false);
  const abilityPressed = useRef(false);
  const callbackRef = useRef({ onMode, onFinish, onHud });
  callbackRef.current = { onMode, onFinish, onHud };

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d", { alpha: false });
    let raf = 0, last = 0, hudClock = 0;
    const bgStars = Array.from({ length: 95 }, () => ({ x: Math.random() * W, y: Math.random() * H, r: rand(.5, 1.8), a: rand(.15, .65), s: rand(5, 20) }));
    const draw = (r, dt) => {
      const sector = SECTORS[r?.sector || 0];
      const bg = ctx.createLinearGradient(0, 0, W, H); bg.addColorStop(0, sector.bg); bg.addColorStop(1, "#080d1d"); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      ctx.save();
      ctx.strokeStyle = `${sector.glow}0c`; ctx.lineWidth = 1;
      const shift = (r?.totalTime || 0) * 8 % 44;
      for (let x = -44 + shift; x < W + 44; x += 44) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
      for (let y = 0; y < H; y += 44) { ctx.beginPath(); ctx.moveTo(0, y + shift); ctx.lineTo(W, y + shift); ctx.stroke(); }
      bgStars.forEach(s => { s.y += s.s * dt * .12; if (s.y > H) s.y = 0; ctx.globalAlpha = s.a; ctx.fillStyle = "#cceaff"; ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2); ctx.fill(); }); ctx.globalAlpha = 1;
      const gx = W / 2, gy = H / 2;
      const aura = ctx.createRadialGradient(gx, gy, 10, gx, gy, 390); aura.addColorStop(0, `${sector.glow}12`); aura.addColorStop(1, "#00000000"); ctx.fillStyle = aura; ctx.fillRect(0, 0, W, H);
      // Ancient relay markings make each arena feel like a place, not an empty screen.
      ctx.save(); ctx.translate(gx, gy); ctx.rotate((r?.totalTime || 0) * .018); ctx.strokeStyle = `${sector.glow}21`; ctx.lineWidth = 2;
      for (let k = 0; k < 3; k++) { ctx.beginPath(); ctx.ellipse(0, 0, 150 + k * 42, 70 + k * 30, k * .65, 0, Math.PI * 2); ctx.stroke(); }
      for (let k = 0; k < 8; k++) { const a = k * Math.PI / 4; ctx.fillStyle = `${sector.glow}28`; ctx.beginPath(); ctx.arc(Math.cos(a) * 230, Math.sin(a) * 155, 5, 0, Math.PI * 2); ctx.fill(); }
      ctx.restore(); ctx.restore();
      if (!r) { ctx.textAlign = "center"; ctx.fillStyle = "#dce9ff"; ctx.font = "800 28px system-ui"; ctx.fillText("ASTRA RECLAIMER", W / 2, H / 2); return; }

      // Pickups
      r.pickups.forEach(p => { const pulse = 1 + Math.sin(r.clock * 6 + p.id) * .14; ctx.save(); ctx.translate(p.x, p.y); ctx.scale(pulse, pulse); ctx.shadowColor = p.type === "crystal" ? "#ffd37d" : p.type === "heal" ? "#87ffd2" : sector.glow; ctx.shadowBlur = 14; ctx.fillStyle = p.type === "crystal" ? "#ffcf75" : p.type === "heal" ? "#84ffca" : sector.glow; ctx.beginPath(); if (p.type === "xp") { ctx.moveTo(0, -7); ctx.lineTo(7, 0); ctx.lineTo(0, 7); ctx.lineTo(-7, 0); } else ctx.arc(0, 0, p.type === "crystal" ? 7 : 8, 0, Math.PI * 2); ctx.closePath(); ctx.fill(); ctx.restore(); });

      // Enemy projectiles
      r.hostile.forEach(b => { ctx.save(); ctx.shadowColor = b.color; ctx.shadowBlur = 13; ctx.fillStyle = b.color; ctx.beginPath(); ctx.arc(b.x, b.y, b.radius || 5, 0, Math.PI * 2); ctx.fill(); ctx.restore(); });
      // Player projectiles
      r.shots.forEach(b => { ctx.save(); ctx.strokeStyle = b.color; ctx.lineWidth = 4; ctx.shadowColor = b.color; ctx.shadowBlur = 15; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(b.x - b.vx * .025, b.y - b.vy * .025); ctx.lineTo(b.x, b.y); ctx.stroke(); ctx.restore(); });

      // Enemies
      r.enemies.forEach(e => {
        ctx.save(); ctx.translate(e.x, e.y); ctx.rotate(e.wobble + r.clock * (e.kind === "phantom" ? 1.5 : .28)); ctx.shadowColor = e.color; ctx.shadowBlur = e.hitFlash > 0 ? 25 : 10; ctx.fillStyle = e.hitFlash > 0 ? "#ffffff" : e.color;
        if (e.kind === "brute") { ctx.beginPath(); ctx.moveTo(0, -e.radius); ctx.lineTo(e.radius * .8, -e.radius * .45); ctx.lineTo(e.radius, e.radius * .5); ctx.lineTo(0, e.radius); ctx.lineTo(-e.radius, e.radius * .5); ctx.lineTo(-e.radius * .8, -e.radius * .45); ctx.closePath(); ctx.fill(); }
        else if (e.kind === "spitter") { ctx.beginPath(); for (let k = 0; k < 6; k++) { const a = k * Math.PI / 3; const x = Math.cos(a) * e.radius, y = Math.sin(a) * e.radius; k ? ctx.lineTo(x, y) : ctx.moveTo(x, y); } ctx.closePath(); ctx.fill(); }
        else if (e.kind === "phantom") { ctx.beginPath(); ctx.moveTo(0, -e.radius); ctx.quadraticCurveTo(e.radius * 1.5, -e.radius * .2, e.radius * .8, e.radius); ctx.lineTo(0, e.radius * .45); ctx.lineTo(-e.radius * .8, e.radius); ctx.quadraticCurveTo(-e.radius * 1.5, -e.radius * .2, 0, -e.radius); ctx.fill(); }
        else { ctx.beginPath(); ctx.arc(0, 0, e.radius, 0, Math.PI * 2); ctx.fill(); }
        ctx.shadowBlur = 0; ctx.fillStyle = "#12152b"; ctx.beginPath(); ctx.arc(-4, -2, 2.5, 0, Math.PI * 2); ctx.arc(4, -2, 2.5, 0, Math.PI * 2); ctx.fill(); ctx.restore();
        if (e.elite) { ctx.save(); ctx.strokeStyle = "#ffe4a0"; ctx.lineWidth = 2; ctx.shadowColor = "#ffc85b"; ctx.shadowBlur = 16; ctx.beginPath(); ctx.arc(e.x, e.y, e.radius + 8 + Math.sin(r.clock * 7) * 2, 0, Math.PI * 2); ctx.stroke(); ctx.textAlign = "center"; ctx.font = "900 8px system-ui"; ctx.fillStyle = "#ffe7ae"; ctx.fillText(e.eliteName.toUpperCase(), e.x, e.y - e.radius - 17); ctx.restore(); }
        if (e.hp < e.maxHp * .9) { ctx.fillStyle = "#050914aa"; ctx.fillRect(e.x - 14, e.y - e.radius - 9, 28, 3); ctx.fillStyle = e.color; ctx.fillRect(e.x - 14, e.y - e.radius - 9, 28 * Math.max(0, e.hp / e.maxHp), 3); }
      });

      if (r.boss) {
        const b = r.boss; ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(Math.sin(r.clock * .9) * .08); ctx.shadowColor = b.color; ctx.shadowBlur = 28; ctx.fillStyle = b.hitFlash > 0 ? "#fff" : b.color;
        ctx.beginPath(); ctx.moveTo(0, -b.radius); ctx.lineTo(b.radius * 1.2, -b.radius * .45); ctx.lineTo(b.radius * 1.05, b.radius * .7); ctx.lineTo(0, b.radius * 1.15); ctx.lineTo(-b.radius * 1.05, b.radius * .7); ctx.lineTo(-b.radius * 1.2, -b.radius * .45); ctx.closePath(); ctx.fill(); ctx.shadowBlur = 0; ctx.fillStyle = "#18132d"; ctx.beginPath(); ctx.arc(-16, -4, 6, 0, Math.PI * 2); ctx.arc(16, -4, 6, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = "#fff3db"; ctx.fillRect(-7, 18, 14, 4); ctx.restore();
        ctx.fillStyle = "#080b17cc"; ctx.fillRect(W / 2 - 185, 20, 370, 10); ctx.fillStyle = b.color; ctx.fillRect(W / 2 - 185, 20, 370 * Math.max(0, b.hp / b.maxHp), 10); ctx.textAlign = "center"; ctx.font = "900 10px system-ui"; ctx.fillStyle = "#eaf0ff"; ctx.fillText(b.name.toUpperCase(), W / 2, 15);
      }

      // orbit blades
      if (r.player.upgrades.blades) { const n = r.player.upgrades.blades; for (let i = 0; i < n; i++) { const orbitRadius = r.player.evolutions?.includes("evo_orbit") ? 62 : 45, a = r.clock * (r.player.evolutions?.includes("evo_orbit") ? 3.6 : 2.2 + n * .12) + i * Math.PI * 2 / n, x = r.player.x + Math.cos(a) * orbitRadius, y = r.player.y + Math.sin(a) * orbitRadius; ctx.save(); ctx.translate(x, y); ctx.rotate(a); ctx.shadowColor = "#8cf7ff"; ctx.shadowBlur = 15; ctx.fillStyle = "#c7fbff"; ctx.beginPath(); ctx.moveTo(0, -11); ctx.lineTo(6, 0); ctx.lineTo(0, 11); ctx.lineTo(-6, 0); ctx.closePath(); ctx.fill(); ctx.restore(); } }
      // Operator signature satellites (Vega's temporary sentry array).
      if (r.player.turretTime > 0) { for(let i=0;i<3;i++){const a=r.clock*1.8+i*Math.PI*2/3,tx=r.player.x+Math.cos(a)*38,ty=r.player.y+Math.sin(a)*38;ctx.save();ctx.translate(tx,ty);ctx.rotate(a);ctx.shadowColor="#a9e6ff";ctx.shadowBlur=18;ctx.fillStyle="#c9f1ff";ctx.fillRect(-5,-5,10,10);ctx.strokeStyle="#ffffff";ctx.strokeRect(-5,-5,10,10);ctx.restore();} }
      // Player
      const p = r.player; ctx.save(); ctx.translate(p.x, p.y); ctx.globalAlpha = p.invuln > 0 && Math.floor(r.clock * 18) % 2 ? .36 : 1; ctx.shadowColor = heroColor(r.hero); ctx.shadowBlur = 26; ctx.fillStyle = "#142943"; ctx.beginPath(); ctx.arc(0, 0, 20, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0; ctx.strokeStyle = heroColor(r.hero); ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, 16, 0, Math.PI * 2); ctx.stroke(); ctx.fillStyle = "#eaffff"; ctx.beginPath(); ctx.moveTo(0, -13); ctx.lineTo(8, 8); ctx.lineTo(0, 4); ctx.lineTo(-8, 8); ctx.closePath(); ctx.fill(); ctx.restore();
      if (p.dashTime > 0) { ctx.strokeStyle = `${heroColor(r.hero)}66`; ctx.lineWidth = 4; ctx.beginPath(); ctx.arc(p.x, p.y, 34 + Math.sin(r.clock * 30) * 3, 0, Math.PI * 2); ctx.stroke(); }
      // Particles
      r.particles.forEach(q => { ctx.globalAlpha = clamp(q.life / q.max, 0, 1); ctx.fillStyle = q.color; ctx.beginPath(); ctx.arc(q.x, q.y, q.size, 0, Math.PI * 2); ctx.fill(); }); ctx.globalAlpha = 1;
      r.floats.forEach(f => { ctx.globalAlpha = clamp(f.life / 1, 0, 1); ctx.textAlign = "center"; ctx.font = "900 12px system-ui"; ctx.fillStyle = f.color; ctx.fillText(f.text, f.x, f.y); }); ctx.globalAlpha = 1;
      // pointer joystick anchor
      if (pointer.current) { ctx.globalAlpha = .32; ctx.strokeStyle = "#dffaff"; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(pointer.current.sx, pointer.current.sy, 40, 0, Math.PI * 2); ctx.stroke(); ctx.fillStyle = "#dffaff"; ctx.beginPath(); ctx.arc(pointer.current.x, pointer.current.y, 13, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1; }
      ctx.restore();
    };
    function heroColor(id) { return HEROES.find(h => h.id === id)?.color || "#8cf7ff"; }
    const finish = (won) => {
      const r = runRef.current; if (!r || r.finished) return; r.finished = true; r.mode = won ? "victory" : "defeat";
      const prof = readProfile();
      const baseBanked = Math.floor(r.shards * (won ? 1 : .72)) + (won ? 260 : r.cleared * 45);
      const banked = Math.floor(baseBanked * (r.difficulty === "veteran" ? 1.3 : r.difficulty === "story" ? .85 : 1));
      prof.crystals += banked; prof.runs += 1; prof.bestSector = Math.max(prof.bestSector, r.cleared || (r.sector + (won ? 1 : 0))); if (r.endless) prof.bestEndless = Math.max(prof.bestEndless || 0, r.cleared || 0); prof.bestKills = Math.max(prof.bestKills, r.kills); prof.bestLevel = Math.max(prof.bestLevel, r.level);
      if (r.daily && prof.daily.date !== todayKey()) prof.daily = { date: todayKey(), claimed: false, bestKills: 0 };
      if (r.daily) prof.daily.bestKills = Math.max(prof.daily.bestKills || 0, r.kills);
      if (!prof.achievements.includes("first-run")) prof.achievements.push("first-run");
      if (r.kills >= 100 && !prof.achievements.includes("century")) prof.achievements.push("century");
      const newlyEarned = MILESTONES.filter(m => m.test(r) && !prof.achievements.includes(m.id));
      newlyEarned.forEach(m => prof.achievements.push(m.id));
      const milestoneBonus = newlyEarned.reduce((sum, m) => sum + m.reward, 0);
      prof.crystals += milestoneBonus;
      persistProfile(prof); callbackRef.current.onFinish(prof, { won, banked: banked + milestoneBonus, milestoneBonus, newlyEarned: newlyEarned.map(m => m.title), kills: r.kills, level: r.level, sector: r.cleared || (r.sector + (won ? 1 : 0)), shards: r.shards, duration: r.totalTime, endless: r.endless, loop: r.loop });
      callbackRef.current.onMode(won ? "victory" : "defeat");
    };
    const tick = (now) => {
      const dt = Math.min(.035, Math.max(0, (now - (last || now)) / 1000)); last = now;
      const r = runRef.current;
      if (r && r.mode === "playing") {
        r.clock += dt; r.time += dt; r.totalTime += dt; const p = r.player; const sector = SECTORS[r.sector];
        let mx = 0, my = 0; if (keys.current.has("a") || keys.current.has("arrowleft")) mx--; if (keys.current.has("d") || keys.current.has("arrowright")) mx++; if (keys.current.has("w") || keys.current.has("arrowup")) my--; if (keys.current.has("s") || keys.current.has("arrowdown")) my++;
        if (pointer.current) { const dx = pointer.current.x - pointer.current.sx, dy = pointer.current.y - pointer.current.sy; const len = Math.hypot(dx, dy); if (len > 8) { mx += dx / len; my += dy / len; } }
        const len = Math.hypot(mx, my) || 1; mx /= len; my /= len; if (mx || my) { p.facing = mx || p.facing; p.x += mx * p.speed * (p.dashTime > 0 ? 2.15 : 1) * dt; p.y += my * p.speed * (p.dashTime > 0 ? 2.15 : 1) * dt; }
        p.x = clamp(p.x, 24, W - 24); p.y = clamp(p.y, 34, H - 24); p.invuln = Math.max(0, p.invuln - dt); p.dashCd = Math.max(0, p.dashCd - dt); p.dashTime = Math.max(0, p.dashTime - dt); p.arcCd -= dt; p.regenCd -= dt;
        if (dashPressed.current && p.dashCd <= 0) { p.dashCd = 4; p.dashTime = .25; p.invuln = Math.max(p.invuln, .45); addParticles(r, p.x, p.y, heroColor(r.hero), 18, 230); dashPressed.current = false; }
        p.abilityCd = Math.max(0, p.abilityCd - dt); p.abilityTime = Math.max(0, p.abilityTime - dt); p.armorTime = Math.max(0, p.armorTime - dt);
        if (abilityPressed.current) {
          abilityPressed.current = false;
          if (p.abilityCd <= 0) {
            const hero = HEROES.find(h => h.id === r.hero) || HEROES[0];
            p.abilityCd = hero.abilityCd;
            if (r.hero === "astra") {
              r.hostile = []; let hits = 0;
              for (const e of r.enemies) if (dist2(p, e) < 265 ** 2) { e.hp -= 105 * p.damage; e.slow = 2.4; e.hitFlash = .2; hits++; addParticles(r, e.x, e.y, "#9af7ff", 12, 190); }
              if (r.boss && dist2(p, r.boss) < 310 ** 2) { r.boss.hp -= 145 * p.damage; r.boss.hitFlash = .25; hits++; }
              addParticles(r, p.x, p.y, "#8cf7ff", 55, 320); r.floats.push({ x:p.x, y:p.y-44, text:`RIFT PULSE · ${hits} HITS`, color:"#a8fbff", life:1.1 });
            } else if (r.hero === "bront") {
              p.hp = Math.min(p.maxHp, p.hp + 42); p.armorTime = 5.5; p.invuln = Math.max(p.invuln, 1.25); addParticles(r, p.x, p.y, "#ffd18a", 38, 245); r.floats.push({ x:p.x, y:p.y-44, text:"BASTION CORE · FORTIFIED", color:"#ffe0a9", life:1.2 });
            } else if (r.hero === "vega") {
              p.turretTime = 10; p.turretCd = .1; p.invuln = Math.max(p.invuln, .45); addParticles(r,p.x,p.y,"#a9e6ff",42,260); r.floats.push({x:p.x,y:p.y-44,text:"SENTINEL ARRAY · ONLINE",color:"#c8f2ff",life:1.2});
            } else {
              p.invuln = Math.max(p.invuln, 1.35); p.dashTime = .42; const burst = 16;
              for (let i=0;i<burst;i++) { const a=i*Math.PI*2/burst; r.shots.push({x:p.x,y:p.y,vx:Math.cos(a)*390,vy:Math.sin(a)*390,damage:34*p.damage,pierce:1,life:1.12,hit:[],color:"#d7b7ff"}); }
              addParticles(r,p.x,p.y,"#c9a6ff",50,290); r.floats.push({x:p.x,y:p.y-44,text:"PHASE BLOOM",color:"#decaff",life:1.1});
            }
          }
        }
        if (p.regenCd <= 0) { p.hp = Math.min(p.maxHp, p.hp + (p.evolutions.includes("evo_aegis") ? 4 : 1)); p.regenCd = Math.max(2.1, 7 - (p.upgrades.regen || 0) * .9 - (p.evolutions.includes("evo_aegis") ? 2.4 : 0)); }
        // Continuous offensive loop: bolt + optional orbit, drone and arc modules.
        p.fireCd -= dt; if (p.fireCd <= 0 && r.enemies.length + (r.boss ? 1 : 0)) {
          const target = r.boss || r.enemies.reduce((best, e) => !best || dist2(p, e) < dist2(p, best) ? e : best, null);
          if (target) { const dx = target.x - p.x, dy = target.y - p.y, d = Math.hypot(dx, dy) || 1, level = p.upgrades.twin || 0, n = 1 + Math.floor(level / 2), nova = p.evolutions.includes("evo_nova"); for (let i = 0; i < n; i++) { const spread = (i - (n - 1) / 2) * .12, a = Math.atan2(dy, dx) + spread; r.shots.push({ x: p.x, y: p.y, vx: Math.cos(a) * (nova ? 590 : 520), vy: Math.sin(a) * (nova ? 590 : 520), damage: 18 * p.damage * (1 + (p.upgrades.pulse || 0) * .22) * (nova ? 1.72 : 1), pierce: nova ? 3 : level >= 3 ? 1 : 0, life: 1.3, hit: [], color: nova ? "#fff0a6" : sector.glow, nova }); } }
          p.fireCd = Math.max(.18, .62 / (1 + (p.upgrades.haste || 0) * .13));
        }
        if ((p.upgrades.drone || 0) > 0) { p.droneCd -= dt; if (p.droneCd <= 0 && r.enemies.length) { const target = r.enemies.reduce((best, e) => !best || dist2(p, e) < dist2(p, best) ? e : best, null); if (target) { const dx = target.x - p.x, dy = target.y - p.y, d = Math.hypot(dx, dy) || 1; r.shots.push({ x: p.x + 24, y: p.y - 20, vx: dx / d * 430, vy: dy / d * 430, damage: 14 * (p.upgrades.drone || 1), pierce: 0, life: 1.3, hit: [], color: "#ffcf84" }); } p.droneCd = Math.max(.42, 1.65 - (p.upgrades.drone || 0) * .24); } }
        p.turretTime = Math.max(0, p.turretTime - dt); p.turretCd -= dt;
        if (p.turretTime > 0 && p.turretCd <= 0 && r.enemies.length) { const target = r.enemies.reduce((best,e)=>!best || dist2(p,e)<dist2(p,best)?e:best,null); if(target){ for(let i=0;i<3;i++){ const a=r.clock*1.8+i*Math.PI*2/3, sx=p.x+Math.cos(a)*38, sy=p.y+Math.sin(a)*38, dx=target.x-sx, dy=target.y-sy, d=Math.hypot(dx,dy)||1; r.shots.push({x:sx,y:sy,vx:dx/d*470,vy:dy/d*470,damage:22*p.damage,pierce:0,life:1.2,hit:[],color:"#b5edff"}); } } p.turretCd=.48; }
        if ((p.upgrades.arc || 0) > 0 && p.arcCd <= 0 && r.enemies.length) { const target = r.enemies.reduce((best, e) => !best || dist2(p, e) < dist2(p, best) ? e : best, null); const evolvedStorm = p.evolutions.includes("evo_storm"); const chain = 2 + p.upgrades.arc + (evolvedStorm ? 3 : 0); let from = { x: p.x, y: p.y }; const used = new Set(); for (let i = 0; i < chain && target; i++) { const next = r.enemies.filter(e => !used.has(e.id)).reduce((best, e) => !best || dist2(from, e) < dist2(from, best) ? e : best, null); if (!next || dist2(from, next) > (evolvedStorm ? 245 : 180) ** 2) break; used.add(next.id); next.hp -= 32 * p.damage * p.upgrades.arc * (evolvedStorm ? 1.85 : 1); next.hitFlash = .12; addParticles(r, next.x, next.y, "#b9faff", 7, 100); from = next; } p.arcCd = Math.max(2.2, 9 - p.upgrades.arc * 1.1 - (evolvedStorm ? 2.4 : 0)); }
        if ((p.upgrades.blades || 0) > 0) { const n = p.upgrades.blades; for (let i = 0; i < n; i++) { const a = r.clock * (p.evolutions.includes("evo_orbit") ? 3.6 : 2.5) + i * Math.PI * 2 / n; const orbitRadius = p.evolutions.includes("evo_orbit") ? 62 : 45; const bx = p.x + Math.cos(a) * orbitRadius, by = p.y + Math.sin(a) * orbitRadius; for (const e of r.enemies) { if (dist2({ x: bx, y: by }, e) < (e.radius + 9) ** 2) { const cd = e.bladeHit || 0; if (cd <= 0) { e.hp -= 23 * p.damage * (1 + n * .14); e.bladeHit = .35; e.hitFlash = .1; addParticles(r, e.x, e.y, "#b1faff", 4, 75); } } } if (r.boss && dist2({ x: bx, y: by }, r.boss) < (r.boss.radius + 10) ** 2) { if ((r.boss.bladeHit || 0) <= 0) { r.boss.hp -= 18 * p.damage; r.boss.bladeHit = .4; r.boss.hitFlash = .1; } } } }
        // Spawns and sector boss gate.
        if (!r.boss && r.time >= SECTOR_LENGTH) spawnBoss(r);
        if (!r.boss) { r.spawnCd -= dt; const interval = Math.max(.28, .95 - r.totalTime / 300 - r.sector * .07); if (r.spawnCd <= 0 && r.enemies.length < 78) { r.enemies.push(enemyFor(r)); if (r.time > 65 && Math.random() < .2) r.enemies.push(enemyFor(r)); r.spawnCd = interval; } }
        if (!r.boss && r.time >= r.nextEliteAt && r.time < SECTOR_LENGTH - 12) { r.enemies.push(enemyFor(r, true)); r.floats.push({x:W/2,y:90,text:"ELITE HUNTER DETECTED · BONUS SALVAGE",color:"#ffe3a2",life:1.6}); r.nextEliteAt += 58; }
        // Enemies move, shoot and collide.
        r.enemies.forEach(e => { e.hitFlash = Math.max(0, e.hitFlash - dt); e.bladeHit = Math.max(0, (e.bladeHit || 0) - dt); e.slow = Math.max(0, e.slow - dt); const dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy) || 1; if (e.kind === "spitter" && d < 320) { if (d > 215) { e.x += dx / d * e.speed * dt; e.y += dy / d * e.speed * dt; } else if (d < 160) { e.x -= dx / d * e.speed * .65 * dt; e.y -= dy / d * e.speed * .65 * dt; } e.shootCd -= dt; if (e.shootCd <= 0) { r.hostile.push({ x: e.x, y: e.y, vx: dx / d * 205, vy: dy / d * 205, damage: e.damage, radius: 5, color: e.color, life: 3 }); e.shootCd = e.shoot; } } else { const speed = e.speed * (e.slow > 0 ? .48 : 1); e.x += dx / d * speed * dt; e.y += dy / d * speed * dt; }
          if (d < e.radius + 17 && p.invuln <= 0) { p.hp -= Math.max(1, e.damage - p.armor - (p.armorTime > 0 ? 4 : 0)); p.invuln = .75; r.cameraShake = .2; addParticles(r, p.x, p.y, "#ff8eaa", 13, 180); r.floats.push({ x: p.x, y: p.y - 28, text: "-" + Math.max(1, Math.round(e.damage - p.armor * 2)), color: "#ff8eaa", life: .8 }); }
        });
        r.hostile.forEach(b => { b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt; if (p.invuln <= 0 && dist2(p, b) < 25 ** 2) { p.hp -= Math.max(1, b.damage - (p.armor + (p.armorTime > 0 ? 4 : 0)) * 2); p.invuln = .72; b.life = -1; addParticles(r, p.x, p.y, "#ff9eae", 10, 140); } }); r.hostile = r.hostile.filter(b => b.life > 0 && b.x > -35 && b.x < W + 35 && b.y > -35 && b.y < H + 35);
        // Player bolts
        r.shots.forEach(b => { b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt; for (const e of r.enemies) { if (!b.hit.includes(e.id) && dist2(b, e) < (e.radius + 7) ** 2) { e.hp -= b.damage; e.hitFlash = .1; b.hit.push(e.id); if (b.pierce <= 0) b.life = -1; else b.pierce--; addParticles(r, b.x, b.y, b.color, 3, 55); break; } } if (r.boss && !b.hit.includes("boss") && dist2(b, r.boss) < (r.boss.radius + 10) ** 2) { r.boss.hp -= b.damage; r.boss.hitFlash = .09; b.hit.push("boss"); if (b.pierce <= 0) b.life = -1; else b.pierce--; addParticles(r, b.x, b.y, b.color, 4, 65); } }); r.shots = r.shots.filter(b => b.life > 0 && b.x > -50 && b.x < W + 50 && b.y > -50 && b.y < H + 50);
        // Kills and loot
        const alive = []; for (const e of r.enemies) { if (e.hp <= 0) { r.kills++; r.sectorKills++; if (e.elite) { r.eliteKills++; r.shards += 22; r.floats.push({x:e.x,y:e.y-28,text:"ELITE DOWN · +22 ◈",color:"#ffe3a2",life:1.2}); } r.pickups.push({ id: r.id++, x: e.x, y: e.y, type: "xp", value: e.xp, life: 22 }); if (Math.random() < e.shard * (1 + (p.upgrades.salvage || 0) * .18)) r.pickups.push({ id: r.id++, x: e.x + rand(-7, 7), y: e.y + rand(-7, 7), type: "crystal", value: e.elite ? 9 : 2, life: 24 }); if (Math.random() < .025) r.pickups.push({ id: r.id++, x: e.x, y: e.y, type: "heal", value: 15, life: 18 }); addParticles(r, e.x, e.y, e.color, e.kind === "brute" ? 15 : 8, 120); r.floats.push({ x: e.x, y: e.y - 12, text: "+" + e.xp + " XP", color: "#bfffee", life: .65 }); } else alive.push(e); } r.enemies = alive;
        if (r.boss) { const b = r.boss; b.hitFlash = Math.max(0, b.hitFlash - dt); b.bladeHit = Math.max(0, (b.bladeHit || 0) - dt); b.spin += dt; const dx = p.x - b.x, dy = p.y - b.y, d = Math.hypot(dx, dy) || 1; b.x += Math.sin(r.clock * .7) * 35 * dt + clamp(dx, -1, 1) * 24 * dt; b.y += Math.cos(r.clock * .6) * 12 * dt + clamp(dy, -1, 1) * 13 * dt; b.x = clamp(b.x, 90, W - 90); b.y = clamp(b.y, 80, 230);
          b.phase = b.hp <= b.maxHp * .55 ? 2 : 1;
          b.shotCd -= dt; if (b.shotCd <= 0) {
            const speed = 128 + r.sector * 17 + (r.loop - 1) * 14 + b.phase * 18;
            const fire = (a, v = speed, damage = 13 + r.sector * 2 + (r.loop - 1) * 2) => r.hostile.push({ x:b.x, y:b.y, vx:Math.cos(a)*v, vy:Math.sin(a)*v, damage, radius:6, color:b.color, life:4 });
            const aimed = Math.atan2(p.y - b.y, p.x - b.x);
            if (r.sector === 0) { const count = b.phase === 2 ? 14 : 9; for (let i=0;i<count;i++) fire(i*Math.PI*2/count+b.spin); }
            else if (r.sector === 1) { const count = b.phase === 2 ? 7 : 5; for (let i=0;i<count;i++) fire(aimed+(i-(count-1)/2)*.22); }
            else if (r.sector === 2) { const count = b.phase === 2 ? 18 : 12; for (let i=0;i<count;i++) fire(i*Math.PI*2/count+b.spin*.72, speed*.82); }
            else if (r.sector === 3) { for (let i=-1;i<=1;i++) fire(aimed+i*(b.phase===2?.3:.19), speed*1.18); if (b.phase===2) for(let i=0;i<10;i++) fire(i*Math.PI*2/10-b.spin*.8,speed*.7,9); }
            else { const count=b.phase===2?16:10; for(let i=0;i<count;i++) fire(i*Math.PI*2/count+b.spin); for(let i=-1;i<=1;i++) fire(aimed+i*.16,speed*1.22,18); }
            b.pattern++;
            b.shotCd = Math.max(.72, (2.25 - r.sector * .2) * (b.phase === 2 ? .72 : 1));
          }
          b.summonCd -= dt; if (b.summonCd <= 0 && r.enemies.length < 75) { for (let i = 0; i < 2 + r.sector; i++) r.enemies.push(enemyFor(r)); b.summonCd = 5.5; }
          if (d < b.radius + 22 && p.invuln <= 0) { p.hp -= Math.max(2, 21 - p.armor - (p.armorTime > 0 ? 4 : 0)); p.invuln = .85; addParticles(r, p.x, p.y, "#ff8eaa", 18, 190); }
          if (b.hp <= 0) { addParticles(r, b.x, b.y, b.color, 75, 310); r.shards += 45 + r.sector * 25 + (r.loop - 1) * 30; r.boss = null; r.cleared += 1; if (r.sector >= SECTORS.length - 1 && !r.endless) { finish(true); } else { r.mode = "reward"; r.reward = getRewardChoices(); callbackRef.current.onMode("reward"); } }
        }
        // Loot attraction and collection.
        r.pickups.forEach(q => { q.life -= dt; const dx = p.x - q.x, dy = p.y - q.y, d = Math.hypot(dx, dy) || 1; if (d < p.magnet) { q.x += dx / d * (140 + (p.magnet - d) * 1.1) * dt; q.y += dy / d * (140 + (p.magnet - d) * 1.1) * dt; } if (d < 22) { q.life = -1; if (q.type === "xp") r.xp += q.value; if (q.type === "crystal") r.shards += q.value; if (q.type === "heal") p.hp = Math.min(p.maxHp, p.hp + q.value); addParticles(r, q.x, q.y, q.type === "crystal" ? "#ffd37d" : "#a6ffe5", 5, 85); } }); r.pickups = r.pickups.filter(q => q.life > 0);
        // One level-up at a time, so upgrades are deliberate choices.
        if (r.xp >= r.xpNeed) { r.xp -= r.xpNeed; r.level++; r.xpNeed = Math.floor(34 + r.level * 16 + Math.pow(r.level, 1.2) * 4); r.selectedUpgrades = getChoices(r); r.mode = "upgrade"; callbackRef.current.onMode("upgrade"); }
        r.particles.forEach(q => { q.x += q.vx * dt; q.y += q.vy * dt; q.vx *= .96; q.vy *= .96; q.life -= dt; }); r.particles = r.particles.filter(q => q.life > 0);
        r.floats.forEach(f => { f.y -= 20 * dt; f.life -= dt; }); r.floats = r.floats.filter(f => f.life > 0);
        r.cameraShake = Math.max(0, r.cameraShake - dt);
        if (p.hp <= 0) finish(false);
      }
      draw(r, dt);
      hudClock += dt; if (hudClock > .16 && r) { hudClock = 0; callbackRef.current.onHud({ hp: Math.ceil(r.player.hp), maxHp: r.player.maxHp, xp: r.xp, xpNeed: r.xpNeed, level: r.level, kills: r.kills, shards: r.shards, sector: r.sector, time: r.time, boss: !!r.boss, bossHp: r.boss ? r.boss.hp / r.boss.maxHp : 0, dashCd: r.player.dashCd, abilityCd: r.player.abilityCd, upgrades: r.player.upgrades }); }
      raf = requestAnimationFrame(tick);
    };
    const keydown = e => { const k = e.key.toLowerCase(); if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault(); keys.current.add(k); if (k === " " || k === "shift") dashPressed.current = true; if (k === "q") abilityPressed.current = true; };
    const keyup = e => keys.current.delete(e.key.toLowerCase());
    const pointerDown = e => { if (e.target !== canvas) return; const rect = canvas.getBoundingClientRect(); const x = (e.clientX - rect.left) / rect.width * W, y = (e.clientY - rect.top) / rect.height * H; pointer.current = { sx: x, sy: y, x, y }; canvas.setPointerCapture?.(e.pointerId); };
    const pointerMove = e => { if (!pointer.current) return; const rect = canvas.getBoundingClientRect(); pointer.current.x = (e.clientX - rect.left) / rect.width * W; pointer.current.y = (e.clientY - rect.top) / rect.height * H; };
    const pointerUp = () => { pointer.current = null; };
    window.addEventListener("keydown", keydown); window.addEventListener("keyup", keyup); canvas.addEventListener("pointerdown", pointerDown); canvas.addEventListener("pointermove", pointerMove); window.addEventListener("pointerup", pointerUp); window.addEventListener("blur", pointerUp);
    raf = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("keydown", keydown); window.removeEventListener("keyup", keyup); canvas.removeEventListener("pointerdown", pointerDown); canvas.removeEventListener("pointermove", pointerMove); window.removeEventListener("pointerup", pointerUp); window.removeEventListener("blur", pointerUp); };
  }, [runRef]);

  const hold = (key, down) => { if (down) keys.current.add(key); else keys.current.delete(key); };
  const dash = () => { dashPressed.current = true; };
  const activate = () => { abilityPressed.current = true; };
  return <div className="rift-canvas-wrap">
    <canvas ref={canvasRef} width={W} height={H} className="rift-canvas" aria-label="Astra Reclaimer arena survival game" />
    <div className="rift-touch-pad" aria-label="Touch movement controls">
      <button onPointerDown={e => { e.preventDefault(); hold("arrowup", true); }} onPointerUp={() => hold("arrowup", false)} onPointerLeave={() => hold("arrowup", false)}>▲</button>
      <div><button onPointerDown={e => { e.preventDefault(); hold("arrowleft", true); }} onPointerUp={() => hold("arrowleft", false)} onPointerLeave={() => hold("arrowleft", false)}>◀</button><button onPointerDown={e => { e.preventDefault(); hold("arrowdown", true); }} onPointerUp={() => hold("arrowdown", false)} onPointerLeave={() => hold("arrowdown", false)}>▼</button><button onPointerDown={e => { e.preventDefault(); hold("arrowright", true); }} onPointerUp={() => hold("arrowright", false)} onPointerLeave={() => hold("arrowright", false)}>▶</button></div>
    </div>
    <button className="rift-ability" onClick={activate}>Q · SKILL</button>
    <button className="rift-dash" onClick={dash}>ϟ DASH</button>
  </div>;
}

function AstraReclaimer() {
  const [profile, setProfile] = useState(readProfile);
  const [mode, setMode] = useState("hub");
  const [hud, setHud] = useState({ hp: 0, maxHp: 0, xp: 0, xpNeed: 34, level: 1, kills: 0, shards: 0, sector: 0, time: 0, boss: false, bossHp: 1, dashCd: 0, abilityCd: 0, upgrades: {} });
  const [result, setResult] = useState(null);
  const [heroSelect, setHeroSelect] = useState(profile.hero || "astra");
  const [difficulty, setDifficulty] = useState("standard");
  const runRef = useRef(null);
  const chosenHero = HEROES.find(h => h.id === heroSelect) || HEROES[0];
  const sector = SECTORS[clamp(hud.sector, 0, SECTORS.length - 1)];
  const mins = Math.floor(hud.time / 60), secs = Math.floor(hud.time % 60);

  const finish = useCallback((nextProfile, summary) => { setProfile(nextProfile); setResult(summary); setMode(summary.won ? "victory" : "defeat"); }, []);
  const updateMode = useCallback(next => setMode(next), []);
  const updateHud = useCallback(next => setHud(next), []);
  const begin = (daily = false, endless = false) => {
    const p = { ...profile, hero: heroSelect }; persistProfile({ ...profile, hero: heroSelect });
    const r = makeRun(p, heroSelect, daily, endless, daily ? "standard" : difficulty); r.hero = heroSelect; if (daily) { r.player.hp *= .85; r.player.maxHp = r.player.hp; r.player.damage *= 1.22; }
    runRef.current = r; setResult(null); setHud({ hp: r.player.hp, maxHp: r.player.maxHp, xp: 0, xpNeed: r.xpNeed, level: 1, kills: 0, shards: 0, sector: 0, time: 0, boss: false, bossHp: 1, dashCd: 0, abilityCd: 0, upgrades: {} }); setMode("playing");
  };
  const chooseUpgrade = id => {
    const r = runRef.current; if (!r || r.mode !== "upgrade") return; const u = UPGRADES.find(x => x.id === id); const evolution = EVOLUTIONS.find(x => x.id === id); if (!u && !evolution) return; const p = r.player;
    if (evolution) { p.evolutions.push(id); if (id === "evo_aegis") p.armor += 2; } else p.upgrades[id] = (p.upgrades[id] || 0) + 1;
    if (id === "vitality") { p.maxHp += 24; p.hp = Math.min(p.maxHp, p.hp + 24); }
    if (id === "armor") p.armor += 1;
    if (id === "speed") p.speed *= 1.09;
    if (id === "magnet") p.magnet *= 1.3;
    if (id === "regen") p.regenCd = Math.min(p.regenCd, 3.5);
    r.mode = "playing"; setMode("playing");
  };
  const chooseReward = id => {
    const r = runRef.current; if (!r || r.mode !== "reward") return;
    if (id === "cache") r.shards += 140;
    if (id === "repair") { r.player.hp = r.player.maxHp; r.player.maxHp += 12; r.player.hp += 12; }
    if (id === "forge") r.player.damage *= 1.16;
    if (r.sector >= SECTORS.length - 1 && r.endless) { r.sector = 0; r.loop++; } else r.sector++; r.time = 0; r.enemies = []; r.hostile = []; r.shots = []; r.pickups = []; r.boss = null; r.spawnCd = .4; r.player.hp = Math.min(r.player.maxHp, r.player.hp + 16); r.mode = "playing"; setMode("playing");
  };
  const upgradeLab = item => {
    const rank = profile.lab[item.id] || 0; if (rank >= item.max) return; const cost = item.base * (rank + 1) + rank * 25; if (profile.crystals < cost) return;
    const next = { ...profile, crystals: profile.crystals - cost, lab: { ...profile.lab, [item.id]: rank + 1 } }; setProfile(next); persistProfile(next);
  };
  const unlockHero = hero => {
    if (profile.unlocked.includes(hero.id) || profile.crystals < hero.cost) return;
    const next = { ...profile, crystals: profile.crystals - hero.cost, unlocked: [...profile.unlocked, hero.id], hero: hero.id }; setProfile(next); persistProfile(next); setHeroSelect(hero.id);
  };
  const claimDaily = () => {
    const daily = profile.daily.date === todayKey() ? profile.daily : { date: todayKey(), claimed: false, bestKills: 0 };
    if (daily.claimed || daily.bestKills < 70) return;
    const next = { ...profile, crystals: profile.crystals + 90, daily: { ...daily, claimed: true } }; setProfile(next); persistProfile(next);
  };
  const daily = profile.daily.date === todayKey() ? profile.daily : { date: todayKey(), claimed: false, bestKills: 0 };
  const unlockedHeroes = useMemo(() => HEROES.filter(h => profile.unlocked.includes(h.id)), [profile.unlocked]);

  return <div className="rift-game">
    {mode === "hub" && <div className="rift-hub">
      <div className="rift-hub-hero"><div><span className="rift-kicker"><i/> ORIGINAL ACTION ROGUELITE</span><h2>ASTRA RECLAIMER <em>SECTOR ZERO</em></h2><p>A full expedition with five distinct boss fights, elite hunter events, weapon evolutions and a signature skill for every operator. Shape a build, survive the breach and bring your salvage home.</p><div className="rift-hub-badges"><span>✦ PERSISTENT UPGRADES</span><span>◈ 5 SECTORS</span><span>ϟ UNIQUE BOSS PATTERNS</span><span>✧ OPERATOR SKILLS</span><span>⬡ 3 DIFFICULTIES</span></div></div><div className="rift-hub-core"><div className="rift-core-ring ring-1"/><div className="rift-core-ring ring-2"/><div className="rift-core-orb">✦</div><span>THE RECLAIMER IS ONLINE</span></div></div>
      <div className="rift-profile-strip"><div><small>YOUR CRYSTALS</small><b>◈ {profile.crystals.toLocaleString()}</b></div><div><small>EXPEDITIONS</small><b>{profile.runs}</b></div><div><small>BEST SECTOR</small><b>{profile.bestSector}/5</b></div><div><small>BEST KILLS</small><b>{profile.bestKills}</b></div><div><small>ENDLESS BEST</small><b>{profile.bestEndless || 0}</b></div></div>
      <div className="rift-hub-grid">
        <section className="rift-panel rift-hero-select"><div className="rift-panel-head"><div><small>CHOOSE YOUR OPERATOR</small><h3>Pick a <em>survivor.</em></h3></div><span>04 OPERATORS · 04 ACTIVE SKILLS</span></div><div className="rift-heroes">{HEROES.map(h => { const open = profile.unlocked.includes(h.id); return <button key={h.id} onClick={() => open ? setHeroSelect(h.id) : unlockHero(h)} className={`rift-hero-card ${heroSelect === h.id ? "selected" : ""} ${!open ? "locked" : ""}`}><span className="rift-hero-icon" style={{ "--hero": h.color }}>{h.icon}</span><b>{h.name}</b><small>{h.title}</small><em>{open ? h.special : `UNLOCK · ${h.cost} ◈`}</em>{heroSelect === h.id && <i>SELECTED</i>}</button>; })}</div><div className="rift-difficulty-select"><span>EXPEDITION DIFFICULTY</span><div><button className={difficulty === "story" ? "active" : ""} onClick={() => setDifficulty("story")}>STORY <small>More forgiving</small></button><button className={difficulty === "standard" ? "active" : ""} onClick={() => setDifficulty("standard")}>STANDARD <small>Balanced</small></button><button className={difficulty === "veteran" ? "active" : ""} onClick={() => setDifficulty("veteran")}>VETERAN <small>+30% salvage</small></button></div></div><div className="rift-start-row"><button className="rift-start" onClick={() => begin(false)}>START CAMPAIGN <b>→</b></button><button className="rift-daily" onClick={() => begin(false, true)}>ENDLESS DESCENT <small>LOOPS FOREVER · SCALING BOSSES</small></button><button className="rift-daily" onClick={() => begin(true)}>DAILY CONTRACT <small>FIXED DAILY CHALLENGE</small></button></div></section>
        <section className="rift-panel rift-lab"><div className="rift-panel-head"><div><small>RECLAIMER WORKSHOP</small><h3>Permanent <em>upgrades.</em></h3></div><span>CORE LAB</span></div><div className="rift-lab-list">{LAB.map(item => { const rank = profile.lab[item.id] || 0, cost = item.base * (rank + 1) + rank * 25; return <div className="rift-lab-row" key={item.id}><span className="rift-lab-icon">{item.icon}</span><div className="rift-lab-copy"><b>{item.name}</b><small>{item.desc}</small><div className="rift-rank">{Array.from({ length: item.max }, (_, i) => <i key={i} className={i < rank ? "filled" : ""}/>)}</div></div><button disabled={rank >= item.max || profile.crystals < cost} onClick={() => upgradeLab(item)}>{rank >= item.max ? "MAX" : `${cost} ◈`}</button></div>; })}</div></section>
      </div>
      <div className="rift-bottom-grid"><div className="rift-panel rift-sector-panel"><div className="rift-panel-head"><div><small>THE FRACTURE MAP</small><h3>Five sectors. <em>One final target.</em></h3></div><span>5-BOSS CAMPAIGN</span></div><div className="rift-sector-list">{SECTORS.map((s, i) => <div className={`rift-sector-item ${profile.bestSector > i ? "cleared" : ""}`} key={s.name}><span>{String(i + 1).padStart(2, "0")}</span><div><b>{s.name}</b><small>{s.subtitle}</small></div><strong>{profile.bestSector > i ? "CLEARED ✓" : i === 0 ? "OPEN" : "LOCKED"}</strong></div>)}</div></div><div className="rift-panel rift-contract"><div className="rift-panel-head"><div><small>DAILY CONTRACT · {todayKey()}</small><h3>Complete the <em>daily hunt.</em></h3></div><span>+90 ◈</span></div><p>Defeat 70 enemies in a Daily Contract. Your daily run trades a little hull for stronger weapons.</p><div className="rift-contract-progress"><span style={{ width: `${Math.min(100, daily.bestKills / 70 * 100)}%` }}/></div><div className="rift-contract-foot"><small>{Math.min(70, daily.bestKills)} / 70 ELIMINATIONS</small><button onClick={claimDaily} disabled={daily.claimed || daily.bestKills < 70}>{daily.claimed ? "CLAIMED ✓" : "CLAIM REWARD"}</button></div></div></div>
      <section className="rift-panel rift-achievement-panel"><div className="rift-panel-head"><div><small>LONG-TERM OBJECTIVES</small><h3>Field <em>commendations.</em></h3></div><span>{MILESTONES.filter(m => profile.achievements.includes(m.id)).length}/{MILESTONES.length} UNLOCKED</span></div><div className="rift-achievement-grid">{MILESTONES.map(m => { const done = profile.achievements.includes(m.id); return <div className={`rift-achievement ${done ? "earned" : "locked"}`} key={m.id}><span>{done ? "✦" : "◇"}</span><div><b>{m.title}</b><small>{m.desc}</small></div><strong>{done ? "EARNED" : `+${m.reward} ◈`}</strong></div>; })}</div></section>
      <p className="rift-save-note">Progress saves automatically on this device. No account or download required.</p>
    </div>}

    {(mode === "playing" || mode === "upgrade" || mode === "reward" || mode === "victory" || mode === "defeat") && <div className="rift-run">
      <div className="rift-run-head"><div><span className="rift-kicker"><i/> {mode === "victory" ? "CAMPAIGN COMPLETE" : mode === "defeat" ? "SIGNAL LOST" : `SECTOR ${hud.sector + 1} / ${SECTORS.length}${runRef.current?.endless ? ` · LOOP ${runRef.current.loop}` : ""}`}</span><h3>{SECTORS[clamp(hud.sector, 0, SECTORS.length - 1)].name}</h3></div><div className="rift-run-metrics"><div><small>TIME IN SECTOR</small><b>{String(mins).padStart(2, "0")}:{String(secs).padStart(2, "0")}</b></div><div><small>LEVEL</small><b>{hud.level}</b></div><div><small>ELIMINATIONS</small><b>{hud.kills}</b></div><div><small>SHARDS</small><b>◈ {hud.shards}</b></div></div><button className="rift-exit" onClick={() => { runRef.current = null; setMode("hub"); }}>EXIT ✕</button></div>
      <div className="rift-health-row"><span>HULL</span><div><i style={{ width: `${clamp(hud.hp / Math.max(1, hud.maxHp) * 100, 0, 100)}%` }}/></div><b>{hud.hp} / {hud.maxHp}</b><span className="rift-dash-ready">{hud.dashCd <= 0 ? "ϟ DASH READY" : `ϟ ${hud.dashCd.toFixed(1)}s`}</span><span className="rift-skill-ready">Q · {chosenHero.ability} {hud.abilityCd <= 0 ? "READY" : `${hud.abilityCd.toFixed(1)}s`}</span></div>
      <div className="rift-xp-row"><span>LEVEL {hud.level}</span><div><i style={{ width: `${clamp(hud.xp / Math.max(1, hud.xpNeed) * 100, 0, 100)}%` }}/></div><span>{hud.xp} / {hud.xpNeed} XP</span></div>
      <RiftCanvas runRef={runRef} onMode={updateMode} onFinish={finish} onHud={updateHud}/>
      <div className="rift-run-footer"><span>WASD / ARROWS TO MOVE</span><span>SPACE TO DASH · Q TO USE OPERATOR SKILL</span><span>AUTO FIRE · ELITE HUNTS · EVOLUTIONS · PHASED BOSSES</span></div>
      {mode === "upgrade" && <div className="rift-overlay"><div className="rift-choice-modal"><span className="rift-kicker"><i/> LEVEL UP · BUILD YOUR LEGEND</span><h3>Choose an <em>upgrade.</em></h3><p>Every choice changes how your build fights. Stack synergies and make this run yours.</p><div className="rift-upgrade-cards">{(runRef.current?.selectedUpgrades || []).map(u => <button className={`rift-upgrade-card ${u.tier}`} key={u.id} onClick={() => chooseUpgrade(u.id)}><span>{u.icon}</span><small>{u.tier === "evolution" ? "WEAPON EVOLUTION" : u.tier === "weapon" ? "WEAPON MODULE" : "CORE SYSTEM"} · RANK {u.rank}</small><b>{u.name}</b><p>{u.desc}</p><em>INSTALL MODULE →</em></button>)}</div></div></div>}
      {mode === "reward" && <div className="rift-overlay"><div className="rift-choice-modal"><span className="rift-kicker"><i/> SECTOR CLEARED</span><h3>Choose your <em>salvage.</em></h3><p>Sector boss eliminated. Claim your salvage and choose the next route.</p><div className="rift-reward-cards">{(runRef.current?.reward || []).map(item => <button key={item.id} onClick={() => chooseReward(item.id)}><span>{item.icon}</span><b>{item.name}</b><p>{item.desc}</p><em>{item.detail} →</em></button>)}</div></div></div>}
      {(mode === "victory" || mode === "defeat") && <div className="rift-overlay"><div className="rift-result-modal"><span className="rift-kicker"><i/> {mode === "victory" ? "THE FIVE SECTORS ARE RECLAIMED" : "SIGNAL LOST · RECOVER AND REBUILD"}</span><h3>{mode === "victory" ? "CAMPAIGN COMPLETE" : "SIGNAL LOST"}</h3><p>{mode === "victory" ? "You cleared all five sectors. The system is yours to reclaim." : "The run ended, but every recovered crystal and commendation makes your next attempt stronger."}</p><p className="rift-earned-note">{result?.newlyEarned?.length ? `COMMENDATIONS: ${result.newlyEarned.join(" · ")} · BONUS +${result.milestoneBonus} ◈` : `DIFFICULTY: ${(runRef.current?.difficulty || "standard").toUpperCase()} · KEEP BUILDING YOUR LEGEND`}</p><div className="rift-result-stats"><div><b>{result?.kills || 0}</b><small>ELIMINATIONS</small></div><div><b>{result?.level || 1}</b><small>FINAL LEVEL</small></div><div><b>{result?.banked || 0}</b><small>CRYSTALS BANKED</small></div><div><b>{result?.sector || 0}/5</b><small>STAGES CLEARED</small></div></div><button className="rift-start" onClick={() => setMode("hub")}>RETURN TO WORKSHOP →</button></div></div>}
    </div>}
  </div>;
}

export default AstraReclaimer;
