import React, { useCallback, useEffect, useRef, useState } from "react";

const CW = 1120, CH = 760, TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const rand = (a, b) => a + Math.random() * (b - a);
const hypot = (x, y) => Math.hypot(x, y) || 1;
const STORE = "pz-nitro-rift-v1";
const readSave = () => {
  try {
    const s = JSON.parse(localStorage.getItem(STORE) || "{}");
    return { coins: Number(s.coins || 0), wins: Number(s.wins || 0), bestKills: Number(s.bestKills || 0), bestGems: Number(s.bestGems || 0), engine: Number(s.engine || 0), handling: Number(s.handling || 0), armor: Number(s.armor || 0), unlocked: Array.isArray(s.unlocked) ? s.unlocked : ["comet"], selected: s.selected || "comet", totalRaces: Number(s.totalRaces || 0) };
  } catch { return { coins: 0, wins: 0, bestKills: 0, bestGems: 0, engine: 0, handling: 0, armor: 0, unlocked: ["comet"], selected: "comet", totalRaces: 0 }; }
};
const CARS = [
  { id: "comet", name: "COMET S", title: "All-rounder", color: "#45e6e9", accent: "#b8fffb", speed: 390, turn: 2.75, armor: 100, unlock: "STARTER" },
  { id: "vandal", name: "VANDAL GT", title: "Street brawler", color: "#ff815f", accent: "#ffd1a7", speed: 365, turn: 2.45, armor: 128, unlock: "WIN 3 RACES", wins: 3 },
  { id: "spectre", name: "SPECTRE X", title: "Drift specialist", color: "#b28cff", accent: "#edddff", speed: 378, turn: 3.35, armor: 92, unlock: "WIN 8 RACES", wins: 8 },
  { id: "volt", name: "VOLT R", title: "Nitro machine", color: "#f3dc66", accent: "#fff4b5", speed: 420, turn: 2.55, armor: 88, unlock: "EARN 2,000 CREDITS", coins: 2000 }
];
const MODES = [
  { id: "knockout", name: "KNOCKOUT", icon: "✦", desc: "Outplay the pack. First to 8 takedowns wins.", target: "8 TAKEDOWNS", time: 180 },
  { id: "gemrush", name: "GEM RUSH", icon: "◆", desc: "Grab rift crystals, steal drops and bank 25 first.", target: "25 CRYSTALS", time: 180 },
  { id: "lastkart", name: "LAST KART", icon: "♜", desc: "Three lives. No second chances. Be the last kart rolling.", target: "3 LIVES", time: 210 }
];
const MAPS = [
  { name: "PRISM PLAZA", sub: "THE GLASS DISTRICT", floor: "#101c36", line: "#274c70", glow: "#4be8eb", hazard: "#4ee7ed", accent: "#9b88ff", obstacles: [[250,190,48],[530,155,62],[850,210,55],[365,420,68],[735,475,60],[175,590,46],[950,585,52]], pads: [[560,325,0],[560,625,Math.PI],[130,385,Math.PI/2],[990,390,-Math.PI/2]] },
  { name: "EMBER WORKS", sub: "THE FOUNDRY", floor: "#251728", line: "#75404a", glow: "#ff815f", hazard: "#ff775e", accent: "#f4d06b", obstacles: [[220,210,60],[440,300,44],[720,180,58],[900,350,66],[315,565,58],[710,555,52]], pads: [[555,145,Math.PI/2],[550,640,-Math.PI/2],[100,385,0],[1020,385,Math.PI]] },
  { name: "TIDEBREAKER", sub: "THE FLOODED DOCKS", floor: "#102735", line: "#236075", glow: "#60c8ff", hazard: "#50d6bc", accent: "#9ef1d5", obstacles: [[235,165,52],[485,200,70],[825,170,52],[200,475,65],[520,545,50],[850,480,75]], pads: [[555,125,Math.PI/2],[555,660,-Math.PI/2],[95,385,0],[1025,385,Math.PI]] }
];
const WEAPONS = {
  rocket: { name: "RIFT ROCKET", short: "ROCKET", color: "#ff9d79", tip: "Homing burst" },
  plasma: { name: "PLASMA BOLT", short: "PLASMA", color: "#8de9ff", tip: "Fast straight shot" },
  mine: { name: "PULSE MINE", short: "MINE", color: "#f4dc78", tip: "Drop behind you" },
  emp: { name: "EMP NOVA", short: "EMP", color: "#c7a4ff", tip: "Disable nearby rivals" }
};

function makeCar(id, x, y, angle, player = false) {
  const spec = CARS.find(c => c.id === id) || CARS[0];
  return { id: `${player ? "player" : "bot"}-${Math.random().toString(36).slice(2,8)}`, carId: spec.id, x, y, vx: 0, vy: 0, angle, hp: spec.armor, maxHp: spec.armor, color: spec.color, accent: spec.accent, name: player ? "YOU" : ["PIXEL", "JINX", "ROOK", "NOVA", "KRAKEN", "MISO"][Math.floor(Math.random()*6)], player, score: 0, gems: 0, lives: 3, weapon: player ? "plasma" : ["rocket","plasma","mine"][Math.floor(Math.random()*3)], weaponAmmo: player ? 999 : 5, shield: 0, nitro: 100, boostTime: 0, stun: 0, invuln: 1.4, fireCd: rand(.5,1.8), ramCd: 0, drift: 0, skid: 0, hit: 0, aiThink: 0, aiTurn: 0, aiThrottle: 1, targetX: x, targetY: y, respawn: 0, kills: 0, deaths: 0, distTravelled: 0 };
}
function spawnPoint(i, count) { const a = -Math.PI/2 + i * TAU/count; return { x: CW/2 + Math.cos(a)*300, y: CH/2 + Math.sin(a)*215, a: a + Math.PI/2 }; }
function makeMatch(mode, mapIndex, save) {
  const map = MAPS[mapIndex];
  const cars = [];
  for (let i = 0; i < 6; i++) { const p = spawnPoint(i, 6); const id = i === 0 ? save.selected : CARS[(i + mapIndex) % CARS.length].id; cars.push(makeCar(id, p.x, p.y, p.a, i === 0)); }
  const player = cars[0];
  player.hp = player.maxHp = (CARS.find(c=>c.id===player.carId)?.armor || 100) + save.armor*10;
  player.invuln = 3.2;
  player.maxSpeed = (CARS.find(c=>c.id===player.carId)?.speed || 390) + save.engine*14;
  player.turnPower = (CARS.find(c=>c.id===player.carId)?.turn || 2.75) + save.handling*.16;
  const pads = map.pads.map(([x,y,a], i)=>({x,y,a,id:i,flash:0}));
  const boxes = [ [CW/2,CH/2], [110,CH/2], [CW-110,CH/2], [CW/2,95], [CW/2,CH-95] ].map(([x,y],i)=>({x,y,respawn:0,weapon:["rocket","emp","mine","plasma"][i%4],spin:rand(0,TAU)}));
  const crystals = [];
  for(let i=0;i<16;i++) crystals.push(makeCrystal(map));
  return { mode, mapIndex, map, cars, player, pads, boxes, crystals, shots:[], mines:[], particles:[], texts:[], sparks:[], clock:0, remaining:MODES.find(m=>m.id===mode).time, state:"playing", shake:0, combo:0, comboTimer:0, totalKills:0, bestStreak:0, pickups:0, lastHud:0, matchId:Date.now(), finishReason:"", winner:null, nextCrystal:2, lastAnnounce:3, events:[], seed:Math.random()*1000 };
}
function makeCrystal(map) { let x=rand(95,CW-95),y=rand(95,CH-95); if(map){for(let tries=0;tries<18;tries++){x=rand(95,CW-95);y=rand(95,CH-95);if(map.obstacles.every(([ox,oy,r])=>Math.hypot(x-ox,y-oy)>r+54))break;}} return { x,y,spin:rand(0,TAU),life:18,value:1,bob:rand(0,TAU) }; }
function addBurst(g,x,y,color,n=12,power=180) { for(let i=0;i<n;i++){const a=Math.random()*TAU,s=rand(power*.22,power);g.particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:rand(.25,.75),max:.75,color,size:rand(2,6)});} }
function addText(g,x,y,text,color="#fff") { g.texts.push({x,y,text,color,life:1.15,max:1.15}); }
function nearestEnemy(g, car, max=1000) { let best=null, bd=max*max; for(const other of g.cars){if(other===car||other.respawn>0||other.eliminated)continue;const dx=other.x-car.x,dy=other.y-car.y,d=dx*dx+dy*dy;if(d<bd){bd=d;best=other;}}return best; }
function wrap(a){while(a>Math.PI)a-=TAU;while(a<-Math.PI)a+=TAU;return a;}

function drawKart(ctx, car, now) {
  ctx.save(); ctx.translate(car.x,car.y); ctx.rotate(car.angle);
  const scale = car.player ? 1.06 : 1;
  ctx.scale(scale,scale);
  // soft ground shadow and boost trail
  ctx.fillStyle="#03071299"; ctx.beginPath(); ctx.ellipse(-2,8,25,17,0,0,TAU); ctx.fill();
  if(car.boostTime>0){ctx.globalAlpha=.75;ctx.fillStyle=car.accent;ctx.shadowColor=car.accent;ctx.shadowBlur=22;ctx.beginPath();ctx.moveTo(-24,-7);ctx.lineTo(-54,0);ctx.lineTo(-24,8);ctx.closePath();ctx.fill();ctx.globalAlpha=1;ctx.shadowBlur=0;}
  // tyres
  ctx.fillStyle="#070c16"; ctx.strokeStyle="#46566e"; ctx.lineWidth=2;
  for(const [x,y] of [[-15,-13],[15,-13],[-15,14],[15,14]]){ctx.beginPath();ctx.roundRect(x-6,y-5,12,10,3);ctx.fill();ctx.stroke();}
  // chassis
  const grad=ctx.createLinearGradient(-21,-19,22,19);grad.addColorStop(0,car.accent);grad.addColorStop(.32,car.color);grad.addColorStop(1,"#182238");
  ctx.fillStyle=grad;ctx.shadowColor=car.color;ctx.shadowBlur=car.player?18:9;ctx.beginPath();ctx.moveTo(-21,15);ctx.quadraticCurveTo(-25,9,-23,-9);ctx.quadraticCurveTo(-20,-19,-8,-20);ctx.lineTo(13,-18);ctx.quadraticCurveTo(23,-15,23,-4);ctx.lineTo(21,13);ctx.quadraticCurveTo(17,19,5,19);ctx.lineTo(-13,19);ctx.closePath();ctx.fill();ctx.shadowBlur=0;
  // cockpit
  ctx.fillStyle="#111e35";ctx.beginPath();ctx.roundRect(-11,-12,22,19,6);ctx.fill();
  ctx.fillStyle="#9cecff";ctx.globalAlpha=.85;ctx.beginPath();ctx.roundRect(-8,-10,16,8,3);ctx.fill();ctx.globalAlpha=1;
  ctx.fillStyle="#f5ffff";ctx.globalAlpha=.7;ctx.fillRect(-16,14,7,3);ctx.fillRect(9,14,7,3);ctx.globalAlpha=1;
  // nose stripe
  ctx.fillStyle=car.accent;ctx.globalAlpha=.85;ctx.beginPath();ctx.moveTo(-3,-19);ctx.lineTo(3,-19);ctx.lineTo(1,-8);ctx.lineTo(-1,-8);ctx.fill();ctx.globalAlpha=1;
  if(car.shield>0){ctx.strokeStyle="#b9efff";ctx.globalAlpha=.35+.15*Math.sin(now/90);ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(0,0,33,25,0,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
  if(car.invuln>0){ctx.globalAlpha=.32+.26*Math.sin(now/45);ctx.strokeStyle="#fff";ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(0,0,29,23,0,0,TAU);ctx.stroke();ctx.globalAlpha=1;}
  ctx.restore();
}
function drawArena(ctx,g,now){
  const m=g.map;
  ctx.fillStyle=m.floor;ctx.fillRect(0,0,CW,CH);
  // layered floor grid and radial panels
  ctx.save();ctx.globalAlpha=.18;ctx.strokeStyle=m.line;ctx.lineWidth=1;for(let x=36;x<CW;x+=48){ctx.beginPath();ctx.moveTo(x,28);ctx.lineTo(x,CH-28);ctx.stroke();}for(let y=28;y<CH;y+=48){ctx.beginPath();ctx.moveTo(28,y);ctx.lineTo(CW-28,y);ctx.stroke();}ctx.restore();
  const radial=ctx.createRadialGradient(CW/2,CH/2,30,CW/2,CH/2,520);radial.addColorStop(0,m.glow+"13");radial.addColorStop(1,"#050a1600");ctx.fillStyle=radial;ctx.fillRect(0,0,CW,CH);
  // boundary
  ctx.save();ctx.strokeStyle=m.glow;ctx.shadowColor=m.glow;ctx.shadowBlur=22;ctx.lineWidth=5;ctx.strokeRect(35,35,CW-70,CH-70);ctx.shadowBlur=0;ctx.globalAlpha=.45;ctx.lineWidth=1;ctx.strokeRect(47,47,CW-94,CH-94);ctx.restore();
  // corner beacons
  for(const [x,y] of [[35,35],[CW-35,35],[35,CH-35],[CW-35,CH-35]]){ctx.fillStyle=m.accent;ctx.shadowColor=m.accent;ctx.shadowBlur=18;ctx.beginPath();ctx.arc(x,y,7,0,TAU);ctx.fill();ctx.shadowBlur=0;}
  // arena obstacles with layered stone/metal rings
  m.obstacles.forEach(([x,y,r],i)=>{ctx.save();ctx.translate(x,y);ctx.fillStyle="#050a16";ctx.beginPath();ctx.ellipse(2,9,r*1.22,r*.86,0,0,TAU);ctx.fill();const gr=ctx.createRadialGradient(-r*.3,-r*.4,4,0,0,r);gr.addColorStop(0,"#52647e");gr.addColorStop(.5,"#263651");gr.addColorStop(1,"#111c32");ctx.fillStyle=gr;ctx.strokeStyle=m.glow+"88";ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.fill();ctx.stroke();ctx.strokeStyle="#c5d4e522";ctx.lineWidth=2;ctx.beginPath();ctx.arc(0,0,r*.72,Math.PI*.15,Math.PI*1.35);ctx.stroke();ctx.fillStyle=i%2?m.accent:m.glow;ctx.globalAlpha=.8;ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=12;ctx.beginPath();ctx.arc(Math.cos(now/900+i)*r*.56,Math.sin(now/900+i)*r*.56,5,0,TAU);ctx.fill();ctx.restore();});
  // boost pads
  g.pads.forEach(p=>{ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.a);ctx.globalAlpha=.35+Math.max(0,p.flash)*.65;ctx.fillStyle=m.glow;ctx.shadowColor=m.glow;ctx.shadowBlur=20;ctx.beginPath();ctx.roundRect(-42,-19,84,38,10);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle="#081321";for(let i=-2;i<=2;i++){ctx.beginPath();ctx.moveTo(i*13-5,-11);ctx.lineTo(i*13+4,0);ctx.lineTo(i*13-5,11);ctx.closePath();ctx.fill();}ctx.restore();});
  // decorative floor arrows
  ctx.save();ctx.globalAlpha=.12;ctx.fillStyle=m.accent;for(let i=0;i<8;i++){const x=120+i*126;ctx.beginPath();ctx.moveTo(x,70);ctx.lineTo(x+18,70);ctx.lineTo(x+18,90);ctx.lineTo(x+31,90);ctx.lineTo(x+9,111);ctx.lineTo(x-13,90);ctx.lineTo(x,90);ctx.fill();}ctx.restore();
}

export default function NitroRift(){
  const canvasRef=useRef(null),gRef=useRef(null),keysRef=useRef(new Set()),frameRef=useRef(0),lastHudRef=useRef(0);
  const [screen,setScreen]=useState("menu"),[mode,setMode]=useState("knockout"),[mapIndex,setMapIndex]=useState(0),[save,setSave]=useState(readSave),[hud,setHud]=useState({time:180,score:0,hp:100,nitro:100,weapon:"PLASMA",ammo:999,kills:0,gems:0,lives:3,position:1}),[result,setResult]=useState(null),[notice,setNotice]=useState(""),[help,setHelp]=useState(false),[soundOn,setSoundOn]=useState(true);
  const inputRef=useRef({});
  const saveRef=useRef(save);
  const screenRef=useRef(screen);
  const helpRef=useRef(help);
  const audioRef=useRef(null);
  const soundEnabledRef=useRef(soundOn);
  const persist=(next)=>{saveRef.current=next;setSave(next);try{localStorage.setItem(STORE,JSON.stringify(next));}catch{}};
  const announce=(text)=>{setNotice(text);window.clearTimeout(announce.timer);announce.timer=window.setTimeout(()=>setNotice(""),1600);};
  const playSound=useCallback((kind)=>{try{if(!soundEnabledRef.current)return;const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;const ac=audioRef.current||(audioRef.current=new AC());if(ac.state==="suspended")ac.resume();const specs={start:[260,520,.16,"triangle"],fire:[230,85,.085,"sawtooth"],rocket:[150,55,.19,"sawtooth"],pickup:[680,1120,.14,"sine"],hit:[105,48,.13,"square"],boost:[170,540,.2,"sawtooth"],kill:[420,980,.2,"triangle"],emp:[520,95,.23,"sine"],win:[520,1040,.34,"triangle"],lose:[170,65,.32,"triangle"]};const [from,to,duration,type]=specs[kind]||specs.fire;const osc=ac.createOscillator(),gain=ac.createGain();osc.type=type;osc.frequency.setValueAtTime(from,ac.currentTime);osc.frequency.exponentialRampToValueAtTime(Math.max(35,to),ac.currentTime+duration);gain.gain.setValueAtTime(.0001,ac.currentTime);gain.gain.exponentialRampToValueAtTime(kind==="hit"?.055:.035,ac.currentTime+.012);gain.gain.exponentialRampToValueAtTime(.0001,ac.currentTime+duration);osc.connect(gain);gain.connect(ac.destination);osc.start();osc.stop(ac.currentTime+duration+.02);}catch{}},[]);
  const startMatch=useCallback(()=>{playSound("start");const g=makeMatch(mode,mapIndex,save);gRef.current=g;keysRef.current.clear();setHud({time:g.remaining,score:0,hp:g.player.hp,nitro:100,weapon:"PLASMA",ammo:999,kills:0,gems:0,lives:3,position:1});setResult(null);setScreen("playing");},[mode,mapIndex,save,playSound]);
  const finishMatch=(g,reason)=>{if(g.state!=="playing")return;g.state="finished";screenRef.current="result";g.finishReason=reason;const place=g.mode==="gemrush"?(g.cars.slice().sort((a,b)=>b.gems-a.gems).findIndex(c=>c.player)+1):g.mode==="lastkart"?(g.cars.filter(c=>!c.eliminated).sort((a,b)=>b.lives-a.lives||b.hp-a.hp).findIndex(c=>c.player)+1):(g.cars.slice().sort((a,b)=>b.kills-a.kills).findIndex(c=>c.player)+1);const won=place===1;const current=saveRef.current;const reward=Math.max(25,Math.round(g.player.score*.45+g.player.gems*3+g.player.kills*24+(won?160:0)));const next={...current,coins:current.coins+reward,wins:current.wins+(won?1:0),bestKills:Math.max(current.bestKills,g.player.kills),bestGems:Math.max(current.bestGems,g.player.gems),totalRaces:current.totalRaces+1};if(next.wins>=3&&!next.unlocked.includes("vandal"))next.unlocked=[...next.unlocked,"vandal"];if(next.wins>=8&&!next.unlocked.includes("spectre"))next.unlocked=[...next.unlocked,"spectre"];if(next.coins>=2000&&!next.unlocked.includes("volt"))next.unlocked=[...next.unlocked,"volt"];persist(next);setResult({won,place,reward,kills:g.player.kills,gems:g.player.gems,score:g.player.score,mode:g.mode,reason});playSound(won?"win":"lose");setScreen("result");};
  const buyUpgrade=(key)=>{const price=[350,650,1000][save[key]]||1500;if(save[key]>=3){announce("UPGRADE MAXED");return;}if(save.coins<price){announce("NOT ENOUGH CREDITS");return;}persist({...save,coins:save.coins-price,[key]:save[key]+1});announce("UPGRADE INSTALLED");};
  const chooseCar=(id)=>{if(!save.unlocked.includes(id)){const c=CARS.find(x=>x.id===id);announce(c?.wins?`NEED ${c.wins} WINS`:`NEED ${c?.coins||2000} CREDITS`);return;}persist({...save,selected:id});};

  useEffect(()=>{
    const canvas=canvasRef.current;if(!canvas)return;const ctx=canvas.getContext("2d");let raf=0,last=0,now=0;const gRefLocal=gRef;
    const resize=()=>{const dpr=Math.min(window.devicePixelRatio||1,2);const rect=canvas.getBoundingClientRect();canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);ctx.setTransform(canvas.width/CW,0,0,canvas.height/CH,0,0);};resize();const ro=new ResizeObserver(resize);ro.observe(canvas);
    const input=inputRef.current;
    const updateBot=(g,car,dt)=>{
      if(car.respawn>0)return;
      car.aiThink-=dt;if(car.aiThink<=0){const target=nearestEnemy(g,car,780);if(target){car.targetX=target.x+rand(-95,95);car.targetY=target.y+rand(-95,95);}else{car.targetX=rand(100,CW-100);car.targetY=rand(100,CH-100);}car.aiThink=rand(.5,1.3);}
      let dx=car.targetX-car.x,dy=car.targetY-car.y;let want=Math.atan2(dy,dx);for(const [ox,oy,r] of g.map.obstacles){const odx=ox-car.x,ody=oy-car.y,od=Math.hypot(odx,ody)||1;const aim=wrap(Math.atan2(ody,odx)-car.angle);if(od<r+112&&Math.abs(aim)<1.0){const side=Math.sign(Math.sin(wrap(want-Math.atan2(ody,odx))))||1;const around=Math.atan2(car.y-oy,car.x-ox)+side*.95;car.targetX=ox+Math.cos(around)*(r+112);car.targetY=oy+Math.sin(around)*(r+112);dx=car.targetX-car.x;dy=car.targetY-car.y;want=Math.atan2(dy,dx);break;}}let delta=wrap(want-car.angle);let steer=clamp(delta*2.1,-1,1);if(Math.abs(delta)>1.9)car.aiThrottle=.42;else car.aiThrottle=1;
      if(g.mode==="gemrush"&&Math.random()<.15){const c=g.crystals.reduce((best,q)=>!best||Math.hypot(q.x-car.x,q.y-car.y)<Math.hypot(best.x-car.x,best.y-car.y)?q:best,null);if(c){car.targetX=c.x;car.targetY=c.y;}}
      return {throttle:car.aiThrottle,steer,brake:0,drift:Math.abs(steer)>.55&&Math.random()<.018,nitro:Math.abs(delta)<.4&&car.nitro>45,fire:true,shield:car.hp<55&&car.shield<=0};
    };
    const spawnProjectile=(g,car,type,target)=>{
      if(type==="mine"){g.mines.push({x:car.x-Math.cos(car.angle)*35,y:car.y-Math.sin(car.angle)*35,owner:car.id,life:12,arm:.45,damage:55,r:13});addBurst(g,car.x,car.y,"#f2d77b",8,100);return;}
      if(type==="emp"){if(car.player)playSound("emp");for(const c of g.cars){if(c!==car&&c.respawn<=0&&Math.hypot(c.x-car.x,c.y-car.y)<205){c.stun=Math.max(c.stun,1.65);c.nitro=Math.max(0,c.nitro-28);c.hit=.35;}}g.shots.push({x:car.x,y:car.y,life:.35,type:"emp",owner:car.id,r:205});addBurst(g,car.x,car.y,"#c8a2ff",34,250);g.shake=.18;return;}
      if(!target)target=nearestEnemy(g,car,850);
      const a=type==="rocket"&&target?Math.atan2(target.y-car.y,target.x-car.x):car.angle;const speed=type==="rocket"?420:650;
      g.shots.push({x:car.x+Math.cos(car.angle)*26,y:car.y+Math.sin(car.angle)*26,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed,angle:a,life:type==="rocket"?3.2:1.8,type,owner:car.id,targetId:target?.id||null,damage:type==="rocket"?45:28,r:type==="rocket"?8:5,color:type==="rocket"?"#ff9b76":"#91ecff"});
      addBurst(g,car.x+Math.cos(car.angle)*25,car.y+Math.sin(car.angle)*25,type==="rocket"?"#ff9b76":"#91ecff",5,80);if(car.player)playSound(type==="rocket"?"rocket":"fire");
    };
    const respawnCar=(g,car)=>{const p=spawnPoint(Math.floor(rand(0,6)),6);car.x=p.x;car.y=p.y;car.vx=0;car.vy=0;car.angle=p.a;car.hp=car.maxHp;car.invuln=2.4;car.respawn=0;car.weapon="plasma";car.weaponAmmo=999;car.shield=0;addBurst(g,car.x,car.y,car.color,22,190);};
    const damageCar=(g,car,amount,attacker)=>{if(car.invuln>0||car.respawn>0)return;const real=Math.max(1,amount-(car.shield>0?amount*.72:0));car.hp-=real;car.hit=.25;g.shake=Math.max(g.shake,.12);if(car.player)playSound("hit");addBurst(g,car.x,car.y,car.shield>0?"#a7eaff":"#ff997e",8,130);if(car.hp<=0){car.deaths++;addBurst(g,car.x,car.y,car.color,35,260);if(attacker&&attacker!==car){attacker.kills++;attacker.score+=100;g.totalKills++;if(attacker.player){g.combo++;g.comboTimer=4;addText(g,car.x,car.y-32,"TAKEDOWN +100","#ffe28b");}}if(g.mode==="lastkart"){car.lives--;if(car.lives<=0){car.respawn=0;car.eliminated=true;if(car.player){finishMatch(g,"Your kart was eliminated.");return;}}else{car.respawn=2.1;}}else{car.respawn=2.0;}}
    };
    const tick=(g,dt,timestamp)=>{
      g.clock+=dt;g.remaining=Math.max(0,g.remaining-dt);g.shake=Math.max(0,g.shake-dt);g.comboTimer=Math.max(0,g.comboTimer-dt);if(g.comboTimer===0)g.combo=0;
      const p=g.player;const playerInput=inputRef.current;
      // Bots and their controls
      for(const car of g.cars){if(car.eliminated)continue;if(car.respawn>0){car.respawn-=dt;if(car.respawn<=0){if(car.eliminated){continue;}respawnCar(g,car);}continue;}if(car===p)continue;const b=updateBot(g,car,dt);driveCar(g,car,b,dt,g,damageCar,spawnProjectile);if(b.fire&&car.fireCd<=0&&Math.random()<dt*.26){if(car.weaponAmmo>0&&car.weapon){spawnProjectile(g,car,car.weapon,nearestEnemy(g,car));car.weaponAmmo--;car.fireCd=rand(2.8,4.2);}else{car.weapon="plasma";car.weaponAmmo=999;car.fireCd=1.2;}}if(b.shield&&Math.random()<dt*.2)car.shield=2.0;}
      const inp={throttle:playerInput.up?1:0,steer:(playerInput.right?1:0)-(playerInput.left?1:0),brake:!!playerInput.down,drift:!!playerInput.drift,nitro:!!playerInput.nitro,fire:!!playerInput.fire,shield:!!playerInput.shield};
      if(p.respawn<=0){if(inp.nitro&&inp.throttle>0&&p.boostTime<=0)playSound("boost");driveCar(g,p,inp,dt,g,damageCar,spawnProjectile);if(inp.fire&&p.fireCd<=0){if(p.weaponAmmo>0){spawnProjectile(g,p,p.weapon,nearestEnemy(g,p));p.weaponAmmo--;p.fireCd=p.weapon==="rocket"?1.05:p.weapon==="mine"?2.8:1.35;}else{p.weapon="plasma";p.weaponAmmo=999;addText(g,p.x,p.y-32,"BLASTER RELOADED","#9ceaff");p.fireCd=.35;}}if(inp.shield&&p.shield<=0&&p.nitro>=20){p.shield=2.1;p.nitro-=20;addBurst(g,p.x,p.y,"#a8e9ff",20,155);}}
      // collisions between karts
      for(let i=0;i<g.cars.length;i++){const a=g.cars[i];if(a.respawn>0||a.eliminated)continue;for(let j=i+1;j<g.cars.length;j++){const b=g.cars[j];if(b.respawn>0||b.eliminated)continue;const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,min=34;if(d<min){const nx=dx/d,ny=dy/d,over=(min-d)/2;a.x-=nx*over;a.y-=ny*over;b.x+=nx*over;b.y+=ny*over;const rel=Math.abs((a.vx-b.vx)*nx+(a.vy-b.vy)*ny);a.vx-=nx*rel*.18;a.vy-=ny*rel*.18;b.vx+=nx*rel*.18;b.vy+=ny*rel*.18;if(rel>205&&a.ramCd<=0){damageCar(g,b,7,a);a.ramCd=.8;}if(rel>205&&b.ramCd<=0){damageCar(g,a,7,b);b.ramCd=.8;}}}}
      // weapon projectiles, guided rockets and mines
      for(const s of g.shots){s.life-=dt;if(s.type==="emp")continue;if(s.type==="rocket"&&s.targetId){const t=g.cars.find(c=>c.id===s.targetId&&c.respawn<=0);if(t){const a=Math.atan2(t.y-s.y,t.x-s.x);s.angle=wrap(s.angle+clamp(wrap(a-s.angle),-2.2*dt,2.2*dt));s.vx=Math.cos(s.angle)*440;s.vy=Math.sin(s.angle)*440;}}s.x+=s.vx*dt;s.y+=s.vy*dt;const owner=g.cars.find(c=>c.id===s.owner);for(const c of g.cars){if(c===owner||c.respawn>0||c.eliminated)continue;if(Math.hypot(c.x-s.x,c.y-s.y)<s.r+18){damageCar(g,c,s.damage,owner);s.life=-1;if(s.type==="rocket")addBurst(g,s.x,s.y,"#ff9e76",22,220);else addBurst(g,s.x,s.y,"#9ceaff",10,110);break;}}}
      g.shots=g.shots.filter(s=>s.life>0&&s.x>-40&&s.x<CW+40&&s.y>-40&&s.y<CH+40);
      for(const m of g.mines){m.life-=dt;m.arm-=dt;if(m.arm<=0){const victim=g.cars.find(c=>c.id!==m.owner&&!c.eliminated&&c.respawn<=0&&Math.hypot(c.x-m.x,c.y-m.y)<70);if(victim){damageCar(g,victim,m.damage,g.cars.find(c=>c.id===m.owner));m.life=-1;g.shots.push({x:m.x,y:m.y,life:.3,type:"emp",owner:m.owner,r:90});addBurst(g,m.x,m.y,"#ffe18b",24,210);}}}g.mines=g.mines.filter(m=>m.life>0);
      // crystal collection and re-spawn
      for(const c of g.crystals){c.spin+=dt*2;c.bob+=dt*3;for(const car of g.cars){if(!car.eliminated&&car.respawn<=0&&Math.hypot(car.x-c.x,car.y-c.y)<27){car.gems++;car.score+=g.mode==="gemrush"?20:12;car.nitro=Math.min(100,car.nitro+10);addBurst(g,c.x,c.y,"#83ffe4",12,150);if(car.player){addText(g,c.x,c.y-18,"+1 RIFT SHARD","#8dffe4");playSound("pickup");}const nextCrystal=makeCrystal(g.map);c.x=nextCrystal.x;c.y=nextCrystal.y;c.spin=nextCrystal.spin;c.bob=nextCrystal.bob;break;}}}
      // crates respawn, weapons can change the fight
      for(const box of g.boxes){box.spin+=dt;box.respawn-=dt;if(box.respawn<=0){for(const car of g.cars){if(!car.eliminated&&car.respawn<=0&&Math.hypot(car.x-box.x,car.y-box.y)<38){car.weapon=box.weapon;car.weaponAmmo=box.weapon==="rocket"?3:box.weapon==="plasma"?9:box.weapon==="mine"?2:2;box.respawn=8;addBurst(g,box.x,box.y,WEAPONS[box.weapon].color,14,140);if(car.player){addText(g,box.x,box.y-30,WEAPONS[box.weapon].name,"#fff0bd");playSound("pickup");}break;}}}}
      // pads and environment; rotate maps between matches
      for(const pad of g.pads){pad.flash=Math.max(0,pad.flash-dt);for(const car of g.cars){if(car.respawn>0||car.eliminated)continue;const dx=car.x-pad.x,dy=car.y-pad.y;if(Math.hypot(dx,dy)<43&&Math.abs(wrap(car.angle-pad.a))<1.25){const fx=Math.cos(pad.a),fy=Math.sin(pad.a);car.vx+=fx*330*dt;car.vy+=fy*330*dt;car.nitro=Math.min(100,car.nitro+16*dt);pad.flash=.18;}}}
      if(g.mapIndex===1){for(let i=0;i<4;i++){const x=170+i*260,y=355+Math.sin(g.clock*.8+i)*32;for(const car of g.cars){if(!car.eliminated&&car.respawn<=0&&Math.hypot(car.x-x,car.y-y)<53){car.hazardCd=(car.hazardCd||0)-dt;if(car.hazardCd<=0){damageCar(g,car,9,null);car.hazardCd=.7;}}}}}
      if(g.mapIndex===2){for(let i=0;i<3;i++){const x=340+i*215,y=350+Math.sin(g.clock*.55+i*2)*110;for(const car of g.cars){if(!car.eliminated&&car.respawn<=0&&Math.hypot((car.x-x)*.72,car.y-y)<48){car.vx*=Math.pow(.46,dt);car.vy*=Math.pow(.46,dt);car.nitro=Math.max(0,car.nitro-5*dt);}}}}
      // particles and floaty text
      for(const a of g.particles){a.life-=dt;a.x+=a.vx*dt;a.y+=a.vy*dt;a.vx*=Math.pow(.08,dt);a.vy*=Math.pow(.08,dt);}g.particles=g.particles.filter(a=>a.life>0);
      for(const t of g.texts){t.life-=dt;t.y-=20*dt;}g.texts=g.texts.filter(t=>t.life>0);
      // match objective checks
      if(g.mode==="knockout"){const leader=g.cars.reduce((a,b)=>a.kills>b.kills?a:b);if(leader.kills>=8){finishMatch(g,leader.player?"You reached eight takedowns.":`${leader.name} reached eight takedowns.`);return;}}
      if(g.mode==="gemrush"){const leader=g.cars.reduce((a,b)=>a.gems>b.gems?a:b);if(leader.gems>=25){finishMatch(g,leader.player?"You banked 25 rift shards.":`${leader.name} collected 25 rift shards.`);return;}}
      if(g.mode==="lastkart"){const living=g.cars.filter(c=>!c.eliminated);if(living.length<=1){finishMatch(g,living[0]?.player?"You are the last kart rolling.":"The arena is lost.");return;}}
      if(g.remaining<=0){finishMatch(g,"The match timer expired.");return;}
      if(timestamp-lastHudRef.current>130){lastHudRef.current=timestamp;const ranking=g.cars.filter(c=>!c.eliminated).sort((a,b)=>g.mode==="gemrush"?b.gems-a.gems:g.mode==="knockout"?b.kills-a.kills:b.lives-a.lives);setHud({time:g.remaining,score:g.mode==="gemrush"?p.gems:p.score,hp:p.hp,nitro:p.nitro,weapon:p.weapon?WEAPONS[p.weapon].short:"EMPTY",ammo:p.weaponAmmo,kills:p.kills,gems:p.gems,lives:p.lives,position:Math.max(1,ranking.findIndex(c=>c.player)+1),combo:g.combo,mode:g.mode});}
    };
    const draw=(g,timestamp)=>{ctx.save();let sx=0,sy=0;if(g.shake>0){sx=rand(-g.shake*40,g.shake*40);sy=rand(-g.shake*40,g.shake*40);}ctx.translate(sx,sy);drawArena(ctx,g,timestamp); // floating islands / hazards
      if(g.mapIndex===1){for(let i=0;i<4;i++){const x=170+i*260,y=355+Math.sin(g.clock*.8+i)*32;ctx.fillStyle="#ff654022";ctx.shadowColor="#ff634f";ctx.shadowBlur=19;ctx.beginPath();ctx.ellipse(x,y,55,17,0,0,TAU);ctx.fill();ctx.shadowBlur=0;}}
      if(g.mapIndex===2){for(let i=0;i<3;i++){const x=340+i*215,y=350+Math.sin(g.clock*.55+i*2)*110;ctx.fillStyle="#50d6bc18";ctx.beginPath();ctx.ellipse(x,y,85,44,Math.sin(g.clock+i),0,TAU);ctx.fill();}}
      // crystals
      for(const c of g.crystals){ctx.save();ctx.translate(c.x,c.y+Math.sin(c.bob)*4);ctx.rotate(c.spin);ctx.shadowColor="#64ffe0";ctx.shadowBlur=18;ctx.fillStyle="#66ffe0";ctx.beginPath();ctx.moveTo(0,-13);ctx.lineTo(10,0);ctx.lineTo(0,13);ctx.lineTo(-10,0);ctx.closePath();ctx.fill();ctx.fillStyle="#eaffff";ctx.globalAlpha=.75;ctx.fillRect(-2,-7,3,8);ctx.restore();}
      // weapon boxes
      for(const b of g.boxes){if(b.respawn>0)continue;const col=WEAPONS[b.weapon].color;ctx.save();ctx.translate(b.x,b.y);ctx.rotate(Math.sin(b.spin*1.8)*.08);ctx.shadowColor=col;ctx.shadowBlur=20;ctx.fillStyle="#121b30";ctx.strokeStyle=col;ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(-17,-17,34,34,8);ctx.fill();ctx.stroke();ctx.shadowBlur=0;ctx.fillStyle=col;ctx.font="900 17px system-ui";ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillText(b.weapon==="rocket"?"R":b.weapon==="plasma"?"P":b.weapon==="mine"?"M":"E",0,1);ctx.restore();}
      // mines
      for(const m of g.mines){ctx.fillStyle="#11182a";ctx.strokeStyle="#ffe28a";ctx.lineWidth=2;ctx.beginPath();ctx.arc(m.x,m.y,12,0,TAU);ctx.fill();ctx.stroke();ctx.fillStyle="#ffdf7e";ctx.beginPath();ctx.arc(m.x,m.y,4,0,TAU);ctx.fill();}
      // projectiles and EMP fields
      for(const s of g.shots){if(s.type==="emp"){ctx.strokeStyle="#c9a2ff";ctx.globalAlpha=Math.max(0,s.life/.35);ctx.lineWidth=5;ctx.beginPath();ctx.arc(s.x,s.y,s.r*(1-s.life/.35),0,TAU);ctx.stroke();ctx.globalAlpha=1;continue;}ctx.save();ctx.translate(s.x,s.y);ctx.rotate(s.angle);ctx.fillStyle=s.color;ctx.shadowColor=s.color;ctx.shadowBlur=18;ctx.beginPath();if(s.type==="rocket"){ctx.roundRect(-13,-5,25,10,4);ctx.moveTo(12,-5);ctx.lineTo(21,0);ctx.lineTo(12,5);ctx.fill();}else{ctx.beginPath();ctx.arc(0,0,5,0,TAU);ctx.fill();}ctx.restore();}
      // cars
      for(const car of g.cars){if(car.respawn>0||car.eliminated)continue;drawKart(ctx,car,timestamp);ctx.save();ctx.fillStyle="#030711aa";ctx.fillRect(car.x-22,car.y-34,44,5);ctx.fillStyle=car.hp>car.maxHp*.5?"#66edc4":"#ff897e";ctx.fillRect(car.x-22,car.y-34,44*clamp(car.hp/car.maxHp,0,1),5);ctx.font="800 10px system-ui";ctx.textAlign="center";ctx.fillStyle=car.player?"#bffff7":"#c2cde4";ctx.fillText(car.player?"YOU":car.name,car.x,car.y-41);ctx.restore();}
      // particles / floating events
      for(const a of g.particles){ctx.globalAlpha=clamp(a.life/a.max,0,1);ctx.fillStyle=a.color;ctx.beginPath();ctx.arc(a.x,a.y,a.size,0,TAU);ctx.fill();}ctx.globalAlpha=1;
      for(const t of g.texts){ctx.globalAlpha=clamp(t.life/t.max,0,1);ctx.font="900 14px system-ui";ctx.textAlign="center";ctx.shadowColor="#000";ctx.shadowBlur=8;ctx.fillStyle=t.color;ctx.fillText(t.text,t.x,t.y);}ctx.globalAlpha=1;ctx.restore();};
    const loop=(ts)=>{now=ts;const dt=Math.min(.033,(ts-(last||ts))/1000);last=ts;const g=gRefLocal.current;if(g&&g.state==="playing"&&screenRef.current==="playing"&&!helpRef.current){tick(g,dt,ts);draw(g,ts);}else{ctx.clearRect(0,0,CW,CH);if(g)draw(g,ts);else drawMenuBackdrop(ctx,ts);}raf=requestAnimationFrame(loop);};
    const keyMap={w:"up",ArrowUp:"up",s:"down",ArrowDown:"down",a:"left",ArrowLeft:"left",d:"right",ArrowRight:"right", " ":"drift",Shift:"nitro",j:"fire",J:"fire",e:"shield",E:"shield"};
    const keyDown=(e)=>{const k=keyMap[e.key]||keyMap[e.key.toLowerCase()];if(k){e.preventDefault();input[k]=true;}if(e.key.toLowerCase()==="h")setHelp(v=>!v);};
    const keyUp=(e)=>{const k=keyMap[e.key]||keyMap[e.key.toLowerCase()];if(k)input[k]=false;};
    window.addEventListener("keydown",keyDown);window.addEventListener("keyup",keyUp);window.addEventListener("blur",()=>{Object.keys(input).forEach(k=>input[k]=false);});
    raf=requestAnimationFrame(loop);
    return()=>{cancelAnimationFrame(raf);ro.disconnect();window.removeEventListener("keydown",keyDown);window.removeEventListener("keyup",keyUp);};
  },[]);
  useEffect(()=>{screenRef.current=screen;},[screen]);
  useEffect(()=>{helpRef.current=help;},[help]);
  useEffect(()=>{soundEnabledRef.current=soundOn;},[soundOn]);

  const control=(name,pressed)=>{inputRef.current[name]=pressed;};
  const touchBtn=(name,label,cls="")=><button key={name} className={`nr-touch ${cls}`} onPointerDown={e=>{e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);control(name,true);}} onPointerUp={e=>{e.preventDefault();control(name,false);}} onPointerCancel={()=>control(name,false)} onLostPointerCapture={()=>control(name,false)}>{label}</button>;
  const modeMeta=MODES.find(m=>m.id===mode),carMeta=CARS.find(c=>c.id===save.selected)||CARS[0];
  const formatTime=s=>`${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,"0")}`;
  return <div className="nitro-rift-shell">
    <div className="nr-topbar"><div className="nr-live"><span/> RIFT ARENA · LIVE BUILD</div><div className="nr-wallet"><span>✦ {save.coins.toLocaleString()} CREDITS</span><span>🏆 {save.wins} WINS</span></div></div>
    <div className="nr-stage-wrap">
      <canvas ref={canvasRef} className="nr-canvas" aria-label="Nitro Rift top-down kart combat arena" />
      {screen!=="playing"&&<div className="nr-overlay">
        {screen==="menu"&&<div className="nr-menu nr-panel">
          <div className="nr-kicker">PLAYZIPPY ORIGINAL · SEASON ZERO</div><div className="nr-logo">NITRO <em>RIFT</em></div><div className="nr-subtitle">DRIVE HARD. HIT BACK. OWN THE RIFT.</div>
          <div className="nr-menu-grid"><div className="nr-select-block"><div className="nr-section-title">01 / PICK YOUR MODE</div>{MODES.map(m=><button key={m.id} className={`nr-mode-card ${mode===m.id?"selected":""}`} onClick={()=>setMode(m.id)}><span className="nr-mode-icon">{m.icon}</span><span><b>{m.name}</b><small>{m.desc}</small></span><i>{mode===m.id?"●":"○"}</i></button>)}
          <div className="nr-section-title nr-map-title">02 / CHOOSE AN ARENA</div><div className="nr-map-row">{MAPS.map((m,i)=><button key={m.name} className={`nr-map-chip ${mapIndex===i?"selected":""}`} onClick={()=>setMapIndex(i)}><span style={{background:m.glow}}/>{m.name}</button>)}</div></div>
          <div className="nr-garage"><div className="nr-section-title">03 / GARAGE</div><div className="nr-car-preview" style={{"--car":carMeta.color,"--car-glow":carMeta.color}}><div className="nr-preview-orbit"/><div className="nr-preview-kart">▰</div><div className="nr-car-name">{carMeta.name}</div><small>{carMeta.title}</small></div><div className="nr-car-list">{CARS.map(c=>{const unlocked=save.unlocked.includes(c.id);return <button key={c.id} className={`nr-car-chip ${save.selected===c.id?"selected":""} ${!unlocked?"locked":""}`} onClick={()=>chooseCar(c.id)}><span style={{background:c.color}}/><b>{c.name}</b><small>{unlocked?"OWNED":c.unlock}</small>{!unlocked&&<i>🔒</i>}</button>;})}</div>
          <div className="nr-upgrades"><div className="nr-section-title">WORKSHOP · PERMANENT UPGRADES</div>{[{k:"engine",n:"ENGINE",d:"Top speed +14",icon:"↗"},{k:"handling",n:"HANDLING",d:"Steering +0.16",icon:"⌁"},{k:"armor",n:"ARMOR",d:"Hull +10",icon:"⬡"}].map(u=>{const level=save[u.k],price=[350,650,1000][level]||1500;return <div className="nr-upgrade" key={u.k}><span>{u.icon}</span><div><b>{u.n} <small>LV.{level}/3</small></b><small>{u.d}</small></div><button disabled={level>=3||save.coins<price} onClick={()=>buyUpgrade(u.k)}>{level>=3?"MAX":`${price} ✦`}</button></div>;})}</div></div></div>
          <div className="nr-menu-bottom"><div><b>{modeMeta.target}</b><small>{formatTime(modeMeta.time)} MATCH · 5 RIVALS · BOT AI</small></div><button className="nr-start" onClick={startMatch}>ENTER THE ARENA <span>↗</span></button></div>
          <div className="nr-controls-note">KEYBOARD: WASD / ARROWS DRIVE · SPACE DRIFT · SHIFT NITRO · J FIRE · E SHIELD</div>
        </div>}
        {screen==="result"&&result&&<div className="nr-result nr-panel"><div className="nr-kicker">MATCH COMPLETE</div><div className={`nr-result-title ${result.won?"win":"lose"}`}>{result.won?"RIFT CHAMPION":"RACE OVER"}</div><p>{result.reason}</p><div className="nr-result-stats"><div><b>{result.kills}</b><small>TAKEDOWNS</small></div><div><b>{result.gems}</b><small>SHARDS</small></div><div><b>{result.place}{result.place===1?"ST":result.place===2?"ND":result.place===3?"RD":"TH"}</b><small>FINAL PLACE</small></div><div><b>+{result.reward}</b><small>CREDITS</small></div></div><div className="nr-result-actions"><button className="nr-start" onClick={startMatch}>RACE AGAIN ↻</button><button className="nr-secondary" onClick={()=>setScreen("menu")}>GARAGE / MODES</button></div></div>}
        {screen==="paused"&&<div className="nr-result nr-panel"><div className="nr-kicker">TAKE A BREATHER</div><div className="nr-result-title">PAUSED</div><p>Your match is waiting.</p><div className="nr-result-actions"><button className="nr-start" onClick={()=>setScreen("playing")}>RESUME ▶</button><button className="nr-secondary" onClick={()=>{if(gRef.current)gRef.current.state="finished";setScreen("menu");}}>QUIT MATCH</button></div></div>}
      </div>}
      {screen==="playing"&&<><div className="nr-hud-top"><div className="nr-hud-box"><small>{mode.toUpperCase()}</small><b>{formatTime(hud.time)}</b></div><div className="nr-hud-box nr-place"><small>POSITION</small><b>#{hud.position||"–"}<i>/6</i></b></div><div className="nr-hud-box"><small>{mode==="gemrush"?"RIFT SHARDS":"TAKEDOWNS"}</small><b>{mode==="gemrush"?hud.gems:hud.kills}</b></div><button className="nr-pause" onClick={()=>setScreen("paused")}>Ⅱ</button></div><div className="nr-hud-bottom"><div className="nr-hp"><span>HULL</span><div><i style={{width:`${clamp(hud.hp/(carMeta.armor+save.armor*10)*100,0,100)}%`}}/></div><b>{Math.max(0,Math.ceil(hud.hp))}</b></div><div className="nr-nitro"><span>NITRO</span><div><i style={{width:`${hud.nitro}%`}}/></div></div><div className="nr-weapon"><small>WEAPON</small><b>{hud.weapon} <i>{hud.ammo>100?"∞":`×${hud.ammo}`}</i></b></div>{mode==="lastkart"&&<div className="nr-lives">♥ ×{hud.lives}</div>}</div></>}
    </div>
    {screen==="playing"&&<div className="nr-touch-controls"><div className="nr-steer-pad">{touchBtn("left","◀")}{touchBtn("right","▶")}</div><div className="nr-action-pad">{touchBtn("down","BRAKE","brake")}{touchBtn("up","GAS","gas")}{touchBtn("drift","DRIFT","drift")}{touchBtn("nitro","BOOST","boost")}{touchBtn("fire","FIRE","fire")}{touchBtn("shield","SHIELD","shield")}</div></div>}
    <div className="nr-footer"><div><b>{screen==="playing"?MAPS[mapIndex].name:"SEASON ZERO"}</b><span>{screen==="playing"?"Find weapon crates · Chain boosts · Protect your hull":"6 KARTS · 3 MODES · 3 ARENAS · LOCAL SAVE"}</span></div><div className="nr-footer-actions"><button onClick={()=>setSoundOn(v=>!v)}>{soundOn?"SOUND ON ♫":"SOUND OFF ×"}</button><button onClick={()=>setHelp(v=>!v)}>HOW TO PLAY ?</button></div></div>
    {help&&<div className="nr-help-backdrop" onClick={()=>setHelp(false)}><div className="nr-help nr-panel" onClick={e=>e.stopPropagation()}><button className="nr-help-close" onClick={()=>setHelp(false)}>×</button><div className="nr-kicker">DRIVER BRIEFING</div><h3>HOW TO OWN THE RIFT</h3><div className="nr-help-grid"><div><b>DRIVE</b><p>WASD or arrow keys. Turn while moving; use Space to drift around corners. Shift gives a short nitro burst.</p></div><div><b>FIGHT</b><p>Drive through glowing crates to equip rockets, plasma, mines or EMP. Press J to fire. E triggers a short shield by spending nitro.</p></div><div><b>WIN</b><p>Knockout: reach 8 takedowns. Gem Rush: collect 25 rift shards. Last Kart: survive with your 3 lives.</p></div><div><b>GET BETTER</b><p>Use boost pads, ram rivals at speed, save credits and upgrade your kart in the workshop. New karts unlock as you win.</p></div></div><button className="nr-start" onClick={()=>setHelp(false)}>GOT IT</button></div></div>}
    {notice&&<div className="nr-toast">{notice}</div>}
    <div className="nr-mobile-tip">TIP: Hold multiple controls together for boost + drift combinations.</div>
  </div>;
}

function driveCar(g,car,inp,dt,game,damageCar,spawnProjectile){
  if(car.stun>0){car.stun-=dt;car.vx*=Math.pow(.12,dt);car.vy*=Math.pow(.12,dt);return;}
  const spec=CARS.find(c=>c.id===car.carId)||CARS[0];const maxSpeed=(car.player?car.maxSpeed:spec.speed)*(inp.nitro&&car.nitro>0?1.38:1);const accel=inp.nitro&&car.nitro>0?650:430;
  const throttle=inp.throttle||0;const speedBefore=Math.hypot(car.vx,car.vy);const forwardX=Math.cos(car.angle),forwardY=Math.sin(car.angle);const forwardSpeed=car.vx*forwardX+car.vy*forwardY;
  if(throttle!==0){car.vx+=forwardX*accel*throttle*dt;car.vy+=forwardY*accel*throttle*dt;}
  if(inp.nitro&&car.nitro>0&&throttle>0){car.boostTime=.14;car.nitro=Math.max(0,car.nitro-32*dt);}else{car.nitro=Math.min(100,car.nitro+8*dt);}
  if(inp.drift&&speedBefore>80){car.drift=Math.min(1,car.drift+dt*3);car.skid=.22;}else car.drift=Math.max(0,car.drift-dt*2.4);
  const turn=(car.player?car.turnPower:spec.turn)*(0.26+Math.min(speedBefore/maxSpeed,1)*.95)*(inp.drift?1.52:1);car.angle+= (inp.steer||0)*turn*dt*(speedBefore<12?0.45:1)*(forwardSpeed< -25?-.72:1);
  // Drift retains lateral velocity; normal driving grips toward the nose.
  const fx=Math.cos(car.angle),fy=Math.sin(car.angle),rx=-fy,ry=fx;const vf=car.vx*fx+car.vy*fy,vl=car.vx*rx+car.vy*ry;const grip=inp.drift?.985:.82;car.vx=fx*vf+rx*vl*grip;car.vy=fy*vf+ry*vl*grip;
  if(throttle===0&&!inp.brake){car.vx*=Math.pow(.66,dt);car.vy*=Math.pow(.66,dt);}if(inp.brake){if(forwardSpeed>35){car.vx*=Math.pow(.22,dt);car.vy*=Math.pow(.22,dt);}else{car.vx-=forwardX*230*dt;car.vy-=forwardY*230*dt;}}
  let speed=Math.hypot(car.vx,car.vy);if(speed>maxSpeed){car.vx=car.vx/speed*maxSpeed;car.vy=car.vy/speed*maxSpeed;}
  car.x+=car.vx*dt;car.y+=car.vy*dt;car.distTravelled+=speed*dt;car.boostTime=Math.max(0,car.boostTime-dt);car.invuln=Math.max(0,car.invuln-dt);car.shield=Math.max(0,car.shield-dt);car.hit=Math.max(0,car.hit-dt);car.ramCd=Math.max(0,car.ramCd-dt);car.fireCd=Math.max(0,car.fireCd-dt);
  // Soft wall bounce keeps karts in the combat arena.
  const pad=57;for(const [axis,min,max] of [["x",pad,CW-pad],["y",pad,CH-pad]]){if(car[axis]<min){car[axis]=min; if(axis==="x")car.vx=Math.abs(car.vx)*.55;else car.vy=Math.abs(car.vy)*.55;car.hp-=.8;car.hit=.08;}if(car[axis]>max){car[axis]=max;if(axis==="x")car.vx=-Math.abs(car.vx)*.55;else car.vy=-Math.abs(car.vy)*.55;car.hp-=.8;car.hit=.08;}}
  // Bump off arena pillars.
  for(const [ox,oy,r] of game.map.obstacles){const dx=car.x-ox,dy=car.y-oy,d=Math.hypot(dx,dy)||1,min=r+22;if(d<min){const nx=dx/d,ny=dy/d;car.x=ox+nx*min;car.y=oy+ny*min;const vn=car.vx*nx+car.vy*ny;if(vn<0){car.vx-=1.55*vn*nx;car.vy-=1.55*vn*ny;}if(Math.abs(vn)>190&&car.ramCd<=0){car.hp-=4;car.ramCd=.5;game.shake=.1;addBurst(game,car.x,car.y,game.map.glow,5,90);}}}
  // Drift sparks, trails and pad pickup feedback.
  if(inp.drift&&speed>120&&Math.random()<dt*34){game.particles.push({x:car.x-rx*13-rand(-3,3),y:car.y-ry*13-rand(-3,3),vx:-car.vx*.24+rand(-40,40),vy:-car.vy*.24+rand(-40,40),life:.35,max:.35,color:game.map.glow,size:rand(2,4)});}
}
function drawMenuBackdrop(ctx,t){ctx.fillStyle="#091426";ctx.fillRect(0,0,CW,CH);const gr=ctx.createRadialGradient(CW/2,CH/2,20,CW/2,CH/2,480);gr.addColorStop(0,"#225b7570");gr.addColorStop(1,"#080d1b00");ctx.fillStyle=gr;ctx.fillRect(0,0,CW,CH);ctx.strokeStyle="#58dfee18";for(let x=0;x<CW;x+=48){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,CH);ctx.stroke();}for(let y=0;y<CH;y+=48){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(CW,y);ctx.stroke();}for(let i=0;i<6;i++){const a=t/1800+i*TAU/6,x=CW/2+Math.cos(a)*280,y=CH/2+Math.sin(a)*180;ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.fillStyle=["#45e6e9","#ff815f","#b28cff","#f3dc66"][i%4];ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=24;ctx.beginPath();ctx.roundRect(-25,-15,50,30,9);ctx.fill();ctx.restore();}}
