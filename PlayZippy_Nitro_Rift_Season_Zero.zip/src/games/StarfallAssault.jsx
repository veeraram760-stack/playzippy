import React, { useEffect, useRef, useState } from "react";

const W = 900, H = 560;
const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));

export default function StarfallAssault(){
  const canvas=useRef(null), game=useRef(null);
  const [status,setStatus]=useState("ready"),[score,setScore]=useState(0),[wave,setWave]=useState(1),[lives,setLives]=useState(3),[best,setBest]=useState(()=>Number(localStorage.getItem("pz-starfall-best")||0));
  useEffect(()=>{
    const c=canvas.current,ctx=c.getContext("2d");
    const s=game.current={mode:"ready",x:W/2,y:H-75,bullets:[],foes:[],sparks:[],stars:Array.from({length:100},()=>({x:Math.random()*W,y:Math.random()*H,z:.5+Math.random()*2})),score:0,wave:1,lives:3,frame:0,spawn:0,fire:0,power:0,boss:null,aim:W/2};
    const keys=new Set();let raf,last=0;
    const start=()=>{Object.assign(s,{mode:"playing",x:W/2,y:H-75,bullets:[],foes:[],sparks:[],score:0,wave:1,lives:3,frame:0,spawn:0,fire:0,power:0,boss:null,aim:W/2});setStatus("playing");setScore(0);setWave(1);setLives(3);};s.start=start;
    const boom=(x,y,color,n=20)=>{for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,v=1+Math.random()*5;s.sparks.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,life:20+Math.random()*24,color,size:1+Math.random()*3});}};
    const spawnFoe=()=>{const boss=s.wave%5===0 && !s.boss; if(boss){s.boss={x:W/2,y:70,hp:28,max:28,dir:1};return;}const kind=Math.random()<.24?"tank":"scout";s.foes.push({x:50+Math.random()*(W-100),y:-35,hp:kind==="tank"?3:1,max:kind==="tank"?3:1,kind,phase:Math.random()*6.2,speed:kind==="tank"?1.1:2.1});};
    const drawShip=(x,y)=>{ctx.save();ctx.translate(x,y);ctx.shadowColor="#58e6ff";ctx.shadowBlur=24;const g=ctx.createLinearGradient(0,-35,0,26);g.addColorStop(0,"#eaffff");g.addColorStop(.35,"#65dfff");g.addColorStop(1,"#2853a7");ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(0,-34);ctx.lineTo(30,22);ctx.lineTo(9,14);ctx.lineTo(0,24);ctx.lineTo(-9,14);ctx.lineTo(-30,22);ctx.closePath();ctx.fill();ctx.shadowBlur=0;ctx.fillStyle="#14325c";ctx.beginPath();ctx.ellipse(0,-1,7,14,0,0,Math.PI*2);ctx.fill();ctx.fillStyle="#b9ffff";ctx.beginPath();ctx.ellipse(0,-3,3.5,9,0,0,Math.PI*2);ctx.fill();ctx.fillStyle="#ff9c5c";ctx.fillRect(-19,18,7,13);ctx.fillRect(12,18,7,13);ctx.restore();};
    const drawEnemy=(e)=>{ctx.save();ctx.translate(e.x,e.y);ctx.shadowColor=e.kind==="tank"?"#ff9c4c":"#ff4c9a";ctx.shadowBlur=15;const g=ctx.createLinearGradient(0,-20,0,20);g.addColorStop(0,e.kind==="tank"?"#ffd17a":"#ff8bc0");g.addColorStop(1,e.kind==="tank"?"#a74b68":"#7a3f9d");ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(0,20);ctx.lineTo(32,-12);ctx.lineTo(12,-8);ctx.lineTo(0,-22);ctx.lineTo(-12,-8);ctx.lineTo(-32,-12);ctx.closePath();ctx.fill();ctx.shadowBlur=0;ctx.fillStyle="#361c57";ctx.beginPath();ctx.ellipse(0,-2,8,7,0,0,Math.PI*2);ctx.fill();ctx.restore();};
    const draw=(dt)=>{
      const bg=ctx.createLinearGradient(0,0,0,H);bg.addColorStop(0,"#070f2b");bg.addColorStop(1,"#10113c");ctx.fillStyle=bg;ctx.fillRect(0,0,W,H);
      s.stars.forEach(st=>{st.y+=(s.mode==="playing"?st.z*2.2:.5);if(st.y>H){st.y=0;st.x=Math.random()*W;}ctx.globalAlpha=.3+st.z*.3;ctx.fillStyle=st.z>1.6?"#a8f7ff":"#8198e7";ctx.beginPath();ctx.arc(st.x,st.y,st.z,0,Math.PI*2);ctx.fill();});ctx.globalAlpha=1;
      // distant nebula light
      const neb=ctx.createRadialGradient(180,210,20,180,210,340);neb.addColorStop(0,"#7d48c432");neb.addColorStop(1,"#7d48c400");ctx.fillStyle=neb;ctx.fillRect(0,0,W,H);
      s.bullets.forEach(b=>{ctx.shadowColor=b.enemy?"#ff6eac":"#61f7ff";ctx.shadowBlur=14;ctx.fillStyle=b.enemy?"#ff90be":"#a5ffff";ctx.beginPath();ctx.roundRect(b.x-3,b.y-12,6,22,3);ctx.fill();ctx.shadowBlur=0;});
      s.foes.forEach(drawEnemy);if(s.boss){ctx.save();ctx.translate(s.boss.x,s.boss.y);ctx.shadowColor="#ff4b83";ctx.shadowBlur=24;ctx.fillStyle="#d85287";ctx.beginPath();ctx.moveTo(-65,-25);ctx.lineTo(-25,-48);ctx.lineTo(0,-36);ctx.lineTo(25,-48);ctx.lineTo(65,-25);ctx.lineTo(48,32);ctx.lineTo(0,48);ctx.lineTo(-48,32);ctx.closePath();ctx.fill();ctx.shadowBlur=0;ctx.fillStyle="#fff0f7";ctx.fillRect(-33,-9,20,7);ctx.fillRect(13,-9,20,7);ctx.fillStyle="#531f66";ctx.fillRect(-10,4,20,7);ctx.restore();ctx.fillStyle="#241b3f";ctx.fillRect(W/2-130,18,260,8);ctx.fillStyle="#ff6598";ctx.fillRect(W/2-130,18,260*(s.boss.hp/s.boss.max),8);}
      s.sparks.forEach(p=>{ctx.globalAlpha=clamp(p.life/35,0,1);ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,Math.PI*2);ctx.fill();});ctx.globalAlpha=1;
      drawShip(s.x,s.y);
      if(s.mode!=="playing"){ctx.fillStyle="#040819b8";ctx.fillRect(0,0,W,H);ctx.textAlign="center";ctx.shadowColor="#7b6cff";ctx.shadowBlur=25;ctx.fillStyle="#fff";ctx.font="900 52px system-ui";ctx.fillText(s.mode==="over"?"MISSION FAILED":"STARFALL ASSAULT",W/2,230);ctx.shadowBlur=0;ctx.fillStyle="#b2c5eb";ctx.font="600 17px system-ui";ctx.fillText(s.mode==="over"?`Final score  ${s.score.toLocaleString()}  •  Wave ${s.wave}`:"DEFEND THE GALAXY",W/2,270);ctx.fillStyle="#80f6ff";ctx.font="900 17px system-ui";ctx.fillText(s.mode==="over"?"TAP TO REDEPLOY":"TAP TO LAUNCH",W/2,330);}
    };
    const loop=(now)=>{const dt=Math.min(32,now-(last||now));last=now;const f=dt/16.67;
      if(s.mode==="playing"){
        s.frame+=f;let dx=0;if(keys.has("ArrowLeft")||keys.has("a"))dx-=1;if(keys.has("ArrowRight")||keys.has("d"))dx+=1;s.x=clamp(s.x+dx*6*f,38,W-38);if(keys.has("ArrowUp")||keys.has("w"))s.y=clamp(s.y-4*f,H*.45,H-58);if(keys.has("ArrowDown")||keys.has("s"))s.y=clamp(s.y+4*f,H*.45,H-58);
        if(s.mode==="playing" && (s.frame-s.fire)>9){s.fire=s.frame;s.bullets.push({x:s.x-13,y:s.y-25,v:-11,enemy:false},{x:s.x+13,y:s.y-25,v:-11,enemy:false});if(s.power>0){s.bullets.push({x:s.x,y:s.y-40,v:-13,enemy:false});s.power-=f;}}
        s.spawn+=f;if(s.spawn>Math.max(18,52-s.wave*2)){s.spawn=0;spawnFoe();}
        if(s.boss){s.boss.x+=s.boss.dir*2.2*f;if(s.boss.x>W-95||s.boss.x<95)s.boss.dir*=-1;if(s.frame%75<2)s.bullets.push({x:s.boss.x-38,y:s.boss.y+25,v:4,enemy:true},{x:s.boss.x,y:s.boss.y+35,v:5,enemy:true},{x:s.boss.x+38,y:s.boss.y+25,v:4,enemy:true});}
        s.foes.forEach(e=>{e.y+=e.speed*f;e.x+=Math.sin(s.frame*.025+e.phase)*1.5*f;if(s.frame%100<1&&Math.random()<.35)s.bullets.push({x:e.x,y:e.y+18,v:4,enemy:true});});
        s.bullets.forEach(b=>b.y+=b.v*f);
        s.bullets=s.bullets.filter(b=>{if(!b.enemy){let hit=false;s.foes=s.foes.filter(e=>{if(Math.abs(e.x-b.x)<30&&Math.abs(e.y-b.y)<28){e.hp--;boom(b.x,b.y,"#7cf8ff",5);if(e.hp<=0){s.score+=e.kind==="tank"?40:15;boom(e.x,e.y,"#ff80bb",18);return false;}hit=true;}return true;});if(s.boss&&Math.abs(s.boss.x-b.x)<75&&Math.abs(s.boss.y-b.y)<55){s.boss.hp--;s.score+=3;hit=true;boom(b.x,b.y,"#ffb5d4",4);if(s.boss.hp<=0){boom(s.boss.x,s.boss.y,"#ff82c2",70);s.score+=500;s.boss=null;s.wave++;setWave(s.wave);}}return !hit&&b.y>-30;}if(Math.abs(b.x-s.x)<27&&Math.abs(b.y-s.y)<28){s.lives--;setLives(s.lives);boom(s.x,s.y,"#ff8e9f",25);if(s.lives<=0){s.mode="over";setStatus("over");const n=Math.max(s.score,Number(localStorage.getItem("pz-starfall-best")||0));localStorage.setItem("pz-starfall-best",String(n));setBest(n);}return false;}return b.y<H+30;});
        s.foes=s.foes.filter(e=>{if(e.y>H+45){s.lives--;setLives(s.lives);if(s.lives<=0){s.mode="over";setStatus("over");const n=Math.max(s.score,Number(localStorage.getItem("pz-starfall-best")||0));localStorage.setItem("pz-starfall-best",String(n));setBest(n);}return false;}return true;});
        if(s.frame%18<1){const next=Math.floor(s.score/180)+1;if(next>s.wave&&!s.boss){s.wave=next;setWave(next);}}
        s.sparks=s.sparks.filter(p=>{p.x+=p.vx*f;p.y+=p.vy*f;p.vx*=.98;p.vy*=.98;p.life-=f;return p.life>0;});if(s.frame%10<1)setScore(s.score);
      }
      draw(dt);raf=requestAnimationFrame(loop);
    };
    const down=e=>{if(["ArrowLeft","ArrowRight","ArrowUp","ArrowDown"," "].includes(e.key))e.preventDefault();keys.add(e.key.toLowerCase());if(e.key===" "&&s.mode!=="playing")start();};const up=e=>keys.delete(e.key.toLowerCase());
    const drag=e=>{if(s.mode!=="playing")return;const r=c.getBoundingClientRect();s.x=clamp((e.clientX-r.left)*W/r.width,38,W-38);s.y=clamp((e.clientY-r.top)*H/r.height,H*.42,H-58);};const tap=e=>{if(s.mode!=="playing")start();else drag(e);};
    window.addEventListener("keydown",down);window.addEventListener("keyup",up);c.addEventListener("pointerdown",tap);c.addEventListener("pointermove",drag);raf=requestAnimationFrame(loop);
    return()=>{cancelAnimationFrame(raf);window.removeEventListener("keydown",down);window.removeEventListener("keyup",up);c.removeEventListener("pointerdown",tap);c.removeEventListener("pointermove",drag);};
  },[]);
  const start=()=>game.current?.start?.();
  return <div className="arcade-shell space-shell"><div className="arcade-topline"><div><span className="live-dot purple"/> SPACE COMBAT • WAVE SURVIVAL</div><div className="arcade-stats"><span>WAVE <b>{wave}</b></span><span>HULL <b>{"♥".repeat(Math.max(0,lives))}{"♡".repeat(Math.max(0,3-lives))}</b></span><span>BEST <b>{best.toLocaleString()}</b></span></div></div><div className="space-frame"><canvas ref={canvas} width={W} height={H} aria-label="Starfall Assault space shooter"/><div className="canvas-hud"><span>✦ {score.toLocaleString()}</span><span>WAVE {wave}</span></div></div><div className="arcade-controls centered"><button className="arcade-play" onClick={start}>{status==="playing"?"RESTART MISSION":status==="over"?"TRY AGAIN":"LAUNCH MISSION"}</button></div><p className="arcade-instruction">Move with <b>W A S D</b> or arrow keys. Your cannons auto-fire. Drag your ship on touch screens. Clear waves and destroy the boss ships.</p></div>
}
