import React, { useCallback, useEffect, useMemo, useState } from "react";
const COLORS=["ruby","aqua","violet","amber","lime","rose"];
const SYMBOLS={ruby:"◆",aqua:"✦",violet:"✧",amber:"✹",lime:"❖",rose:"✿"};
const SIZE=8;
const makeBoard=()=>{const board=Array.from({length:SIZE},()=>Array(SIZE).fill(null));for(let y=0;y<SIZE;y++)for(let x=0;x<SIZE;x++){let choices=COLORS.filter(c=>!(x>=2&&board[y][x-1]===c&&board[y][x-2]===c)&&!(y>=2&&board[y-1][x]===c&&board[y-2][x]===c));board[y][x]=choices[Math.floor(Math.random()*choices.length)];}return board;};
const copy=b=>b.map(r=>[...r]);
function findMatches(board){const hits=new Set();for(let y=0;y<SIZE;y++){let x=0;while(x<SIZE){let e=x+1;while(e<SIZE&&board[y][e]===board[y][x])e++;if(board[y][x]&&e-x>=3)for(let k=x;k<e;k++)hits.add(`${y}-${k}`);x=e;}}for(let x=0;x<SIZE;x++){let y=0;while(y<SIZE){let e=y+1;while(e<SIZE&&board[e][x]===board[y][x])e++;if(board[y][x]&&e-y>=3)for(let k=y;k<e;k++)hits.add(`${k}-${x}`);y=e;}}return hits;}
export default function CrystalCascade(){
 const [board,setBoard]=useState(makeBoard),[selected,setSelected]=useState(null),[score,setScore]=useState(0),[moves,setMoves]=useState(24),[combo,setCombo]=useState(0),[busy,setBusy]=useState(false),[seconds,setSeconds]=useState(90),[best,setBest]=useState(()=>Number(localStorage.getItem("pz-crystal-best")||0)),[ended,setEnded]=useState(false);
 const matches=useMemo(()=>findMatches(board),[board]);
 const reset=useCallback(()=>{setBoard(makeBoard());setSelected(null);setScore(0);setMoves(24);setCombo(0);setBusy(false);setSeconds(90);setEnded(false);},[]);
 useEffect(()=>{if(ended)return;const t=setInterval(()=>setSeconds(s=>{if(s<=1){setEnded(true);return 0;}return s-1;}),1000);return()=>clearInterval(t);},[ended]);
 useEffect(()=>{if(ended){setBest(b=>{const n=Math.max(b,score);localStorage.setItem("pz-crystal-best",String(n));return n;});}},[ended]);
 const resolve=useCallback(async(initial)=>{let b=copy(initial),chain=0,total=0;setBusy(true);while(true){const hit=findMatches(b);if(!hit.size)break;chain++;total+=hit.size*10*chain;setCombo(chain);await new Promise(r=>setTimeout(r,260));hit.forEach(k=>{const [y,x]=k.split("-").map(Number);b[y][x]=null;});setBoard(copy(b));await new Promise(r=>setTimeout(r,160));for(let x=0;x<SIZE;x++){let col=b.map(row=>row[x]).filter(Boolean);while(col.length<SIZE)col.unshift(COLORS[Math.floor(Math.random()*COLORS.length)]);for(let y=0;y<SIZE;y++)b[y][x]=col[y];}setBoard(copy(b));await new Promise(r=>setTimeout(r,220));}setScore(s=>s+total);setCombo(0);setBusy(false);},[]);
 const choose=(y,x)=>{if(busy||ended)return;if(!selected){setSelected([y,x]);return;}const [sy,sx]=selected;if(sy===y&&sx===x){setSelected(null);return;}if(Math.abs(sy-y)+Math.abs(sx-x)!==1){setSelected([y,x]);return;}const b=copy(board);[b[sy][sx],b[y][x]]=[b[y][x],b[sy][sx]];setSelected(null);const hit=findMatches(b);if(!hit.size)return;setMoves(m=>m-1);setBoard(b);resolve(b);};
 useEffect(()=>{if(moves<=0&&!busy){setEnded(true);}},[moves,busy]);
 return <div className="crystal-shell">
  <div className="crystal-top"><div><span className="eyebrow">MATCH • COMBO • SHINE</span><h2>Crystal <em>Cascade</em></h2><p>Connect 3 or more matching crystals. Build chain reactions for huge scores.</p></div><div className="crystal-best"><small>PERSONAL BEST</small><b>{best.toLocaleString()}</b></div></div>
  <div className="crystal-stats"><div><small>SCORE</small><b>{score.toLocaleString()}</b></div><div><small>MOVES LEFT</small><b>{moves}</b></div><div><small>TIME</small><b className={seconds<=15?"urgent":""}>{`0:${String(seconds).padStart(2,"0")}`}</b></div></div>
  <div className="crystal-board-wrap"><div className="crystal-board">{board.map((row,y)=>row.map((color,x)=><button key={`${y}-${x}`} disabled={busy||ended} className={`crystal-tile ${color||""} ${selected?.[0]===y&&selected?.[1]===x?"selected":""} ${matches.has(`${y}-${x}`)?"matched":""}`} onClick={()=>choose(y,x)} aria-label={`Row ${y+1} column ${x+1} ${color||"empty"}`}><span>{SYMBOLS[color]||""}</span></button>))}</div>{ended&&<div className="crystal-overlay"><div><span>✦ ROUND COMPLETE ✦</span><strong>{score.toLocaleString()}</strong><small>POINTS EARNED</small><button className="arcade-play" onClick={reset}>PLAY AGAIN</button></div></div>}</div>
  <div className="crystal-bottom"><span>{combo>1?`🔥 ${combo}× CASCADE!`:"Make a match to start a cascade"}</span><button className="crystal-reset" onClick={reset}>↻ New round</button></div>
  <p className="arcade-instruction">Tap one crystal, then an adjacent crystal to swap. Matches of 3+ clear; falling gems can trigger cascading combos. 90-second challenge.</p>
 </div>
}
