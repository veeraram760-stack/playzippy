import React from "react";

// Monetization placeholder. Keep hidden until an ad network approves the site
// and provides the correct publisher/client identifiers and ad code.
export default function AdSlot({ label="Advertisement", className="" }) {
  const enabled = import.meta.env.VITE_ADS_ENABLED === "true";
  if (!enabled) return null;
  return <div className={`ad-slot ${className}`} aria-label={label}>{label}</div>;
}
