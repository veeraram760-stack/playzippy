import React from "react";
import { Link, NavLink } from "react-router-dom";
export default function Header() {
  return <header className="site-header">
    <Link to="/" className="brand"><span className="brand-mark">▶</span><span>play<span className="brand-accent">zippy</span></span></Link>
    <nav><NavLink to="/">Home</NavLink><a href="/#games">Games</a><NavLink to="/about">About</NavLink></nav>
    <a className="header-cta" href="/#games">PLAY NOW <span>↗</span></a>
  </header>;
}
