/*
 * EMBERFALL: THE LAST HEARTH — CAMPAIGN RUNTIME
 * A full browser action-RPG campaign layer for the existing Babylon.js scene.
 * Three handcrafted realms, nine combat encounters, enemy archetypes, boss phases,
 * persistent progression, upgrades, skill cooldowns, projectiles and combat VFX.
 */
(() => {
  'use strict';
  const base = window.EmberfallMossGate;
  const B = window.BABYLON;
  if (!base || !B) return;

  const scene = base.scene;
  const engine = base.engine;
  const hero = base.hero;
  const canvas = document.getElementById('renderCanvas');
  const oldGuardian = base.guardian;
  oldGuardian.root.setEnabled(false);

  // Keep Lyra and her sword; the old blockout scenery is replaced by campaign realms.
  for (const mesh of scene.meshes) {
    const keep = mesh.name.startsWith('Lyra_') || mesh.name.startsWith('Sword_');
    if (!keep) mesh.setEnabled(false);
  }
  scene.clearColor = new B.Color4(0.035, 0.045, 0.052, 1);
  scene.fogMode = B.Scene.FOGMODE_EXP2;
  scene.fogDensity = 0.006;
  scene.fogColor = new B.Color3(0.08, 0.11, 0.12);
  const key = scene.getLightByName('Warm_Canopy_Key');
  const hemi = scene.getLightByName('Forest_Ambient');
  const campaignSun = new B.DirectionalLight('Campaign_Shadow_Sun', new B.Vector3(-.42,-1,.34), scene);
  campaignSun.position = new V(-28,42,-24); campaignSun.intensity = 1.05;
  const campaignShadow = new B.ShadowGenerator(1024, campaignSun);
  campaignShadow.usePercentageCloserFiltering = true;
  campaignShadow.filteringQuality = B.ShadowGenerator.QUALITY_MEDIUM;
  campaignShadow.bias = .0006; campaignShadow.normalBias = .025;

  const V = B.Vector3;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const dist2 = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
  const forwardOf = (yaw) => new V(Math.sin(yaw), 0, Math.cos(yaw));
  const safeLocal = (() => { try { return window.localStorage; } catch (_) { return null; } })();
  const SAVE_KEY = 'emberfall_campaign_save_v1';

  const STAGES = [
    {
      name: 'VERDANT HOLLOW', chapter: 'CHAPTER I · THE ROOTBOUND OATH', subtitle: 'The old forest has learned to hate the living.', boss: 'THORNHEART COLOSSUS', bossType: 'colossus',
      palette: { sky: '#182c25', fog: '#1b3029', ground: '#293a2d', trim: '#647b51', glow: '#9bd47c', hot: '#f3a15a', stone: '#55604e', dark: '#202b25' },
      waves: [
        [{t:'stalker',x:-7,z:2},{t:'stalker',x:7,z:3},{t:'archer',x:0,z:8}],
        [{t:'stalker',x:-9,z:3},{t:'stalker',x:7,z:6},{t:'archer',x:-3,z:9},{t:'wraith',x:9,z:10}],
        [{t:'brute',x:-7,z:5},{t:'brute',x:7,z:6},{t:'archer',x:0,z:10},{t:'stalker',x:-10,z:10},{t:'stalker',x:10,z:11}],
        [{t:'colossus',x:0,z:7,boss:true},{t:'stalker',x:-9,z:7},{t:'archer',x:9,z:10}]
      ]
    },
    {
      name: 'ASHEN FOUNDRY', chapter: 'CHAPTER II · THE IRON REQUIEM', subtitle: 'Beneath the mountain, the furnaces still remember war.', boss: 'THE CINDER TYRANT', bossType: 'tyrant',
      palette: { sky: '#301c19', fog: '#3b211d', ground: '#292322', trim: '#9a5740', glow: '#ff633b', hot: '#ffc36b', stone: '#5a4941', dark: '#211b1a' },
      waves: [
        [{t:'cinder',x:-8,z:3},{t:'cinder',x:8,z:4},{t:'artillerist',x:0,z:9}],
        [{t:'knight',x:-8,z:4},{t:'knight',x:8,z:4},{t:'artillerist',x:-2,z:10},{t:'wraith',x:8,z:11}],
        [{t:'brute',x:-8,z:5},{t:'cinder',x:7,z:4},{t:'artillerist',x:0,z:11},{t:'knight',x:-10,z:11},{t:'cinder',x:10,z:10}],
        [{t:'tyrant',x:0,z:7,boss:true},{t:'knight',x:-9,z:8},{t:'artillerist',x:9,z:10}]
      ]
    },
    {
      name: 'MOONWELL CITADEL', chapter: 'CHAPTER III · THE ECLIPSE CROWN', subtitle: 'At the edge of night, the last light must choose its heir.', boss: 'THE ECLIPSE MATRIARCH', bossType: 'matriarch',
      palette: { sky: '#111a35', fog: '#192343', ground: '#202a42', trim: '#758bbd', glow: '#80c8ff', hot: '#d2a8ff', stone: '#485674', dark: '#151e35' },
      waves: [
        [{t:'wraith',x:-7,z:3},{t:'wraith',x:7,z:4},{t:'lancer',x:0,z:9}],
        [{t:'lancer',x:-8,z:4},{t:'lancer',x:8,z:5},{t:'artillerist',x:-2,z:10},{t:'wraith',x:9,z:11}],
        [{t:'brute',x:-8,z:5},{t:'wraith',x:7,z:4},{t:'artillerist',x:0,z:11},{t:'lancer',x:-10,z:10},{t:'lancer',x:10,z:10}],
        [{t:'matriarch',x:0,z:7,boss:true},{t:'lancer',x:-9,z:8},{t:'wraith',x:9,z:10}]
      ]
    }
  ];

  const SPECS = {
    stalker: { hp:105, speed:3.75, damage:13, range:2.25, cooldown:1.55, size:.82, xp:28, color:'#557b49', armor:'#2e4932', ranged:false },
    cinder: { hp:118, speed:3.35, damage:16, range:2.5, cooldown:1.55, size:.9, xp:34, color:'#864337', armor:'#442b29', ranged:false },
    archer: { hp:92, speed:2.45, damage:14, range:10, cooldown:2.5, size:.86, xp:34, color:'#6a8150', armor:'#394734', ranged:true },
    artillerist: { hp:125, speed:2.1, damage:18, range:12, cooldown:2.7, size:1.02, xp:42, color:'#92503b', armor:'#3b2b2a', ranged:true },
    brute: { hp:285, speed:1.75, damage:28, range:2.95, cooldown:2.5, size:1.35, xp:62, color:'#4e6250', armor:'#303a31', ranged:false },
    knight: { hp:178, speed:2.55, damage:21, range:2.75, cooldown:1.95, size:1.07, xp:50, color:'#777b86', armor:'#333a4b', ranged:false },
    wraith: { hp:112, speed:2.85, damage:17, range:9.2, cooldown:2.35, size:.9, xp:46, color:'#566f9a', armor:'#29385b', ranged:true, float:true },
    lancer: { hp:162, speed:3.0, damage:22, range:3.15, cooldown:1.65, size:1.0, xp:52, color:'#6e78a2', armor:'#323657', ranged:false },
    colossus: { hp:1180, speed:2.05, damage:38, range:3.5, cooldown:2.65, size:2.18, xp:320, color:'#405b42', armor:'#293c31', ranged:false, boss:true },
    tyrant: { hp:1380, speed:2.15, damage:44, range:3.7, cooldown:2.5, size:2.24, color:'#743e35', armor:'#351f20', ranged:false, boss:true },
    matriarch: { hp:1520, speed:2.0, damage:42, range:10, cooldown:2.25, size:2.05, color:'#59658d', armor:'#262d50', ranged:true, boss:true }
  };

  function makeMat(name, color, emissive = null, rough = .78, metallic = .08) {
    const m = new B.StandardMaterial(name, scene);
    m.diffuseColor = B.Color3.FromHexString(color);
    m.specularColor = new B.Color3(.22, .22, .22);
    m.specularPower = 48 * (1 - rough) + 8;
    m.roughness = rough;
    m.metallic = metallic;
    if (emissive) m.emissiveColor = B.Color3.FromHexString(emissive);
    return m;
  }
  function makeNode(name, parent, pos = [0,0,0]) {
    const n = new B.TransformNode(name, scene);
    n.position.set(pos[0],pos[1],pos[2]);
    if (parent) n.parent = parent;
    return n;
  }
  function mesh(name, kind, parent, pos, scale, material, options = {}) {
    let m;
    if (kind === 'box') {
      const w=options.w||1,h=options.h||1,d=options.d||1;
      m=B.MeshBuilder.CreateBox(name,{width:w,height:h,depth:d},scene);
      m.scaling.set(scale[0]/w,scale[1]/h,scale[2]/d);
    } else if (kind === 'cylinder') {
      const h=options.h||1,top=options.top??.6,bottom=options.bottom??.8,maxD=Math.max(top,bottom);
      m=B.MeshBuilder.CreateCylinder(name,{height:h,diameterTop:top,diameterBottom:bottom,tessellation:options.tess||10},scene);
      m.scaling.set(scale[0]/maxD,scale[1]/h,scale[2]/maxD);
    } else if (kind === 'torus') {
      const d=options.diameter||1;
      m=B.MeshBuilder.CreateTorus(name,{diameter:d,thickness:options.thickness||.08,tessellation:32},scene);
      m.scaling.set(scale[0]/d,scale[1]/d,scale[2]/d);
    } else {
      m=B.MeshBuilder.CreateSphere(name,{diameter:1,segments:options.segments||12},scene);
      m.scaling.set(scale[0],scale[1],scale[2]);
    }
    m.position.set(pos[0],pos[1],pos[2]);
    if (options.rotation) m.rotation.set(...options.rotation);
    m.material = material;
    if (parent) m.parent = parent;
    m.isPickable = false;
    return m;
  }
  function makePine(parent, x, z, s, bark, leaves, leaves2) {
    const t = makeNode('Realm_Pine', parent, [x,0,z]);
    mesh('pine-trunk','cylinder',t,[0,1.25*s,0],[.42*s,2.5*s,.42*s],bark,{h:2.5*s,top:.2*s,bottom:.42*s,tess:8});
    for (let i=0;i<3;i++) mesh('pine-crown','cylinder',t,[0,(2.2+i*.9)*s,0],[(2.3-i*.48)*s,(1.9-i*.18)*s,(2.3-i*.48)*s],i===1?leaves2:leaves,{h:(2-i*.18)*s,top:.04*s,bottom:(2.3-i*.48)*s,tess:8});
    return t;
  }

  const realmRoots = [];
  const realmFx = [];
  function buildRealm(index) {
    const st = STAGES[index], p = st.palette;
    const root = makeNode('Realm_' + index);
    const groundMat = makeMat('RealmGround_'+index,p.ground,null,.98);
    const stoneMat = makeMat('RealmStone_'+index,p.stone,null,.88,.15);
    const darkMat = makeMat('RealmDark_'+index,p.dark,null,.92,.18);
    const glowMat = makeMat('RealmGlow_'+index,p.glow,p.glow,.28,.25);
    const hotMat = makeMat('RealmHot_'+index,p.hot,p.hot,.35,.18);
    const accentMat = makeMat('RealmTrim_'+index,p.trim,p.trim,.55,.38);
    mesh('realm-floor','box',root,[0,-.42,0],[58,.65,58],groundMat,{w:58,h:.65,d:58});
    // Wide, painterly realm vista behind the fully 3D play space.
    const bgName=['bg-verdant.webp','bg-ashen.webp','bg-moonwell.webp'][index];
    const backdropMat=new B.StandardMaterial('RealmBackdropMat_'+index,scene);
    backdropMat.diffuseTexture=new B.Texture('./assets/'+bgName,scene,false,true,B.Texture.TRILINEAR_SAMPLINGMODE);
    backdropMat.emissiveColor=new B.Color3(.72,.72,.72);backdropMat.disableLighting=true;backdropMat.backFaceCulling=false;
    const backdrop=B.MeshBuilder.CreatePlane('Realm_Backdrop_'+index,{width:1,height:1},scene);
    backdrop.position.set(0,13.5,29);backdrop.scaling.set(64,36,1);backdrop.parent=root;backdrop.material=backdropMat;backdrop.isPickable=false;
    // Distinct stone arena edge and navigable battle floor.
    for(let i=0;i<28;i++){
      const a=i*Math.PI*2/28, x=Math.cos(a)*25.1, z=Math.sin(a)*24.5;
      const pillar=mesh('boundary-stone','box',root,[x,1.1,z],[1,2.2,1.8],i%3===0?accentMat:stoneMat,{w:1,h:2.2,d:1.8,rotation:[0,-a,0]});
      pillar.rotation.y=-a;
      if(i%2===0) mesh('boundary-rune','sphere',root,[x,2.48,z],[.22,.32,.22],glowMat);
    }
    if(index===0){
      const bark=makeMat('ForestBark','#40382b'), leaves=makeMat('ForestCanopy','#183a2b'), leaves2=makeMat('ForestCanopy2','#2c5739');
      [[-20,-16,1.7],[-24,-4,1.5],[-19,11,1.6],[-15,21,1.25],[20,-17,1.6],[24,-5,1.8],[19,10,1.5],[15,21,1.35],[-8,-24,1.2],[8,-24,1.25]].forEach(q=>makePine(root,q[0],q[1],q[2],bark,leaves,leaves2));
      // Broken royal gate and overgrown standing stones.
      for(const s of [-1,1]){
        mesh('moss-gate-pillar','cylinder',root,[s*8.6,3.5,18],[1.35,7,1.5],stoneMat,{h:7,top:.9,bottom:1.4,tess:8});
        mesh('moss-gate-cap','box',root,[s*8.6,7.25,18],[1.8,.55,1.8],accentMat,{w:1.8,h:.55,d:1.8});
        mesh('moss-runestone','box',root,[s*13.5,1.7,3],[1.2,3.4,1],darkMat,{w:1.2,h:3.4,d:1,rotation:[0,0,s*.15]});
        mesh('moss-gem','sphere',root,[s*13.5,3.5,3],[.32,.42,.32],glowMat);
      }
      mesh('gate-lintel','box',root,[0,7,18],[18,.85,1.55],stoneMat,{w:18,h:.85,d:1.55});
      for(let i=0;i<9;i++){
        const x=-12+i*3;
        mesh('root-arch','cylinder',root,[x,1.1,-7+(i%2)*1.7],[.3,2.2,.3],bark,{h:2.2,top:.12,bottom:.3,tess:7,rotation:[0,0,(i%2?-.26:.26)]});
      }
      for(let i=0;i<20;i++){
        const x=Math.sin(i*2.4)*18,z=Math.cos(i*1.7)*15;
        mesh('glowing-fungus','sphere',root,[x,.28,z],[.16,.24,.16],i%2?glowMat:hotMat);
      }
    } else if(index===1){
      const lava=makeMat('LavaFlow','#aa3826','#ff4b25',.32,.1), furnace=makeMat('FurnaceGlow','#ff6b2c','#ff3e1e',.28,.12), pipe=makeMat('FoundryIron','#343a3d',null,.35,.72);
      // Broken lava channels, bridge grates and furnace vents.
      for(const s of [-1,1]){
        mesh('molten-channel','box',root,[s*8,-.03,0],[3.1,.13,37],lava,{w:3.1,h:.13,d:37});
        for(let z=-15;z<=15;z+=5){
          mesh('forge-bridge','box',root,[s*8, .22,z],[4.3,.32,2.1],pipe,{w:4.3,h:.32,d:2.1});
          mesh('bridge-glow','box',root,[s*8,.4,z],[.12,.06,1.85],furnace,{w:.12,h:.06,d:1.85});
        }
        for(let i=0;i<4;i++){
          const z=-17+i*11;
          mesh('smelter-stack','cylinder',root,[s*20,4,z],[2.1,8,2.1],pipe,{h:8,top:1.4,bottom:2.1,tess:12});
          mesh('stack-fire','sphere',root,[s*20,8.2,z],[.8,.36,.8],furnace);
        }
      }
      for(let i=0;i<6;i++){
        const x=-13+i*5.2;
        mesh('foundry-rib','box',root,[x,3,-20],[1.15,6,1.4],stoneMat,{w:1.15,h:6,d:1.4});
        mesh('foundry-rib-cap','box',root,[x,6.2,-20],[1.6,.5,1.9],accentMat,{w:1.6,h:.5,d:1.9});
        mesh('forge-pipe','cylinder',root,[x,1.2,-12],[.28,12,.28],pipe,{h:12,top:.28,bottom:.28,tess:10,rotation:[Math.PI/2,0,0]});
      }
      mesh('tyrant-furnace','box',root,[0,5,20],[12,10,3],darkMat,{w:12,h:10,d:3});
      mesh('tyrant-furnace-mouth','box',root,[0,3,18.35],[5,4.4,.15],furnace,{w:5,h:4.4,d:.15});
      for(let i=0;i<18;i++){
        const x=Math.sin(i*4.1)*20,z=Math.cos(i*2.7)*18;
        mesh('slag-rock','sphere',root,[x,.2,z],[.6+(i%3)*.3,.45,.7],i%2?stoneMat:darkMat);
      }
    } else {
      const moon=makeMat('MoonCrystal','#819ad0','#547bdf',.22,.45), silver=makeMat('CitadelSilver','#a8b7d3',null,.4,.7), pool=makeMat('MoonwellWater','#263e73','#2f6fbd',.18,.4);
      // Moonlit ramparts, silver colonnades and a luminous central well.
      for(const s of [-1,1]){
        mesh('citadel-wall','box',root,[s*20,4,0],[2,8,42],stoneMat,{w:2,h:8,d:42});
        for(let z=-17;z<=17;z+=8){
          mesh('citadel-tower','cylinder',root,[s*18.6,6,z],[3.2,12,3.2],darkMat,{h:12,top:2.2,bottom:3.2,tess:8});
          mesh('tower-crown','cylinder',root,[s*18.6,12.5,z],[3.8,1.2,3.8],silver,{h:1.2,top:3.8,bottom:3.8,tess:8});
          mesh('tower-crystal','sphere',root,[s*18.6,13.8,z],[.65,1.05,.65],moon);
        }
      }
      for(let i=0;i<6;i++){
        const x=-12+i*4.8;
        mesh('moon-column','cylinder',root,[x,3.2,-18],[.75,6.4,.75],silver,{h:6.4,top:.55,bottom:.85,tess:12});
        mesh('column-crystal','sphere',root,[x,6.9,-18],[.25,.45,.25],moon);
      }
      mesh('moonwell-basin','cylinder',root,[0,.25,2],[5,.5,5],silver,{h:.5,top:5,bottom:5,tess:40});
      mesh('moonwell-surface','cylinder',root,[0,.52,2],[4.2,.09,4.2],pool,{h:.09,top:4.2,bottom:4.2,tess:40});
      for(let i=0;i<10;i++){
        const a=i*Math.PI/5;
        mesh('floating-moon-shard','sphere',root,[Math.cos(a)*13,2.4+(i%3)*.6,Math.sin(a)*13],[.4,.95,.4],moon,{rotation:[0,0,a]});
      }
      mesh('eclipse-throne','box',root,[0,5,21],[10,10,2],darkMat,{w:10,h:10,d:2});
      for(let s=-1;s<=1;s+=2) mesh('throne-spire','cylinder',root,[s*4.5,8.5,20],[.8,7,.8],silver,{h:7,top:.08,bottom:.8,tess:9});
      mesh('throne-heart','sphere',root,[0,6.1,19.8],[1.1,1.35,.5],moon);
    }
    // The exit arch is built into every realm but only becomes active after its boss falls.
    const portal = makeNode('RealmExitPortal',root,[0,0,15]);
    const ring = mesh('exit-ring','torus',portal,[0,2.2,0],[3.8,3.8,3.8],glowMat,{diameter:3.8,thickness:.16});
    const ring2 = mesh('exit-ring-inner','torus',portal,[0,2.2,.04],[2.7,2.7,2.7],accentMat,{diameter:2.7,thickness:.07});
    const discMat = makeMat('PortalDisc_'+index,p.dark,p.glow,.22,.15); discMat.alpha=.6; discMat.backFaceCulling=false;
    const disc = B.MeshBuilder.CreateDisc('exit-portal-disc',{radius:1.65,tessellation:48},scene); disc.parent=portal; disc.position.set(0,2.2,.02); disc.material=discMat; disc.isVisible=false; disc.isPickable=false;
    portal.setEnabled(false);
    root.getChildMeshes(false).forEach(m=>{
      if(!m.name.startsWith('Realm_Backdrop')){campaignShadow.addShadowCaster(m,true);m.receiveShadows=true;}
    });
    realmRoots[index]=root;
    return {root,portal,ring,ring2,disc,glowMat,hotMat,groundMat,stoneMat};
  }
  const realmData = STAGES.map((_,i)=>buildRealm(i));
  realmData.forEach((r,i)=>r.root.setEnabled(i===0));

  // One soft particle atlas shared by all combat bursts.
  const fxTexture = (() => {
    const t = new B.DynamicTexture('CampaignFxTexture',{width:64,height:64},scene,false);
    const c=t.getContext(),g=c.createRadialGradient(32,32,1,32,32,31);
    g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.24,'rgba(255,255,255,.86)');g.addColorStop(.62,'rgba(255,255,255,.18)');g.addColorStop(1,'rgba(255,255,255,0)');
    c.fillStyle=g;c.fillRect(0,0,64,64);t.update();return t;
  })();
  function burst(pos,c1,c2,count=30,power=5,size=.25){
    const ps=new B.ParticleSystem('Campaign_Burst',Math.max(80,count*2),scene);
    ps.particleTexture=fxTexture;ps.emitter=pos.clone();ps.minEmitBox=new V(-.12,-.12,-.12);ps.maxEmitBox=new V(.12,.12,.12);
    ps.color1=B.Color3.FromHexString(c1).toColor4(1);ps.color2=B.Color3.FromHexString(c2).toColor4(1);ps.colorDead=new B.Color4(.12,.12,.12,0);
    ps.minSize=size*.45;ps.maxSize=size*1.5;ps.minLifeTime=.28;ps.maxLifeTime=.9;ps.emitRate=0;ps.manualEmitCount=count;ps.blendMode=B.ParticleSystem.BLENDMODE_ADD;
    ps.minEmitPower=power*.28;ps.maxEmitPower=power;ps.gravity=new V(0,-8,0);ps.updateSpeed=.012;ps.start();
    setTimeout(()=>{try{ps.stop();ps.dispose();}catch(_){}},1400);
  }

  const enemyMats = {};
  function getEnemyMats(stageIndex,type){
    const keyName=stageIndex+':'+type;
    if(enemyMats[keyName])return enemyMats[keyName];
    const spec=SPECS[type], pal=STAGES[stageIndex].palette;
    const body=makeMat('EnemyBody_'+keyName,spec.color,null,.82,.08);
    const armor=makeMat('EnemyArmor_'+keyName,spec.armor,null,.42,.56);
    const glow=makeMat('EnemyCore_'+keyName,pal.glow,pal.glow,.22,.32);
    const horn=makeMat('EnemyHorn_'+keyName,pal.hot,pal.hot,.4,.18);
    return enemyMats[keyName]={body,armor,glow,horn};
  }
  let uid=0;
  function createEnemy(type,x,z,stageIndex,boss=false){
    const spec=SPECS[type], mm=getEnemyMats(stageIndex,type), scale=spec.size;
    const root=makeNode('Enemy_'+type+'_'+(++uid),null,[x,0,z]);
    root.scaling.setAll(scale);
    const facing=makeNode('EnemyFacing',root);
    const bob=mesh('EnemyBody','sphere',facing,[0,1.28,0],[.72,1.0,.56],mm.body,{segments:16});
    mesh('EnemyChestplate','box',facing,[0,1.35,.39],[.78,.72,.18],mm.armor,{w:.78,h:.72,d:.18,rotation:[.03,0,0]});
    mesh('EnemyCore','sphere',facing,[0,1.48,.53],[.2,.24,.08],mm.glow);
    const head=makeNode('EnemyHead',facing,[0,2.12,.02]);
    mesh('EnemySkull','sphere',head,[0,.08,0],[.55,.57,.5],mm.body,{segments:14});
    mesh('EnemyMask','box',head,[0,.02,.38],[.65,.23,.1],mm.armor,{w:.65,h:.23,d:.1});
    for(const s of [-1,1]){
      mesh('EnemyEye','sphere',head,[s*.16,.08,.445],[.085,.07,.045],mm.glow);
      mesh('EnemyHorn','cylinder',head,[s*.34,.45,-.02],[.15,.66,.15],mm.horn,{h:.66,top:.015,bottom:.15,tess:7,rotation:[0,0,-s*.5]});
    }
    const arms=[],legs=[];
    for(const s of [-1,1]){
      const shoulder=makeNode('EnemyShoulder',facing,[s*.61,1.78,0]);
      mesh('EnemyUpperArm','cylinder',shoulder,[0,-.33,0],[.21,.68,.21],mm.body,{h:.68,top:.19,bottom:.23,tess:9});
      const elbow=makeNode('EnemyElbow',shoulder,[0,-.68,0]);
      mesh('EnemyForearm','cylinder',elbow,[0,-.29,.03],[.24,.61,.25],mm.armor,{h:.61,top:.23,bottom:.28,tess:9});
      mesh('EnemyClaw','sphere',elbow,[0,-.62,.12],[.24,.22,.25],mm.horn);
      arms.push({shoulder,elbow,side:s});
      const hip=makeNode('EnemyHip',facing,[s*.26,.78,0]);
      mesh('EnemyLeg','cylinder',hip,[0,-.35,0],[.23,.72,.24],mm.body,{h:.72,top:.2,bottom:.24,tess:9});
      mesh('EnemyFoot','box',hip,[0,-.72,.13],[.35,.22,.48],mm.armor,{w:.35,h:.22,d:.48});
      legs.push({hip,side:s});
    }
    // Distinct archetype silhouettes: ranged focus, armored brute plates, spirit halo, and boss crown.
    if(spec.ranged){
      mesh('RangedStaff','cylinder',facing,[.78,1.05,.1],[.11,2.25,.11],mm.horn,{h:2.25,top:.08,bottom:.11,tess:8,rotation:[0,0,-.08]});
      mesh('RangedOrb','sphere',facing,[.78,2.22,.1],[.25,.32,.25],mm.glow);
    }
    if(type==='brute'||type==='colossus'||type==='tyrant'){
      for(const s of [-1,1]){
        mesh('BruteShoulderPlate','sphere',facing,[s*.8,2.03,0],[.49,.44,.5],mm.armor);
        mesh('BruteSpine','cylinder',facing,[s*.38,2.55,-.35],[.2,.82,.2],mm.horn,{h:.82,top:.02,bottom:.2,tess:7,rotation:[-.55,0,s*.24]});
      }
      for(let i=0;i<3;i++) mesh('BruteChestRunes','box',facing,[-.28+i*.28,1.55,.51],[.09,.32,.045],mm.glow,{w:.09,h:.32,d:.045});
    }
    if(type==='wraith'||type==='matriarch'){
      mesh('WraithHalo','torus',facing,[0,2.8,-.03],[1.45,1.45,1.45],mm.glow,{diameter:1.45,thickness:.06,rotation:[Math.PI/2,0,0]});
      mesh('WraithMantle','sphere',facing,[0,.95,-.05],[.82,.58,.7],mm.armor);
    }
    if(boss){
      for(let i=0;i<7;i++){
        const a=i*Math.PI*2/7;
        mesh('BossCrownShard','cylinder',facing,[Math.cos(a)*.5,3.0,Math.sin(a)*.3],[.2,.95,.2],mm.horn,{h:.95,top:.015,bottom:.2,tess:7,rotation:[Math.cos(a)*.25,0,Math.sin(a)*.35]});
      }
      mesh('BossCoreRing','torus',facing,[0,1.52,.58],[.75,.75,.75],mm.glow,{diameter:.75,thickness:.055});
    }
    const ring=mesh('EnemyTelegraph','torus',root,[0,.09,0],[spec.boss?5.5:2.7, spec.boss?5.5:2.7, spec.boss?5.5:2.7],mm.horn,{diameter:spec.boss?5.5:2.7,thickness:.07});
    ring.setEnabled(false);
    root.getChildMeshes(false).forEach(m=>{campaignShadow.addShadowCaster(m,true);m.receiveShadows=true;});
    return {id:uid,type,root,facing,body:bob,head,arms,legs,ring,mm,hp:spec.hp*(boss?1:1),maxHp:spec.hp,speed:spec.speed,damage:spec.damage,range:spec.range,cooldown:spec.cooldown,xp:spec.xp,alive:true,boss,ranged:!!spec.ranged,mode:'approach',timer:0,attackCd:1.1+Math.random()*.8,hitstun:0,float:!!spec.float,summoned:false,stageIndex};
  }

  // Campaign data and saved progression.
  let save={};
  try{save=safeLocal?JSON.parse(safeLocal.getItem(SAVE_KEY)||'{}')||{}:{};}catch(_){save={};}
  let stageIndex=clamp(Number(save.stageIndex)||0,0,2);
  let level=Math.max(1,Number(save.level)||1),xp=Math.max(0,Number(save.xp)||0),xpNext=160;
  let upgrades=Array.isArray(save.upgrades)?save.upgrades.slice(0,8):[];
  let playerHpMax=260,playerHp=260,damageMultiplier=1,solarMultiplier=1,skillCooldownMultiplier=1,shieldDuration=3.0;
  let solarCd=0,shieldCd=0,shieldTime=0,ultimate=0,invulnerable=0,combo=0,comboWindow=0,attackCd=0,heavyCd=0;
  let enemies=[],projectiles=[],waveIndex=0,waveDelay=0,awaitingPortal=false,realmClock=0,shake=0,lastTick=performance.now(),totalKills=0,hazardClock=0;
  let currentBoss=null,combatRunning=true,stageSerial=0;
  let ui,uiBossBar,uiEnemyCount,uiMessage,uiModal;

  function saveCampaign(){
    if(!safeLocal)return;
    try{safeLocal.setItem(SAVE_KEY,JSON.stringify({stageIndex,level,xp,upgrades,stageSerial,totalKills}));}catch(_){}
  }
  function updateStatsFromUpgrades(){
    playerHpMax=260;damageMultiplier=1;solarMultiplier=1;skillCooldownMultiplier=1;shieldDuration=3;
    for(const u of upgrades){
      if(u==='heart')playerHpMax+=55;
      if(u==='edge')damageMultiplier+=.18;
      if(u==='solar')solarMultiplier+=.24;
      if(u==='ward'){shieldDuration+=1.2;skillCooldownMultiplier*=.9;}
    }
    playerHp=clamp(playerHp,0,playerHpMax);
  }

  function addUI(){
    const style=document.createElement('style');
    style.textContent=`
      #ef-hud{position:fixed;z-index:30;inset:0;pointer-events:none;color:#f5efdf;font-family:Inter,system-ui,sans-serif;text-shadow:0 2px 10px #000}
      #ef-brand{position:absolute;top:18px;left:50%;transform:translateX(-50%);text-align:center;min-width:260px}
      #ef-chapter{font-size:9px;letter-spacing:.28em;color:#d7bd84;font-weight:900}#ef-realm{font:700 27px/1.1 Georgia,serif;letter-spacing:.1em;color:#fff3d7;margin-top:4px}
      #ef-wave{font-size:10px;letter-spacing:.2em;color:#b7c5b8;margin-top:5px}
      #ef-player{position:absolute;top:18px;left:18px;width:270px;padding:13px 15px;border:1px solid #d7bf8250;border-radius:12px;background:linear-gradient(145deg,#101c19df,#09100fe8);backdrop-filter:blur(9px);box-shadow:0 12px 34px #0007}
      #ef-player .line{display:flex;justify-content:space-between;align-items:center;gap:10px;font-size:10px;letter-spacing:.12em;color:#d9d1bc;margin-bottom:6px}#ef-player strong{color:#fff0d4;font-size:12px}
      .ef-track{height:8px;border-radius:20px;background:#ffffff1c;overflow:hidden;margin:5px 0 10px}.ef-fill{height:100%;width:100%;border-radius:inherit;transition:width .14s linear}
      #ef-health{background:linear-gradient(90deg,#a83c35,#eb8c6d)}#ef-xp{background:linear-gradient(90deg,#648ac4,#b3dcff)}#ef-ultimate{background:linear-gradient(90deg,#ca9b42,#fff0a1)}
      #ef-objective{position:absolute;top:145px;left:19px;width:255px;padding:11px 13px;border-left:2px solid #c8a56a;background:linear-gradient(90deg,#08100fbd,transparent)}#ef-objective b{display:block;font-size:11px;letter-spacing:.11em;color:#f2dfb9}#ef-objective span{display:block;margin-top:5px;font-size:10px;line-height:1.45;color:#b6c4b5}
      #ef-boss{position:absolute;top:105px;left:50%;transform:translateX(-50%);width:min(560px,58vw);text-align:center;display:none}#ef-boss-name{font:700 15px Georgia,serif;letter-spacing:.2em;color:#f6d7aa}#ef-boss .ef-track{height:12px;border:1px solid #edbb7655;background:#160e13d9;margin-top:8px}#ef-boss-fill{background:linear-gradient(90deg,#711e2b,#dc6545,#f4bd75)}
      #ef-count{position:absolute;top:20px;right:20px;padding:10px 13px;border:1px solid #d7bf8240;border-radius:10px;background:#0a1210c9;font-size:10px;letter-spacing:.12em;color:#ded3b6;text-align:right}#ef-count strong{font-size:16px;color:#fff2d7;display:block;margin-top:3px}
      #ef-skills{position:absolute;right:20px;bottom:20px;display:flex;gap:8px;align-items:flex-end} .ef-skill{width:72px;padding:8px 7px;text-align:center;border:1px solid #d9be8055;border-radius:10px;background:#0b1514ce;backdrop-filter:blur(6px)}.ef-skill b{font-size:15px;color:#f1d292;display:block}.ef-skill span{font-size:8px;letter-spacing:.08em;color:#bfc5b9}.ef-skill i{font-style:normal;display:block;font-size:9px;color:#fff;margin-top:3px}
      #ef-combo{position:absolute;left:50%;top:48%;transform:translate(-50%,-50%) scale(.85);font:900 44px Georgia,serif;color:#ffe4a2;opacity:0;transition:opacity .15s,transform .15s;text-shadow:0 0 25px #f78b36}#ef-combo.on{opacity:1;transform:translate(-50%,-50%) scale(1.05)}
      #ef-toast{position:absolute;top:25%;left:50%;transform:translateX(-50%);font-size:13px;font-weight:900;letter-spacing:.18em;color:#ffe3a2;background:#101510cc;border:1px solid #dbb56b66;border-radius:30px;padding:11px 20px;opacity:0;transition:opacity .2s;white-space:nowrap}#ef-toast.on{opacity:1}
      #ef-modal{position:fixed;inset:0;z-index:50;display:none;align-items:center;justify-content:center;padding:20px;background:#05090bdc;backdrop-filter:blur(10px);color:#f5ead4;font-family:Inter,system-ui,sans-serif}#ef-modal.open{display:flex}.ef-card{width:min(760px,96vw);padding:30px;border:1px solid #d0b07166;border-radius:18px;background:linear-gradient(145deg,#17251f,#09110f);box-shadow:0 30px 110px #000c}.ef-eyebrow{font-size:10px;letter-spacing:.24em;color:#d8b777;font-weight:900}.ef-title{font:700 clamp(32px,6vw,52px)/1.05 Georgia,serif;margin:12px 0;color:#fff0d4}.ef-copy{max-width:650px;color:#bdcabb;font-size:13px;line-height:1.7}.ef-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:22px}.ef-upgrade{border:1px solid #c8a56866;background:linear-gradient(160deg,#24382d,#111c19);border-radius:12px;padding:18px 15px;color:#eee3ce;text-align:left;cursor:pointer;min-height:150px}.ef-upgrade:hover{border-color:#f1d391;transform:translateY(-2px)}.ef-upgrade b{display:block;font:700 17px Georgia,serif;color:#f1d79f;margin-bottom:10px}.ef-upgrade span{font-size:11px;line-height:1.55;color:#bdc6b7}.ef-main-btn{margin-top:22px;border:0;border-radius:9px;padding:13px 22px;background:linear-gradient(135deg,#e9d09a,#a77a43);color:#121710;font-size:11px;font-weight:900;letter-spacing:.14em;cursor:pointer}.ef-muted{font-size:10px;color:#8f9f92;margin-top:12px}
      @media(max-width:700px){#ef-player{top:10px;left:8px;width:185px;padding:9px}#ef-player .line{font-size:8px}#ef-objective{top:130px;left:8px;width:180px}#ef-brand{top:10px;min-width:160px}#ef-realm{font-size:18px}#ef-chapter{font-size:7px}#ef-wave{font-size:8px}#ef-count{top:10px;right:8px;padding:7px;font-size:8px}#ef-boss{top:100px;width:72vw}#ef-boss-name{font-size:11px}#ef-skills{right:8px;bottom:8px;gap:4px}.ef-skill{width:53px;padding:6px 3px}.ef-skill b{font-size:12px}.ef-skill span{font-size:7px}.ef-cards{grid-template-columns:1fr}.ef-upgrade{min-height:0;padding:13px}.ef-card{padding:21px;max-height:92vh;overflow:auto}}
    `;
    document.head.appendChild(style);
    document.getElementById('hud')?.classList.add('hidden');
    document.getElementById('mobile-controls')?.classList.remove('hidden');
    document.getElementById('menu-screen')?.classList.add('hidden');
    document.getElementById('result-screen')?.classList.add('hidden');
    document.getElementById('loading-note')?.remove();
    ui=document.createElement('div');ui.id='ef-hud';
    ui.innerHTML=`
      <div id="ef-player">
        <div class="line"><span>LYRA · LAST HEARTH</span><strong id="ef-level">LEVEL 01</strong></div>
        <div class="line"><span>VITALITY</span><strong id="ef-hp-text">260 / 260</strong></div><div class="ef-track"><div id="ef-health" class="ef-fill"></div></div>
        <div class="line"><span>EXPERIENCE</span><strong id="ef-xp-text">0 / 160</strong></div><div class="ef-track"><div id="ef-xp" class="ef-fill"></div></div>
        <div class="line"><span>HEARTH CHARGE</span><strong id="ef-ult-text">0%</strong></div><div class="ef-track"><div id="ef-ultimate" class="ef-fill"></div></div>
      </div>
      <div id="ef-brand"><div id="ef-chapter"></div><div id="ef-realm"></div><div id="ef-wave"></div></div>
      <div id="ef-objective"><b id="ef-objective-title">CLEAR THE HOLLOW</b><span id="ef-objective-copy">Hunt the corrupted.</span></div>
      <div id="ef-count">HOSTILES REMAINING<strong id="ef-count-value">0</strong></div>
      <div id="ef-boss"><div id="ef-boss-name"></div><div class="ef-track"><div id="ef-boss-fill" class="ef-fill"></div></div></div>
      <div id="ef-skills">
        <div class="ef-skill"><b>J</b><span>SWORD COMBO</span><i id="ef-j-cd">READY</i></div>
        <div class="ef-skill"><b>K</b><span>HEAVY CUT</span><i id="ef-k-cd">READY</i></div>
        <div class="ef-skill"><b>Q</b><span>SOLAR NOVA</span><i id="ef-q-cd">READY</i></div>
        <div class="ef-skill"><b>E</b><span>WARD SHIELD</span><i id="ef-e-cd">READY</i></div>
        <div class="ef-skill"><b>R</b><span>HEARTHFIRE</span><i id="ef-r-cd">0%</i></div>
      </div>
      <div id="ef-combo"></div><div id="ef-toast"></div>`;
    document.body.appendChild(ui);
    uiModal=document.createElement('div');uiModal.id='ef-modal';document.body.appendChild(uiModal);
    uiBossBar=document.getElementById('ef-boss');uiEnemyCount=document.getElementById('ef-count-value');uiMessage=document.getElementById('ef-toast');
  }
  addUI();

  function notify(msg,duration=2.1){
    uiMessage.textContent=msg;uiMessage.classList.add('on');
    clearTimeout(notify._timer);notify._timer=setTimeout(()=>uiMessage.classList.remove('on'),duration*1000);
  }
  function objective(title,copy){
    document.getElementById('ef-objective-title').textContent=title;
    document.getElementById('ef-objective-copy').textContent=copy;
  }
  function updateHUD(){
    const hpPct=playerHp/playerHpMax*100;
    document.getElementById('ef-level').textContent='LEVEL '+String(level).padStart(2,'0');
    document.getElementById('ef-hp-text').textContent=Math.ceil(playerHp)+' / '+playerHpMax;
    document.getElementById('ef-health').style.width=hpPct+'%';
    document.getElementById('ef-xp-text').textContent=xp+' / '+xpNext;
    document.getElementById('ef-xp').style.width=(xp/xpNext*100)+'%';
    document.getElementById('ef-ult-text').textContent=Math.floor(ultimate)+'%';
    document.getElementById('ef-ultimate').style.width=ultimate+'%';
    const alive=enemies.filter(e=>e.alive);
    uiEnemyCount.textContent=alive.length;
    const boss=alive.find(e=>e.boss);
    uiBossBar.style.display=boss?'block':'none';
    if(boss){document.getElementById('ef-boss-name').textContent=STAGES[stageIndex].boss+' · '+Math.ceil(boss.hp)+' / '+boss.maxHp;document.getElementById('ef-boss-fill').style.width=clamp(boss.hp/boss.maxHp*100,0,100)+'%';}
    document.getElementById('ef-q-cd').textContent=solarCd<=0?'READY':solarCd.toFixed(1)+'s';
    document.getElementById('ef-e-cd').textContent=shieldCd<=0?'READY':shieldCd.toFixed(1)+'s';
    document.getElementById('ef-r-cd').textContent=Math.floor(ultimate)+'%';
    document.getElementById('ef-j-cd').textContent=attackCd<=0?'READY':attackCd.toFixed(1)+'s';
    document.getElementById('ef-k-cd').textContent=heavyCd<=0?'READY':heavyCd.toFixed(1)+'s';
    const stage=STAGES[stageIndex];
    document.getElementById('ef-chapter').textContent=stage.chapter;
    document.getElementById('ef-realm').textContent=stage.name;
    document.getElementById('ef-wave').textContent=awaitingPortal?'REALM CLEARED · FIND THE EXIT':('ENCOUNTER '+(waveIndex+1)+' / 4  ·  '+['SCOUTS','HUNTERS','ELITES','WARLORD'][waveIndex]);
  }

  // Multi-archetype enemy creation, combat and realm progression.
  function spawnEnemy(d, stage=stageIndex){
    const spec=SPECS[d.t];
    const e=createEnemy(d.t,d.x,d.z,stage,!!d.boss);
    if(e.boss){e.hp=spec.hp;e.maxHp=spec.hp;e.attackCd=1.8;currentBoss=e;}
    enemies.push(e);
    return e;
  }
  function disposeEnemies(){
    for(const e of enemies){if(e.root&&!e.root.isDisposed())e.root.dispose();}
    enemies=[];currentBoss=null;
    for(const p of projectiles){if(p.mesh&&!p.mesh.isDisposed())p.mesh.dispose();}
    projectiles=[];
  }
  function spawnWave(){
    const stage=STAGES[stageIndex], wave=stage.waves[waveIndex];
    wave.forEach(d=>spawnEnemy(d));
    awaitingPortal=false;
    realmData[stageIndex].portal.setEnabled(false);
    objective(waveIndex===3?'DEFEAT THE REALM TYRANT':'ELIMINATE ALL HOSTILES',waveIndex===3?'Break the champion’s guard. Watch for its marked ground attacks.':'Protect the last hearth. Use your dodge to escape committed strikes.');
    notify(waveIndex===3?stage.boss+' APPROACHES':'ENEMY FORCES INCOMING',2.2);
    updateHUD();
  }
  function beginRealm(index){
    stageIndex=index;stageSerial++;waveIndex=0;waveDelay=0;awaitingPortal=false;combatRunning=true;
    disposeEnemies();
    realmData.forEach((r,i)=>r.root.setEnabled(i===index));
    const sky=B.Color3.FromHexString(STAGES[index].palette.sky);scene.clearColor=new B.Color4(sky.r,sky.g,sky.b,1);
    scene.fogColor=B.Color3.FromHexString(STAGES[index].palette.fog);scene.fogDensity=index===2?.008:.006;
    if(key){key.diffuse=B.Color3.FromHexString(STAGES[index].palette.hot);key.intensity=index===1?1.35:1.05;}
    campaignSun.diffuse=B.Color3.FromHexString(STAGES[index].palette.trim);campaignSun.intensity=index===1?1.25:1.05;
    if(hemi){hemi.diffuse=B.Color3.FromHexString(STAGES[index].palette.trim);hemi.intensity=index===2?.82:.68;}
    hero.root.position.set(0,0,-14);hero.facing.rotation.y=0;
    playerHp=clamp(playerHp+55,0,playerHpMax);solarCd=0;shieldCd=0;shieldTime=0;invulnerable=1.2;ultimate=clamp(ultimate+20,0,100);
    spawnWave();saveCampaign();updateHUD();
  }
  function beginNextWave(){
    waveIndex++;waveDelay=0;spawnWave();
  }
  function openExit(){
    awaitingPortal=true;
    const r=realmData[stageIndex];r.portal.setEnabled(true);r.disc.isVisible=true;
    objective('THE CHAMPION HAS FALLEN','Reach the illuminated gate at the far end of the arena to carry the hearth onward.');
    notify('REALM PURGED · THE WAY IS OPEN',3);
    updateHUD();saveCampaign();
  }
  function showModal(type,body){
    uiModal.innerHTML=body;uiModal.classList.add('open');combatRunning=false;
    ui.querySelectorAll('*').forEach(()=>{});
  }
  function hideModal(){uiModal.classList.remove('open');uiModal.innerHTML='';combatRunning=true;}
  const upgradeChoices=[
    {id:'edge',title:'ECLIPSE EDGE',copy:'Increase all sword and heavy-attack damage by 18%. The blade learns to cut through armor.'},
    {id:'heart',title:'HEARTHCORE',copy:'Increase maximum vitality by 55 and restore Lyra to full health.'},
    {id:'solar',title:'SOLAR CONDUIT',copy:'Solar Nova deals 24% more damage and its cooldown is shortened.'},
    {id:'ward',title:'WARDEN’S OATH',copy:'Extend Ward Shield duration and shorten its cooldown.'}
  ];
  function showUpgrade(){
    const picks=upgradeChoices.filter(u=>!upgrades.includes(u.id));
    const options=(picks.length? picks:upgradeChoices).sort(()=>Math.random()-.5).slice(0,3);
    const stage=STAGES[stageIndex];
    showModal('upgrade',`<div class="ef-card"><div class="ef-eyebrow">REALM CONQUERED · ${stage.chapter}</div><div class="ef-title">THE HEARTH GROWS STRONGER</div><p class="ef-copy">${stage.boss} has fallen. Choose one permanent relic before the next realm. Your choice will shape Lyra’s build for the rest of the campaign.</p><div class="ef-cards">${options.map(u=>`<button class="ef-upgrade" data-upgrade="${u.id}"><b>${u.title}</b><span>${u.copy}</span></button>`).join('')}</div><div class="ef-muted">Relics persist between realms and are saved to this browser.</div></div>`);
    uiModal.querySelectorAll('[data-upgrade]').forEach(btn=>btn.addEventListener('click',()=>{
      upgrades.push(btn.dataset.upgrade);updateStatsFromUpgrades();
      if(btn.dataset.upgrade==='heart')playerHp=playerHpMax;
      saveCampaign();hideModal();
      if(stageIndex<STAGES.length-1){beginRealm(stageIndex+1);notify('ENTERING '+STAGES[stageIndex].name,3);}
      else showVictory();
    }));
  }
  function showVictory(){
    showModal('victory',`<div class="ef-card"><div class="ef-eyebrow">EMBERFALL · THE LAST HEARTH</div><div class="ef-title">THE ECLIPSE IS BROKEN</div><p class="ef-copy">The three realms have been reclaimed. The last hearth burns again, and Lyra has carried its light through the Hollow, the Foundry and the Moonwell. This campaign run is complete.</p><div class="ef-cards"><div class="ef-upgrade"><b>${totalKills} HOSTILES</b><span>Defeated across the three realms.</span></div><div class="ef-upgrade"><b>LEVEL ${level}</b><span>Lyra’s final campaign level.</span></div><div class="ef-upgrade"><b>${upgrades.length} RELICS</b><span>Permanent powers claimed.</span></div></div><button class="ef-main-btn" id="ef-new-run">BEGIN NEW CAMPAIGN</button></div>`);
    uiModal.querySelector('#ef-new-run').addEventListener('click',()=>{
      stageIndex=0;level=1;xp=0;upgrades=[];totalKills=0;playerHpMax=260;playerHp=260;damageMultiplier=1;solarMultiplier=1;skillCooldownMultiplier=1;ultimate=0;saveCampaign();hideModal();beginRealm(0);
    });
    if(safeLocal)try{safeLocal.setItem(SAVE_KEY,JSON.stringify({stageIndex:0,level:1,xp:0,upgrades:[],complete:true,totalKills}));}catch(_){}
  }
  function showDefeat(){
    showModal('defeat',`<div class="ef-card"><div class="ef-eyebrow">THE LAST HEARTH FALTERS</div><div class="ef-title">LYRA HAS FALLEN</div><p class="ef-copy">The realm remembers your progress. Regroup at the entrance and face the current encounter again. Your relics and earned levels remain.</p><button class="ef-main-btn" id="ef-retry">RETRY ENCOUNTER</button></div>`);
    uiModal.querySelector('#ef-retry').addEventListener('click',()=>{
      playerHp=playerHpMax;solarCd=0;shieldCd=0;ultimate=Math.max(0,ultimate-20);hideModal();
      const current=stageIndex;realmData[current].root.setEnabled(true);hero.root.position.set(0,0,-14);disposeEnemies();waveIndex=0;awaitingPortal=false;spawnWave();updateHUD();
    });
  }

  function gainXP(amount){
    xp+=amount;
    while(xp>=xpNext){xp-=xpNext;level++;xpNext=Math.floor(xpNext*1.34);playerHpMax+=18;playerHp=Math.min(playerHpMax,playerHp+55);damageMultiplier+=.035;notify('LEVEL UP · LEVEL '+level,2.6);burst(hero.root.position.add(new V(0,1.5,0)),'#ffe5a2','#7bcaff',72,7,.33);}
    saveCampaign();
  }
  function setEnemyHitFlash(e){
    const original=e.mm.body.diffuseColor.clone();
    e.mm.body.emissiveColor=new B.Color3(.8,.48,.22);
    setTimeout(()=>{if(e.mm.body&&!e.mm.body.isDisposed())e.mm.body.emissiveColor=B.Color3.Black();},115);
  }
  function killEnemy(e){
    if(!e.alive)return;
    e.alive=false;e.root.setEnabled(false);totalKills++;gainXP(e.xp);ultimate=clamp(ultimate+(e.boss?45:7),0,100);
    playerHp=Math.min(playerHpMax,playerHp+(e.boss?65:5));
    burst(e.root.position.add(new V(0,1.3*e.root.scaling.y,0)),STAGES[stageIndex].palette.hot,STAGES[stageIndex].palette.glow,e.boss?150:42,e.boss?10:6,e.boss?.44:.25);
    if(currentBoss===e)currentBoss=null;
    updateHUD();
  }
  function damageEnemy(e,amount,knock=1){
    if(!e||!e.alive)return;
    e.hp=Math.max(0,e.hp-amount);
    const away=e.root.position.subtract(hero.root.position);away.y=0;
    if(away.lengthSquared()>.01){away.normalize();e.root.position.addInPlace(away.scale(knock));}
    e.hitstun=.16;setEnemyHitFlash(e);
    burst(e.root.position.add(new V(0,1.6*e.root.scaling.y,0)),'#ffe6a2',STAGES[stageIndex].palette.hot,13,3.4,.17);
    shake=Math.max(shake,.11);
    if(e.boss&&!e.summoned&&e.hp<e.maxHp*.58){
      e.summoned=true;notify('THE CHAMPION CALLS ITS GUARD',2.4);
      const adds=stageIndex===2?['wraith','lancer']:stageIndex===1?['cinder','knight']:['stalker','archer'];
      spawnEnemy({t:adds[0],x:-10,z:7});spawnEnemy({t:adds[1],x:10,z:9});
    }
    if(e.hp<=0)killEnemy(e);
    updateHUD();
  }

  function closestTarget(maxDist=8,frontOnly=false){
    const f=forwardOf(hero.facing.rotation.y),pos=hero.root.position;
    let best=null,bestD=maxDist;
    for(const e of enemies){if(!e.alive)continue;const d=e.root.position.subtract(pos);d.y=0;const len=d.length();if(len>=bestD)continue;if(frontOnly&&len>.2&&B.Vector3.Dot(d.normalize(),f)<-.12)continue;best=e;bestD=len;}
    return best;
  }
  let comboFlashTimer=0;
  function showCombo(text){const el=document.getElementById('ef-combo');el.textContent=text;el.classList.add('on');comboFlashTimer=.72;}
  function playerAttack(kind){
    if(!combatRunning||base.getState()!=='playing')return;
    const now=performance.now()/1000;
    if(kind==='heavy'){if(heavyCd>0)return;heavyCd=1.05;combo=0;comboWindow=0;}
    else{if(attackCd>0)return;combo=comboWindow>0?(combo%3)+1:1;comboWindow=1.0;attackCd=.31;}
    const target=closestTarget(kind==='heavy'?5.7:4.8,false);
    if(target){const d=target.root.position.subtract(hero.root.position);d.y=0;if(d.lengthSquared()>.01)hero.facing.rotation.y=Math.atan2(d.x,d.z);}
    const amount=(kind==='heavy'?112:(combo===3?78:(combo===2?59:46)))*damageMultiplier*(target&&target.boss?.83:1);
    const f=forwardOf(hero.facing.rotation.y);
    let landed=0;
    for(const e of enemies){
      if(!e.alive)continue;
      const to=e.root.position.subtract(hero.root.position);to.y=0;const len=to.length();
      if(len>(kind==='heavy'?5.2:4.2)||len<.2)continue;
      if(B.Vector3.Dot(to.normalize(),f)<(kind==='heavy'?-.05:.18))continue;
      damageEnemy(e,amount*(kind==='heavy'?1:(1+(combo-1)*.14)),kind==='heavy'?2.0:1.0);landed++;
    }
    const hitAt=hero.root.position.add(f.scale(1.9)).add(new V(0,1.4,0));
    burst(hitAt,kind==='heavy'?'#fff0b2':'#d9f5ff',STAGES[stageIndex].palette.hot,kind==='heavy'?58:30,kind==='heavy'?7:5,kind==='heavy'?.34:.24);
    if(landed){ultimate=clamp(ultimate+landed*(kind==='heavy'?16:10),0,100);showCombo(kind==='heavy'?'HEAVY BREAK':(['','FIRST CUT','SECOND CUT','SOLAR FINISH'][combo]));}
    updateHUD();
  }
  function solarNova(){
    if(!combatRunning||solarCd>0||base.getState()!=='playing')return;
    solarCd=9.5*skillCooldownMultiplier;
    const center=hero.root.position.add(new V(0,1,0));
    burst(center,'#fff1ad','#ff6b39',150,11,.48);
    const shockMat=makeMat('SolarNovaShockwaveMat','#fff0b2','#ffd16a',.16,.25);shockMat.alpha=1;const ring=mesh('SolarNovaShockwave','torus',null,[hero.root.position.x,.15,hero.root.position.z],[.8,.8,.8],shockMat,{diameter:.8,thickness:.22});
    let elapsed=0;const origin=hero.root.position.clone();
    const observer=scene.onBeforeRenderObservable.add(()=>{const dt=engine.getDeltaTime()/1000;elapsed+=dt;const s=1+elapsed*19;ring.scaling.set(s,s,s);ring.material.alpha=clamp(1-elapsed/.72,0,1);if(elapsed>.72){scene.onBeforeRenderObservable.remove(observer);ring.dispose();}});
    for(const e of enemies){if(e.alive&&dist2(e.root.position,hero.root.position)<8.2)damageEnemy(e,205*solarMultiplier*(e.boss?.72:1),2.6);}
    ultimate=clamp(ultimate+10,0,100);shake=.6;notify('SOLAR NOVA',1.3);updateHUD();
  }
  function wardShield(){
    if(!combatRunning||shieldCd>0||base.getState()!=='playing')return;
    shieldCd=13*skillCooldownMultiplier;shieldTime=shieldDuration;
    burst(hero.root.position.add(new V(0,1.2,0)),'#bceaff','#5c9bff',95,5,.38);
    const aura=mesh('WardShell','torus',null,[hero.root.position.x,1.1,hero.root.position.z],[2.35,2.35,2.35],makeMat('WardShellMat','#80caff','#539cff',.15,.45),{diameter:2.35,thickness:.12});
    aura.rotation.x=Math.PI/2;
    const observer=scene.onBeforeRenderObservable.add(()=>{if(shieldTime<=0||aura.isDisposed()){scene.onBeforeRenderObservable.remove(observer);aura.dispose();return;}aura.position.copyFrom(hero.root.position);aura.position.y=1.1;});
    notify('WARD SHIELD · DAMAGE REDUCED',1.8);updateHUD();
  }
  function hearthfire(){
    if(!combatRunning||ultimate<100||base.getState()!=='playing')return;
    ultimate=0;shake=.9;
    burst(hero.root.position.add(new V(0,1.4,0)),'#fff4c5','#ee6a31',220,13,.58);
    for(const e of enemies){if(e.alive&&dist2(e.root.position,hero.root.position)<13)damageEnemy(e,520*(e.boss?.62:1),4.2);}
    notify('ULTIMATE · HEARTHFIRE UNLEASHED',2.4);updateHUD();
  }

  function hurtPlayer(amount,source){
    if(invulnerable>0||!combatRunning)return;
    const damage=amount*(shieldTime>0?.28:1);
    playerHp=Math.max(0,playerHp-damage);invulnerable=.65;shake=Math.max(shake,.28);
    burst(hero.root.position.add(new V(0,1.2,0)),'#f39b80','#e9d4a1',32,5,.24);
    notify(source||'LYRA TAKES A HIT',1.2);updateHUD();
    if(playerHp<=0){combatRunning=false;showDefeat();}
  }
  function spawnProjectile(e){
    const pal=STAGES[stageIndex].palette;
    const matp=makeMat('EnemyProjectile_'+e.id,pal.hot,pal.glow,.2,.25);
    const orb=mesh('EnemyBolt','sphere',null,[e.root.position.x,1.55*e.root.scaling.y,e.root.position.z],[.28,.28,.28],matp);
    const target=hero.root.position.add(new V(0,1,0));
    const direction=target.subtract(orb.position).normalize();
    const trail=mesh('EnemyBoltCore','sphere',orb,[0,0,-.2],[.44,.44,.44],getEnemyMats(stageIndex,e.type).glow);
    projectiles.push({mesh:orb,velocity:direction.scale(e.boss?12.5:10),life:4,damage:e.damage*(e.boss?1:.85),source:e});
  }

  function updateEnemy(e,dt){
    if(!e.alive)return;
    e.attackCd-=dt;e.hitstun=Math.max(0,e.hitstun-dt);
    const pos=e.root.position, delta=hero.root.position.subtract(pos);delta.y=0;
    const d=Math.max(.001,delta.length()), dir=delta.scale(1/d);
    const yaw=Math.atan2(dir.x,dir.z);e.facing.rotation.y+=((yaw-e.facing.rotation.y+Math.PI*3)%(Math.PI*2)-Math.PI)*(1-Math.exp(-9*dt));
    const phase=e.boss&&e.hp<e.maxHp*.52?1.3:1;
    const approachRange=e.range*(e.boss?.78:1);
    if(e.hitstun<=0){
      if(e.mode==='approach'){
        const wantRange=e.type==='archer'||e.type==='artillerist'||e.type==='wraith'||e.type==='matriarch'?Math.min(e.range*.72,7.3):approachRange*.82;
        if(d>wantRange){pos.addInPlace(dir.scale(e.speed*phase*dt));}
        else if(e.attackCd<=0){
          e.mode='windup';e.timer=e.boss?1.0:(e.ranged?.82:.62);e.ring.setEnabled(true);e.ring.scaling.setAll(e.boss?1.2:1);
        }
      } else if(e.mode==='windup'){
        e.timer-=dt;
        e.ring.scaling.setAll((e.boss?1.2:1)+Math.sin(realmClock*18)*.08);
        if(e.timer<=0){
          e.ring.setEnabled(false);
          if(e.boss){
            e.mode='strike';e.timer=.35;
            if(d<7.1&&invulnerable<=0)hurtPlayer(e.damage*(phase), 'COLOSSAL IMPACT');
            burst(new V(pos.x,.25,pos.z),'#ff8c5b',STAGES[stageIndex].palette.hot,80,7,.3);
          }else if(e.ranged){spawnProjectile(e);e.mode='recover';e.attackCd=e.cooldown;}
          else{
            e.mode='strike';e.timer=.26;pos.addInPlace(dir.scale(1.1));
            if(d<e.range+1.0)hurtPlayer(e.damage,'ENEMY STRIKE');
          }
        }
      }else if(e.mode==='strike'){
        e.timer-=dt;if(e.timer<=0){e.mode='recover';e.attackCd=e.cooldown/phase;}
      }else if(e.mode==='recover'){
        e.timer-=dt;if(e.timer<=0)e.mode='approach';
      }
    }
    pos.x=clamp(pos.x,-12.2,12.2);pos.z=clamp(pos.z,-18.5,14.5);
    const gait=e.mode==='approach'?Math.sin(realmClock*8+e.id)*.36:0;
    e.legs.forEach(l=>l.hip.rotation.x=l.side*gait);
    e.arms.forEach(a=>{
      if(e.mode==='windup'){a.shoulder.rotation.x=-.75+Math.sin(realmClock*15)*.07;a.elbow.rotation.x=-.5;}
      else if(e.mode==='strike'){a.shoulder.rotation.x=.75;a.elbow.rotation.x=.35;}
      else{a.shoulder.rotation.x=a.side*gait*.35;a.elbow.rotation.x=.06;}
    });
    if(e.float){pos.y=1.0+Math.sin(realmClock*2.6+e.id)*.32;}else pos.y=0;
    e.body.scaling.y=1+Math.sin(realmClock*4+e.id)*.025;
  }
  function updateProjectiles(dt){
    for(let i=projectiles.length-1;i>=0;i--){
      const p=projectiles[i];p.life-=dt;p.mesh.position.addInPlace(p.velocity.scale(dt));
      p.mesh.rotation.x+=dt*6;p.mesh.rotation.y+=dt*7;
      if(dist2(p.mesh.position,hero.root.position)<1.05&&Math.abs(p.mesh.position.y-(hero.root.position.y+1))<1.7){hurtPlayer(p.damage,'A BOLT FINDS ITS MARK');burst(p.mesh.position,'#ffd59b','#f05b45',22,4,.22);p.life=0;}
      if(p.life<=0||Math.abs(p.mesh.position.x)>34||Math.abs(p.mesh.position.z)>34){p.mesh.dispose();projectiles.splice(i,1);}
    }
  }
  function checkWave(){
    if(awaitingPortal||waveDelay>0||!combatRunning)return;
    if(enemies.some(e=>e.alive))return;
    if(waveIndex<3){waveDelay=2.2;notify('AREA CLEAR · NEXT HOSTILE WAVE',1.6);}
    else openExit();
  }
  function checkPortal(){
    if(!awaitingPortal||!combatRunning)return;
    const pos=hero.root.position;
    if(dist2(pos,new V(0,0,15))<3.0){
      if(stageIndex<STAGES.length-1)showUpgrade();else showVictory();
    }
  }
  function updatePortal(dt){
    const p=realmData[stageIndex];if(!awaitingPortal)return;
    p.ring.rotation.z+=dt*.8;p.ring2.rotation.z-=dt*1.1;
    p.portal.position.y=Math.sin(realmClock*2)*.12;
  }

  function tick(){
    const now=performance.now(),dt=Math.min(.05,(now-lastTick)/1000);lastTick=now;
    if(base.getState()!=='playing'||!combatRunning)return;
    realmClock+=dt;
    solarCd=Math.max(0,solarCd-dt);shieldCd=Math.max(0,shieldCd-dt);shieldTime=Math.max(0,shieldTime-dt);invulnerable=Math.max(0,invulnerable-dt);
    attackCd=Math.max(0,attackCd-dt);heavyCd=Math.max(0,heavyCd-dt);comboWindow=Math.max(0,comboWindow-dt);
    enemies.forEach(e=>updateEnemy(e,dt));updateProjectiles(dt);
    // Realm hazards and sanctuary bonuses are active combat rules, not scenery.
    hazardClock=Math.max(0,hazardClock-dt);
    if(stageIndex===1 && hazardClock<=0 && Math.abs(Math.abs(hero.root.position.x)-8)<1.9 && Math.abs(hero.root.position.z)<18){
      hurtPlayer(13,'LAVA CHANNEL · MOVE TO STONE');hazardClock=1.05;
    }
    if(stageIndex===2 && dist2(hero.root.position,new V(0,0,2))<3.1 && playerHp<playerHpMax){playerHp=Math.min(playerHpMax,playerHp+7*dt);}
    if(waveDelay>0){waveDelay-=dt;if(waveDelay<=0)beginNextWave();}
    updatePortal(dt);checkWave();checkPortal();
    if(shake>0){shake=Math.max(0,shake-dt*1.8);const cam=scene.activeCamera;if(cam){cam.position.x+=Math.sin(realmClock*61)*shake*.2;cam.position.y+=Math.cos(realmClock*73)*shake*.12;}}
    if(comboFlashTimer>0){comboFlashTimer-=dt;if(comboFlashTimer<=0)document.getElementById('ef-combo').classList.remove('on');}
    updateHUD();
  }

  // Input hooks are additive to the existing sword animation and movement system.
  window.addEventListener('keydown',e=>{
    if(e.repeat)return;
    if(e.code==='KeyJ')playerAttack('light');
    else if(e.code==='KeyK')playerAttack('heavy');
    else if(e.code==='KeyQ')solarNova();
    else if(e.code==='KeyE')wardShield();
    else if(e.code==='KeyR')hearthfire();
    else if(e.code==='Escape'&&base.getState()==='playing'){
      document.querySelector('#pause-screen .intro').textContent='Your campaign is paused. The last hearth waits for your return.';
      document.querySelector('#pause-screen .title-mark').textContent='CAMPAIGN PAUSED';
    }
  });
  canvas.addEventListener('pointerdown',e=>{if(e.button===0)playerAttack('light');});
  document.querySelectorAll('[data-action]').forEach(btn=>btn.addEventListener('pointerdown',e=>{
    e.preventDefault();const a=btn.dataset.action;
    if(a==='light')playerAttack('light');else if(a==='heavy')playerAttack('heavy');else if(a==='solar')solarNova();else if(a==='dodge'){};
  },{passive:false}));
  // New campaign abilities are also exposed on the mobile action pad.
  const mobileActions=document.querySelector('.mobile-actions');
  if(mobileActions){
    const shield=document.createElement('button');shield.textContent='WARD';shield.dataset.campaign='shield';mobileActions.appendChild(shield);
    shield.addEventListener('pointerdown',e=>{e.preventDefault();wardShield();},{passive:false});
    const ult=document.createElement('button');ult.textContent='NOVA';ult.dataset.campaign='ultimate';mobileActions.appendChild(ult);
    ult.addEventListener('pointerdown',e=>{e.preventDefault();hearthfire();},{passive:false});
  }

  // Replace the old one-boss objective with the first chapter of the campaign.
  playerHp=playerHpMax;updateStatsFromUpgrades();
  if(safeLocal&&save.complete){stageIndex=0;level=1;xp=0;upgrades=[];totalKills=0;}
  beginRealm(stageIndex);
  scene.registerBeforeRender(tick);
  window.EmberfallCampaign={scene,engine,stages:STAGES,getProgress:()=>({stage:stageIndex+1,wave:waveIndex+1,level,xp,upgrades:[...upgrades],kills:totalKills,alive:enemies.filter(e=>e.alive).length}),restart:()=>{playerHp=playerHpMax;waveIndex=0;disposeEnemies();spawnWave();combatRunning=true;}};
})();
