# Emberfall: The Last Hearth — Campaign Build

A browser-first, full-3D third-person action RPG campaign built on Babylon.js. The game runs in a desktop browser and does not require Unity, Unreal, Blender, a local 3D editor, or a local install. The project uses procedural 3D geometry, materials, lighting, animation, particles and combat effects so the campaign can run as a static web app.

## Campaign

Emberfall is structured as a three-realm campaign rather than a single-arena encounter:

1. **Verdant Hollow** — overgrown ruins, ancient pines, rootbound stalkers, thorn archers, brutes and the Thornheart Colossus.
2. **Ashen Foundry** — a volcanic foundry with lava channels, iron bridges, furnace stacks, cinder beasts, forged knights, artillery casters and the Cinder Tyrant.
3. **Moonwell Citadel** — a moonlit fortress with ramparts, towers, a luminous well, wraiths, lancers, spectral artillery and the Eclipse Matriarch.

Each realm contains four sequential combat encounters. The final encounter is a boss battle supported by adds; the boss can summon reinforcements as its health falls. Defeat the champion, reach the realm gate, and claim a permanent relic before the next chapter. The final boss completes the campaign.

## Combat and progression

- Third-person movement with camera-relative keyboard controls and a smooth chase camera.
- Three-hit sword combo, heavy armor-breaking strike, dodge invulnerability, and jump.
- **Solar Nova (Q):** area burst that damages groups.
- **Ward Shield (E):** temporary damage reduction.
- **Hearthfire (R):** charged ultimate; build charge by landing attacks and defeating enemies.
- Enemy archetypes use different movement, ranges, health, attack cadence and telegraphs. Archers and casters fire projectiles; brutes hit harder at close range; bosses use marked ground attacks and summon support.
- Experience, character levels, permanent relic upgrades, healing from kills and saved campaign progress.
- Realm-specific lighting, fog, environment architecture, emissive materials, bloom, hit sparks, impact particles, shockwaves, boss health bars and camera shake.

## Controls

| Action | Keyboard / mouse |
|---|---|
| Move | W A S D / arrow keys |
| Light sword combo | J / left mouse click |
| Heavy strike | K |
| Dodge | Space |
| Jump | Shift |
| Solar Nova | Q |
| Ward Shield | E |
| Hearthfire ultimate | R (when charged) |
| Orbit camera | Hold right mouse button and drag |
| Pause | Esc |

Touch devices use the on-screen movement stick and action buttons. The game requires a modern browser and an internet connection for Babylon.js from its official CDN.

## Files

- `index.html` — browser entry point and HUD shell.
- `style.css` — base visual shell and touch controls.
- `src/game.js` — Babylon.js engine setup, Lyra character rig, movement, camera, animation and audio.
- `src/campaign.js` — realm environments, enemy factions, encounters, boss AI, skills, VFX, XP, relics, saves and campaign flow.

## Run

Serve this folder as a static website or deploy it to Cloudflare Pages. No local build step or heavy 3D software is required. Open `index.html` in a modern desktop browser; the campaign launches automatically.

## Project scope

This is a playable, self-contained campaign build with procedural character and environment assets. It is not a pre-rendered video or a static environment viewer. The models and animation are authored procedurally rather than imported from a commercial AAA asset library or motion-capture pipeline; the game loop, encounters, enemy AI, skills, realm changes and progression are playable systems.
