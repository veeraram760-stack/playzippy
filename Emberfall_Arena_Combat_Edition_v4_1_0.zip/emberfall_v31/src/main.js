import { AIR_MOVES, HEAVY_MOVE, LIGHT_CHAIN, SOLAR_MODES, getStyleRank, nextChainIndex } from './systems/combat-data.js';
import { getChamberLayout, surfaceHeightAt } from './systems/chambers.js';
import { getEnemyProfile } from './systems/enemy-data.js';
import { getEncounterWaves } from './systems/encounter-data.js';

const W = 1280, H = 720;
const $ = (id) => document.getElementById(id);
const canvas = $('game');
const ctx = canvas.getContext('2d', { alpha: false });
const frame = $('canvasFrame');
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const lerp = (a,b,t) => a + (b-a)*t;
const rand = (a,b) => a + Math.random()*(b-a);
const choice = (arr) => arr[Math.floor(Math.random()*arr.length)];
const easeOut = t => 1 - Math.pow(1-t, 3);
const angleDelta = (a,b) => Math.atan2(Math.sin(b-a),Math.cos(b-a));
const angleLerp = (a,b,t) => a + angleDelta(a,b)*t;

const realms = [
  { name:'THE VERDANT HOLLOW', roomNames:['MOSS GATE','ROOTBOUND CHAPEL','HANGING ORCHARD',"THE ROOTBOUND WARDEN"], tag:'REALM I · THE ROOTS', title:'The Verdant Hollow', desc:'A forest swallowed by a living blight. Even the old stones have begun to breathe.', palette:{sky:'#243a31',floor:'#304536',floor2:'#40563d',line:'#68734b',accent:'#a9ba77',glow:'#c6d77e',portal:'#9fc58f',mist:'#91a98a'}, objective:'Break the root seals' },
  { name:'THE ASHEN FOUNDRY', roomNames:['CINDER WALK','THE BROKEN FURNACE','THE ASHEN COLOSSUS'], tag:'REALM II · THE EMBERS', title:'The Ashen Foundry', desc:'A kingdom of black iron and sleeping furnaces, where every breath tastes of old fire.', palette:{sky:'#402a27',floor:'#49362e',floor2:'#5e4435',line:'#89634b',accent:'#df9860',glow:'#f5a46b',portal:'#ed9b69',mist:'#bd806a'}, objective:'Quench the furnace heart' },
  { name:'THE MOONWELL KEEP', roomNames:['SILVER APPROACH','THE FLOODED ARCHIVE','THE HOLLOW CROWN'], tag:'REALM III · THE VEIL', title:'The Moonwell Keep', desc:'A drowned palace caught between moonlight and shadow. The Crown waits below.', palette:{sky:'#2b2f4b',floor:'#3d425f',floor2:'#505677',line:'#8588a8',accent:'#b6b9e2',glow:'#d9ddff',portal:'#b8c7e9',mist:'#98a2ce'}, objective:'Shatter the Hollow Crown' },
  { name:'THE STARFALL BASTION', roomNames:['FALLEN CAUSEWAY','ASTRAL FORGE','ECLIPSE SANCTUM','THE STARFALL REGENT'], tag:'REALM IV · THE LAST SKY', title:'The Starfall Bastion', desc:'A fortress suspended above a broken sky. Star engines tear open the void beneath its towers.', palette:{sky:'#141b38',floor:'#202b4b',floor2:'#334568',line:'#607fa9',accent:'#89c8ed',glow:'#91eaff',portal:'#9de6ff',mist:'#8e9fd0'}, objective:'Defeat the Starfall Regent' }
];

const images = {};
const heroAtlas = new Image(); heroAtlas.src = '/art/hero-atlas.png';
const heroIdle = new Image(); heroIdle.src = '/art/hero-idle.png';
for (const name of ['hero','thornling','archer','brute','boss','wisp']) {
  const img = new Image(); img.src = name === 'wisp' ? `/art/${name}.svg` : `/art/${name}.webp`; images[name] = img;
}
const enemyAtlases = {};
for (const name of ['thornling','archer','brute','boss']) {
  const atlas = new Image(); atlas.src = `/art/${name}-atlas.png`; enemyAtlases[name] = atlas;
}
const realmBackgrounds = ['verdant','ashen','moonwell'].map(name => {
  const img = new Image();
  img.src = `/art/bg-${name}.webp`;
  img.onload = () => { if (typeof game !== 'undefined' && game) buildBackground(); };
  return img;
});

const saveKey = 'playzippy_emberfall_save_v1';
let stored = {};
try { stored = JSON.parse(localStorage.getItem(saveKey) || '{}'); } catch { stored = {}; }
const meta = { bestTime: stored.bestTime || 0, bestKills: stored.bestKills || 0, bestRank: stored.bestRank || '—', bestSecrets: stored.bestSecrets || 0, current: stored.current || null, sound: stored.sound !== false, riskMode: stored.riskMode === true };
let muted = !meta.sound;

const player = {
  x:640,y:520,vx:0,vy:0,r:17,hp:100,maxHp:100,speed:235,damage:18,airBonus:0,heavyBonus:0,attackCd:0,attackTime:0,attackDuration:.42,attackAngle:-Math.PI/2,attackApplied:false,attackLunge:0,combo:0,comboTimer:0,attackKind:'light',attackMove:null,chargeTime:0,heavyCharging:false,perfectDodgeWindow:0,perfectDodgeTime:0,elevation:0,airBonus:0,heavyBonus:0,
  dashCd:0,dashTime:0,dashVX:0,dashVY:0,jumpCd:0,jumpActive:false,jumpZ:0,jumpVy:0,jumpVX:0,jumpVY:0,landTime:0,animTime:0,facingAngle:0,facingSign:1,invuln:0,hurtTime:0,hurtAngle:0,specialCd:0,specialTime:0,riftCd:0,aetherCd:0,level:1,xp:0,xpNeed:100,gold:0,kills:0,damageBonus:0,solarBonus:0,dodgeBonus:0,critBonus:0,regen:0,runTime:0,stepTimer:0,stepSide:0
};
const game = {
  phase:'menu',stage:0,room:0,riskMode:meta.riskMode,enemies:[],waveQueue:[],waveIndex:0,waveDelay:0,projectiles:[],particles:[],pickups:[],floaters:[],combatFX:[],afterimages:[],decor:[],plants:[],chamberLayout:null,portal:null,boss:null,roomCleared:false,roomTime:0,roomKills:0,shake:0,hitStop:0,impactFlash:0,cameraZoom:0,toastTimer:0,toastText:'',rewardOptions:[],pendingTransition:null,sessionStart:0,continued:false,previousFrame:0,styleScore:0,dodgeStreak:0,solarMode:0,solarModeCooldown:0,grabCooldown:0,secretFound:0
};
const input = { keys:new Set(), pointer:{x:640,y:360,down:false,inside:false}, joy:{x:0,y:0,active:false}, attackHeld:false };
const background = document.createElement('canvas'); background.width=W; background.height=H;
const bg = background.getContext('2d');

const relicPool = [
  {id:'sunsteel',name:'Sunsteel Edge',icon:'✦',rarity:'WEAPON · RARE',desc:'Your blade bites deeper. +22% attack damage.',apply:()=>{player.damageBonus+=.22;}},
  {id:'hearth',name:'Hearthstone Core',icon:'♥',rarity:'VITALITY · RARE',desc:'A warm pulse returns. +24 maximum health and heal 24.',apply:()=>{player.maxHp+=24;player.hp=Math.min(player.maxHp,player.hp+24);}},
  {id:'swift',name:'Swift Ember',icon:'➶',rarity:'MOBILITY · UNCOMMON',desc:'Move like a spark. Dodge cooldown reduced by 18%.',apply:()=>{player.dodgeBonus+=.18;}},
  {id:'solar',name:'Solar Lens',icon:'☼',rarity:'ARCANA · RARE',desc:'Your burst burns brighter. +35% solar damage and radius.',apply:()=>{player.solarBonus+=.35;}},
  {id:'hunters',name:'Hunter’s Thread',icon:'⌖',rarity:'PRECISION · UNCOMMON',desc:'Find the gaps. +8% chance to land a critical strike.',apply:()=>{player.critBonus+=.08;}},
  {id:'moss',name:'Mossbound Vow',icon:'❧',rarity:'RECOVERY · UNCOMMON',desc:'The forest lends its strength. Restore 1.5 health each second.',apply:()=>{player.regen+=1.5;}},
  {id:'cinder',name:'Cinder Rhythm',icon:'♫',rarity:'TECHNIQUE · RARE',desc:'A faster blade. Combo strikes recover 13% sooner.',apply:()=>{player.attackHaste=(player.attackHaste||0)+.13;}},
  {id:'ward',name:'Warden’s Sigil',icon:'◇',rarity:'WARDING · RARE',desc:'A sliver of old protection. +12% maximum health.',apply:()=>{player.maxHp=Math.round(player.maxHp*1.12);player.hp=Math.min(player.maxHp,player.hp+12);}},
  {id:'aerial',name:'Skyshard Crest',icon:'↟',rarity:'AERIAL · RARE',desc:'The air remembers your blade. +35% aerial attack damage.',apply:()=>{player.airBonus=(player.airBonus||0)+.35;}},
  {id:'breaker',name:'Sunbreaker Knot',icon:'✹',rarity:'TECHNIQUE · RARE',desc:'Your charged attacks hit harder. +28% heavy attack damage.',apply:()=>{player.heavyBonus=(player.heavyBonus||0)+.28;}},
  {id:'rootward',name:'Rootward Heart',icon:'❧',rarity:'VITALITY · UNCOMMON',desc:'A living root guards the hearth. Heal 16 and gain 12 maximum health.',apply:()=>{player.maxHp+=12;player.hp=Math.min(player.maxHp,player.hp+16);}}
];

function persist() {
  try { localStorage.setItem(saveKey, JSON.stringify({bestTime:meta.bestTime,bestKills:meta.bestKills,bestRank:meta.bestRank,bestSecrets:meta.bestSecrets,current:meta.current,sound:!muted,riskMode:game.riskMode})); $('saveStatus').textContent='PROGRESS SAVED'; }
  catch { $('saveStatus').textContent='SAVE UNAVAILABLE'; }
}
function snapshotRun() {
  return {stage:game.stage,room:game.room,hp:player.hp,maxHp:player.maxHp,damage:player.damageBonus,solar:player.solarBonus,dodge:player.dodgeBonus,crit:player.critBonus,regen:player.regen,attackHaste:player.attackHaste||0,level:player.level,xp:player.xp,xpNeed:player.xpNeed,gold:player.gold,kills:player.kills,runTime:player.runTime,relics:[...runRelics],styleScore:game.styleScore,solarMode:game.solarMode,secretFound:game.secretFound,riskMode:game.riskMode,airBonus:player.airBonus||0,heavyBonus:player.heavyBonus||0};
}
let runRelics = [];
function clearRunSave(){meta.current=null;persist();}
function resetPlayer(){
  Object.assign(player,{x:640,y:515,vx:0,vy:0,r:17,hp:100,maxHp:100,speed:235,damage:18,attackCd:0,attackTime:0,attackDuration:.42,attackAngle:-Math.PI/2,attackApplied:false,attackLunge:0,combo:0,comboTimer:0,attackKind:'light',attackMove:null,chargeTime:0,heavyCharging:false,perfectDodgeWindow:0,perfectDodgeTime:0,elevation:0,airBonus:0,heavyBonus:0,dashCd:0,dashTime:0,dashVX:0,dashVY:0,jumpCd:0,jumpActive:false,jumpZ:0,jumpVy:0,jumpVX:0,jumpVY:0,landTime:0,animTime:0,facingAngle:0,facingSign:1,invuln:0,hurtTime:0,hurtAngle:0,specialCd:0,specialTime:0,riftCd:0,aetherCd:0,level:1,xp:0,xpNeed:100,gold:0,kills:0,damageBonus:0,solarBonus:0,dodgeBonus:0,critBonus:0,regen:0,runTime:0,attackHaste:0,stepTimer:0,stepSide:0});
  game.styleScore=0;game.dodgeStreak=0;game.solarMode=0;game.secretFound=0;runRelics=[];game.riskMode=meta.riskMode;
}
function isBossRoom(){return game.room===realms[game.stage].roomNames.length-1;}
function currentSolarMode(){return SOLAR_MODES[game.solarMode]||SOLAR_MODES[0];}
function startJourney(continueSaved=false){
  resetPlayer();game.stage=0;game.room=0;game.sessionStart=performance.now();game.continued=continueSaved;
  if(continueSaved && meta.current){const s=meta.current;game.stage=clamp(s.stage||0,0,3);game.room=clamp(s.room||0,0,realms[game.stage].roomNames.length-1);game.styleScore=s.styleScore||0;game.solarMode=clamp(s.solarMode||0,0,SOLAR_MODES.length-1);game.secretFound=s.secretFound||0;game.riskMode=typeof s.riskMode==='boolean'?s.riskMode:meta.riskMode;Object.assign(player,{hp:s.hp||100,maxHp:s.maxHp||100,damageBonus:s.damage||0,airBonus:s.airBonus||0,heavyBonus:s.heavyBonus||0,solarBonus:s.solar||0,dodgeBonus:s.dodge||0,critBonus:s.crit||0,regen:s.regen||0,attackHaste:s.attackHaste||0,level:s.level||1,xp:s.xp||0,xpNeed:s.xpNeed||100,gold:s.gold||0,kills:s.kills||0,runTime:s.runTime||0});runRelics=s.relics||[];}
  player.x=445;player.y=520;player.vx=player.vy=0;player.attackCd=0;player.dashCd=0;player.specialCd=0;
  loadEncounter();setPhase('playing');$('chapterPill').textContent=`CHAPTER ${['I','II','III'][game.stage]} · ${realms[game.stage].name}`;showToast(continueSaved?'THE EMBERS REMEMBER YOU':'THE JOURNEY BEGINS',1.9);sound('start');
  updateUI();
}
function setPhase(phase){
  game.phase=phase;
  const overlay=$('overlay');
  if(phase==='playing'){overlay.classList.add('hidden');}
  else {overlay.classList.remove('hidden');$('menuPanel').classList.toggle('hidden',phase!=='menu');$('pausePanel').classList.toggle('hidden',phase!=='paused');$('rewardPanel').classList.toggle('hidden',phase!=='reward');$('endPanel').classList.toggle('hidden',phase!=='victory'&&phase!=='defeat');}
}
function showToast(text,duration=1.4){game.toastText=text;game.toastTimer=duration;$('toast').textContent=text;$('toast').classList.add('show');}
function createRng(seed){let s=seed>>>0;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}

function buildBackground(){
  const p=realms[game.stage].palette;
  const painted=realmBackgrounds[game.stage];
  if(painted && painted.complete && painted.naturalWidth){
    bg.clearRect(0,0,W,H);
    bg.drawImage(painted,0,0,W,H);
    // Keep the combat silhouettes and floating damage text readable over the richer art.
    bg.fillStyle='rgba(7,14,11,.12)'; bg.fillRect(0,0,W,H);
    const vignette=bg.createRadialGradient(640,350,250,640,350,780);
    vignette.addColorStop(0,'rgba(3,8,7,0)'); vignette.addColorStop(.72,'rgba(3,8,7,.08)'); vignette.addColorStop(1,'rgba(3,8,7,.42)');
    bg.fillStyle=vignette; bg.fillRect(0,0,W,H);
    return;
  }
  const randBG=createRng((game.stage+1)*91+game.room*17);
  const sky=bg.createLinearGradient(0,0,0,H);sky.addColorStop(0,p.sky);sky.addColorStop(.62,p.floor);sky.addColorStop(1,'#17231c');bg.fillStyle=sky;bg.fillRect(0,0,W,H);
  // atmospheric light pools
  const halo=bg.createRadialGradient(640,210,20,640,300,590);halo.addColorStop(0,p.glow+'28');halo.addColorStop(1,'transparent');bg.fillStyle=halo;bg.fillRect(0,0,W,H);
  // arena floor, hand-laid irregular stone tiles
  bg.save();bg.beginPath();bg.roundRect(52,65,1176,610,38);bg.clip();
  bg.fillStyle=p.floor;bg.fillRect(52,65,1176,610);
  for(let row=0;row<12;row++){
    for(let col=0;col<17;col++){
      const x=48+col*72+(row%2)*34,y=64+row*53;const w=65+randBG()*9,h=43+randBG()*8;const tone=randBG();
      bg.fillStyle=tone>.66?p.floor2:tone<.13?'#1b3028':p.floor;bg.globalAlpha=.25+randBG()*.18;
      bg.beginPath();bg.roundRect(x+2,y+2,w,h,4+randBG()*7);bg.fill();bg.globalAlpha=1;
      bg.strokeStyle=p.line;bg.globalAlpha=.14;bg.lineWidth=1;bg.stroke();bg.globalAlpha=1;
      if(randBG()>.68){bg.fillStyle=p.accent;bg.globalAlpha=.16;bg.beginPath();bg.ellipse(x+randBG()*w,y+randBG()*h,randBG()*12+3,randBG()*3+1,randBG(),0,TAU);bg.fill();bg.globalAlpha=1;}
    }
  }
  // worn circular dais
  bg.strokeStyle=p.accent;bg.globalAlpha=.18;bg.lineWidth=2;bg.beginPath();bg.ellipse(640,356,280,174,0,0,TAU);bg.stroke();bg.beginPath();bg.ellipse(640,356,251,151,0,0,TAU);bg.stroke();bg.globalAlpha=1;
  for(let i=0;i<12;i++){const a=i/12*TAU;const x=640+Math.cos(a)*264,y=356+Math.sin(a)*160;bg.save();bg.translate(x,y);bg.rotate(a);bg.fillStyle=p.line;bg.globalAlpha=.3;bg.beginPath();bg.roundRect(-12,-5,24,10,2);bg.fill();bg.restore();bg.globalAlpha=1;}
  // edge parapets and broken masonry
  for(let i=0;i<18;i++){let x=70+i*66+randBG()*15;const y=i%2?77:645;bg.fillStyle=i%3===0?'#17231d':p.floor2;bg.globalAlpha=.7;bg.beginPath();bg.roundRect(x,y,38+randBG()*28,21+randBG()*12,5);bg.fill();bg.globalAlpha=1;bg.strokeStyle=p.line;bg.globalAlpha=.35;bg.stroke();bg.globalAlpha=1;}
  // moss, ash or moon flowers / stones
  for(let i=0;i<105;i++){const x=65+randBG()*1150,y=78+randBG()*580;if(x>390&&x<890&&y>190&&y<555&&randBG()>.20)continue;const size=2+randBG()*7;bg.globalAlpha=.18+randBG()*.25;bg.fillStyle=game.stage===0?(randBG()>.5?'#a8c17b':'#758f61'):game.stage===1?(randBG()>.5?'#d9865c':'#695149'):'#a7b3df';bg.beginPath();bg.ellipse(x,y,size,size*.42,randBG()*TAU,0,TAU);bg.fill();bg.globalAlpha=1;}
  // decorative pillars or crystals around the outskirts
  for(let i=0;i<13;i++){const x=100+randBG()*1080,y=90+randBG()*535;if(x>480&&x<800&&y>255&&y<480)continue;const h=18+randBG()*35;bg.fillStyle=game.stage===1?'#483b37':game.stage===2?'#4c5270':'#43513c';bg.beginPath();bg.moveTo(x-10,y);bg.lineTo(x-6,y-h);bg.lineTo(x+5,y-h-5);bg.lineTo(x+13,y-2);bg.closePath();bg.fill();bg.strokeStyle=p.line;bg.globalAlpha=.28;bg.stroke();bg.globalAlpha=1;}
  // region-specific landmarks: living roots, furnace iron, and moonlit water
  if(game.stage===0){
    bg.save();bg.lineCap='round';bg.lineJoin='round';
    for(const side of [0,1]){const x=side?1210:70;bg.strokeStyle='#172b20';bg.lineWidth=34;bg.beginPath();bg.moveTo(x,95);bg.bezierCurveTo(x+(side?-58:58),190,x+(side?30:-30),215,x,300);bg.bezierCurveTo(x+(side?-45:45),382,x+(side?30:-30),430,x+(side?0:0),575);bg.stroke();bg.strokeStyle='#617b4c';bg.globalAlpha=.5;bg.lineWidth=4;bg.beginPath();bg.moveTo(x+(side?-8:8),100);bg.bezierCurveTo(x+(side?-48:48),190,x+(side?26:-26),215,x+(side?-4:4),300);bg.stroke();bg.globalAlpha=1;}
    for(const [x,y,scale] of [[145,130,.85],[1136,155,1],[125,550,1.05],[1143,555,.8]]){bg.save();bg.translate(x,y);bg.scale(scale,scale);bg.fillStyle='#1a2d22';bg.beginPath();bg.moveTo(-8,50);bg.lineTo(-15,-8);bg.lineTo(-33,-28);bg.lineTo(-8,-22);bg.lineTo(0,-62);bg.lineTo(11,-22);bg.lineTo(34,-36);bg.lineTo(17,-3);bg.lineTo(13,50);bg.closePath();bg.fill();bg.strokeStyle='#64784b';bg.globalAlpha=.42;bg.lineWidth=3;bg.stroke();bg.restore();}
    for(let i=0;i<16;i++){const x=115+randBG()*1050,y=100+randBG()*520;if(x>330&&x<950&&y>205&&y<540)continue;bg.fillStyle='#c0d17f';bg.globalAlpha=.34;bg.beginPath();bg.ellipse(x,y,3+randBG()*4,2,randBG()*TAU,0,TAU);bg.fill();bg.globalAlpha=1;}
    bg.restore();
  }else if(game.stage===1){
    bg.save();
    for(const [x,y] of [[105,135],[1175,145],[105,555],[1178,550]]){bg.fillStyle='#211d1c';bg.beginPath();bg.roundRect(x-27,y-42,54,84,7);bg.fill();bg.strokeStyle='#986249';bg.lineWidth=3;bg.stroke();const glow=bg.createRadialGradient(x,y,4,x,y,85);glow.addColorStop(0,'#f59a5c66');glow.addColorStop(1,'transparent');bg.fillStyle=glow;bg.fillRect(x-85,y-85,170,170);bg.fillStyle='#e58a55';bg.globalAlpha=.7;bg.beginPath();bg.moveTo(x,y-25);bg.quadraticCurveTo(x+20,y+1,x,y+16);bg.quadraticCurveTo(x-19,y+1,x,y-25);bg.fill();bg.globalAlpha=1;}
    bg.strokeStyle='#9d533b';bg.lineWidth=5;bg.globalAlpha=.38;for(let i=0;i<8;i++){const x=180+i*135;bg.beginPath();bg.moveTo(x,100);bg.lineTo(x+randBG()*38-19,160+randBG()*80);bg.lineTo(x-14+randBG()*28,210+randBG()*65);bg.stroke();}bg.globalAlpha=1;
    for(let i=0;i<32;i++){const x=80+randBG()*1120,y=85+randBG()*560;bg.fillStyle=randBG()>.5?'#e28c5b':'#ffd18a';bg.globalAlpha=.22+randBG()*.28;bg.beginPath();bg.arc(x,y,1+randBG()*2.2,0,TAU);bg.fill();}bg.globalAlpha=1;bg.restore();
  }else if(game.stage===2){
    bg.save();
    for(const [x,y,rx,ry] of [[165,250,76,31],[1115,265,83,29],[150,550,58,22],[1118,540,70,27]]){const water=bg.createRadialGradient(x,y,3,x,y,Math.max(rx,ry));water.addColorStop(0,'#9caedb88');water.addColorStop(.55,'#687bb466');water.addColorStop(1,'transparent');bg.fillStyle=water;bg.beginPath();bg.ellipse(x,y,rx,ry,0,0,TAU);bg.fill();bg.strokeStyle='#b2c3e8';bg.globalAlpha=.35;bg.lineWidth=2;bg.beginPath();bg.ellipse(x,y,rx*.72,ry*.58,0,0,TAU);bg.stroke();bg.globalAlpha=1;}
    for(const [x,y] of [[118,180],[1160,175],[120,590],[1160,590]]){bg.fillStyle='#4c5474';bg.beginPath();bg.roundRect(x-14,y-42,28,84,4);bg.fill();bg.fillStyle='#a8b6dc';bg.globalAlpha=.35;bg.fillRect(x-19,y-46,38,7);bg.globalAlpha=1;bg.strokeStyle='#8f9cc6';bg.globalAlpha=.28;bg.strokeRect(x-14,y-42,28,84);bg.globalAlpha=1;}
    bg.strokeStyle='#b8c7eb';bg.globalAlpha=.23;bg.lineWidth=2;for(let i=0;i<9;i++){const x=180+i*115,y=110+(i%3)*8;bg.beginPath();bg.moveTo(x,y);bg.lineTo(x+10,y+12);bg.lineTo(x,y+24);bg.lineTo(x-10,y+12);bg.closePath();bg.stroke();}bg.globalAlpha=1;bg.restore();
  }else{
    // Starfall Bastion: a new astral skyline, fractured halo and floating causeways.
    bg.save();
    const nebula=bg.createRadialGradient(640,185,18,640,235,570);nebula.addColorStop(0,'rgba(97,177,235,.37)');nebula.addColorStop(.46,'rgba(69,96,174,.2)');nebula.addColorStop(1,'transparent');bg.fillStyle=nebula;bg.fillRect(42,54,1196,620);
    bg.strokeStyle='#80c7ec';bg.globalAlpha=.46;bg.lineWidth=12;bg.beginPath();bg.ellipse(640,176,330,118,-.10,.22,Math.PI*1.82);bg.stroke();bg.globalAlpha=.19;bg.lineWidth=3;bg.beginPath();bg.ellipse(640,176,365,135,-.10,0,TAU);bg.stroke();
    // Floating citadel spires at three distances create a new skyline silhouette.
    for(const [x,y,h,w] of [[92,505,220,60],[205,286,154,49],[390,190,86,34],[910,190,112,39],[1080,290,173,54],[1195,505,245,66],[640,124,112,48]]){bg.fillStyle='#172343';bg.beginPath();bg.moveTo(x-w*.55,y);bg.lineTo(x-w*.3,y-h*.68);bg.lineTo(x-w*.08,y-h);bg.lineTo(x+w*.1,y-h*.62);bg.lineTo(x+w*.48,y);bg.closePath();bg.fill();bg.strokeStyle='#6c9dca';bg.globalAlpha=.42;bg.lineWidth=3;bg.stroke();bg.globalAlpha=1;bg.strokeStyle='#8de7ff';bg.globalAlpha=.48;bg.lineWidth=3;bg.beginPath();bg.moveTo(x+3,y-h*.68);bg.lineTo(x+7,y-h*.18);bg.stroke();bg.globalAlpha=1;}
    // Cracked starwell in the arena floor.
    const crater=bg.createRadialGradient(640,370,8,640,370,270);crater.addColorStop(0,'rgba(120,222,255,.38)');crater.addColorStop(.42,'rgba(78,126,207,.2)');crater.addColorStop(1,'transparent');bg.fillStyle=crater;bg.beginPath();bg.ellipse(640,370,290,186,0,0,TAU);bg.fill();bg.strokeStyle='#91e6ff';bg.globalAlpha=.48;bg.lineWidth=3;bg.beginPath();bg.ellipse(640,370,240,148,0,0,TAU);bg.stroke();bg.globalAlpha=.2;bg.lineWidth=1.5;for(let i=0;i<12;i++){const a=i*TAU/12;bg.beginPath();bg.moveTo(640+Math.cos(a)*242,370+Math.sin(a)*149);bg.lineTo(640+Math.cos(a+.09)*300,370+Math.sin(a+.09)*190);bg.stroke();}bg.globalAlpha=1;
    // Suspended bridges connect the outer platforms to the starwell.
    for(const [x1,y1,x2,y2] of [[165,425,475,340],[805,340,1115,410],[470,175,590,245],[690,245,870,180]]){bg.strokeStyle='#101b35';bg.lineWidth=25;bg.lineCap='round';bg.beginPath();bg.moveTo(x1,y1);bg.lineTo(x2,y2);bg.stroke();bg.strokeStyle='#7ba6ce';bg.globalAlpha=.44;bg.lineWidth=3;bg.beginPath();bg.moveTo(x1,y1-9);bg.lineTo(x2,y2-9);bg.stroke();bg.globalAlpha=1;}
    for(let i=0;i<64;i++){const x=70+randBG()*1140,y=70+randBG()*570;const r=1+randBG()*2.6;bg.fillStyle=i%4?'#91eaff':'#d7c5ff';bg.globalAlpha=.28+randBG()*.55;bg.beginPath();bg.arc(x,y,r,0,TAU);bg.fill();}bg.globalAlpha=1;
    for(const [x,y] of [[160,564],[1120,565],[640,125]]){const g=bg.createRadialGradient(x,y,2,x,y,56);g.addColorStop(0,'#8de7ff88');g.addColorStop(1,'transparent');bg.fillStyle=g;bg.fillRect(x-56,y-56,112,112);}
    bg.restore();
  }
  // fine rune marks
  bg.strokeStyle=p.glow;bg.lineWidth=1;bg.globalAlpha=.15;
  for(let i=0;i<7;i++){const x=250+i*130,y=350+(i%2?18:-18);bg.beginPath();bg.moveTo(x,y-10);bg.lineTo(x+8,y);bg.lineTo(x,y+10);bg.lineTo(x-8,y);bg.closePath();bg.stroke();}
  bg.globalAlpha=1;bg.restore();
  // ornamental outer border
  bg.strokeStyle=p.accent;bg.globalAlpha=.25;bg.lineWidth=2;bg.beginPath();bg.roundRect(43,56,1194,628,42);bg.stroke();bg.globalAlpha=1;
  const shade=bg.createLinearGradient(0,0,0,H);shade.addColorStop(0,'rgba(4,10,8,.38)');shade.addColorStop(.25,'transparent');shade.addColorStop(.78,'transparent');shade.addColorStop(1,'rgba(4,10,8,.45)');bg.fillStyle=shade;bg.fillRect(0,0,W,H);
}

function spawnEnemy(kind,x,y,boss=false,elite=false){
  const motion={vx:0,vy:0,moveSpeed:0,stepTimer:rand(.02,.18),strafeTimer:rand(.4,1.2),strafeDir:Math.random()<.5?-1:1,facingSign:player.x>=x?1:-1,attackApplied:false,attackP:0};
  if(boss){
    const hp=(game.stage===0?900:game.stage===1?1120:game.stage===2?1420:1880)*(game.riskMode?1.28:1);
    const e={kind:'boss',x,y,r:62,hp,maxHp:hp,speed:66,damage:22,xp:220,attackCd:2.6,state:'idle',stateT:0,flash:0,phase:1,lastPhase:1,phaseFlash:0,seed:rand(0,10),anim:rand(0,TAU),boss:true,chargeVX:0,chargeVY:0,knockVX:0,knockVY:0,hitStun:0,aimX:x,aimY:y,windupDuration:.92,...motion};
    e.elevation=surfaceHeightAt(e.x,e.y,game.chamberLayout);game.enemies.push(e);game.boss=e;return e;
  }
  const d=getEnemyProfile(kind,game.stage,game.room,game.riskMode);
  const e={kind,x,y,r:d.r,hp:d.hp,maxHp:d.maxHp,speed:d.speed,damage:d.damage,xp:d.xp,elite,attackCd:rand(.4,1.5),state:'idle',stateT:0,flash:0,seed:rand(0,10),anim:rand(0,TAU),chargeVX:0,chargeVY:0,knockVX:0,knockVY:0,hitStun:0,aimX:x,aimY:y,windupDuration:0,...motion};
  if(elite){e.maxHp=Math.round(e.maxHp*1.5);e.hp=e.maxHp;e.speed*=1.12;e.damage*=1.25;e.xp=Math.round(e.xp*1.7);}
  e.elevation=surfaceHeightAt(e.x,e.y,game.chamberLayout);game.enemies.push(e);return e;
}
function spawnAtEdge(kind,elite=false){const side=Math.floor(rand(0,4));let x,y;if(side===0){x=rand(180,1100);y=rand(205,250);}else if(side===1){x=rand(150,1130);y=rand(575,620);}else if(side===2){x=rand(105,155);y=rand(250,565);}else{x=rand(1125,1180);y=rand(250,565);}return spawnEnemy(kind,x,y,false,elite);}
function spawnEncounterWave(){const wave=game.waveQueue[game.waveIndex];if(!wave)return;game.waveIndex++;for(const foe of wave)spawnAtEdge(foe.kind,foe.elite);game.waveDelay=0;game.roomCleared=false;$('waveHud').style.display='block';$('waveCurrent').textContent='WAVE '+game.waveIndex+' / '+game.waveQueue.length;$('waveHostiles').textContent=game.enemies.length+' HOSTILES';$('waveFill').style.width=(game.waveIndex/game.waveQueue.length*100)+'%';$('objectiveLabel').textContent='WAVE '+game.waveIndex+'/'+game.waveQueue.length+' · '+game.enemies.length+' HOSTILES';for(const e of game.enemies)addCombatFX('spawnRift',e.x,e.y,{life:.58,radius:e.elite?58:46,color:e.elite?'#f6cb79':realms[game.stage].palette.glow});showToast(game.waveIndex===1?'SCOUTS · ENGAGE':'REINFORCEMENTS · WAVE '+game.waveIndex,1.35);}
function loadEncounter(){
  const p=realms[game.stage];game.enemies=[];game.projectiles=[];game.particles=[];game.pickups=[];game.floaters=[];game.combatFX=[];game.afterimages=[];game.hitStop=0;game.impactFlash=0;game.portal=null;game.boss=null;game.roomCleared=false;game.waveQueue=[];game.waveIndex=0;game.waveDelay=0;game.roomTime=0;game.roomKills=0;player.x=445;player.y=515;player.vx=player.vy=0;player.combo=0;player.comboTimer=0;player.attackTime=0;player.specialTime=0;player.jumpActive=false;player.jumpZ=0;player.jumpVy=0;player.landTime=0;player.invuln=.65;
  buildBackground();
  player.elevation=0;player.attackMove=null;player.attackKind='light';player.heavyCharging=false;player.chargeTime=0;game.chamberLayout=getChamberLayout(game.stage,game.room);
  game.plants=(game.chamberLayout.plants||[]).map((plant,index)=>({...plant,r:18,active:true,phase:index*.9,secret:game.room===2&&index===0}));
  const isBoss=isBossRoom();$('waveHud').style.display=isBoss?'none':'block';
  if(isBoss){if($('bossName'))$('bossName').textContent=game.stage===3?'THE STARFALL REGENT':game.stage===2?'THE HOLLOW CROWN':game.stage===1?'THE ASHEN COLOSSUS':'THE ROOTBOUND WARDEN';spawnEnemy('boss',800,320,true);const minions=game.stage===3?4:game.stage===2?3:2;for(let i=0;i<minions;i++)spawnAtEdge(i%2?'wisp':'stalker');$('bossHud').style.display='block';$('objectiveLabel').textContent='DEFEAT THE WARDEN';}else{game.waveQueue=getEncounterWaves(game.stage,game.room,game.riskMode);$('bossHud').style.display='none';spawnEncounterWave();}
  $('locationLabel').textContent=p.name;$('roomLabel').textContent=p.roomNames[game.room];$('chapterPill').textContent=`CHAPTER ${['I','II','III','IV'][game.stage]} · ${p.name}`;$('realmTag').textContent=p.tag;$('realmTitle').textContent=p.title;$('realmDesc').textContent=p.desc;$('objectiveTitle').textContent=p.objective;$('objectiveCopy').textContent=isBoss?'Break the guardian. The ember gate will carry you onward.':'Defeat every guardian in this chamber. Reach the glowing gate when it opens.';
  $('realmArt').dataset.stage=game.stage;$('progressSteps').innerHTML=Array.from({length:p.roomNames.length},(_,i)=>`<span class="step ${i===game.room?'active':i<game.room?'done':''}"></span>`).join('');$('objectiveChecks').innerHTML=Array.from({length:p.roomNames.length},(_,i)=>`<span class="check-dot ${i===game.room?'active':i<game.room?'done':''}"></span>`).join('');$('objectiveTitle').textContent=`Chamber ${game.room+1} of ${p.roomNames.length}`;
  $('bottomHint').textContent=isBoss?'THE GUARDIAN STANDS BETWEEN YOU AND THE NEXT REALM':'DEFEAT THE GUARDIANS TO OPEN THE WAY';updateUI();
}
function openPortal(){
  if(game.roomCleared)return;game.roomCleared=true;game.waveDelay=0;$('waveHud').style.display='none';$('bossHud').style.display='none';game.portal={x:640,y:176,r:48,pulse:0};$('objectiveLabel').textContent='GATE OPEN · APPROACH';$('bottomHint').textContent='APPROACH THE EMBER GATE AND PRESS E';$('interactionHint').style.display='flex';
  showToast(isBossRoom()?'THE GUARDIAN HAS FALLEN':'THE CHAMBER IS CLEARED',2);sound('portal');
  for(let i=0;i<34;i++)particle(640,151,choice(['#f0cf93','#9fcca1','#d49c68']),rand(1,4),rand(-2,2),rand(-3,-.2),rand(.5,1.6));
  player.hp=Math.min(player.maxHp,player.hp+Math.max(5,player.maxHp*.07));player.gold+=12+game.stage*7;persistCurrent();updateUI();
}
function persistCurrent(){meta.current=snapshotRun();persist();}
function interactPortal(){if(!game.portal||dist(player,game.portal)>105)return;sound('portal');game.pendingTransition=isBossRoom()&&game.stage===3?'victory':'next';openReward();}
function openReward(){
  game.rewardOptions=[];const candidates=[...relicPool];while(game.rewardOptions.length<3&&candidates.length){const i=Math.floor(Math.random()*candidates.length);game.rewardOptions.push(candidates.splice(i,1)[0]);}
  const cards=$('rewardCards');cards.innerHTML='';for(const relic of game.rewardOptions){const el=document.createElement('button');el.className='reward-card';el.innerHTML=`<span class="reward-icon">${relic.icon}</span><b>${relic.name}</b><p>${relic.desc}</p><span class="reward-rarity">${relic.rarity}</span>`;el.addEventListener('click',()=>chooseReward(relic));cards.appendChild(el);}
  $('rewardIntro').textContent=isBossRoom()?'The guardian’s core yields a fragment of its power.':'A quiet ember rises from the chamber floor.';setPhase('reward');
}
function chooseReward(relic){
  relic.apply();runRelics.push(relic);if(runRelics.length>6)runRelics.shift();sound('reward');
  if(game.pendingTransition==='victory'){finishRun(true);return;}
  if(isBossRoom()){game.stage++;game.room=0;}else game.room++;
  game.pendingTransition=null;loadEncounter();persistCurrent();setPhase('playing');showToast(`${relic.name.toUpperCase()} · BLESSING CLAIMED`,1.8);updateUI();
}
function finishRun(won){
  const time=player.runTime;const secs=Math.floor(time),minutes=Math.floor(secs/60),rest=secs%60;const pretty=`${String(minutes).padStart(2,'0')}:${String(rest).padStart(2,'0')}`;
  const rank=getStyleRank(game.styleScore);$('endSymbol').textContent=won?'✧':'✕';$('endKicker').textContent=won?'THE LIGHT ENDURES':'THE EMBERS FADE';$('endTitle').textContent=won?'The Hollow Crown is broken.':'The dark takes the path.';$('endCopy').textContent=won?'Four realms breathe again. Somewhere, a new hearth is kindled.':'Lyra falls, but the old fire remembers. Rise again and finish what you began.';
  $('runResults').innerHTML=`<div><b>${pretty}</b><small>TIME</small></div><div><b>${player.kills}</b><small>GUARDIANS</small></div><div><b>${player.level}</b><small>LEVEL</small></div><div><b>${player.gold}</b><small>SHARDS</small></div><div><b class="style-rank">${rank}</b><small>STYLE RANK</small></div>`;
  if(won){if(!meta.bestTime||time<meta.bestTime)meta.bestTime=time;meta.bestKills=Math.max(meta.bestKills,player.kills);const rankOrder=['D','C','B','A','S'];if(rankOrder.indexOf(rank)>rankOrder.indexOf(meta.bestRank))meta.bestRank=rank;meta.bestSecrets=Math.max(meta.bestSecrets,game.secretFound);meta.current=null;}else{meta.current=null;}persist();$('continueBtn').disabled=!meta.current;$('continueMeta').textContent=meta.current?'SAVE FOUND':'— NO SAVE —';setPhase(won?'victory':'defeat');sound(won?'victory':'defeat');
}

function particle(x,y,color,size,vx,vy,life=0.6){game.particles.push({x,y,color,size,vx,vy,life,max:life,drag:.94});}
function burst(x,y,color,count=12,scale=1){for(let i=0;i<count;i++){const a=rand(0,TAU),s=rand(40,240)*scale;particle(x,y,color,rand(1.5,4)*scale,Math.cos(a)*s,Math.sin(a)*s,rand(.25,.8));}}
function addCombatFX(type,x,y,options={}){const life=options.life??.34;game.combatFX.push({type,x,y,life,max:life,...options});}
function floater(x,y,text,color='#ffe2a4',size=15){game.floaters.push({x,y,text,color,size,life:.8,max:.8,vy:-36});}
function dropLoot(e){game.pickups.push({x:e.x+rand(-11,11),y:e.y+rand(-11,11),kind:'xp',value:e.boss?e.xp:e.xp*.7,life:16,phase:rand(0,TAU)});if(Math.random()<.48||e.boss||e.elite)game.pickups.push({x:e.x+rand(-17,17),y:e.y+rand(-17,17),kind:'gold',value:e.boss?28:e.elite?14+Math.floor(rand(0,8)):4+Math.floor(rand(0,5)),life:15,phase:rand(0,TAU)});}
function killEnemy(e){const i=game.enemies.indexOf(e);if(i<0)return;game.enemies.splice(i,1);if(e===game.boss)game.boss=null;player.kills++;game.roomKills++;dropLoot(e);addCombatFX('deathBurst',e.x,e.y,{life:.48,radius:e.boss?112:54,color:e.boss?'#f5cf8a':realms[game.stage].palette.glow});burst(e.x,e.y,e.boss?'#f0c27e':realms[game.stage].palette.glow,e.boss?54:24,e.boss?2.1:1.2);floater(e.x,e.y-18,e.boss?'WARDEN BROKEN':'+'+Math.round(e.xp)+' XP','#e8d59f',e.boss?18:12);game.shake=Math.max(game.shake,e.boss?11:4);sound('kill');if(e.elite){addCombatFX('eliteDeath',e.x,e.y,{life:.62,radius:98,color:'#f4c875'});game.shake=Math.max(game.shake,7);game.cameraZoom=Math.max(game.cameraZoom,.025);floater(e.x,e.y-34,'ELITE BROKEN · BONUS SHARDS','#ffe0a0',16);}if(game.enemies.length===0){if(game.waveIndex<game.waveQueue.length){game.waveDelay=2.15;$('waveCurrent').textContent='WAVE '+(game.waveIndex+1)+' / '+game.waveQueue.length;$('waveHostiles').textContent='REINFORCEMENTS INCOMING';$('waveFill').style.width=(game.waveIndex/game.waveQueue.length*100)+'%';showToast('WAVE CLEARED · HOLD THE LINE',1.45);}else openPortal();}updateUI();}
function damageEnemy(e,amount,crit=false,sourceX=player.x,sourceY=player.y,combo=1){if(e.hp<=0)return;e.hp-=amount;e.flash=.19;e.stateT=Math.max(e.stateT||0,0);const a=Math.atan2(e.y-sourceY,e.x-sourceX);const force=(e.boss?52:e.kind==='brute'?145:190)*(combo>=3?1.35:1)*(crit?1.18:1);e.knockVX+=Math.cos(a)*force;e.knockVY+=Math.sin(a)*force;e.hitStun=Math.max(e.hitStun||0,e.boss?.11:combo>=3?.26:.21);game.impactFlash=Math.max(game.impactFlash,crit?.62:.22);const color=crit?'#fff0a3':'#f5d5a0';floater(e.x+rand(-12,12),e.y-e.r,Math.round(amount),crit?'#fff1a5':'#e7d4ae',crit?18:14);addCombatFX('impact',e.x,e.y,{life:crit?.34:.25,angle:a,crit,color});if(e.elite)addCombatFX('eliteHit',e.x,e.y,{life:.25,angle:a,color:'#f8d48b'});game.hitStop=Math.max(game.hitStop,crit?.085:.052);game.shake=Math.max(game.shake,crit?7:3.8);for(let i=0;i<(crit?16:9);i++){const spread=a+rand(-1.15,1.15),speed=rand(90,310)*(crit?1.25:1);particle(e.x,e.y,choice(crit?['#fff2b0','#f2c875','#fff8df']:['#e9d3a4','#c3aa7b','#f7e4bd']),rand(1.6,3.5),Math.cos(spread)*speed,Math.sin(spread)*speed,rand(.18,.42));}if(e.hp<=0)killEnemy(e);}
function damagePlayer(amount,sourceX,sourceY){
  if(game.phase!=='playing')return;
  if(player.perfectDodgeWindow>0){resolvePerfectDodge(sourceX,sourceY);return;}
  if(player.invuln>0)return;
  player.hp-=amount;player.invuln=.72;player.hurtTime=.25;game.dodgeStreak=0;game.styleScore=Math.max(0,game.styleScore-12);game.hitStop=Math.max(game.hitStop,.045);game.impactFlash=Math.max(game.impactFlash,.42);game.shake=14;sound('hurt');burst(player.x,player.y,'#e88769',20,.85);floater(player.x,player.y-27,'-'+Math.round(amount),'#f08e75',18);
  if(sourceX!==undefined){const a=Math.atan2(player.y-sourceY,player.x-sourceX);player.hurtAngle=a;player.vx+=Math.cos(a)*190;player.vy+=Math.sin(a)*190;addCombatFX('impact',player.x,player.y,{life:.28,angle:a,color:'#ff9b85',crit:true});}
  if(player.hp<=0){player.hp=0;updateUI();finishRun(false);}updateUI();
}
function resolvePerfectDodge(sourceX,sourceY){
  player.perfectDodgeWindow=0;player.perfectDodgeTime=.62;player.invuln=Math.max(player.invuln,.28);game.dodgeStreak=Math.min(5,game.dodgeStreak+1);game.styleScore+=125;game.cameraZoom=Math.max(game.cameraZoom,.035);game.hitStop=Math.max(game.hitStop,.035);game.shake=Math.max(game.shake,5);sound('parry');
  const attacker=game.enemies.filter(e=>e.hp>0).sort((a,b)=>Math.hypot(a.x-player.x,a.y-player.y)-Math.hypot(b.x-player.x,b.y-player.y))[0];
  if(attacker&&Math.hypot(attacker.x-player.x,attacker.y-player.y)<220){const a=Math.atan2(attacker.y-player.y,attacker.x-player.x);damageEnemy(attacker,34*(1+player.damageBonus),true,player.x,player.y,4);attacker.hitStun=Math.max(attacker.hitStun||0,.32);addCombatFX('parryCounter',player.x+Math.cos(a)*34,player.y+Math.sin(a)*34,{life:.42,angle:a,color:'#c9f4dc'});}
  else addCombatFX('parryCounter',player.x,player.y,{life:.42,angle:player.attackAngle,color:'#c9f4dc'});
  burst(player.x,player.y,'#c9f4dc',23,1.05);floater(player.x,player.y-44,'PERFECT DODGE','#d9ffe8',17);showToast('PERFECT DODGE · COUNTER',.85);updateUI();
}
function startAirAttack(kind='light'){
  if(game.phase!=='playing'||player.attackTime>0||player.attackCd>0)return;
  const move=AIR_MOVES[kind];if(!move)return;player.attackKind=kind==='slam'?'airSlam':'airLight';player.attackMove=move;player.combo=kind==='slam'?4:3;player.comboTimer=.9;player.attackDuration=move.duration;player.attackTime=move.duration;player.attackApplied=false;player.attackCd=move.cooldown;player.attackPower=1;game.styleScore+=kind==='slam'?85:45;sound(kind==='slam'?'heavy':'slash3');
}
function beginHeavyCharge(){
  if(game.phase!=='playing'||player.heavyCharging||player.attackCd>0||player.attackTime>0||player.dashTime>0)return;
  if(player.jumpActive||player.jumpZ>12){startAirAttack('slam');return;}
  player.heavyCharging=true;player.chargeTime=0;player.attackKind='heavyCharge';addCombatFX('chargeAura',player.x,player.y,{life:1.25,color:'#ffc978'});sound('charge');
}
function releaseHeavyCharge(){
  if(!player.heavyCharging)return;const charge=clamp(player.chargeTime/1.15,0,1);player.heavyCharging=false;player.chargeTime=0;
  player.attackKind='heavy';player.attackMove=HEAVY_MOVE;player.attackPower=1+charge*HEAVY_MOVE.chargeDamage;player.combo=4;player.comboTimer=1;player.attackDuration=HEAVY_MOVE.duration;player.attackTime=HEAVY_MOVE.duration;player.attackApplied=false;player.attackCd=HEAVY_MOVE.cooldown*(1-charge*.18);game.styleScore+=Math.round(70+charge*80);game.cameraZoom=Math.max(game.cameraZoom,.022+charge*.025);sound('heavy');showToast(charge>.72?'SUNBREAKER · FULL CHARGE':'SUNBREAKER',.65);
}
function resolvePlayerAttack(){
  const move=player.attackMove||LIGHT_CHAIN[Math.max(0,player.combo-1)]||LIGHT_CHAIN[0];
  const kind=player.attackKind;const heavy=kind==='heavy',air=kind==='airLight'||kind==='airSlam';
  const range=move.range*(heavy?1+player.attackPower*.10:1),arc=move.arc;
  const damageScale=heavy?(move.baseDamage+(player.attackPower-1)*move.chargeDamage)*(1+(player.heavyBonus||0)):air?move.damage*(1+(player.airBonus||0)):move.damage;
  const hits=[];
  for(const e of [...game.enemies]){
    if(e.hp<=0||Math.abs((e.elevation||0)-(player.elevation||0))>78)continue;
    const d=Math.hypot(e.x-player.x,e.y-player.y);if(d>range+e.r)continue;
    const a=Math.atan2(e.y-player.y,e.x-player.x);const diff=Math.atan2(Math.sin(a-player.attackAngle),Math.cos(a-player.attackAngle));
    if(Math.abs(diff)>arc)continue;
    const crit=heavy?Math.random()<Math.min(.55,.16+player.critBonus):Math.random()<player.critBonus;
    const amount=player.damage*(1+player.damageBonus)*damageScale*(crit?2.05:1)*(kind==='airSlam'&&player.jumpZ<36?1.18:1);
    damageEnemy(e,amount,crit,player.x,player.y,player.combo);const force=move.knockback||move.baseKnockback||34;e.knockVX+=Math.cos(a)*force;e.knockVY+=Math.sin(a)*force;
    if(kind==='airSlam'||heavy)e.hitStun=Math.max(e.hitStun||0,heavy?.24:.28);e.x+=Math.cos(a)*(kind==='airSlam'?42:heavy?34:move.lunge||18);e.y+=Math.sin(a)*(kind==='airSlam'?42:heavy?34:move.lunge||18);hits.push(e);
  }
  triggerPlantsInArc(range,arc);
  const color=heavy||kind==='airSlam'?'#ffd18c':kind==='airLight'?'#bcebe9':player.combo===4?'#fff0a3':'#f1d7a0';
  player.attackLunge=heavy?24:kind==='airSlam'?12:(move.lunge||10);player.x=clamp(player.x+Math.cos(player.attackAngle)*player.attackLunge,85,1195);player.y=clamp(player.y+Math.sin(player.attackAngle)*player.attackLunge,100,632);
  addCombatFX(kind==='airSlam'?'airSlam':heavy?'heavySlash':'slash',player.x,player.y,{life:(heavy||kind==='airSlam') ? .48 : .34,angle:player.attackAngle,combo:player.combo,color,charge:player.attackPower||1});
  if(hits.length){game.styleScore+=hits.length*(heavy?65:kind==='airSlam'?72:25);if(hits.length>=3)showToast('CROWD CONTROL · '+hits.length+' HITS',.7);addCombatFX('impactGround',player.x+Math.cos(player.attackAngle)*64,player.y+Math.sin(player.attackAngle)*64,{life:.24,color});}
  const sparks=heavy||kind==='airSlam'?28:player.combo===4?24:14;for(let i=0;i<sparks;i++){const a=player.attackAngle+rand(-arc,arc),speed=rand(110,340);particle(player.x+Math.cos(a)*48,player.y+Math.sin(a)*48,color,rand(1.4,3.4),Math.cos(a)*speed,Math.sin(a)*speed,.38);}
  if(heavy||kind==='airSlam'){game.hitStop=Math.max(game.hitStop,move.hitstop||.09);game.shake=Math.max(game.shake,heavy?8:9);game.cameraZoom=Math.max(game.cameraZoom,.04);}
}
function triggerPlantsInArc(range,arc){
  for(const plant of game.plants){if(!plant.active)continue;const d=Math.hypot(plant.x-player.x,plant.y-player.y);if(d>range+plant.r)continue;const a=Math.atan2(plant.y-player.y,plant.x-player.x),diff=Math.atan2(Math.sin(a-player.attackAngle),Math.cos(a-player.attackAngle));if(Math.abs(diff)>arc)continue;
    plant.active=false;game.styleScore+=plant.secret?180:35;
    if(plant.kind==='volatile'){
      addCombatFX('plantExplosion',plant.x,plant.y,{life:.52,radius:128,color:realms[game.stage].palette.glow});burst(plant.x,plant.y,realms[game.stage].palette.glow,34,1.6);game.shake=Math.max(game.shake,6);
      for(const e of [...game.enemies])if(Math.hypot(e.x-plant.x,e.y-plant.y)<128+e.r)damageEnemy(e,58*(1+player.solarBonus*.2),true,plant.x,plant.y,4);
      showToast('BLIGHT BLOOM · DETONATED',.7);
    }else{player.hp=Math.min(player.maxHp,player.hp+28);floater(player.x,player.y-35,'+28 HEART','#b8e0aa',16);burst(plant.x,plant.y,'#b8e0aa',22,.9);showToast('HEARTHBLOOM · RESTORED',.7);}
    if(plant.secret){game.secretFound++;player.gold+=24;player.hp=Math.min(player.maxHp,player.hp+18);floater(plant.x,plant.y-35,'HIDDEN CACHE +24','#f6d891',16);showToast('ROOT CACHE DISCOVERED',1.1);}
  }
  updateUI();
}
function grabThrow(){
  if(game.phase!=='playing'||game.grabCooldown>0)return;const target=game.enemies.filter(e=>!e.boss&&Math.hypot(e.x-player.x,e.y-player.y)<92).sort((a,b)=>Math.hypot(a.x-player.x,a.y-player.y)-Math.hypot(b.x-player.x,b.y-player.y))[0];
  if(!target){showToast('NO TARGET IN GRAB RANGE',.55);return;}const a=Math.atan2(target.y-player.y,target.x-player.x);target.x=clamp(player.x+Math.cos(a)*138,85,1195);target.y=clamp(player.y+Math.sin(a)*138,100,632);target.hitStun=.62;damageEnemy(target,player.damage*(1+player.damageBonus)*1.45,true,player.x,player.y,4);target.knockVX=Math.cos(a)*330;target.knockVY=Math.sin(a)*330;game.grabCooldown=.95;game.styleScore+=95;game.shake=Math.max(game.shake,5);addCombatFX('throwImpact',target.x,target.y,{life:.42,angle:a,color:'#f5d49b'});for(const e of [...game.enemies])if(e!==target&&Math.hypot(e.x-target.x,e.y-target.y)<58)damageEnemy(e,player.damage*.7,false,target.x,target.y,3);showToast('EMBER THROW',.65);sound('heavy');
}


function aimAtPointer(){if(input.pointer.inside){const w=unprojectPoint(input.pointer.x,input.pointer.y);player.attackAngle=Math.atan2(w.y-player.y,w.x-player.x);}}
function nearestAngle(){let nearest=null,best=Infinity;for(const e of game.enemies){const d=dist(player,e);if(d<best){best=d;nearest=e;}}if(nearest)player.attackAngle=Math.atan2(nearest.y-player.y,nearest.x-player.x);}
function startAttack(){if(game.phase!=='playing'||player.attackCd>0||player.attackTime>0||player.dashTime>0||player.heavyCharging)return;if(player.jumpActive||player.jumpZ>20){startAirAttack('light');return;}aimAtPointer();if(!input.pointer.inside)nearestAngle();player.combo=nextChainIndex(player.combo,player.comboTimer);player.attackMove=LIGHT_CHAIN[player.combo-1];player.attackKind='light';player.comboTimer=1.02;player.attackDuration=Math.max(.28,player.attackMove.duration-(player.attackHaste||0)*.12);player.attackTime=player.attackDuration;player.attackApplied=false;player.attackLunge=0;player.attackCd=Math.max(.22,player.attackMove.cooldown-(player.attackHaste||0)*.16);game.styleScore+=12;sound(player.combo===4?'slash4':player.combo===3?'slash3':player.combo===2?'slash2':'slash');}
function useDash(){if(game.phase!=='playing'||player.dashCd>0||player.jumpActive)return;if(player.heavyCharging){player.heavyCharging=false;player.chargeTime=0;showToast('CHARGE CANCELLED · DODGE',.5);}let dx=(input.keys.has('d')||input.keys.has('arrowright')?1:0)-(input.keys.has('a')||input.keys.has('arrowleft')?1:0)+input.joy.x;let dy=(input.keys.has('s')||input.keys.has('arrowdown')?1:0)-(input.keys.has('w')||input.keys.has('arrowup')?1:0)+input.joy.y;let l=Math.hypot(dx,dy);if(l<.1){dx=Math.cos(player.attackAngle);dy=Math.sin(player.attackAngle);l=1;}dx/=l;dy/=l;player.dashVX=dx*690;player.dashVY=dy*690;if(Math.abs(dx)>.12)player.facingSign=dx>=0?1:-1;player.dashTime=.22;player.invuln=.38;player.perfectDodgeWindow=.16;player.dashCd=Math.max(.72,1.25-player.dodgeBonus*.75);game.dodgeStreak=Math.min(5,game.dodgeStreak+1);addCombatFX('dashBurst',player.x,player.y,{life:.26,angle:Math.atan2(dy,dx),color:'#c9f3df'});game.shake=Math.max(game.shake,2);sound('dash');burst(player.x,player.y,'#c9f3df',20,.85);}
function useJump(){
  if(game.phase!=='playing'||player.jumpCd>0||player.jumpActive||player.dashTime>0)return;
  let dx=(input.keys.has('d')||input.keys.has('arrowright')?1:0)-(input.keys.has('a')||input.keys.has('arrowleft')?1:0)+input.joy.x;
  let dy=(input.keys.has('s')||input.keys.has('arrowdown')?1:0)-(input.keys.has('w')||input.keys.has('arrowup')?1:0)+input.joy.y;
  let l=Math.hypot(dx,dy);
  if(l<.1){dx=Math.cos(player.attackAngle);dy=Math.sin(player.attackAngle);l=1;}
  dx/=l;dy/=l;
  player.jumpActive=true;game.styleScore+=8;if(Math.abs(dx)>.12)player.facingSign=dx>=0?1:-1;player.jumpZ=0;player.jumpVy=575;player.jumpVX=dx*315;player.jumpVY=dy*315;player.jumpCd=.95;player.invuln=Math.max(player.invuln,.68);player.landTime=0;
  player.facingAngle=angleLerp(player.facingAngle,Math.atan2(dy,dx)+Math.PI/2,.8);
  addCombatFX('jumpTakeoff',player.x,player.y,{life:.24,angle:Math.atan2(dy,dx),color:'#c8f4e7'});
  for(let i=0;i<12;i++)particle(player.x+rand(-12,12),player.y+rand(-6,7),'#d8e9b9',rand(1.5,3.2),rand(-75,75),rand(-35,35),rand(.18,.35));
  sound('jump');
}
function cycleSolarMode(){game.solarMode=(game.solarMode+1)%SOLAR_MODES.length;const mode=currentSolarMode();showToast(`SOLAR ASPECT · ${mode.name} · ${mode.hint}`,1.05);}
function useSpecial(){
  if(game.phase!=='playing'||player.specialCd>0)return;const mode=currentSolarMode(),dmg=38*(1+player.solarBonus)*mode.damage;player.specialCd=Math.max(3.8,mode.cooldown-player.solarBonus*1.7);player.specialTime=.72;game.styleScore+=60;game.cameraZoom=Math.max(game.cameraZoom,.045);game.shake=Math.max(game.shake,mode.id==='rupture'?19:15);sound('solar');
  if(mode.id==='nova'){
    const radius=178*(1+player.solarBonus*.35);addCombatFX('solarBurst',player.x,player.y,{life:.72,radius,color:'#ffe7a6'});burst(player.x,player.y,'#ffe4a5',76,1.8);
    for(const e of [...game.enemies]){const d=dist(player,e);if(d<radius+e.r){damageEnemy(e,dmg*(1-d/(radius*2)),true,player.x,player.y,4);const a=Math.atan2(e.y-player.y,e.x-player.x);e.x+=Math.cos(a)*34;e.y+=Math.sin(a)*34;}}
  }else if(mode.id==='lance'){
    addCombatFX('solarLance',player.x,player.y,{life:.55,angle:player.attackAngle,length:560,color:'#fff0b1'});burst(player.x+Math.cos(player.attackAngle)*50,player.y+Math.sin(player.attackAngle)*50,'#fff0b1',32,1.2);
    for(const e of [...game.enemies]){const dx=e.x-player.x,dy=e.y-player.y,along=dx*Math.cos(player.attackAngle)+dy*Math.sin(player.attackAngle),side=Math.abs(-dx*Math.sin(player.attackAngle)+dy*Math.cos(player.attackAngle));if(along>0&&along<560&&side<48+e.r)damageEnemy(e,dmg,true,player.x,player.y,4);}
  }else{
    addCombatFX('solarRupture',player.x,player.y,{life:.68,radius:245,color:'#ffbd76'});burst(player.x,player.y,'#ffc078',58,1.55);
    for(const e of [...game.enemies]){const d=dist(player,e);if(d<245+e.r){damageEnemy(e,dmg*(1-d/360),true,player.x,player.y,4);e.hitStun=Math.max(e.hitStun||0,.42);}}
  }
  showToast(`SOLAR ${mode.name}`,1.0);
}
function movementVector(){let dx=(input.keys.has('d')||input.keys.has('arrowright')?1:0)-(input.keys.has('a')||input.keys.has('arrowleft')?1:0)+input.joy.x;let dy=(input.keys.has('s')||input.keys.has('arrowdown')?1:0)-(input.keys.has('w')||input.keys.has('arrowup')?1:0)+input.joy.y;let len=Math.hypot(dx,dy);if(len<.12){dx=Math.cos(player.attackAngle);dy=Math.sin(player.attackAngle);len=1;}return {x:dx/len,y:dy/len};}
function useRiftStep(){
  if(game.phase!=='playing'||player.riftCd>0||player.jumpActive||player.dashTime>0||player.heavyCharging)return;
  const dir=movementVector(),sx=player.x,sy=player.y,travel=220,ex=clamp(sx+dir.x*travel,85,1195),ey=clamp(sy+dir.y*travel,198,630);
  for(let i=0;i<10;i++){const t=i/10;game.afterimages.push({x:lerp(sx,ex,t),y:lerp(sy,ey,t),elevation:player.elevation||0,angle:player.facingAngle,life:.42,max:.42,phase:player.animTime});}
  addCombatFX('riftStep',sx,sy,{life:.52,radius:74,color:'#91eaff'});addCombatFX('riftStep',ex,ey,{life:.68,radius:96,color:'#b9a7ff'});
  player.x=ex;player.y=ey;player.vx=dir.x*165;player.vy=dir.y*165;player.facingSign=dir.x<-.12?-1:dir.x>.12?1:player.facingSign;player.facingAngle=Math.atan2(dir.y,dir.x)+Math.PI/2;player.invuln=Math.max(player.invuln,.58);player.riftCd=9.5;game.styleScore+=120;game.shake=Math.max(game.shake,5.5);game.cameraZoom=Math.max(game.cameraZoom,.04);sound('dash');
  let pierced=0;for(const e of [...game.enemies]){const vx=ex-sx,vy=ey-sy,wx=e.x-sx,wy=e.y-sy,t=clamp((wx*vx+wy*vy)/(vx*vx+vy*vy),0,1),px=sx+t*vx,py=sy+t*vy;if(Math.hypot(e.x-px,e.y-py)<49+e.r){damageEnemy(e,player.damage*(1+player.damageBonus)*1.65,true,sx,sy,4);e.hitStun=Math.max(e.hitStun||0,.48);e.knockVX+=dir.x*205;e.knockVY+=dir.y*205;pierced++;}}
  burst(sx,sy,'#91eaff',22,1.0);burst(ex,ey,'#b9a7ff',36,1.35);floater(ex,ey-27,pierced?'RIFT STEP · '+pierced+' PIERCED':'RIFT STEP','#c6f1ff',16);showToast('RIFT STEP · PHASE THROUGH THE ENEMY LINE',1.0);updateUI();
}
function useAetherSnare(){
  if(game.phase!=='playing'||player.aetherCd>0||player.heavyCharging)return;
  const dir=movementVector(),cx=clamp(player.x+dir.x*88,90,1190),cy=clamp(player.y+dir.y*88,205,625),radius=205;player.aetherCd=15;game.styleScore+=75;game.shake=Math.max(game.shake,6);game.cameraZoom=Math.max(game.cameraZoom,.035);sound('solar');addCombatFX('aetherSnare',cx,cy,{life:1.05,radius,color:'#9fdcff'});
  let caught=0;for(const e of [...game.enemies]){const d=Math.hypot(e.x-cx,e.y-cy);if(d>radius+e.r)continue;const pull=e.boss?.34:.58;e.x=lerp(e.x,cx,pull);e.y=lerp(e.y,cy,pull);e.rootX=cx;e.rootY=cy;e.rootedTime=Math.max(e.rootedTime||0,e.boss?.5:1.05);e.attackCd=Math.max(e.attackCd,.8);damageEnemy(e,player.damage*(e.boss?1.05:1.38),false,cx,cy,4);e.rootX=cx;e.rootY=cy;e.rootedTime=Math.max(e.rootedTime||0,e.boss?.5:1.05);e.knockVX*=.18;e.knockVY*=.18;caught++;}
  burst(cx,cy,'#9fdcff',caught?36:20,1.25);floater(cx,cy-38,caught?'AETHER SNARE · '+caught+' BOUND':'AETHER SNARE','#c9edff',17);showToast('AETHER SNARE · GATHER AND ROOT HOSTILES',1.05);updateUI();
}
function interact(){if(game.phase==='playing')interactPortal();}

function updatePlayer(dt){
  player.attackCd=Math.max(0,player.attackCd-dt);player.attackTime=Math.max(0,player.attackTime-dt);player.hurtTime=Math.max(0,player.hurtTime-dt);player.comboTimer=Math.max(0,player.comboTimer-dt);player.dashCd=Math.max(0,player.dashCd-dt);player.jumpCd=Math.max(0,player.jumpCd-dt);player.landTime=Math.max(0,player.landTime-dt);player.animTime+=dt;player.specialCd=Math.max(0,player.specialCd-dt);player.riftCd=Math.max(0,player.riftCd-dt);player.aetherCd=Math.max(0,player.aetherCd-dt);player.specialTime=Math.max(0,player.specialTime-dt);player.invuln=Math.max(0,player.invuln-dt);player.perfectDodgeWindow=Math.max(0,player.perfectDodgeWindow-dt);player.perfectDodgeTime=Math.max(0,player.perfectDodgeTime-dt);game.grabCooldown=Math.max(0,game.grabCooldown-dt);game.solarModeCooldown=Math.max(0,game.solarModeCooldown-dt);
  if(player.heavyCharging){player.chargeTime=Math.min(1.15,player.chargeTime+dt);player.vx*=Math.pow(.32,dt);player.vy*=Math.pow(.32,dt);if(Math.random()<.65)particle(player.x+rand(-20,20),player.y+rand(-18,18),player.chargeTime>.7?'#fff0b0':'#e9b96d',rand(1.5,3.2),rand(-24,24),rand(-25,25),.28);}
  if(player.comboTimer===0&&player.attackTime===0)player.combo=0;
  if(player.regen>0&&player.hp>0)player.hp=Math.min(player.maxHp,player.hp+player.regen*dt);
  if(player.dashTime>0){
    player.dashTime-=dt;player.vx=player.dashVX;player.vy=player.dashVY;player.x+=player.vx*dt;player.y+=player.vy*dt;
    for(let i=0;i<2;i++)particle(player.x+rand(-12,12),player.y+rand(-12,12),'#c9f3df',rand(2,4),rand(-35,35),rand(-28,28),.28);
    if(Math.random()<.72)game.afterimages.push({x:player.x,y:player.y,elevation:player.elevation||0,angle:player.facingAngle,life:.23,max:.23,phase:player.animTime});
  }else if(player.jumpActive){
    player.x+=player.jumpVX*dt;player.y+=player.jumpVY*dt;player.jumpVX*=Math.pow(.22,dt);player.jumpVY*=Math.pow(.22,dt);player.vx=player.jumpVX;player.vy=player.jumpVY;
    player.jumpZ+=player.jumpVy*dt;player.jumpVy-=1680*dt;
    if(Math.random()<.38)particle(player.x+rand(-12,12),player.y+rand(8,17),'#d2e1b4',rand(1.3,2.7),rand(-22,22),rand(-15,12),.22);
    if(player.jumpZ<=0&&player.jumpVy<0){player.jumpZ=0;player.jumpVy=0;player.jumpActive=false;player.landTime=.22;game.shake=Math.max(game.shake,2.5);addCombatFX('landing',player.x,player.y,{life:.34,color:'#d7e5b7'});for(let i=0;i<16;i++){const a=rand(0,TAU),v=rand(28,125);particle(player.x,player.y,'#cbd9ae',rand(1.4,3),Math.cos(a)*v,Math.sin(a)*v*.45,.32);}}
  }else{
    let dx=(input.keys.has('d')||input.keys.has('arrowright')?1:0)-(input.keys.has('a')||input.keys.has('arrowleft')?1:0)+input.joy.x;
    let dy=(input.keys.has('s')||input.keys.has('arrowdown')?1:0)-(input.keys.has('w')||input.keys.has('arrowup')?1:0)+input.joy.y;
    const l=Math.hypot(dx,dy);if(l>1){dx/=l;dy/=l;}const chargeMove=player.heavyCharging ? .34 : 1;const targetX=dx*player.speed*chargeMove,targetY=dy*player.speed*chargeMove;const accel=1-Math.exp(-dt*12);
    player.vx=lerp(player.vx,targetX,accel);player.vy=lerp(player.vy,targetY,accel);
    if(Math.abs(dx)+Math.abs(dy)<.01){player.vx*=Math.pow(.03,dt);player.vy*=Math.pow(.03,dt);}
    player.x+=player.vx*dt;player.y+=player.vy*dt;
    const actualSpeed=Math.hypot(player.vx,player.vy);
    if(actualSpeed>100){player.stepTimer-=dt;if(player.stepTimer<=0){player.stepTimer=clamp(0.19-actualSpeed/1600,.075,.15);player.stepSide^=1;const side=player.stepSide?1:-1;const a=Math.atan2(player.vy,player.vx);const px=player.x-Math.cos(a)*8+Math.cos(a+Math.PI/2)*side*9;const py=player.y-Math.sin(a)*8+Math.sin(a+Math.PI/2)*side*9;for(let i=0;i<3;i++)particle(px,py,realms[game.stage].palette.accent,rand(1,2.5),rand(-18,18),rand(-15,12),.2);}}
  }
  const moveSpeed=Math.hypot(player.vx,player.vy);
  let faceTarget=player.facingAngle;
  if(player.attackTime>0||input.pointer.inside){faceTarget=player.attackAngle+Math.PI/2; if(Math.abs(Math.cos(player.attackAngle))>.12)player.facingSign=Math.cos(player.attackAngle)>=0?1:-1;}
  else if(moveSpeed>48){faceTarget=Math.atan2(player.vy,player.vx)+Math.PI/2; if(Math.abs(player.vx)>18)player.facingSign=player.vx>=0?1:-1;}
  player.facingAngle=angleLerp(player.facingAngle,faceTarget,1-Math.exp(-dt*13));
  player.x=clamp(player.x,85,1195);player.y=clamp(player.y,198,630);player.elevation=surfaceHeightAt(player.x,player.y,game.chamberLayout);
  if(player.attackTime>0&&!player.attackApplied){
    const progress=1-player.attackTime/player.attackDuration;
    const move=player.attackMove||LIGHT_CHAIN[Math.max(0,player.combo-1)]||LIGHT_CHAIN[0];
    if(progress>=(move.activeAt??.48)){player.attackApplied=true;resolvePlayerAttack();}
  }
  if(input.attackHeld&&player.attackCd<=0)startAttack();
}
function finishEnemyMotion(e,oldX,oldY,dt){
  const safeDt=Math.max(.001,dt);
  e.vx=(e.x-oldX)/safeDt;e.vy=(e.y-oldY)/safeDt;e.moveSpeed=Math.hypot(e.vx,e.vy);
  if(Math.abs(e.vx)>5)e.facingSign=e.vx>=0?1:-1;else e.facingSign=player.x>=e.x?1:-1;
  if(e.moveSpeed>24){
    e.stepTimer=(e.stepTimer??.2)-dt;
    if(e.stepTimer<=0){
      const heavy=e.kind==='brute'||e.kind==='boss';
      const backX=e.x-e.facingSign*rand(7,16),footY=e.y+rand(2,9);
      particle(backX,footY,game.stage===1?'#df9667':game.stage===2?'#a9b8e2':'#bdc99b',heavy?rand(2,4):rand(1.4,3),rand(-28,28)-e.vx*.035,rand(-28,-4),heavy?.32:.23);
      e.stepTimer=heavy?.31:.22;
    }
  }else e.stepTimer=Math.min(e.stepTimer??.2,.12);
}
function updateEnemy(e,dt){
  const oldX=e.x,oldY=e.y;
  const dx=player.x-e.x,dy=player.y-e.y,d=Math.max(1,Math.hypot(dx,dy)),nx=dx/d,ny=dy/d;
  e.attackCd-=dt;e.flash=Math.max(0,e.flash-dt);e.stateT=Math.max(0,e.stateT-dt);e.anim=(e.anim||0)+dt;
  if(e.hitStun>0){
    e.hitStun=Math.max(0,e.hitStun-dt);e.x+=e.knockVX*dt;e.y+=e.knockVY*dt;e.knockVX*=Math.pow(.035,dt);e.knockVY*=Math.pow(.035,dt);
    e.x=clamp(e.x,75,1205);e.y=clamp(e.y,85,645);e.elevation=surfaceHeightAt(e.x,e.y,game.chamberLayout);finishEnemyMotion(e,oldX,oldY,dt);return;
  }
  if(e.rootedTime>0){e.rootedTime=Math.max(0,e.rootedTime-dt);const pull=e.boss?Math.min(1,dt*2.7):Math.min(1,dt*7);e.x=lerp(e.x,e.rootX??e.x,pull);e.y=lerp(e.y,e.rootY??e.y,pull);e.x=clamp(e.x,75,1205);e.y=clamp(e.y,85,645);e.elevation=surfaceHeightAt(e.x,e.y,game.chamberLayout);finishEnemyMotion(e,oldX,oldY,dt);return;}
  if(e.kind==='boss'){
    const pct=e.hp/e.maxHp;e.phase=pct<.34?3:pct<.68?2:1;e.speed=66+(e.phase-1)*19;e.phaseFlash=Math.max(0,(e.phaseFlash||0)-dt);if(e.phase<e.lastPhase){const phase=e.phase;e.phaseFlash=.95;game.shake=Math.max(game.shake,10);game.cameraZoom=Math.max(game.cameraZoom,.055);game.hitStop=Math.max(game.hitStop,.10);addCombatFX('bossPhase',e.x,e.y,{life:.9,radius:phase===3?230:180,color:realms[game.stage].palette.glow,phase});burst(e.x,e.y,realms[game.stage].palette.glow,42,1.7);const count=phase===2?2:3;for(let i=0;i<count;i++){const kind=game.stage===3?(i===0?'shade':i===1?'archer':i===2?'wisp':'brute'):phase===2?(i===0?'archer':'stalker'):(i===0?'brute':i===1?'wisp':'stalker');spawnAtEdge(kind,phase===3&&i===0);}showToast(game.stage===3?(phase===2?'REGENT PHASE II · VOID SENTINELS':'REGENT FINAL PHASE · SKYFALL'):(phase===2?'WARDEN PHASE II · ROOTBOUND GUARD':'WARDEN FINAL PHASE · THE LAST HEARTH'),1.8);e.lastPhase=phase;}
    if(e.state==='windup'&&e.stateT<=0){
      if(e.attackPattern==='storm'){
        const count=e.phase===3?18:e.phase===2?14:10;for(let i=0;i<count;i++){const a=i/count*TAU;spawnProjectile(e.x,e.y,Math.cos(a)*185,Math.sin(a)*185,11,'#efaa75');}
        e.state='recover';e.stateT=.32;e.attackCd=e.phase===3?1.18:e.phase===2?1.5:2.1;e.attackPattern='';addCombatFX('enemySlam',e.x,e.y,{life:.42,color:'#f0ad7d',radius:150});
      }else if(e.attackPattern==='starfall'){
        const count=e.phase===3?11:7,aim=Math.atan2(e.aimY-e.y,e.aimX-e.x);for(let i=0;i<count;i++){const a=aim+(i-(count-1)/2)*.125;spawnProjectile(e.x,e.y,Math.cos(a)*300,Math.sin(a)*300,13,'#8de7ff');}e.state='recover';e.stateT=.44;e.attackCd=e.phase===3?1.25:1.8;e.attackPattern='';addCombatFX('bossPhase',e.x,e.y,{life:.54,radius:150,color:'#8de7ff'});burst(e.x,e.y,'#8de7ff',22,1.0);
      }else if(e.attackPattern==='rootsweep'){
        const aim=Math.atan2(e.aimY-e.y,e.aimX-e.x);for(let i=-1;i<=1;i++){const a=aim+i*.28;spawnProjectile(e.x,e.y,Math.cos(a)*250,Math.sin(a)*250,14,'#d5b777');}
        e.state='recover';e.stateT=.48;e.attackCd=1.22;e.attackPattern='';addCombatFX('enemySlam',e.x,e.y,{life:.48,color:'#d8bb83',radius:174});burst(e.x,e.y,'#d8bb83',30,1.35);
      }else{
        e.state='burst';e.stateT=.50;const ta=Math.atan2(e.aimY-e.y,e.aimX-e.x);e.chargeVX=Math.cos(ta)*390;e.chargeVY=Math.sin(ta)*390;e.attackApplied=false;addCombatFX('enemyCharge',e.x,e.y,{life:.28,angle:ta,color:'#f08d72'});burst(e.x,e.y,'#f09a70',24,1.1);
      }
    }else if(e.state==='burst'){
      e.x+=e.chargeVX*dt;e.y+=e.chargeVY*dt;e.chargeVX*=Math.pow(.12,dt);e.chargeVY*=Math.pow(.12,dt);
      if(!e.attackApplied&&Math.abs((player.elevation||0)-(e.elevation||0))<78&&Math.hypot(e.x-player.x,e.y-player.y)<e.r+player.r+24){damagePlayer(e.damage,e.x,e.y);e.attackApplied=true;addCombatFX('enemySlam',player.x,player.y,{life:.28,color:'#f0a078',radius:86});}
      if(e.stateT<=0){e.state='recover';e.stateT=.48;e.attackCd=e.phase===3?1.05:e.phase===2?1.35:1.9;addCombatFX('enemySlam',e.x,e.y,{life:.5,color:'#f0a078',radius:125});}
    }else if(e.state==='recover'){
      if(e.stateT<=0)e.state='idle';
    }else if(e.state==='idle'&&e.attackCd<=0){
      const pattern=Math.floor(rand(0,game.stage===3?4:e.phase===3?3:e.phase===2?3:2));e.state='windup';e.windupDuration=pattern===0?.96:pattern===2?.88:pattern===3?.72:.84;e.stateT=e.windupDuration;e.attackPattern=pattern===0?'charge':pattern===2?'rootsweep':pattern===3?'starfall':'storm';e.aimX=player.x+player.vx*(game.dodgeStreak>1?.24:.08);e.aimY=player.y+player.vy*(game.dodgeStreak>1?.24:.08);
      showToast(pattern===3?'REGENT · STARFALL VOLLEY':pattern===0?'WARDEN · ROOT CHARGE':pattern===2?'WARDEN · ROOT SWEEP':'WARDEN · SHARD STORM',.7);e.attackCd=e.phase===3?1.5:e.phase===2?1.75:2.6;
    }
    if(e.state==='idle'){e.x+=nx*e.speed*.66*dt;e.y+=ny*e.speed*.66*dt;}
    e.x=clamp(e.x,160,1120);e.y=clamp(e.y,130,590);e.elevation=surfaceHeightAt(e.x,e.y,game.chamberLayout);finishEnemyMotion(e,oldX,oldY,dt);return;
  }
  if(e.kind==='stalker'){
    if(e.state==='melee'){
      const p=1-clamp(e.stateT/.42,0,1),lunge=p<.48?Math.sin((p/.48)*Math.PI)*42:0;
      e.x+=nx*lunge*dt*4.1;e.y+=ny*lunge*dt*4.1;
      if(!e.attackApplied&&e.stateT<.17){if(Math.abs((player.elevation||0)-(e.elevation||0))<78&&Math.hypot(player.x-e.x,player.y-e.y)<e.r+player.r+28){damagePlayer(e.damage,e.x,e.y);addCombatFX('enemySwipe',e.x+e.facingSign*14,e.y-16,{life:.3,angle:Math.atan2(player.y-e.y,player.x-e.x),color:'#b6d28b'});}e.attackApplied=true;}
      if(e.stateT<=0){e.state='recover';e.stateT=.22;e.attackCd=.82;}
    }else if(e.state==='recover'){
      if(e.stateT<=0)e.state='idle';
    }else if(d>e.r+player.r+30){
      e.x+=nx*e.speed*1.16*dt;e.y+=ny*e.speed*1.16*dt;
    }else if(e.attackCd<=0){
      e.state='melee';e.stateT=.42;e.windupDuration=.42;e.attackApplied=false;e.aimX=player.x+player.vx*(game.dodgeStreak>1?.18:0);e.aimY=player.y+player.vy*(game.dodgeStreak>1?.18:0);
    }else{
      const strafe=Math.sin(e.anim*2.1+e.seed)*.82;e.x+=(-ny*strafe)*e.speed*.68*dt + nx*e.speed*.12*dt;e.y+=(nx*strafe)*e.speed*.68*dt + ny*e.speed*.12*dt;
    }
  }else if(e.kind==='archer'){
    e.strafeTimer=(e.strafeTimer??.7)-dt;if(e.strafeTimer<=0){e.strafeDir*=-1;e.strafeTimer=rand(.7,1.4);}
    const sideX=-ny*e.strafeDir,sideY=nx*e.strafeDir;
    if(e.state==='windup'){
      if(e.stateT<=0){const a=Math.atan2(e.aimY-e.y,e.aimX-e.x);spawnProjectile(e.x,e.y-e.r*.35,Math.cos(a)*300,Math.sin(a)*300,10,'#e7d59b');e.state='release';e.stateT=.24;e.attackCd=1.65;burst(e.x+nx*18,e.y-22,'#d5e9b3',7,.45);}
    }else if(e.state==='release'){
      if(e.stateT<=0)e.state='idle';
      e.x-=sideX*e.speed*.16*dt;e.y-=sideY*e.speed*.16*dt;
    }else{
      if(d>330){e.x+=nx*e.speed*1.05*dt;e.y+=ny*e.speed*1.05*dt;e.x+=sideX*e.speed*.24*dt;e.y+=sideY*e.speed*.24*dt;}
      else if(d<220){e.x-=nx*e.speed*1.02*dt;e.y-=ny*e.speed*1.02*dt;e.x+=sideX*e.speed*.70*dt;e.y+=sideY*e.speed*.70*dt;}
      else{e.x+=sideX*e.speed*.78*dt;e.y+=sideY*e.speed*.78*dt;}
      if(e.attackCd<=0&&d<520){e.state='windup';e.windupDuration=.76;e.stateT=e.windupDuration;e.aimX=player.x+player.vx*(game.dodgeStreak>1?.28:.08);e.aimY=player.y+player.vy*(game.dodgeStreak>1?.28:.08);}
    }
  }else if(e.kind==='brute'){
    if(e.state==='charge'){
      e.x+=e.chargeVX*dt;e.y+=e.chargeVY*dt;e.chargeVX*=Math.pow(.16,dt);e.chargeVY*=Math.pow(.16,dt);
      if(!e.attackApplied&&Math.abs((player.elevation||0)-(e.elevation||0))<78&&Math.hypot(e.x-player.x,e.y-player.y)<e.r+player.r+22){damagePlayer(e.damage,e.x,e.y);e.attackApplied=true;addCombatFX('enemySlam',player.x,player.y,{life:.35,color:'#e7a06d',radius:96});}
      if(e.stateT<=0){e.state='recover';e.stateT=.38;e.attackCd=1.85;addCombatFX('enemySlam',e.x,e.y,{life:.42,color:'#e7a06d',radius:92});}
    }else if(e.state==='windup'){
      if(e.stateT<=0){e.state='charge';e.stateT=.48;const a=Math.atan2(e.aimY-e.y,e.aimX-e.x);e.chargeVX=Math.cos(a)*515;e.chargeVY=Math.sin(a)*515;e.attackApplied=false;addCombatFX('enemyCharge',e.x,e.y,{life:.3,angle:a,color:'#f0aa77'});burst(e.x,e.y,'#e9a777',22,.95);}
    }else if(e.state==='recover'){
      if(e.stateT<=0)e.state='idle';
    }else{
      if(d>126){e.x+=nx*e.speed*1.18*dt;e.y+=ny*e.speed*1.18*dt;}
      else {const guardOrbit=Math.sin(e.anim*1.35+e.seed)*.62;e.x+=(-ny*guardOrbit+nx*.12)*e.speed*.52*dt;e.y+=(nx*guardOrbit+ny*.12)*e.speed*.52*dt;}
      if(e.attackCd<=0&&d<390){e.state='windup';e.windupDuration=.9;e.stateT=e.windupDuration;e.aimX=player.x+player.vx*(game.dodgeStreak>1?.20:.06);e.aimY=player.y+player.vy*(game.dodgeStreak>1?.20:.06);showToast('BRUTE · WINDING UP',.55);}
    }
  }else if(e.kind==='shade'){
    e.blinkCd=(e.blinkCd??3)-dt;
    if(e.state==='windup'){
      if(e.stateT<=0){const a=Math.atan2(e.aimY-e.y,e.aimX-e.x);e.x=clamp(e.x+Math.cos(a)*120,75,1205);e.y=clamp(e.y+Math.sin(a)*120,85,645);if(Math.hypot(player.x-e.x,player.y-e.y)<e.r+player.r+48)damagePlayer(e.damage,e.x,e.y);e.state='recover';e.stateT=.36;e.attackCd=1.28;addCombatFX('enemySwipe',e.x,e.y,{life:.38,angle:a,color:'#a99cff',radius:70});burst(e.x,e.y,'#9284ff',18,.9);}
    }else if(e.state==='recover'){if(e.stateT<=0)e.state='idle';}
    else if(e.state==='phase-in'){if(e.stateT<=0)e.state='idle';}
    else if(e.blinkCd<=0&&d>142){const a=Math.atan2(player.y-e.y,player.x-e.x),side=Math.random()<.5?-1:1;e.x=clamp(player.x-Math.cos(a)*108+Math.cos(a+Math.PI/2)*side*54,90,1190);e.y=clamp(player.y-Math.sin(a)*108+Math.sin(a+Math.PI/2)*side*54,205,625);e.blinkCd=rand(3.2,4.2);e.state='phase-in';e.stateT=.28;addCombatFX('riftStep',e.x,e.y,{life:.44,radius:58,color:'#9b8aff'});}
    else if(d>e.r+player.r+23){e.x+=nx*e.speed*1.28*dt;e.y+=ny*e.speed*1.28*dt;}
    else if(e.attackCd<=0){e.state='windup';e.windupDuration=.48;e.stateT=.48;e.aimX=player.x+player.vx*.14;e.aimY=player.y+player.vy*.14;showToast('SHADE ASSASSIN · PHASE STRIKE',.7);}
  }else if(e.kind==='wisp'){
    const orbit=Math.sin(game.roomTime*2.2+e.seed)*.9;if(d>230){e.x+=nx*e.speed*1.08*dt;e.y+=ny*e.speed*1.08*dt;}else if(d<150){e.x-=nx*e.speed*.9*dt;e.y-=ny*e.speed*.9*dt;}e.x+=-ny*orbit*54*dt;e.y+=nx*orbit*54*dt;
    if(e.attackCd<=0){const a=Math.atan2(player.y-e.y,player.x-e.x);spawnProjectile(e.x,e.y,Math.cos(a)*165,Math.sin(a)*165,8,'#98cbb5',true);e.attackCd=2.25;e.state='pulse';e.stateT=.22;}
    if(e.state==='pulse'&&e.stateT<=0)e.state='idle';
  }
  e.x=clamp(e.x,75,1205);e.y=clamp(e.y,85,645);e.elevation=surfaceHeightAt(e.x,e.y,game.chamberLayout);finishEnemyMotion(e,oldX,oldY,dt);
}
function spawnProjectile(x,y,vx,vy,damage,color,homing=false){game.projectiles.push({x,y,vx,vy,damage,color,life:3,r:7,homing,trail:[],age:0});}
function updateProjectiles(dt){for(let i=game.projectiles.length-1;i>=0;i--){const p=game.projectiles[i];p.age+=dt;if(p.homing){const a=Math.atan2(player.y-p.y,player.x-p.x);const speed=Math.hypot(p.vx,p.vy);p.vx=lerp(p.vx,Math.cos(a)*speed,.45*dt);p.vy=lerp(p.vy,Math.sin(a)*speed,.45*dt);}p.trail.push({x:p.x,y:p.y});if(p.trail.length>9)p.trail.shift();p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;if(Math.random()<.8)particle(p.x,p.y,p.color,rand(1,2.5),rand(-12,12),rand(-12,12),.2);if(Math.hypot(p.x-player.x,p.y-player.y)<p.r+player.r&&p.life>0){damagePlayer(p.damage,p.x,p.y);game.projectiles.splice(i,1);continue;}if(p.life<=0||p.x<-50||p.x>W+50||p.y<-50||p.y>H+50)game.projectiles.splice(i,1);}}
function updatePickups(dt){for(let i=game.pickups.length-1;i>=0;i--){const p=game.pickups[i];p.life-=dt;p.phase+=dt*3;const d=dist(player,p);if(d<140){const a=Math.atan2(player.y-p.y,player.x-p.x);const pull=(1-d/140)*260;p.x+=Math.cos(a)*pull*dt;p.y+=Math.sin(a)*pull*dt;}if(d<player.r+14){if(p.kind==='xp'){player.xp+=p.value;while(player.xp>=player.xpNeed){player.xp-=player.xpNeed;player.level++;player.xpNeed=Math.round(player.xpNeed*1.28);player.damage+=2;player.maxHp+=5;player.hp=Math.min(player.maxHp,player.hp+18);floater(player.x,player.y-34,'LEVEL '+player.level+'!','#f5d78c',20);sound('level');}}else{player.gold+=p.value;floater(p.x,p.y,'+'+p.value+' SHARDS','#e6c57f',12);}game.pickups.splice(i,1);updateUI();continue;}if(p.life<=0)game.pickups.splice(i,1);}}
function updateEffects(dt){game.cameraZoom=Math.max(0,game.cameraZoom-dt*.16);for(let i=game.particles.length-1;i>=0;i--){const p=game.particles[i];if(p.ring){p.ring.rr+=(p.ring.max/p.ring.life)*dt;p.ring.life-=dt;if(p.ring.life<=0)game.particles.splice(i,1);continue;}p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.pow(p.drag||.93,dt*60);p.vy*=Math.pow(p.drag||.93,dt*60);p.life-=dt;if(p.life<=0)game.particles.splice(i,1);}for(let i=game.floaters.length-1;i>=0;i--){const f=game.floaters[i];f.y+=f.vy*dt;f.life-=dt;if(f.life<=0)game.floaters.splice(i,1);}for(let i=game.combatFX.length-1;i>=0;i--){game.combatFX[i].life-=dt;if(game.combatFX[i].life<=0)game.combatFX.splice(i,1);}for(let i=game.afterimages.length-1;i>=0;i--){game.afterimages[i].life-=dt;if(game.afterimages[i].life<=0)game.afterimages.splice(i,1);}game.impactFlash=Math.max(0,game.impactFlash-dt*3.8);game.shake=Math.max(0,game.shake-dt*34);game.toastTimer=Math.max(0,game.toastTimer-dt);if(game.toastTimer<=0)$('toast').classList.remove('show');}
function updateGame(dt){if(game.phase!=='playing')return;game.roomTime+=dt;player.runTime+=dt;game.dodgeStreak=Math.max(0,game.dodgeStreak-dt*.34);updatePlayer(dt);for(const e of [...game.enemies])updateEnemy(e,dt);if(game.waveDelay>0){game.waveDelay=Math.max(0,game.waveDelay-dt);if(game.waveDelay===0&&game.enemies.length===0&&game.waveIndex<game.waveQueue.length)spawnEncounterWave();}updateProjectiles(dt);updatePickups(dt);updateEffects(dt);if(game.portal){game.portal.pulse+=dt;if(dist(player,game.portal)<105)$('interactionHint').style.display='flex';else $('interactionHint').style.display='none';}else $('interactionHint').style.display='none';if(game.boss){$('bossFill').style.width=(game.boss.hp/game.boss.maxHp*100)+'%';$('bossPercent').textContent=Math.ceil(game.boss.hp/game.boss.maxHp*100)+'%';}if(Math.floor(player.runTime)%1===0)updateHUDLight();}
let hudTick=0;function updateHUDLight(){hudTick++;if(hudTick%8===0)updateUI();}

function drawWorld(){ctx.drawImage(background,0,0);const p=realms[game.stage].palette;
  // drifting motes and drifting haze bands
  // Elevation remains active for actors and hit checks; the authored realm
  // background already depicts the terraces. Do not cover it with placeholder slabs.
  const t=performance.now()/1000;ctx.save();ctx.globalAlpha=.08;for(let i=0;i<5;i++){const x=(i*287+t*7)%1400-60;const g=ctx.createRadialGradient(x,120+i*120,5,x,120+i*120,220);g.addColorStop(0,p.mist);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(x-220,30+i*100,440,150);}ctx.restore();
  // Layered realm weather gives every chamber its own moving atmosphere without obscuring the hand-painted backdrop.
  ctx.save();for(let i=0;i<34;i++){const seed=i*71.73+game.stage*119;const drift=game.stage===1? t*(18+(i%5)*8):t*(5+(i%4)*3);const x=((seed*13+drift* (i%2?1:-.48))%1360+1360)%1360-40;const y=game.stage===1?650-((seed*7+t*(28+i%6*12))%760):((seed*11+t*(game.stage===2?22:11))%760)-20;const pulse=.45+.45*Math.sin(t*(2.1+i%4)+seed);const r=game.stage===1?1.1+(i%3)*.7:1.2+(i%2)*.9;const col=game.stage===0?(i%3?'#c6df91':'#f2d58b'):game.stage===1?(i%3?'#ff9a54':'#ffd27d'):game.stage===2?(i%3?'#a8d8f4':'#e0e6ff'):(i%3?'#8deaff':'#c8aaff');ctx.globalAlpha=(game.stage===1?.35:.22)+pulse*.32;ctx.fillStyle=col;ctx.shadowColor=col;ctx.shadowBlur=game.stage===1?9:12;ctx.beginPath();if(game.stage===2||game.stage===3){ctx.moveTo(x,y-r*2);ctx.lineTo(x+r,y);ctx.lineTo(x,y+r*2);ctx.lineTo(x-r,y);ctx.closePath();}else ctx.arc(x,y,r,0,TAU);ctx.fill();}ctx.restore();
  if(game.stage===3){ctx.save();for(let i=0;i<8;i++){const phase=(t*(.08+i*.013)+i*.137)%1,x=85+i*156+phase*220,y=82+(i*67)%420+phase*82;ctx.globalAlpha=(1-phase)*.62;ctx.strokeStyle=i%2?'#8deaff':'#d0b6ff';ctx.shadowColor=ctx.strokeStyle;ctx.shadowBlur=13;ctx.lineWidth=1.7;ctx.beginPath();ctx.moveTo(x-34,y-15);ctx.lineTo(x,y);ctx.stroke();ctx.fillStyle='#f2f8ff';ctx.beginPath();ctx.arc(x,y,2.1,0,TAU);ctx.fill();}ctx.restore();}
  // Realm colour grade and low ground haze unify actors with the environment art.
  ctx.save();const wash=ctx.createLinearGradient(0,0,0,H);wash.addColorStop(0,game.stage===0?'rgba(95,135,83,.035)':game.stage===1?'rgba(196,91,43,.07)':game.stage===2?'rgba(91,116,181,.065)':'rgba(73,129,198,.10)');wash.addColorStop(.58,'rgba(0,0,0,0)');wash.addColorStop(1,game.stage===0?'rgba(39,76,45,.10)':game.stage===1?'rgba(120,43,22,.13)':game.stage===2?'rgba(55,64,119,.13)':'rgba(32,42,99,.24)');ctx.fillStyle=wash;ctx.fillRect(0,0,W,H);ctx.restore();
  if(game.portal){const q=game.portal,pt=projectPoint(q.x,q.y);const pulse=.5+Math.sin(q.pulse*3.2)*.08;ctx.save();ctx.translate(pt.x,pt.y);ctx.scale(pt.scaleX*.86*pulse,.86/pulse);const glow=ctx.createRadialGradient(0,0,8,0,0,95);glow.addColorStop(0,p.portal+'88');glow.addColorStop(.5,p.portal+'30');glow.addColorStop(1,'transparent');ctx.fillStyle=glow;ctx.beginPath();ctx.arc(0,0,100,0,TAU);ctx.fill();ctx.strokeStyle=p.portal;ctx.globalAlpha=.8;ctx.lineWidth=5;ctx.beginPath();ctx.ellipse(0,0,33,47,0,0,TAU);ctx.stroke();ctx.globalAlpha=.5;ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(0,0,49,64,0,0,TAU);ctx.stroke();ctx.fillStyle='#f4daa3';ctx.globalAlpha=.8;ctx.font='12px DM Mono';ctx.textAlign='center';ctx.fillText('GATE',0,4);ctx.restore();for(let i=0;i<3;i++){const a=t*1.1+i*TAU/3;ctx.fillStyle=p.portal;ctx.globalAlpha=.8;ctx.beginPath();ctx.arc(pt.x+Math.cos(a)*42*pt.scaleX,pt.y+Math.sin(a)*57*.86,2.5,0,TAU);ctx.fill();ctx.globalAlpha=1;}}
}
function drawSprite(name,x,y,w,h,angle=0,alpha=1,flash=false){const im=images[name];if(!im||!im.complete||!im.naturalWidth)return false;ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.globalAlpha=alpha;if(flash){ctx.shadowColor='#fff0c9';ctx.shadowBlur=20;}ctx.drawImage(im,-w/2,-h/2,w,h);ctx.restore();return true;}
function projectPoint(x,y,elevation=0){
  const depth=clamp((y-198)/432,0,1);
  const scaleX=.70+depth*.30;
  return {x:640+(x-640)*scaleX,y:225+(y-198)*.86-elevation*.86,depth,scaleX,scale:.70+depth*.43};
}
function drawPlatforms(){
  const layout=game.chamberLayout;if(!layout)return;
  for(const ramp of layout.ramps||[]){const p1=projectPoint(ramp.x,ramp.y,ramp.from),p2=projectPoint(ramp.x+ramp.w,ramp.y,ramp.to),p3=projectPoint(ramp.x+ramp.w,ramp.y+ramp.h,ramp.to),p4=projectPoint(ramp.x,ramp.y+ramp.h,ramp.from);ctx.save();ctx.globalAlpha=.72;ctx.fillStyle='rgba(16,24,18,.5)';ctx.beginPath();ctx.moveTo(p1.x,p1.y+12);ctx.lineTo(p2.x,p2.y+12);ctx.lineTo(p3.x,p3.y+12);ctx.lineTo(p4.x,p4.y+12);ctx.closePath();ctx.fill();ctx.globalAlpha=.32;ctx.strokeStyle='#d4c38b';ctx.lineWidth=2;ctx.setLineDash([8,9]);ctx.beginPath();ctx.moveTo(p1.x,p1.y);ctx.lineTo(p3.x,p3.y);ctx.stroke();ctx.setLineDash([]);ctx.restore();}
  for(const platform of layout.platforms||[]){const z=platform.z||0,points=[[platform.x,platform.y],[platform.x+platform.w,platform.y],[platform.x+platform.w,platform.y+platform.h],[platform.x,platform.y+platform.h]].map(([x,y])=>projectPoint(x,y,z));const base=[[platform.x,platform.y],[platform.x+platform.w,platform.y],[platform.x+platform.w,platform.y+platform.h],[platform.x,platform.y+platform.h]].map(([x,y])=>projectPoint(x,y,0));ctx.save();ctx.globalAlpha=.34;ctx.fillStyle='#050b08';ctx.beginPath();ctx.moveTo(base[0].x,base[0].y+10);for(let i=1;i<4;i++)ctx.lineTo(base[i].x,base[i].y+10);ctx.closePath();ctx.fill();ctx.globalAlpha=.92;ctx.fillStyle=platform.tint||'#657b50';ctx.beginPath();ctx.moveTo(base[3].x,base[3].y);ctx.lineTo(base[2].x,base[2].y);ctx.lineTo(points[2].x,points[2].y);ctx.lineTo(points[3].x,points[3].y);ctx.closePath();ctx.fill();ctx.globalAlpha=.86;ctx.fillStyle=platform.tint||'#657b50';ctx.beginPath();ctx.moveTo(base[1].x,base[1].y);ctx.lineTo(base[2].x,base[2].y);ctx.lineTo(points[2].x,points[2].y);ctx.lineTo(points[1].x,points[1].y);ctx.closePath();ctx.fill();ctx.globalAlpha=.82;ctx.fillStyle='#829365';ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);for(let i=1;i<4;i++)ctx.lineTo(points[i].x,points[i].y);ctx.closePath();ctx.fill();ctx.globalAlpha=.30;ctx.strokeStyle='#d8daa3';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(points[0].x+8,points[0].y+8);ctx.lineTo(points[1].x-8,points[1].y+8);ctx.stroke();ctx.globalAlpha=.22;ctx.strokeStyle='#0c120d';ctx.lineWidth=5;for(let i=1;i<5;i++){const x=lerp(points[0].x,points[1].x,i/5);ctx.beginPath();ctx.moveTo(x,points[0].y+12);ctx.lineTo(x+rand(-5,5),points[3].y-8);ctx.stroke();}ctx.restore();}
}
function unprojectPoint(x,y){
  const worldY=clamp(198+(y-225)/.86,198,630);
  const depth=clamp((worldY-198)/432,0,1);
  const scaleX=.70+depth*.30;
  return {x:640+(x-640)/scaleX,y:worldY};
}
function projectAngle(angle,y){
  const depth=clamp((y-198)/432,0,1),sx=.70+depth*.30;
  return Math.atan2(Math.sin(angle)*.86,Math.cos(angle)*sx);
}
function depthScale(y){return .70+clamp((y-198)/432,0,1)*.43;}
function drawAtlasFrame(atlas,row,col,x,y,w,h,alpha=1,flip=false){
  if(!atlas||!atlas.complete||!atlas.naturalWidth)return false;
  const cw=atlas.naturalWidth/4,ch=atlas.naturalHeight/4;
  ctx.save();ctx.globalAlpha=alpha;ctx.translate(x,y);if(flip)ctx.scale(-1,1);
  ctx.drawImage(atlas,col*cw,row*ch,cw,ch,-w/2,-h,w,h);ctx.restore();return true;
}
function enemyFrame(e){
  const t=e.anim||0,hit=e.hitStun>0,st=e.state||'idle';
  if(hit)return [3,e.hitStun>.10?0:1];
  if(e.kind==='shade'){if(st==='windup')return [2,clamp(Math.floor((1-e.stateT/.48)*4),0,3)];if(st==='phase-in')return [3,0];if(e.moveSpeed>9)return [1,Math.floor(t*10)%4];return [0,Math.floor(t*3.2)%4];}
  if(st==='melee')return [2,clamp(Math.floor((1-e.stateT/.42)*4),0,3)];
  if(e.kind==='archer'){
    if(st==='windup')return [2,clamp(Math.floor((1-e.stateT/(e.windupDuration||.76))*3),0,2)];
    if(st==='release')return [2,3];
    if(e.moveSpeed>9)return [1,Math.floor(t*8)%4];
    return [0,Math.floor(t*2.8)%4];
  }
  if(e.kind==='brute'){
    if(st==='windup')return [2,clamp(Math.floor((1-e.stateT/(e.windupDuration||.9))*2.5),0,2)];
    if(st==='charge')return [2,3];
    if(st==='recover')return [3,0];
    if(e.moveSpeed>9)return [1,Math.floor(t*5.6)%4];
    return [0,Math.floor(t*2.2)%4];
  }
  if(st==='windup'||st==='burst')return [2,clamp(Math.floor((1-e.stateT/(e.windupDuration||.8))*4),0,3)];
  if(st==='recover')return [3,0];
  if(e.moveSpeed>9)return [1,Math.floor(t*7.8)%4];
  return [0,Math.floor(t*2.8)%4];
}
function drawEnemy(e){
  const t=performance.now()/1000,pt=projectPoint(e.x,e.y,e.elevation||0),depth=depthScale(e.y),hit=e.hitStun>0;
  const face=e.facingSign|| (player.x>=e.x?1:-1);
  const base=e.kind==='boss'?276:e.kind==='brute'?212:e.kind==='archer'?152:e.kind==='shade'?160:e.kind==='wisp'?86:146;
  const eliteScale=e.elite?1.14:1;const h=base*depth*eliteScale,w=(e.kind==='wisp'?h*1.1:h*.98);
  const moving=e.moveSpeed>9,breath=Math.sin((e.anim||0)*2.4+(e.seed||0));
  const bob=moving?Math.abs(Math.sin((e.anim||0)*(e.kind==='brute'?7.2:10.5)))*(e.kind==='brute'?3.2:4.6)*depth:breath*2.2*depth;
  const lift=(e.kind==='wisp'?-8*Math.sin((e.anim||0)*2.1):0);
  const screenX=pt.x,screenY=pt.y+bob+lift;
  const atlas=enemyAtlases[e.kind==='stalker'||e.kind==='shade'?'thornling':e.kind];
  const [row,col]=enemyFrame(e);
  // A perspective-correct ground shadow remains separate from the sprite's upright silhouette.
  if(e.elite){ctx.save();const pulse=.5+.5*Math.sin(t*5.4+(e.seed||0));ctx.globalAlpha=.12+.10*pulse;const aura=ctx.createRadialGradient(pt.x,pt.y-h*.44,4,pt.x,pt.y-h*.44,h*.72);aura.addColorStop(0,'rgba(255,221,150,.52)');aura.addColorStop(.55,'rgba(245,174,77,.18)');aura.addColorStop(1,'rgba(245,174,77,0)');ctx.fillStyle=aura;ctx.beginPath();ctx.ellipse(pt.x,pt.y-h*.43,h*.48,h*.55,0,0,TAU);ctx.fill();ctx.globalAlpha=.72;ctx.strokeStyle='#f6cf7e';ctx.shadowColor='#f0b75f';ctx.shadowBlur=15;ctx.lineWidth=2.2;ctx.setLineDash([6,5]);ctx.beginPath();ctx.ellipse(pt.x,pt.y+4,Math.max(20,w*.31)*pt.scaleX,Math.max(7,h*.06)*.86,0,0,TAU);ctx.stroke();ctx.setLineDash([]);for(let k=0;k<3;k++){const a=t*1.8+k*TAU/3+(e.seed||0);const ox=pt.x+Math.cos(a)*w*.27*pt.scaleX,oy=pt.y-h*.45+Math.sin(a)*h*.24;ctx.globalAlpha=.55+.30*pulse;ctx.fillStyle='#fff0b9';ctx.shadowBlur=10;ctx.beginPath();ctx.arc(ox,oy,2.1+Math.sin(t*8+k)*.6,0,TAU);ctx.fill();}ctx.restore();}
  ctx.save();ctx.fillStyle='#06100d';ctx.globalAlpha=e.kind==='wisp'?.20:.34;ctx.filter='blur(5px)';ctx.beginPath();ctx.ellipse(pt.x,pt.y+4,w*.25*pt.scaleX,Math.max(4,h*.055)*.86,0,0,TAU);ctx.fill();ctx.restore();
  // Enemy motion is conveyed by authored frame changes, not by spinning or squashing a single still.
  if(atlas&&atlas.complete&&atlas.naturalWidth){
    const alpha=e.flash>0?.88:1;
    ctx.save();if(e.flash>0){ctx.shadowColor='#fff0c9';ctx.shadowBlur=18;}if(e.kind==='shade'){ctx.filter='hue-rotate(105deg) saturate(1.8) brightness(.82)';ctx.shadowColor='#9e8bff';ctx.shadowBlur=24;}
    drawAtlasFrame(atlas,row,col,screenX,screenY,w*pt.scaleX,h,alpha,face<0);
    ctx.restore();
  }else{
    const art=images[e.kind==='wisp'?'wisp':e.kind==='boss'?'boss':e.kind];
    if(art&&art.complete&&art.naturalWidth){ctx.save();ctx.translate(screenX,screenY);ctx.scale(face*pt.scaleX,1);ctx.globalAlpha=e.flash>0?.82:1;ctx.filter='drop-shadow(0 6px 5px rgba(0,0,0,.34))';ctx.drawImage(art,-w/2,-h,w,h);ctx.restore();}
  }
  // A visible ground lane and target ring telegraph committed heavy attacks in the same camera plane.
  if(e.state==='windup'){
    const pulse=.5+.5*Math.sin(t*15),a=Math.atan2(e.aimY-e.y,e.aimX-e.x),target=projectPoint(e.aimX,e.aimY);
    ctx.save();ctx.lineCap='round';
    if(e.kind==='brute'||(e.kind==='boss'&&e.attackPattern==='charge')){
      ctx.globalAlpha=.13+.10*pulse;ctx.strokeStyle='#ff9b77';ctx.lineWidth=e.kind==='boss'?38:24;ctx.beginPath();ctx.moveTo(pt.x,pt.y);ctx.lineTo(target.x,target.y);ctx.stroke();
      ctx.globalAlpha=.75;ctx.strokeStyle='#ffd0a0';ctx.lineWidth=2;ctx.setLineDash([8,8]);ctx.beginPath();ctx.moveTo(pt.x,pt.y);ctx.lineTo(target.x,target.y);ctx.stroke();ctx.setLineDash([]);
    }else if(e.kind==='boss'&&e.attackPattern==='rootsweep'){
      ctx.globalAlpha=.18+.20*pulse;ctx.strokeStyle='#e3c58d';ctx.lineWidth=18;ctx.beginPath();ctx.arc(pt.x,pt.y,145,-.65, .65);ctx.stroke();ctx.globalAlpha=.72;ctx.setLineDash([7,7]);ctx.lineWidth=2;ctx.beginPath();ctx.arc(pt.x,pt.y,145,-.65,.65);ctx.stroke();ctx.setLineDash([]);
    }else if(e.kind==='archer'){
      ctx.globalAlpha=.18+.24*pulse;ctx.strokeStyle='#f6d99a';ctx.lineWidth=2;ctx.setLineDash([5,7]);ctx.beginPath();ctx.moveTo(pt.x,pt.y-h*.52);ctx.lineTo(target.x,target.y);ctx.stroke();ctx.setLineDash([]);
    }
    ctx.globalAlpha=.55+.25*pulse;ctx.strokeStyle=e.kind==='boss'?'#ff9b77':'#efc178';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(target.x,target.y,e.kind==='boss'?52:30,(e.kind==='boss'?52:30)*.34,0,0,TAU);ctx.stroke();ctx.restore();
  }
  // Health bars follow the projected creature and retain their readable screen proportions.
  if(e.kind!=='wisp'||e.hp<e.maxHp){
    const bw=Math.max(32,Math.min(82,w*.55*pt.scaleX)),bh=e.kind==='boss'?8:e.elite?7:6,bx=screenX-bw/2,by=screenY-h-(e.elite?19:10);
    ctx.save();ctx.fillStyle='rgba(9,12,14,.9)';ctx.fillRect(bx-2,by-2,bw+4,bh+4);ctx.fillStyle=e.elite?'#6a4a20':'#693a34';ctx.fillRect(bx,by,bw,bh);ctx.fillStyle=e.elite?'#e6b95f':e.kind==='shade'?'#a996ff':e.kind==='brute'||e.kind==='boss'?'#f0a05b':'#d85b4f';ctx.fillRect(bx,by,bw*clamp(e.hp/e.maxHp,0,1),bh);ctx.fillStyle='rgba(255,245,217,.72)';ctx.fillRect(bx,by,bw*clamp(e.hp/e.maxHp,0,1),1);if(e.elite){ctx.font='700 9px DM Mono';ctx.textAlign='center';ctx.fillStyle='#ffe3a0';ctx.shadowColor='#d99845';ctx.shadowBlur=10;ctx.fillText('✦ ELITE',screenX,by-4);}ctx.restore();
  }
}

function drawHeroRig(x,y,rotation,pose={},alpha=1,ghost=false){
  const time=pose.time??player.animTime;
  const move=clamp(pose.move??0,0,1);
  const attack=pose.attack??-1;
  const combo=pose.combo??1;
  const jump=clamp(pose.jump??0,0,1);
  const dash=clamp(pose.dash??0,0,1);
  const hurt=clamp(pose.hurt??0,0,1);
  const land=clamp(pose.land??0,0,1);
  const facing=rotation;
  const worldFacing=facing-Math.PI/2;
  const flipX=Math.cos(worldFacing)<-.12;
  const aimWorld=pose.aim??worldFacing;
  const aimLocal=flipX?Math.atan2(Math.sin(aimWorld),-Math.cos(aimWorld)):aimWorld;
  const dirX=Math.cos(aimLocal),dirY=Math.sin(aimLocal),perpX=-dirY,perpY=dirX;
  const phase=time*10.5;
  const stride=Math.sin(phase)*move;
  const bounce=Math.abs(Math.cos(phase*2)) * 4.2 * move;
  const jumpTuck=jump;
  const attackP=attack;
  const wind=attackP>=0&&attackP<.28?easeOut(attackP/.28):0;
  const strike=attackP>=.28&&attackP<.78?Math.sin((attackP-.28)/.5*Math.PI):0;
  const recover=attackP>=.78?1-(attackP-.78)/.22:0;
  const moveLean=Math.cos(worldFacing)*move*.13;
  const bodyLean=moveLean+(dash*.10)+(jumpTuck*-.08)+(strike*(combo===3?.25:.14))-(wind*.09)+(hurt*-.12);
  const bob=(bounce*(1-jumpTuck))-(land*2.5);
  const capeSwing=Math.sin(phase*.75)*move*4 + dash*9 + jumpTuck*5;

  // Ground shadow stays attached to the floor while the body rises into a real jump arc.
  if(!ghost){
    ctx.save();ctx.globalAlpha=alpha*(.34-jumpTuck*.13);ctx.fillStyle='#07100c';ctx.shadowColor='#030806';ctx.shadowBlur=18;
    ctx.beginPath();ctx.ellipse(x+dash*4,y+12,26+jumpTuck*9,10+jumpTuck*2,0,0,TAU);ctx.fill();ctx.restore();
  }

  ctx.save();ctx.globalAlpha=alpha;ctx.translate(x,y-(pose.z||0)*.82+bob);if(flipX)ctx.scale(-1,1);ctx.rotate(bodyLean);ctx.scale(1.16+strike*.065+dash*.05-land*.04,1.14-strike*.04-dash*.11+jumpTuck*.10+land*.035);
  if(pose.flash){ctx.filter='brightness(1.65) saturate(.55)';}

  // Hooded cloak and split tails, drawn behind the articulated limbs.
  ctx.save();ctx.translate(0,4);
  const cape=ctx.createLinearGradient(-18,-5,18,33);cape.addColorStop(0,'#244c46');cape.addColorStop(.48,'#183c37');cape.addColorStop(1,'#102b29');
  ctx.fillStyle=cape;ctx.strokeStyle='#6d8660';ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(-12,-12);ctx.quadraticCurveTo(-22,-1,-18,12+capeSwing*.18);ctx.lineTo(-21,26+capeSwing);ctx.quadraticCurveTo(-11,24+capeSwing,0,34+capeSwing*1.4);ctx.quadraticCurveTo(9,25+capeSwing,21,28+capeSwing*.6);ctx.lineTo(17,9);ctx.quadraticCurveTo(18,-5,11,-13);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.strokeStyle='#a9b86f';ctx.globalAlpha*=.75;ctx.lineWidth=1.15;ctx.beginPath();ctx.moveTo(-8,-2);ctx.quadraticCurveTo(-4,12,-12,22);ctx.moveTo(5,0);ctx.quadraticCurveTo(8,13,14,22);ctx.stroke();ctx.restore();

  // Legs animate independently: opposite stride, bent knees, foot lift and boot roll.
  const legLift=jumpTuck*18;
  for(const side of [-1,1]){
    const swing=(side===-1?stride:-stride);
    let hipX=side*7,hipY=10;
    let kneeX=side*10+swing*11,kneeY=29-Math.max(0,swing)*4;
    let footX=side*10+swing*23,footY=49-Math.max(0,swing)*11;
    if(jumpTuck>.05){kneeX=side*12+swing*6;kneeY=18+legLift*.10;footX=side*16+swing*9;footY=27+legLift*.32;}
    if(attackP>=0){const plant=attackP<.5?1:1-(attackP-.5)*.6;footX+=side===1?-9*plant:5*plant;footY+=side===1?-7*plant:4*plant;}
    const shinW=side===1?7.6:6.7;
    ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle='#241f20';ctx.lineWidth=10;ctx.beginPath();ctx.moveTo(hipX,hipY);ctx.lineTo(kneeX,kneeY);ctx.stroke();
    const thigh=ctx.createLinearGradient(hipX,hipY,kneeX,kneeY);thigh.addColorStop(0,side===1?'#7d513d':'#684431');thigh.addColorStop(1,'#30282a');ctx.strokeStyle=thigh;ctx.lineWidth=7.2;ctx.beginPath();ctx.moveTo(hipX,hipY);ctx.lineTo(kneeX,kneeY);ctx.stroke();
    ctx.fillStyle='#b18b62';ctx.beginPath();ctx.arc(kneeX,kneeY,3.8,0,TAU);ctx.fill();
    ctx.strokeStyle='#1b2725';ctx.lineWidth=shinW+2;ctx.beginPath();ctx.moveTo(kneeX,kneeY);ctx.lineTo(footX,footY-2);ctx.stroke();
    const shin=ctx.createLinearGradient(kneeX,kneeY,footX,footY);shin.addColorStop(0,'#56625a');shin.addColorStop(.55,'#283b37');shin.addColorStop(1,'#172b29');ctx.strokeStyle=shin;ctx.lineWidth=shinW;ctx.beginPath();ctx.moveTo(kneeX,kneeY);ctx.lineTo(footX,footY-2);ctx.stroke();
    ctx.save();ctx.translate(footX,footY);ctx.rotate(swing*.24+jumpTuck*side*.12);const boot=ctx.createLinearGradient(-7,-4,8,8);boot.addColorStop(0,'#8b6244');boot.addColorStop(.45,'#4a342b');boot.addColorStop(1,'#241f20');ctx.fillStyle=boot;ctx.strokeStyle='#b08b60';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(0,0,7.5,5.3,0,0,TAU);ctx.fill();ctx.stroke();ctx.fillStyle='#d0ad79';ctx.fillRect(-2,-2,4,1.6);ctx.restore();
  }

  // Waist, torso and layered chest armour.
  const torso=ctx.createLinearGradient(-15,-15,15,18);torso.addColorStop(0,'#9a6d49');torso.addColorStop(.28,'#58463b');torso.addColorStop(.72,'#354c45');torso.addColorStop(1,'#1d302e');
  ctx.fillStyle='#172321';ctx.beginPath();ctx.roundRect(-14,-14,28,31,8);ctx.fill();ctx.fillStyle=torso;ctx.strokeStyle='#bd9662';ctx.lineWidth=1.35;ctx.beginPath();ctx.moveTo(-11,-12);ctx.quadraticCurveTo(0,-17,11,-12);ctx.lineTo(13,7);ctx.quadraticCurveTo(0,17,-13,7);ctx.closePath();ctx.fill();ctx.stroke();
  ctx.fillStyle='#b18a58';ctx.globalAlpha*=.92;ctx.beginPath();ctx.moveTo(-10,-8);ctx.lineTo(0,-13);ctx.lineTo(10,-8);ctx.lineTo(7,1);ctx.lineTo(0,5);ctx.lineTo(-7,1);ctx.closePath();ctx.fill();ctx.fillStyle='#355a50';ctx.beginPath();ctx.moveTo(-8,-7);ctx.lineTo(0,-10);ctx.lineTo(8,-7);ctx.lineTo(5,1);ctx.lineTo(0,3);ctx.lineTo(-5,1);ctx.closePath();ctx.fill();
  ctx.strokeStyle='#d0ad79';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-10,7);ctx.quadraticCurveTo(0,12,10,7);ctx.stroke();ctx.fillStyle='#e3c27e';ctx.beginPath();ctx.roundRect(-3,5,6,5,1.5);ctx.fill();ctx.fillStyle='#83e5cc';ctx.shadowColor='#8fffe2';ctx.shadowBlur=10;ctx.beginPath();ctx.moveTo(0,-8);ctx.lineTo(4,-4);ctx.lineTo(0,1);ctx.lineTo(-4,-4);ctx.closePath();ctx.fill();ctx.shadowBlur=0;
  // Leather belt and asymmetric shoulder guard.
  ctx.fillStyle='#3e2c27';ctx.beginPath();ctx.roundRect(-12,10,24,5,2);ctx.fill();ctx.strokeStyle='#c59a63';ctx.lineWidth=1;ctx.strokeRect(4,10,5,5);
  ctx.fillStyle='#9d754e';ctx.strokeStyle='#d6b37d';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(6,-14);ctx.lineTo(15,-12);ctx.lineTo(14,-3);ctx.lineTo(7,-1);ctx.lineTo(3,-7);ctx.closePath();ctx.fill();ctx.stroke();ctx.strokeStyle='#e0c68c';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(7,-10);ctx.lineTo(12,-7);ctx.stroke();

  // Head and hood are fixed to the spine; hair and braid react to the movement.
  ctx.save();ctx.translate(0,-22-jumpTuck*1.5);ctx.fillStyle='#123330';ctx.strokeStyle='#bb9b69';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(0,-15);ctx.quadraticCurveTo(18,-14,17,1);ctx.quadraticCurveTo(15,16,0,16);ctx.quadraticCurveTo(-17,13,-17,0);ctx.quadraticCurveTo(-16,-14,0,-15);ctx.fill();ctx.stroke();
  ctx.fillStyle='#c98a66';ctx.beginPath();ctx.ellipse(0,1,9.2,11.5,0,0,TAU);ctx.fill();
  ctx.fillStyle='#452a25';ctx.beginPath();ctx.moveTo(-10,1);ctx.quadraticCurveTo(-14,-14,-2,-17);ctx.quadraticCurveTo(11,-19,13,-5);ctx.lineTo(8,-7);ctx.quadraticCurveTo(1,-12,-4,-6);ctx.lineTo(-9,5);ctx.closePath();ctx.fill();
  ctx.fillStyle='#d69a73';ctx.beginPath();ctx.ellipse(0,2,6.7,8.8,0,0,TAU);ctx.fill();
  ctx.fillStyle='#292324';ctx.beginPath();ctx.ellipse(-3.3,1,1.6,1,0,0,TAU);ctx.ellipse(3.3,1,1.6,1,0,0,TAU);ctx.fill();ctx.strokeStyle='#703f35';ctx.lineWidth=.8;ctx.beginPath();ctx.moveTo(-1,6);ctx.lineTo(1,6);ctx.stroke();
  ctx.fillStyle='#9d4d35';ctx.beginPath();ctx.moveTo(7,-8);ctx.quadraticCurveTo(18,-3,12,13);ctx.quadraticCurveTo(8,19,4,21);ctx.quadraticCurveTo(11,7,7,-8);ctx.fill();ctx.strokeStyle='#d28b5b';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(10,0);ctx.quadraticCurveTo(16,8,9,15);ctx.stroke();
  ctx.fillStyle='#d5b16e';ctx.beginPath();ctx.moveTo(-15,-7);ctx.lineTo(-10,-14);ctx.lineTo(-5,-12);ctx.strokeStyle='#d5b16e';ctx.lineWidth=2;ctx.stroke();ctx.restore();

  // Off-hand arm swings with the run cycle and lifts to balance a jump.
  const offShoulder={x:-10,y:-7};
  const offElbow={x:-17-stride*9,y:1-stride*6-jumpTuck*9};
  const offHand={x:-13-stride*15,y:10+jumpTuck*-18};
  ctx.lineCap='round';ctx.strokeStyle='#2c2925';ctx.lineWidth=8;ctx.beginPath();ctx.moveTo(offShoulder.x,offShoulder.y);ctx.lineTo(offElbow.x,offElbow.y);ctx.lineTo(offHand.x,offHand.y);ctx.stroke();
  ctx.strokeStyle='#52635a';ctx.lineWidth=5.4;ctx.beginPath();ctx.moveTo(offShoulder.x,offShoulder.y);ctx.lineTo(offElbow.x,offElbow.y);ctx.lineTo(offHand.x,offHand.y);ctx.stroke();
  ctx.fillStyle='#c08c67';ctx.beginPath();ctx.arc(offHand.x,offHand.y,4.2,0,TAU);ctx.fill();
  ctx.fillStyle='#ba9364';ctx.strokeStyle='#d4b47f';ctx.lineWidth=1;ctx.beginPath();ctx.roundRect(-17,-10,7,8,2);ctx.fill();ctx.stroke();

  // Sword arm has its own elbow and wrist pose, so the whole character never spins like a badge.
  const armShoulder={x:dirX>=0?10:-10,y:-7};
  let armElbow={x:armShoulder.x+dirX*8+perpX*5,y:armShoulder.y+dirY*8+perpY*5};
  let armHand={x:armShoulder.x+dirX*16+perpX*4,y:armShoulder.y+dirY*16+perpY*4};
  let bladeAngle=aimLocal-.55;
  if(attackP>=0){
    if(attackP<.28){const n=easeOut(attackP/.28);armElbow={x:armShoulder.x+dirX*(7+2*n)-perpX*4,y:armShoulder.y+dirY*(7+2*n)-perpY*4};armHand={x:armShoulder.x+dirX*(12+3*n)-perpX*12,y:armShoulder.y+dirY*(12+3*n)-perpY*12};bladeAngle=aimLocal+.65;}
    else if(attackP<.78){const n=easeOut((attackP-.28)/.5);const reach=19+7*Math.sin(n*Math.PI);const cross=(combo===2?-1:1)*11*Math.sin(n*Math.PI);armElbow={x:armShoulder.x+dirX*12+perpX*cross*.42,y:armShoulder.y+dirY*12+perpY*cross*.42};armHand={x:armShoulder.x+dirX*reach+perpX*cross,y:armShoulder.y+dirY*reach+perpY*cross};bladeAngle=aimLocal+lerp(.9,-.5,n)*(combo===2?-1:1);}
    else{const n=clamp((attackP-.78)/.22,0,1);armElbow={x:lerp(armShoulder.x+dirX*12,armShoulder.x+dirX*8,n),y:lerp(armShoulder.y+dirY*12,armShoulder.y+dirY*8,n)};armHand={x:lerp(armShoulder.x+dirX*20,armShoulder.x+dirX*15,n),y:lerp(armShoulder.y+dirY*20,armShoulder.y+dirY*15,n)};bladeAngle=lerp(aimLocal-.2,aimLocal-.55,n);}
  }else if(jumpTuck>.05){armElbow={x:armShoulder.x+dirX*8-perpX*4,y:armShoulder.y+dirY*8-perpY*4};armHand={x:armShoulder.x+dirX*14-perpX*8,y:armShoulder.y+dirY*14-perpY*8};bladeAngle=aimLocal-.25;}
  else if(dash>.05){armElbow={x:armShoulder.x+dirX*8,y:armShoulder.y+dirY*8};armHand={x:armShoulder.x+dirX*17,y:armShoulder.y+dirY*17};bladeAngle=aimLocal-.35;}
  else{armElbow={x:armShoulder.x+dirX*(8+stride*1.5)+perpX*4,y:armShoulder.y+dirY*(8+stride*1.5)+perpY*4};armHand={x:armShoulder.x+dirX*(16+stride*2)+perpX*4,y:armShoulder.y+dirY*(16+stride*2)+perpY*4};}
  ctx.strokeStyle='#282623';ctx.lineWidth=9;ctx.beginPath();ctx.moveTo(armShoulder.x,armShoulder.y);ctx.lineTo(armElbow.x,armElbow.y);ctx.lineTo(armHand.x,armHand.y);ctx.stroke();
  const sleeve=ctx.createLinearGradient(10,-7,armHand.x,armHand.y);sleeve.addColorStop(0,'#916447');sleeve.addColorStop(.55,'#435b50');sleeve.addColorStop(1,'#263a35');ctx.strokeStyle=sleeve;ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(armShoulder.x,armShoulder.y);ctx.lineTo(armElbow.x,armElbow.y);ctx.lineTo(armHand.x,armHand.y);ctx.stroke();
  ctx.fillStyle='#d19a72';ctx.beginPath();ctx.arc(armHand.x,armHand.y,4.6,0,TAU);ctx.fill();
  ctx.strokeStyle='#b89465';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(armElbow.x-3,armElbow.y+2);ctx.lineTo(armElbow.x+3,armElbow.y-2);ctx.stroke();

  // Blade hilt and steel are attached to the animated wrist, not a screen-space sticker.
  const swordLen=47+strike*5;const tipX=armHand.x+Math.cos(bladeAngle)*swordLen,tipY=armHand.y+Math.sin(bladeAngle)*swordLen;
  ctx.save();ctx.lineCap='round';ctx.strokeStyle='#5d3a29';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(armHand.x-Math.cos(bladeAngle)*7,armHand.y-Math.sin(bladeAngle)*7);ctx.lineTo(armHand.x+Math.cos(bladeAngle)*8,armHand.y+Math.sin(bladeAngle)*8);ctx.stroke();
  ctx.strokeStyle='#e2c18c';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(armHand.x+Math.cos(bladeAngle+Math.PI/2)*6,armHand.y+Math.sin(bladeAngle+Math.PI/2)*6);ctx.lineTo(armHand.x-Math.cos(bladeAngle+Math.PI/2)*6,armHand.y-Math.sin(bladeAngle+Math.PI/2)*6);ctx.stroke();
  const blade=ctx.createLinearGradient(armHand.x,armHand.y,tipX,tipY);blade.addColorStop(0,'#fff4d1');blade.addColorStop(.42,'#d5efe2');blade.addColorStop(1,'#6bbeb5');ctx.fillStyle=blade;ctx.shadowColor='#9bf5df';ctx.shadowBlur=ghost?0:9;ctx.beginPath();ctx.moveTo(armHand.x+Math.cos(bladeAngle+Math.PI/2)*3,armHand.y+Math.sin(bladeAngle+Math.PI/2)*3);ctx.lineTo(armHand.x+Math.cos(bladeAngle-Math.PI/2)*3,armHand.y+Math.sin(bladeAngle-Math.PI/2)*3);ctx.lineTo(tipX,tipY);ctx.closePath();ctx.fill();ctx.restore();
  ctx.restore();
}

function drawHeroFrame(row,col,x,y,width,height,alpha=1,flip=false,air=0){
  if(!heroAtlas.complete||!heroAtlas.naturalWidth)return;
  ctx.save();ctx.globalAlpha=alpha;ctx.translate(x,y-air*.82);
  if(flip)ctx.scale(-1,1);
  const sx=col*256,sy=row*256;
  ctx.drawImage(heroAtlas,sx,sy,256,256,-width/2,-height,width,height);
  ctx.restore();
}
function drawPlayer(){
  const speed=Math.hypot(player.vx,player.vy),moving=speed>52;
  const attack=player.attackTime>0?1-player.attackTime/player.attackDuration:-1;
  const jump=player.jumpActive||player.jumpZ>0||player.landTime>0;
  const dash=player.dashTime>0?1-player.dashTime/.22:0;
  const pt=projectPoint(player.x,player.y,player.elevation||0),depth=depthScale(player.y),px=pt.x,py=pt.y;
  const baseH=148*depth,baseW=142*depth,flip=player.facingSign<0;
  const blink=player.invuln>0&&Math.floor(player.animTime*18)%2===0;
  // Shadow belongs to the projected floor; the character rises independently during a leap.
  ctx.save();const shadowScale=clamp(1-player.jumpZ/190,.38,1);ctx.globalAlpha=.37*shadowScale;ctx.fillStyle='#07100d';ctx.filter='blur(6px)';ctx.beginPath();ctx.ellipse(px,py+4,26*depth*pt.scaleX*shadowScale,8*depth*shadowScale,0,0,TAU);ctx.fill();ctx.restore();
  let row=0,col=0,useIdle=false;
  if(player.dashTime>0){row=3;col=clamp(Math.floor(dash*4),0,3);}
  else if(jump){row=1;if(player.landTime>0&&!player.jumpActive)col=3;else if(player.jumpVy>360)col=0;else if(player.jumpVy>110)col=1;else if(player.jumpVy>0)col=2;else col=3;}
  else if(attack>=0){row=2;col=clamp(Math.floor(attack*4),0,3);}
  else if(moving){row=0;col=Math.floor(player.animTime*11.5)%4;}
  else useIdle=true;
  const bob=useIdle?Math.sin(player.animTime*2.6)*2.2*depth:0;
  const alpha=blink?.78:player.hurtTime>0?.84:1;
  for(const ghost of game.afterimages){
    const age=1-clamp(ghost.life/ghost.max,0,1),frame=clamp(Math.floor(age*4),0,3),fade=clamp(ghost.life/ghost.max,0,1)*.18,gp=projectPoint(ghost.x,ghost.y,ghost.elevation||0);
    drawHeroFrame(3,frame,gp.x,gp.y,baseW*pt.scaleX*.98,baseH*.98,fade,flip,0);
  }
  if(useIdle&&heroIdle.complete&&heroIdle.naturalWidth){
    ctx.save();ctx.globalAlpha=alpha;ctx.translate(px,py-player.jumpZ*.82+bob);if(flip)ctx.scale(-1,1);ctx.drawImage(heroIdle,-baseW*pt.scaleX/2,-baseH,baseW*pt.scaleX,baseH);ctx.restore();
  }else drawHeroFrame(row,col,px,py+bob,baseW*pt.scaleX,baseH,alpha,flip,player.jumpZ);
  // Blade arcs follow the camera projection; the body itself remains side-facing and upright.
  if(attack>=0){
    const a=projectAngle(player.attackAngle,player.y),sweep=player.combo===3?2.9:player.combo===2?-2.35:2.25;
    const wind=player.combo===2?1.05:-1.12;let bladeAngle=a+wind;
    if(attack<.28)bladeAngle=a+wind-(player.combo===2?-.18:.18)*(attack/.28);
    else if(attack<.78)bladeAngle=a+wind+sweep*((attack-.28)/.5);
    else bladeAngle=a+wind+sweep*.98+(1-attack)*.45;
    const hx=px+Math.cos(a+Math.PI/2)*8,hy=py-player.jumpZ*.82+Math.sin(a+Math.PI/2)*8;
    const tipX=hx+Math.cos(bladeAngle)*58*depth,tipY=hy+Math.sin(bladeAngle)*58*depth;
    if(attack>.16&&attack<.9){ctx.save();ctx.globalAlpha=Math.sin((attack-.16)/.74*Math.PI)*.82;ctx.strokeStyle='#fff7d9';ctx.shadowColor='#f4b94e';ctx.shadowBlur=22;ctx.lineWidth=4.2*depth;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(hx,hy);ctx.lineTo(tipX,tipY);ctx.stroke();ctx.restore();}
  }
  if(player.specialTime>0){ctx.save();const pulse=.5+.5*Math.sin(player.animTime*22),cy=py-player.jumpZ*.82;ctx.globalAlpha=.16+.18*pulse;const g=ctx.createRadialGradient(px,cy,10,px,cy,110*depth);g.addColorStop(0,'rgba(255,248,206,0)');g.addColorStop(.4,'rgba(255,220,136,.38)');g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.beginPath();ctx.arc(px,cy,110*depth,0,TAU);ctx.fill();ctx.restore();}
}

function drawEffects(){
  for(const plant of game.plants){if(!plant.active)continue;const pt=projectPoint(plant.x,plant.y,surfaceHeightAt(plant.x,plant.y,game.chamberLayout)),pulse=.5+.5*Math.sin(performance.now()/310+plant.phase);ctx.save();ctx.translate(pt.x,pt.y);ctx.scale(pt.scaleX,.86);ctx.globalAlpha=.32;ctx.fillStyle='#07110b';ctx.beginPath();ctx.ellipse(0,7,18,6,0,0,TAU);ctx.fill();ctx.globalAlpha=.86;ctx.strokeStyle=plant.kind==='healing'?'#c2e4a2':'#c4cf78';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(0,7);ctx.quadraticCurveTo(-9,-3,-4,-17);ctx.moveTo(0,7);ctx.quadraticCurveTo(10,-4,6,-18);ctx.stroke();ctx.fillStyle=plant.kind==='healing'?'#a8d48e':'#edba69';ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=12+10*pulse;ctx.beginPath();ctx.arc(0,-17-pulse*2,7+pulse*2,0,TAU);ctx.fill();if(plant.secret){ctx.globalAlpha=.48+.35*pulse;ctx.strokeStyle='#f8e0a0';ctx.beginPath();ctx.arc(0,-17,15+pulse*5,0,TAU);ctx.stroke();}ctx.restore();}
  for(const p of game.pickups){const bob=Math.sin(p.phase)*4,pt=projectPoint(p.x,p.y);ctx.save();ctx.translate(pt.x,pt.y+bob*.86);ctx.scale(pt.scaleX,.86);ctx.shadowColor=p.kind==='xp'?'#b8db9e':'#f1c379';ctx.shadowBlur=14;ctx.fillStyle=p.kind==='xp'?'#a5c68b':'#dfb86f';ctx.beginPath();if(p.kind==='xp'){ctx.moveTo(0,-8);ctx.lineTo(7,0);ctx.lineTo(0,8);ctx.lineTo(-7,0);}else ctx.arc(0,0,5,0,TAU);ctx.fill();ctx.restore();}
  for(const p of game.projectiles){const pt=projectPoint(p.x,p.y);ctx.save();if(p.trail?.length>1){ctx.lineCap='round';for(let i=1;i<p.trail.length;i++){const a=i/p.trail.length,p1=projectPoint(p.trail[i-1].x,p.trail[i-1].y),p2=projectPoint(p.trail[i].x,p.trail[i].y);ctx.globalAlpha=a*.48;ctx.strokeStyle=p.color;ctx.lineWidth=1+a*7;ctx.shadowColor=p.color;ctx.shadowBlur=10;ctx.beginPath();ctx.moveTo(p1.x,p1.y);ctx.lineTo(p2.x,p2.y);ctx.stroke();}}ctx.globalAlpha=1;ctx.fillStyle='#fff4d4';ctx.shadowColor=p.color;ctx.shadowBlur=22;ctx.beginPath();ctx.arc(pt.x,pt.y,p.r*.72,0,TAU);ctx.fill();ctx.fillStyle=p.color;ctx.globalAlpha=.7;ctx.beginPath();ctx.arc(pt.x,pt.y,p.r*1.3,0,TAU);ctx.fill();ctx.restore();}
  for(const p of game.particles){if(p.ring){const pt=projectPoint(p.ring.x,p.ring.y);ctx.save();ctx.globalAlpha=clamp(p.ring.life/.36,0,1)*.6;ctx.strokeStyle='#ffe0a2';ctx.lineWidth=5;ctx.beginPath();ctx.ellipse(pt.x,pt.y,p.ring.rr*pt.scaleX,p.ring.rr*.36,0,0,TAU);ctx.stroke();ctx.restore();continue;}const pt=projectPoint(p.x,p.y);ctx.save();ctx.globalAlpha=clamp(p.life/p.max,0,1);ctx.fillStyle=p.color;ctx.shadowColor=p.color;ctx.shadowBlur=8;ctx.beginPath();ctx.arc(pt.x,pt.y,p.size*clamp(p.life/p.max,.25,1),0,TAU);ctx.fill();ctx.restore();}
  for(const f of game.floaters){const pt=projectPoint(f.x,f.y);ctx.save();ctx.globalAlpha=clamp(f.life/f.max,0,1);ctx.fillStyle=f.color;ctx.font=`700 ${f.size}px Barlow Condensed, sans-serif`;ctx.textAlign='center';ctx.shadowColor='#111';ctx.shadowBlur=5;ctx.fillText(f.text,pt.x,pt.y);ctx.restore();}
}

function drawCombatFX(){
  const t=performance.now()/1000;
  for(const original of game.combatFX){const pt=projectPoint(original.x,original.y),fx={...original,x:0,y:0},p=1-clamp(fx.life/fx.max,0,1),fade=clamp(fx.life/fx.max,0,1);ctx.save();ctx.translate(pt.x,pt.y);ctx.scale(pt.scaleX,.86);
    if(fx.type==='slash'||fx.type==='heavySlash'||fx.type==='airSlam'){
      const heavy=fx.type==='heavySlash'||fx.type==='airSlam',combo=fx.combo||1;const sweep=heavy?3.0:combo>=4?2.9:combo===3?2.65:combo===2?2.25:2.05;const radius=heavy?122:combo>=4?116:combo===3?112:combo===2?98:88;const dir=combo===2?-1:1;const start=fx.angle-dir*(sweep*.58);const end=start+dir*sweep*easeOut(clamp(p,0,1));const alpha=Math.sin(Math.PI*clamp(p,0,1))*.95;
      ctx.lineCap='round';ctx.globalAlpha=alpha;const grad=ctx.createLinearGradient(-radius,-radius,radius,radius);grad.addColorStop(0,'#fff9dc');grad.addColorStop(.35,fx.color||'#f0d3a0');grad.addColorStop(.75,'#8ed8d0');grad.addColorStop(1,'#fff3c4');
      ctx.strokeStyle=grad;ctx.shadowColor='#ffdf9b';ctx.shadowBlur=26;ctx.lineWidth=heavy?20:combo>=4?17:combo===3?16:11;ctx.beginPath();ctx.arc(0,0,radius,start,end,dir<0);ctx.stroke();
      ctx.globalAlpha=alpha*.58;ctx.shadowBlur=10;ctx.strokeStyle='#fff9dd';ctx.lineWidth=heavy?5:combo>=4?4.4:combo===3?4:2.8;ctx.beginPath();ctx.arc(0,0,radius-8,start,end,dir<0);ctx.stroke();
      ctx.globalAlpha=alpha*.24;ctx.strokeStyle='#f9dca3';ctx.lineWidth=28;ctx.beginPath();ctx.arc(0,0,radius+5,start,end,dir<0);ctx.stroke();
      const tip=end;const tx=Math.cos(tip)*radius,ty=Math.sin(tip)*radius;ctx.globalAlpha=alpha;ctx.fillStyle='#fffbe4';ctx.shadowBlur=24;ctx.beginPath();ctx.arc(tx,ty,combo===3?8:5,0,TAU);ctx.fill();
      if(combo>=3||heavy){ctx.globalAlpha=alpha*.42;ctx.strokeStyle='#fff0ad';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,radius+19,start+.18,end-.15,dir<0);ctx.stroke();}
    }else if(fx.type==='solarLance'){const a=fx.angle||0;ctx.rotate(a);ctx.globalAlpha=fade*.9;const len=fx.length||520;const grad=ctx.createLinearGradient(0,0,len,0);grad.addColorStop(0,'rgba(255,249,216,.96)');grad.addColorStop(.35,'rgba(255,214,132,.88)');grad.addColorStop(1,'rgba(255,152,79,0)');ctx.strokeStyle=grad;ctx.shadowColor='#ffd58e';ctx.shadowBlur=25;ctx.lineCap='round';ctx.lineWidth=38*(1-p*.5);ctx.beginPath();ctx.moveTo(10,0);ctx.lineTo(len,0);ctx.stroke();ctx.strokeStyle='#fff7d9';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(8,0);ctx.lineTo(len*.88,0);ctx.stroke();
    }else if(fx.type==='solarRupture'||fx.type==='plantExplosion'||fx.type==='throwImpact'){const r=(fx.radius||95)*easeOut(p);ctx.globalAlpha=fade*.62;ctx.strokeStyle=fx.color||'#f5d49b';ctx.shadowColor=fx.color||'#f5d49b';ctx.shadowBlur=26;ctx.lineWidth=fx.type==='solarRupture'?7:4;ctx.beginPath();ctx.ellipse(0,0,r,r*.44,0,0,TAU);ctx.stroke();ctx.globalAlpha=fade*.14;ctx.fillStyle=fx.color||'#f5d49b';ctx.beginPath();ctx.ellipse(0,0,r*.68,r*.3,0,0,TAU);ctx.fill();
    }else if(fx.type==='parryCounter'){ctx.rotate(fx.angle||0);ctx.globalAlpha=fade*.9;ctx.strokeStyle='#e5ffe9';ctx.shadowColor='#a8f0cc';ctx.shadowBlur=30;ctx.lineWidth=5*(1-p*.4);ctx.beginPath();ctx.arc(0,0,lerp(18,72,easeOut(p)),-1.4,1.4);ctx.stroke();ctx.beginPath();ctx.arc(0,0,lerp(14,56,easeOut(p)),Math.PI-.8,Math.PI+.8);ctx.stroke();
    }else if(fx.type==='chargeAura'){const r=22+p*68;ctx.globalAlpha=fade*.64;ctx.strokeStyle=fx.color||'#ffc978';ctx.shadowColor=fx.color||'#ffc978';ctx.shadowBlur=22;ctx.lineWidth=2.5;ctx.setLineDash([5,7]);ctx.beginPath();ctx.ellipse(0,0,r,r*.48,0,0,TAU);ctx.stroke();ctx.setLineDash([]);
    }else if(fx.type==='enemySwipe'){
      const radius=fx.radius||42,start=(fx.angle||0)-.85,end=(fx.angle||0)+.72,alpha=Math.sin(Math.PI*clamp(p,0,1))*.86;
      ctx.save();ctx.globalAlpha=alpha;ctx.lineCap='round';ctx.strokeStyle=fx.color||'#b6d28b';ctx.shadowColor=fx.color||'#b6d28b';ctx.shadowBlur=18;ctx.lineWidth=8*(1-p*.45);ctx.beginPath();ctx.arc(fx.x,fx.y,radius,start,end);ctx.stroke();ctx.globalAlpha=alpha*.75;ctx.strokeStyle='#f7f5d7';ctx.lineWidth=2.2;ctx.beginPath();ctx.arc(fx.x,fx.y,radius-6,start+.12,end-.08);ctx.stroke();ctx.restore();
    }else if(fx.type==='enemySlam'){
      const radius=(fx.radius||92)*easeOut(p),alpha=fade*.74;ctx.save();ctx.globalAlpha=alpha;ctx.strokeStyle=fx.color||'#e6a477';ctx.shadowColor=fx.color||'#e6a477';ctx.shadowBlur=18;ctx.lineWidth=5*(1-p*.5);ctx.beginPath();ctx.ellipse(fx.x,fx.y+4,radius,radius*.42,0,0,TAU);ctx.stroke();for(let i=0;i<12;i++){const a=i/12*TAU;ctx.globalAlpha=alpha*.58;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(fx.x+Math.cos(a)*radius*.52,fx.y+Math.sin(a)*radius*.22);ctx.lineTo(fx.x+Math.cos(a)*radius*(.84+p*.18),fx.y+Math.sin(a)*radius*(.34+p*.08));ctx.stroke();}ctx.restore();
    }else if(fx.type==='impact'||fx.type==='impactGround'){
      const r=lerp(5,fx.type==='impact'?40:28,easeOut(p));const a=fx.angle||0;ctx.rotate(a);ctx.globalAlpha=fade;ctx.strokeStyle=fx.color||'#ffe4a8';ctx.shadowColor=fx.color||'#ffe4a8';ctx.shadowBlur=18;ctx.lineWidth=fx.crit?4:2.5;ctx.beginPath();ctx.arc(0,0,r,-1.1,1.1);ctx.stroke();
      if(fx.type==='impact'){for(let i=0;i<9;i++){const ang=i/9*TAU;const len=(fx.crit?28:18)*(1-p*.5);ctx.globalAlpha=fade*(i%2?.75:.45);ctx.lineWidth=i%3===0?3:1.6;ctx.beginPath();ctx.moveTo(Math.cos(ang)*5,Math.sin(ang)*5);ctx.lineTo(Math.cos(ang)*len,Math.sin(ang)*len);ctx.stroke();}}
    }else if(fx.type==='solarBurst'){
      const r=fx.radius*easeOut(p);const alpha=Math.sin(Math.PI*fade);const grd=ctx.createRadialGradient(fx.x,fx.y,Math.max(1,r*.14),fx.x,fx.y,r);grd.addColorStop(0,'rgba(255,248,206,0)');grd.addColorStop(.72,'rgba(255,211,126,0.10)');grd.addColorStop(1,'rgba(255,211,126,0)');ctx.globalAlpha=alpha;ctx.fillStyle=grd;ctx.beginPath();ctx.arc(fx.x,fx.y,r,0,TAU);ctx.fill();
      for(let ring=0;ring<3;ring++){ctx.globalAlpha=alpha*(.65-ring*.13);ctx.strokeStyle=ring===0?'#fff4c9':ring===1?'#ffdb91':'#f2b66e';ctx.lineWidth=ring===0?5:2.5;ctx.shadowColor='#ffd88c';ctx.shadowBlur=20;ctx.beginPath();ctx.arc(fx.x,fx.y,r*(.76+ring*.12),0,TAU);ctx.stroke();}
      for(let i=0;i<24;i++){const a=i/24*TAU+t*.25;const inner=r*.72,outer=r*(.82+.18*Math.sin(t*12+i));ctx.globalAlpha=alpha*.5;ctx.strokeStyle='#fff0ba';ctx.lineWidth=i%3===0?3:1.3;ctx.beginPath();ctx.moveTo(fx.x+Math.cos(a)*inner,fx.y+Math.sin(a)*inner);ctx.lineTo(fx.x+Math.cos(a)*outer,fx.y+Math.sin(a)*outer);ctx.stroke();}
    }else if(fx.type==='deathBurst'){
      const r=fx.radius*easeOut(p);ctx.globalAlpha=fade*.55;ctx.strokeStyle=fx.color;ctx.shadowColor=fx.color;ctx.shadowBlur=26;ctx.lineWidth=fx.radius>80?5:3;ctx.beginPath();ctx.arc(fx.x,fx.y,r,0,TAU);ctx.stroke();ctx.globalAlpha=fade*.16;ctx.fillStyle=fx.color;ctx.beginPath();ctx.arc(fx.x,fx.y,r*.7,0,TAU);ctx.fill();
    }else if(fx.type==='dashBurst'||fx.type==='enemyCharge'){
      const a=fx.angle||0;ctx.rotate(a);ctx.globalAlpha=fade*.7;ctx.strokeStyle=fx.color||'#d3f2dc';ctx.shadowColor=fx.color||'#d3f2dc';ctx.shadowBlur=18;ctx.lineCap='round';for(let i=0;i<5;i++){const yy=(i-2)*7;ctx.lineWidth=i===2?3:1.4;ctx.beginPath();ctx.moveTo(-10,yy);ctx.lineTo(36+p*70,yy);ctx.stroke();}
    }else if(fx.type==='spawnRift'){
      const r=(fx.radius||46)*(.55+easeOut(p)*.75),pulse=.5+.5*Math.sin(t*18);ctx.globalAlpha=fade*.76;ctx.strokeStyle=fx.color||'#cbdc9b';ctx.shadowColor=fx.color||'#cbdc9b';ctx.shadowBlur=22;ctx.lineWidth=3*(1-p*.45);ctx.beginPath();ctx.ellipse(0,0,r,r*.34,0,0,TAU);ctx.stroke();ctx.globalAlpha=fade*.3;ctx.fillStyle=fx.color||'#cbdc9b';ctx.beginPath();ctx.ellipse(0,0,r*.72,r*.25,0,0,TAU);ctx.fill();for(let i=0;i<8;i++){const a=i/8*TAU+t*.7;ctx.globalAlpha=fade*(.34+.24*pulse);ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(Math.cos(a)*r*.55,Math.sin(a)*r*.19);ctx.lineTo(Math.cos(a)*r*(.92+p*.12),Math.sin(a)*r*(.34+p*.08));ctx.stroke();}
    }else if(fx.type==='eliteDeath'){
      const r=(fx.radius||98)*easeOut(p);ctx.globalAlpha=fade*.72;ctx.strokeStyle=fx.color||'#f4c875';ctx.shadowColor=fx.color||'#f4c875';ctx.shadowBlur=30;ctx.lineWidth=5*(1-p*.55);ctx.beginPath();ctx.ellipse(0,0,r,r*.4,0,0,TAU);ctx.stroke();ctx.globalAlpha=fade*.22;ctx.fillStyle=fx.color||'#f4c875';ctx.beginPath();ctx.ellipse(0,0,r*.72,r*.27,0,0,TAU);ctx.fill();for(let i=0;i<18;i++){const a=i/18*TAU+t*.25,inner=r*.22,outer=r*(.8+.18*Math.sin(t*5+i));ctx.globalAlpha=fade*.72;ctx.lineWidth=i%3===0?3:1.5;ctx.beginPath();ctx.moveTo(Math.cos(a)*inner,Math.sin(a)*inner*.4);ctx.lineTo(Math.cos(a)*outer,Math.sin(a)*outer*.4);ctx.stroke();}
    }else if(fx.type==='eliteHit'){
      ctx.rotate(fx.angle||0);ctx.globalAlpha=fade*.9;ctx.strokeStyle=fx.color||'#f8d48b';ctx.shadowColor=fx.color||'#f8d48b';ctx.shadowBlur=22;ctx.lineCap='round';ctx.lineWidth=3.5*(1-p*.5);for(let i=0;i<7;i++){const a=-.9+i*.3;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(Math.cos(a)*lerp(9,34,easeOut(p)),Math.sin(a)*lerp(9,34,easeOut(p)));ctx.stroke();}
    }else if(fx.type==='riftStep'){
      const r=(fx.radius||76)*easeOut(p);ctx.globalAlpha=fade*.78;ctx.strokeStyle=fx.color||'#91eaff';ctx.shadowColor=fx.color||'#91eaff';ctx.shadowBlur=28;ctx.lineWidth=5*(1-p*.5);ctx.beginPath();ctx.ellipse(0,0,r,r*.43,0,0,TAU);ctx.stroke();ctx.setLineDash([8,6]);ctx.lineWidth=2;ctx.globalAlpha=fade*.55;ctx.beginPath();ctx.ellipse(0,0,r*.74,r*.29,p*1.7,0,TAU);ctx.stroke();ctx.setLineDash([]);for(let i=0;i<12;i++){const a=i/12*TAU+t*.5;ctx.globalAlpha=fade*.7;ctx.beginPath();ctx.moveTo(Math.cos(a)*r*.22,Math.sin(a)*r*.09);ctx.lineTo(Math.cos(a)*r*(.76+p*.18),Math.sin(a)*r*(.34+p*.06));ctx.stroke();}
    }else if(fx.type==='aetherSnare'){
      const r=(fx.radius||205)*(.62+easeOut(p)*.43);ctx.globalAlpha=fade*.32;const grad=ctx.createRadialGradient(0,0,5,0,0,r);grad.addColorStop(0,'rgba(120,204,255,.45)');grad.addColorStop(.6,'rgba(117,147,255,.16)');grad.addColorStop(1,'rgba(117,147,255,0)');ctx.fillStyle=grad;ctx.beginPath();ctx.ellipse(0,0,r,r*.42,0,0,TAU);ctx.fill();ctx.globalAlpha=fade*.9;ctx.strokeStyle='#a9eaff';ctx.shadowColor='#87cfff';ctx.shadowBlur=27;ctx.lineWidth=4*(1-p*.48);ctx.beginPath();ctx.ellipse(0,0,r,r*.42,t*.45,0,TAU);ctx.stroke();ctx.setLineDash([5,8]);ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(0,0,r*.78,r*.32,-t*1.15,0,TAU);ctx.stroke();ctx.setLineDash([]);for(let i=0;i<10;i++){const a=i/10*TAU-t*1.8;ctx.beginPath();ctx.moveTo(Math.cos(a)*r*.72,Math.sin(a)*r*.30);ctx.quadraticCurveTo(Math.cos(a+1)*r*.24,Math.sin(a+1)*r*.09,Math.cos(a+1.8)*r*.08,Math.sin(a+1.8)*r*.03);ctx.stroke();}
    }else if(fx.type==='bossPhase'){
      const r=(fx.radius||180)*easeOut(p);ctx.globalAlpha=fade*.68;ctx.strokeStyle=fx.color||'#e8d19a';ctx.shadowColor=fx.color||'#e8d19a';ctx.shadowBlur=28;ctx.lineWidth=7*(1-p*.65);ctx.beginPath();ctx.ellipse(0,0,r,r*.39,0,0,TAU);ctx.stroke();ctx.globalAlpha=fade*.36;ctx.lineWidth=2;ctx.setLineDash([10,7]);ctx.beginPath();ctx.ellipse(0,0,r*.78,r*.3,-p*.9,0,TAU);ctx.stroke();ctx.setLineDash([]);for(let i=0;i<12;i++){const a=i/12*TAU+t*.18;ctx.globalAlpha=fade*.55;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(Math.cos(a)*r*.3,Math.sin(a)*r*.12);ctx.lineTo(Math.cos(a)*r*(.85+p*.12),Math.sin(a)*r*(.34+p*.08));ctx.stroke();}
    }else if(fx.type==='jumpTakeoff'||fx.type==='landing'){
      const r=fx.type==='landing'?lerp(7,54,easeOut(p)):lerp(9,34,easeOut(p));
      ctx.globalAlpha=fade*(fx.type==='landing'?.58:.42);ctx.strokeStyle=fx.color||'#d8e9c0';ctx.shadowColor=fx.color||'#d8e9c0';ctx.shadowBlur=12;ctx.lineWidth=fx.type==='landing'?3:2;ctx.beginPath();ctx.ellipse(fx.x,fx.y+5,r,r*.38,0,0,TAU);ctx.stroke();
      if(fx.type==='landing'){ctx.globalAlpha=fade*.32;for(let i=0;i<10;i++){const a=i/10*TAU;ctx.beginPath();ctx.moveTo(fx.x+Math.cos(a)*r*.3,fx.y+Math.sin(a)*r*.12);ctx.lineTo(fx.x+Math.cos(a)*r,fx.y+Math.sin(a)*r*.32);ctx.stroke();}}
    }
    ctx.restore();
  }
}
function draw(){ctx.save();if(game.cameraZoom>0){ctx.translate(W/2,H/2);ctx.scale(1+game.cameraZoom,1+game.cameraZoom);ctx.translate(-W/2,-H/2);}if(game.shake>0){const amp=game.shake;ctx.translate(rand(-amp,amp),rand(-amp,amp));}drawWorld();const actors=game.enemies.map(e=>({y:projectPoint(e.x,e.y,e.elevation||0).y,draw:()=>drawEnemy(e)}));actors.push({y:projectPoint(player.x,player.y,player.elevation||0).y,draw:drawPlayer});actors.sort((a,b)=>a.y-b.y);for(const actor of actors)actor.draw();drawEffects();drawCombatFX();if(game.impactFlash>0){ctx.save();ctx.globalAlpha=game.impactFlash*.12;ctx.fillStyle='#fff3d0';ctx.fillRect(0,0,W,H);ctx.restore();}ctx.restore();}

function updateUI(){
  if($('riskValue'))$('riskValue').textContent=game.riskMode?'ON':'OFF';if($('riskToggle'))$('riskToggle').classList.toggle('on',game.riskMode);
  $('healthFill').style.width=clamp(player.hp/player.maxHp*100,0,100)+'%';$('xpFill').style.width=clamp(player.xp/player.xpNeed*100,0,100)+'%';$('healthText').textContent=`${Math.ceil(player.hp)} / ${player.maxHp}`;$('xpText').textContent=`${Math.floor(player.xp)} / ${player.xpNeed} XP`;$('levelLabel').textContent='LVL '+String(player.level).padStart(2,'0');$('goldLabel').textContent=player.gold;$('killsLabel').textContent=player.kills;$('comboLabel').textContent=player.combo?`×${player.combo}`:'—';if($('specialSlot'))$('specialSlot').title=`SOLAR ${currentSolarMode().name} · Press C to cycle`;if($('solarName'))$('solarName').textContent=currentSolarMode().name;
  $('dashCooldown').style.width=(player.dashCd>0?player.dashCd/Math.max(.72,1.25-player.dodgeBonus*.75)*100:0)+'%';$('jumpCooldown').style.width=(player.jumpCd>0?player.jumpCd/.95*100:0)+'%';$('specialCooldown').style.width=(player.specialCd>0?player.specialCd/Math.max(3.8,currentSolarMode().cooldown-player.solarBonus*1.7)*100:0)+'%';if($('riftCooldown'))$('riftCooldown').style.width=(player.riftCd>0?player.riftCd/9.5*100:0)+'%';if($('aetherCooldown'))$('aetherCooldown').style.width=(player.aetherCd>0?player.aetherCd/15*100:0)+'%';
  $('relicCount').textContent=`${runRelics.length} / 6`;$('relicGrid').innerHTML='';for(let i=0;i<6;i++){const el=document.createElement('div');if(runRelics[i]){el.className='relic-item';el.textContent=runRelics[i].icon;el.title=runRelics[i].name;}else{el.className='relic-empty';el.textContent='+';} $('relicGrid').appendChild(el);} $('relicFoot').textContent=runRelics.length?runRelics.map(r=>r.name).join(' · '):'Ancient blessings alter your playstyle.';
  const stepEls=$('progressSteps').children,checkEls=$('objectiveChecks').children;for(let i=0;i<stepEls.length;i++)stepEls[i].className='step '+(i<game.room?'done':i===game.room?'active':'');for(let i=0;i<checkEls.length;i++)checkEls[i].className='check-dot '+(i<game.room?'done':i===game.room?'active':'');
}
function updateTimer(){const secs=Math.floor(player.runTime),m=Math.floor(secs/60),s=secs%60;$('timerLabel').textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;}

let audio=null;
function initAudio(){if(muted)return;try{audio ||= new (window.AudioContext||window.webkitAudioContext)();if(audio.state==='suspended')audio.resume();}catch{}}
function tone(freq,duration,type='sine',volume=.06,slide=0){if(muted)return;initAudio();if(!audio)return;const o=audio.createOscillator(),g=audio.createGain();o.type=type;o.frequency.setValueAtTime(freq,audio.currentTime);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(20,freq+slide),audio.currentTime+duration);g.gain.setValueAtTime(volume,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+duration);}
function sound(name){if(muted)return;const sets={start:[[220,.12,'sine',.035,120],[330,.22,'triangle',.035,80],[440,.32,'sine',.025,-70]],slash:[[145,.08,'sawtooth',.035,330],[310,.055,'triangle',.018,-90]],slash2:[[175,.085,'sawtooth',.04,390],[420,.07,'triangle',.022,-140]],slash3:[[115,.12,'sawtooth',.05,520],[250,.12,'triangle',.035,240],[610,.08,'sine',.025,-180]],slash4:[[90,.16,'sawtooth',.06,720],[230,.14,'triangle',.04,380],[760,.1,'sine',.03,-250]],heavy:[[72,.22,'sawtooth',.065,840],[180,.24,'triangle',.05,520],[420,.15,'sine',.035,-120]],charge:[[155,.18,'sine',.035,430],[310,.22,'triangle',.025,260]],parry:[[520,.07,'triangle',.045,720],[880,.14,'sine',.04,-180]],dash:[[300,.19,'sine',.055,560],[780,.1,'triangle',.018,-440]],jump:[[185,.11,'triangle',.035,160],[390,.16,'sine',.022,250]],hurt:[[110,.22,'triangle',.07,-55]],kill:[[330,.08,'triangle',.045,220],[520,.12,'sine',.02,-80]],portal:[[220,.18,'sine',.05,330],[440,.3,'triangle',.035,180]],reward:[[440,.16,'sine',.04,220],[660,.22,'sine',.03,180]],solar:[[95,.2,'sawtooth',.05,680],[210,.32,'sine',.06,880],[540,.22,'triangle',.028,-130]],level:[[520,.12,'sine',.04,160],[780,.17,'sine',.04,190]],victory:[[330,.22,'triangle',.04,220],[440,.27,'sine',.04,220],[660,.55,'sine',.035,320]],defeat:[[220,.4,'triangle',.04,-100],[110,.5,'sine',.035,-40]]};for(const [f,d,t,v,s] of (sets[name]||[]))tone(f,d,t,v,s);}

document.documentElement.dataset.emberfallVersion='4.1.0';
function loop(now){const dt=clamp((now-game.previousFrame)/1000||0,.001,.033);game.previousFrame=now;if(game.phase==='playing'){if(game.hitStop>0){game.hitStop=Math.max(0,game.hitStop-dt);updateEffects(dt*.45);}else updateGame(dt);}else updateEffects(dt*.55);draw();updateTimer();requestAnimationFrame(loop);}

// Keyboard and pointer input
window.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(['arrowup','arrowdown','arrowleft','arrowright',' '].includes(k))e.preventDefault();input.keys.add(k);if(k==='j'&&!e.repeat)startAttack();if(k==='k'&&!e.repeat)beginHeavyCharge();if(k==='f'&&!e.repeat)grabThrow();if(k==='c'&&!e.repeat)cycleSolarMode();if(k===' '&&!e.repeat)useDash();if(k==='shift'&&!e.repeat)useJump();if(k==='q'&&!e.repeat)useSpecial();if(k==='v'&&!e.repeat)useRiftStep();if(k==='t'&&!e.repeat)useAetherSnare();if(k==='e'&&!e.repeat)interact();if(k==='escape'||k==='p'){if(game.phase==='playing')setPhase('paused');else if(game.phase==='paused')setPhase('playing');}});
window.addEventListener('keyup',e=>{const k=e.key.toLowerCase();input.keys.delete(k);if(k==='k')releaseHeavyCharge();});
function pointerPosition(e){const r=canvas.getBoundingClientRect();input.pointer.x=(e.clientX-r.left)/r.width*W;input.pointer.y=(e.clientY-r.top)/r.height*H;input.pointer.inside=input.pointer.x>=0&&input.pointer.x<=W&&input.pointer.y>=0&&input.pointer.y<=H;}
canvas.addEventListener('pointermove',e=>{pointerPosition(e);if(game.phase==='playing')aimAtPointer();});canvas.addEventListener('pointerenter',e=>{pointerPosition(e);});canvas.addEventListener('pointerleave',()=>{input.pointer.inside=false;});canvas.addEventListener('pointerdown',e=>{pointerPosition(e);if(game.phase!=='playing')return;if(e.button===2){beginHeavyCharge();return;}if(e.button!==0)return;input.pointer.down=true;input.attackHeld=true;startAttack();});window.addEventListener('pointerup',e=>{input.pointer.down=false;input.attackHeld=false;if(e.button===2)releaseHeavyCharge();});canvas.addEventListener('contextmenu',e=>e.preventDefault());
$('riskValue').textContent=game.riskMode?'ON':'OFF';$('riskToggle').classList.toggle('on',game.riskMode);$('riskToggle').addEventListener('click',()=>{game.riskMode=!game.riskMode;meta.riskMode=game.riskMode;$('riskValue').textContent=game.riskMode?'ON':'OFF';$('riskToggle').classList.toggle('on',game.riskMode);persist();showToast(game.riskMode?'EMBER VOW · RISK MODE ENABLED':'RISK MODE DISABLED',.9);});$('startBtn').addEventListener('click',()=>{initAudio();startJourney(false);});$('continueBtn').addEventListener('click',()=>{if(meta.current){initAudio();startJourney(true);}});$('continueBtn').disabled=!meta.current;$('continueMeta').textContent=meta.current?'SAVE FOUND':'— NO SAVE —';$('resumeBtn').addEventListener('click',()=>setPhase('playing'));$('restartBtn').addEventListener('click',()=>{if(confirm('Restart this journey from the beginning?')){clearRunSave();startJourney(false);}});$('playAgainBtn').addEventListener('click',()=>startJourney(false));$('returnMenuBtn').addEventListener('click',()=>setPhase('menu'));
$('helpBtn').addEventListener('click',()=>$('helpModal').classList.remove('hidden'));$('closeHelp').addEventListener('click',()=>$('helpModal').classList.add('hidden'));$('helpModal').addEventListener('click',e=>{if(e.target===$('helpModal'))$('helpModal').classList.add('hidden');});
$('soundToggle').addEventListener('click',()=>{muted=!muted;meta.sound=!muted;persist();$('soundToggle').textContent=muted?'♪̸':'♪';if(!muted){initAudio();tone(440,.08,'sine',.03,130);}});
$('soundToggle').textContent=muted?'♪̸':'♪';$('fullscreenBtn').addEventListener('click',()=>{if(!document.fullscreenElement)frame.requestFullscreen?.();else document.exitFullscreen?.();});

// Mobile touch controls
const joy=$('joystick'),knob=$('joyKnob');let joyPointer=null,joyCenter=null;
joy.addEventListener('pointerdown',e=>{joyPointer=e.pointerId;joy.setPointerCapture(e.pointerId);const r=joy.getBoundingClientRect();joyCenter={x:r.left+r.width/2,y:r.top+r.height/2};moveJoy(e);});
joy.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)moveJoy(e);});function moveJoy(e){if(!joyCenter)return;let dx=e.clientX-joyCenter.x,dy=e.clientY-joyCenter.y;const len=Math.hypot(dx,dy),max=36;if(len>max){dx=dx/len*max;dy=dy/len*max;}input.joy.x=dx/max;input.joy.y=dy/max;knob.style.left=`calc(50% + ${dx}px)`;knob.style.top=`calc(50% + ${dy}px)`;}
function endJoy(){joyPointer=null;joyCenter=null;input.joy.x=input.joy.y=0;knob.style.left='50%';knob.style.top='50%';}joy.addEventListener('pointerup',endJoy);joy.addEventListener('pointercancel',endJoy);joy.addEventListener('lostpointercapture',endJoy);
$('mobileAttack').addEventListener('pointerdown',e=>{e.preventDefault();if(game.phase==='playing'){nearestAngle();startAttack();input.attackHeld=true;}});$('mobileAttack').addEventListener('pointerup',()=>input.attackHeld=false);$('mobileAttack').addEventListener('pointercancel',()=>input.attackHeld=false);$('mobileHeavy').addEventListener('pointerdown',e=>{e.preventDefault();beginHeavyCharge();});$('mobileHeavy').addEventListener('pointerup',()=>releaseHeavyCharge());$('mobileHeavy').addEventListener('pointercancel',()=>releaseHeavyCharge());$('mobileThrow').addEventListener('pointerdown',e=>{e.preventDefault();grabThrow();});$('mobileDash').addEventListener('pointerdown',e=>{e.preventDefault();useDash();});$('mobileJump').addEventListener('pointerdown',e=>{e.preventDefault();useJump();});$('mobileSpecial').addEventListener('pointerdown',e=>{e.preventDefault();nearestAngle();useSpecial();});$('mobileRift').addEventListener('pointerdown',e=>{e.preventDefault();useRiftStep();});$('mobileSnare').addEventListener('pointerdown',e=>{e.preventDefault();useAetherSnare();});

// Keep UI responsive on different device pixel ratios and update HUD safely.
window.addEventListener('resize',()=>{canvas.style.width='100%';});
if('ResizeObserver'in window)new ResizeObserver(()=>{canvas.style.width='100%';}).observe(frame);

// Boot into the title scene with a clean visual, without starting gameplay.
buildBackground();updateUI();setPhase('menu');requestAnimationFrame(loop);
