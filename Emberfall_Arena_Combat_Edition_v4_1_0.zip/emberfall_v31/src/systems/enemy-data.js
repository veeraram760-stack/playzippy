// Regular enemies should survive a single sword contact, including a max-charge critical.
export const ENEMY_BASE = {
  stalker: { hp: 155, speed: 80, damage: 10, r: 19, xp: 17 },
  archer:  { hp: 142, speed: 58, damage: 9,  r: 17, xp: 20 },
  brute:   { hp: 310, speed: 44, damage: 18, r: 27, xp: 29 },
  wisp:    { hp: 126, speed: 73, damage: 8,  r: 15, xp: 18 },
  shade:   { hp: 188, speed: 104, damage: 14, r: 19, xp: 34 }
};

export function getEnemyProfile(kind, stage = 0, room = 0, riskMode = false) {
  const base = ENEMY_BASE[kind];
  if (!base) throw new Error(`Unknown enemy kind: ${kind}`);
  const stageScale = (1 + stage * 0.28 + (room === 1 ? 0.16 : 0)) * (riskMode ? 1.24 : 1);
  return {
    ...base,
    hp: Math.round(base.hp * stageScale),
    maxHp: Math.round(base.hp * stageScale),
    speed: base.speed * (1 + stage * 0.12),
    damage: base.damage * (1 + stage * 0.18)
  };
}
