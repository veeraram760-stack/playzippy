import assert from 'node:assert/strict';
import { getEncounterWaves } from '../src/systems/encounter-data.js';
const validKinds=new Set(['stalker','archer','wisp','brute','shade']);
for(let stage=0;stage<4;stage++){const rooms=stage===3?4:3;for(let room=0;room<rooms;room++){const waves=getEncounterWaves(stage,room,false);assert.equal(waves.length,3);assert.ok(waves.every(w=>w.length>=2));for(const e of waves.flat()){assert.ok(validKinds.has(e.kind));assert.equal(typeof e.elite,'boolean');}assert.ok(waves[2].some(e=>e.elite));const risk=getEncounterWaves(stage,room,true);assert.ok(risk.every((w,i)=>w.length>=waves[i].length));}}
assert.ok(getEncounterWaves(3,3,true).flat().some(e=>e.kind==='shade'&&e.elite));
console.log('Encounter tests passed: four realms, fifteen chambers, Shade Assassin waves, elite capstones and risk mode.');
