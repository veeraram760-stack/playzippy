# PlayZippy — Season 1: Astra Reclaimer: Sector Zero

PlayZippy is a responsive browser-game portal built with React and Vite. This release expands the featured game into a longer-form action roguelite campaign focused on meaningful run decisions, replayability and local progression.

## Featured game: Astra Reclaimer

- Five 3-minute sectors (approximately 15 minutes of survival before boss intermissions), with five boss encounters and distinct boss projectile patterns.
- Four operators with signature active abilities: Rift Pulse, Bastion Core, Phase Bloom and Sentinel Array.
- Elite hunter events appear during each sector and grant bonus salvage.
- Four weapon evolutions unlock through upgrade synergies.
- Story, Standard and Veteran difficulty. Veteran increases enemy and boss pressure and pays more salvage.
- Campaign, Endless Descent and Daily Contract modes.
- Permanent workshop upgrades, operator unlocks, daily progress and one-time commendations.
- Progress is stored locally in the player's browser. There are no cross-device cloud saves or global leaderboards in this release.

## Other games

- Starfall Assault — arcade space shooter.
- Neon Drift — endless traffic racer.
- Crystal Cascade — match-three puzzle.
- Panda Dash — jungle platform runner.
- Block Master — block placement puzzle.
- Memory Match — card matching.

## Run locally

Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

Vite outputs the production site into `dist/`.

## Astra Reclaimer controls

- Desktop movement: WASD or arrow keys.
- Dash: Space or Shift.
- Operator signature skill: Q.
- Mobile: use the directional pad and on-screen Dash / Skill controls; drag inside the arena also steers movement.
- Weapons auto-fire. Collect XP, choose an upgrade at each level, hunt elite enemies, defeat each boss and select salvage between sectors.

## Deployment

Cloudflare Pages is connected to the `main` branch. The build command extracts the latest release ZIP stored at the repository root, installs dependencies and runs `npm run build`, publishing `dist/`.

## Release limitations

- This is an original browser game inspired by broad genre patterns. It does not copy proprietary characters, levels, art or assets from other games.
- The build has passed Cloudflare's production build/deploy pipeline for the previous release. This source update must complete a fresh Cloudflare build before being considered live.
- Gameplay changes have had JSX syntax validation but still require hands-on playtesting across desktop and mobile browsers.
- No ad network scripts are enabled. Add provider approval, publisher IDs and any required consent management before monetization.
- Replace placeholder publisher contact details in legal pages before a commercial launch.
- No account system, multiplayer, cloud saves or server-backed leaderboards are enabled.
