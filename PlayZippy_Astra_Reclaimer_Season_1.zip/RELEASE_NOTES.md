# PlayZippy Season 1 — Astra Reclaimer update

This release focuses on retention through meaningful run decisions and long-term progression instead of adding more short score-only mini-games.

## Gameplay additions

- Four operators, each with a different active ability on Q (or the mobile Skill button).
- Story, Standard and Veteran expedition difficulty; Veteran increases enemy/boss pressure and salvage payout.
- Elite hunter events in every sector; elite defeats grant bonus crystals and larger XP/salvage drops.
- Five sector-specific boss projectile patterns, each gaining a more dangerous second phase below 55% health.
- Four one-time commendations with permanent crystal rewards for boss clears, elite hunts, deep builds and a full campaign clear.
- New operator Sentinel Array: deploys three temporary auto-firing sentry drones.

## Existing systems retained

- Five-sector campaign, Endless Descent and Daily Contract.
- Four weapon evolutions, random level-up upgrade drafts and salvage choices between bosses.
- Permanent workshop upgrades, operator unlocks and local browser saves.

## Known limitations

- Saves remain on the current device/browser using localStorage; no online account, shared leaderboard or cross-device save.
- Gameplay has not been independently playtested by a human on all devices. Cloudflare must complete a fresh production build after release upload.
