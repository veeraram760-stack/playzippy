const W = 1280, H = 720;
const $ = (id) => document.getElementById(id);
const canvas = $('game');
const ctx = canvas.getContext('2d', { alpha: false });
const frame = $('canvasFrame');
const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const lerp = (a,b,t) => a + (b-a)*t;
const rand = (a,b) => a + Math.random()*(b-a);
const choice = (arr) => arr[Math.floor(Math.random()*arr.length)];
const easeOut = t => 1 - Math.pow(1-t, 3);

const realms = [
  { name:'THE VERDANT HOLLOW', roomNames:['MOSS GATE','ROOTBOUND CHAPEL','THE ROOTBOUND WARDEN'], tag:'REALM I · THE ROOTS', title:'The Verdant Hollow', desc:'A forest swallowed by a living blight. Even the old stones have begun to breathe.', palette:{sky:'#243a31',floor:'#304536',floor2:'#40563d',line:'#68734b',accent:'#a9ba77',glow:'#c6d77e',portal:'#9fc58f',mist:'#91a98a'}, objective:'Break the root seals' },
  { name:'THE ASHEN FOUNDRY', roomNames:['CINDER WALK','THE BROKEN FURNACE','THE ASHEN COLOSSUS'], tag:'REALM II · THE EMBERS', title:'The Ashen Foundry', desc:'A kingdom of black iron and sleeping furnaces, where every breath tastes of old fire.', palette:{sky:'#402a27',floor:'#49362e',floor2:'#5e4435',line:'#89634b',accent:'#df9860',glow:'#f5a46b',portal:'#ed9b69',mist:'#bd806a'}, objective:'Quench the furnace heart' },
  { name:'THE MOONWELL KEEP', roomNames:['SILVER APPROACH','THE FLOODED ARCHIVE','THE HOLLOW CROWN'], tag:'REALM III · THE VEIL', title:'The Moonwell Keep', desc:'A drowned palace caught between moonlight and shadow. The Crown waits below.', palette:{sky:'#2b2f4b',floor:'#3d425f',floor2:'#505677',line:'#8588a8',accent:'#b6b9e2',glow:'#d9ddff',portal:'#b8c7e9',mist:'#98a2ce'}, objective:'Shatter the Hollow Crown' }
];

const images = {};
for (const name of ['hero','thornling','archer','wisp','brute','boss']) {
  const img = new Image(); img.src = `/art/${name}.svg`; images[name] = img;
}

const saveKey = 'playzippy_emberfall_save_v1';
let stored = {};
try { stored = JSON.parse(localStorage.getItem(saveKey) || '{}'); } catch { stored = {}; }
const meta = { bestTime: stored.bestTime || 0, bestKills: stored.bestKills || 0, current: stored.current || null, sound: stored.sound !== false };
let muted = !meta.sound;

const player = {
  x:640,y:520,vx:0,vy:0,r:17,hp:100,maxHp:100,speed:235,damage:23,attackCd:0,attackTime:0,attackAngle:-Math.PI/2,attackApplied:false,combo:0,comboTimer:0,
  dashCd:0,dashTime:0,dashVX:0,dashVY:0,invuln:0,specialCd:0,level:1,xp:0,xpNeed:100,gold:0,kills:0,damageBonus:0,solarBonus:0,dodgeBonus:0,critBonus:0,regen:0,runTime:0
};
const game = {
  phase:'menu',stage:0,room:0,enemies:[],projectiles:[],particles:[],pickups:[],floaters:[],decor:[],portal:null,boss:null,roomCleared:false,roomTime:0,roomKills:0,shake:0,toastTimer:0,toastText:'',rewardOptions:[],pendingTransition:null,sessionStart:0,continued:false,previousFrame:0
};
const input = { keys:new Set(), pointer:{x:640,y:360,down:false,inside:false}, joy:{x:0,y:0,active:false}, attackHeld:false };
const background = document.createElement('canvas'); background.width=W; background.height=H;
const bg = background.getContext('2d');

const relicPool = [
  {id:'sunsteel',name:'Sunsteel Edge',icon:'✦',rarity:'WEAPON · RARE',desc:'Your blade bites deeper. +22% attack damage.',apply:()=>{player.damageBonus+=.22;}},
  {id:'hearth',name:'Hearthstone Core',icon:'♥',rarity:'VITALITY · RARE',desc:'A warm pulse returns. +24 maximum health and heal 24.',apply:()=>{player.maxHp+=24;player.hp=Math.min(player.maxHp,player.hp+24);}},
  {id:'swift',name:'Swift Ember',icon:'➶',rarity:'MOBILITY · UNCOMMON',desc:'Move like a spark. Dodge cooldown reduced by 18%.',apply:()=>{player.dodgeBonus+=.18;}},
  {id:'solar',name:'Solar Lens',icon:'☼',rarity:'ARCANA · RARE',desc:'Your burst burns brighter. +35% solar damage and radius.',apply:()=>{player.solarBonus+=.35;}},
  {id:'hunters',name:'Hunter’s Thread',icon:'⌖',rarity:'PRECISION · UNCOMMON',desc:'Find the gaps. +8% chance to land a critical strike.',apply:()=>{player.critBonus+=.08;}},
  {id:'moss',name:'Mossbound Vow',icon:'❧',rarity:'RECOVERY · UNCOMMON',desc:'The forest lends its strength. Restore 1.5 health each second.',apply:()=>{player.regen+=1.5;}},
  {id:'cinder',name:'Cinder Rhythm',icon:'♫',rarity:'TECHNIQUE · RARE',desc:'A faster blade. Combo strikes recover 13% sooner.',apply:()=>{player.attackHaste=(player.attackHaste||0)+.13;}},
  {id:'ward',name:'Warden’s Sigil',icon:'◇',rarity:'WARDING · RARE',desc:'A sliver of old protection. +12% maximum health.',apply:()=>{player.maxHp=Math.round(player.maxHp*1.12);player.hp=Math.min(player.maxHp,player.hp+12);}}
];

function persist() {
  try { localStorage.setItem(saveKey, JSON.stringify({bestTime:meta.bestTime,bestKills:meta.bestKills,current:meta.current,sound:!muted})); $('saveStatus').textContent='PROGRESS SAVED'; }
  catch { $('saveStatus').textContent='SAVE UNAVAILABLE'; }
}
function snapshotRun() {
  return {stage:game.stage,room:game.room,hp:player.hp,maxHp:player.maxHp,damage:player.damageBonus,solar:player.solarBonus,dodge:player.dodgeBonus,crit:player.critBonus,regen:player.regen,attackHaste:player.attackHaste||0,level:player.level,xp:player.xp,xpNeed:player.xpNeed,gold:player.gold,kills:player.kills,runTime:player.runTime,relics:[...runRelics]};
}
let runRelics = [];
function clearRunSave(){meta.current=null;persist();}
function resetPlayer(){
  Object.assign(player,{x:640,y:515,vx:0,vy:0,r:17,hp:100,maxHp:100,speed:235,damage:23,attackCd:0,attackTime:0,attackAngle:-Math.PI/2,attackApplied:false,combo:0,comboTimer:0,dashCd:0,dashTime:0,dashVX:0,dashVY:0,invuln:0,specialCd:0,level:1,xp:0,xpNeed:100,gold:0,kills:0,damageBonus:0,solarBonus:0,dodgeBonus:0,critBonus:0,regen:0,runTime:0,attackHaste:0});
  runRelics=[];
}
function startJourney(continueSaved=false){
  resetPlayer();game.stage=0;game.room=0;game.sessionStart=performance.now();game.continued=continueSaved;
  if(continueSaved && meta.current){const s=meta.current;game.stage=clamp(s.stage||0,0,2);game.room=clamp(s.room||0,0,2);Object.assign(player,{hp:s.hp||100,maxHp:s.maxHp||100,damageBonus:s.damage||0,solarBonus:s.solar||0,dodgeBonus:s.dodge||0,critBonus:s.crit||0,regen:s.regen||0,attackHaste:s.attackHaste||0,level:s.level||1,xp:s.xp||0,xpNeed:s.xpNeed||100,gold:s.gold||0,kills:s.kills||0,runTime:s.runTime||0});runRelics=s.relics||[];}
  player.x=640;player.y=520;player.vx=player.vy=0;player.attackCd=0;player.dashCd=0;player.specialCd=0;
  loadEncounter();setPhase('playing');$('chapterPill').textContent=`CHAPTER ${['I','II','III'][game.stage]} · ${realms[game.stage].name}`;showToast(continueSaved?'THE EMBERS REMEMBER YOU':'THE JOURNEY BEGINS',1.9);sound('start');
  updateUI();
}
function setPhase(phase){
  game.phase=phase;
  const overlay=$('overlay');
  if(phase==='playing'){overlay.classList.add('hidden');}
  else {overlay.classList.remove('hidden');$('menuPanel').classList.toggle('hidden',phase!=='menu');$('pausePanel').classList.toggle('hidden',phase!=='paused');$('rewardPanel').classList.toggle('hidden',phase!=='reward');$('endPanel').classList.toggle('hidden',phase!=='victory'&&phase!=='defeat');}
}
function showToast(text,duration=1.4){game.toastText=text;game.toastTimer=duration;$('toast').textContent=text;$('toast').classList.add('show');}
function createRng(seed){let s=seed>>>0;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}

function buildBackground(){
  const p=realms[game.stage].palette;const randBG=createRng((game.stage+1)*91+game.room*17);
  const sky=bg.createLinearGradient(0,0,0,H);sky.addColorStop(0,p.sky);sky.addColorStop(.62,p.floor);sky.addColorStop(1,'#17231c');bg.fillStyle=sky;bg.fillRect(0,0,W,H);
  // atmospheric light pools
  const halo=bg.createRadialGradient(640,210,20,640,300,590);halo.addColorStop(0,p.glow+'28');halo.addColorStop(1,'transparent');bg.fillStyle=halo;bg.fillRect(0,0,W,H);
  // arena floor, hand-laid irregular stone tiles
  bg.save();bg.beginPath();bg.roundRect(52,65,1176,610,38);bg.clip();
  bg.fillStyle=p.floor;bg.fillRect(52,65,1176,610);
  for(let row=0;row<12;row++){
    for(let col=0;col<17;col++){
      const x=48+col*72+(row%2)*34,y=64+row*53;const w=65+randBG()*9,h=43+randBG()*8;const tone=randBG();
      bg.fillStyle=tone>.66?p.floor2:tone<.13?'#1b3028':p.floor;bg.globalAlpha=.25+randBG()*.18;
      bg.beginPath();bg.roundRect(x+2,y+2,w,h,4+randBG()*7);bg.fill();bg.globalAlpha=1;
      bg.strokeStyle=p.line;bg.globalAlpha=.14;bg.lineWidth=1;bg.stroke();bg.globalAlpha=1;
      if(randBG()>.68){bg.fillStyle=p.accent;bg.globalAlpha=.16;bg.beginPath();bg.ellipse(x+randBG()*w,y+randBG()*h,randBG()*12+3,randBG()*3+1,randBG(),0,TAU);bg.fill();bg.globalAlpha=1;}
    }
  }
  // worn circular dais
  bg.strokeStyle=p.accent;bg.globalAlpha=.18;bg.lineWidth=2;bg.beginPath();bg.ellipse(640,356,280,174,0,0,TAU);bg.stroke();bg.beginPath();bg.ellipse(640,356,251,151,0,0,TAU);bg.stroke();bg.globalAlpha=1;
  for(let i=0;i<12;i++){const a=i/12*TAU;const x=640+Math.cos(a)*264,y=356+Math.sin(a)*160;bg.save();bg.translate(x,y);bg.rotate(a);bg.fillStyle=p.line;bg.globalAlpha=.3;bg.beginPath();bg.roundRect(-12,-5,24,10,2);bg.fill();bg.restore();bg.globalAlpha=1;}
  // edge parapets and broken masonry
  for(let i=0;i<18;i++){let x=70+i*66+randBG()*15;const y=i%2?77:645;bg.fillStyle=i%3===0?'#17231d':p.floor2;bg.globalAlpha=.7;bg.beginPath();bg.roundRect(x,y,38+randBG()*28,21+randBG()*12,5);bg.fill();bg.globalAlpha=1;bg.strokeStyle=p.line;bg.globalAlpha=.35;bg.stroke();bg.globalAlpha=1;}
  // moss, ash or moon flowers / stones
  for(let i=0;i<105;i++){const x=65+randBG()*1150,y=78+randBG()*580;if(x>390&&x<890&&y>190&&y<555&&randBG()>.20)continue;const size=2+randBG()*7;bg.globalAlpha=.18+randBG()*.25;bg.fillStyle=game.stage===0?(randBG()>.5?'#a8c17b':'#758f61'):game.stage===1?(randBG()>.5?'#d9865c':'#695149'):'#a7b3df';bg.beginPath();bg.ellipse(x,y,size,size*.42,randBG()*TAU,0,TAU);bg.fill();bg.globalAlpha=1;}
  // decorative pillars or crystals around the outskirts
  for(let i=0;i<13;i++){const x=100+randBG()*1080,y=90+randBG()*535;if(x>480&&x<800&&y>255&&y<480)continue;const h=18+randBG()*35;bg.fillStyle=game.stage===1?'#483b37':game.stage===2?'#4c5270':'#43513c';bg.beginPath();bg.moveTo(x-10,y);bg.lineTo(x-6,y-h);bg.lineTo(x+5,y-h-5);bg.lineTo(x+13,y-2);bg.closePath();bg.fill();bg.strokeStyle=p.line;bg.globalAlpha=.28;bg.stroke();bg.globalAlpha=1;}
  // region-specific landmarks: living roots, furnace iron, and moonlit water
  if(game.stage===0){
    bg.save();bg.lineCap='round';bg.lineJoin='round';
    for(const side of [0,1]){const x=side?1210:70;bg.strokeStyle='#172b20';bg.lineWidth=34;bg.beginPath();bg.moveTo(x,95);bg.bezierCurveTo(x+(side?-58:58),190,x+(side?30:-30),215,x,300);bg.bezierCurveTo(x+(side?-45:45),382,x+(side?30:-30),430,x+(side?0:0),575);bg.stroke();bg.strokeStyle='#617b4c';bg.globalAlpha=.5;bg.lineWidth=4;bg.beginPath();bg.moveTo(x+(side?-8:8),100);bg.bezierCurveTo(x+(side?-48:48),190,x+(side?26:-26),215,x+(side?-4:4),300);bg.stroke();bg.globalAlpha=1;}
    for(const [x,y,scale] of [[145,130,.85],[1136,155,1],[125,550,1.05],[1143,555,.8]]){bg.save();bg.translate(x,y);bg.scale(scale,scale);bg.fillStyle='#1a2d22';bg.beginPath();bg.moveTo(-8,50);bg.lineTo(-15,-8);bg.lineTo(-33,-28);bg.lineTo(-8,-22);bg.lineTo(0,-62);bg.lineTo(11,-22);bg.lineTo(34,-36);bg.lineTo(17,-3);bg.lineTo(13,50);bg.closePath();bg.fill();bg.strokeStyle='#64784b';bg.globalAlpha=.42;bg.lineWidth=3;bg.stroke();bg.restore();}
    for(let i=0;i<16;i++){const x=115+randBG()*1050,y=100+randBG()*520;if(x>330&&x<950&&y>205&&y<540)continue;bg.fillStyle='#c0d17f';bg.globalAlpha=.34;bg.beginPath();bg.ellipse(x,y,3+randBG()*4,2,randBG()*TAU,0,TAU);bg.fill();bg.globalAlpha=1;}
    bg.restore();
  }else if(game.stage===1){
    bg.save();
    for(const [x,y] of [[105,135],[1175,145],[105,555],[1178,550]]){bg.fillStyle='#211d1c';bg.beginPath();bg.roundRect(x-27,y-42,54,84,7);bg.fill();bg.strokeStyle='#986249';bg.lineWidth=3;bg.stroke();const glow=bg.createRadialGradient(x,y,4,x,y,85);glow.addColorStop(0,'#f59a5c66');glow.addColorStop(1,'transparent');bg.fillStyle=glow;bg.fillRect(x-85,y-85,170,170);bg.fillStyle='#e58a55';bg.globalAlpha=.7;bg.beginPath();bg.moveTo(x,y-25);bg.quadraticCurveTo(x+20,y+1,x,y+16);bg.quadraticCurveTo(x-19,y+1,x,y-25);bg.fill();bg.globalAlpha=1;}
    bg.strokeStyle='#9d533b';bg.lineWidth=5;bg.globalAlpha=.38;for(let i=0;i<8;i++){const x=180+i*135;bg.beginPath();bg.moveTo(x,100);bg.lineTo(x+randBG()*38-19,160+randBG()*80);bg.lineTo(x-14+randBG()*28,210+randBG()*65);bg.stroke();}bg.globalAlpha=1;
    for(let i=0;i<32;i++){const x=80+randBG()*1120,y=85+randBG()*560;bg.fillStyle=randBG()>.5?'#e28c5b':'#ffd18a';bg.globalAlpha=.22+randBG()*.28;bg.beginPath();bg.arc(x,y,1+randBG()*2.2,0,TAU);bg.fill();}bg.globalAlpha=1;bg.restore();
  }else{
    bg.save();
    for(const [x,y,rx,ry] of [[165,250,76,31],[1115,265,83,29],[150,550,58,22],[1118,540,70,27]]){const water=bg.createRadialGradient(x,y,3,x,y,Math.max(rx,ry));water.addColorStop(0,'#9caedb88');water.addColorStop(.55,'#687bb466');water.addColorStop(1,'transparent');bg.fillStyle=water;bg.beginPath();bg.ellipse(x,y,rx,ry,0,0,TAU);bg.fill();bg.strokeStyle='#b2c3e8';bg.globalAlpha=.35;bg.lineWidth=2;bg.beginPath();bg.ellipse(x,y,rx*.72,ry*.58,0,0,TAU);bg.stroke();bg.globalAlpha=1;}
    for(const [x,y] of [[118,180],[1160,175],[120,590],[1160,590]]){bg.fillStyle='#4c5474';bg.beginPath();bg.roundRect(x-14,y-42,28,84,4);bg.fill();bg.fillStyle='#a8b6dc';bg.globalAlpha=.35;bg.fillRect(x-19,y-46,38,7);bg.globalAlpha=1;bg.strokeStyle='#8f9cc6';bg.globalAlpha=.28;bg.strokeRect(x-14,y-42,28,84);bg.globalAlpha=1;}
    bg.strokeStyle='#b8c7eb';bg.globalAlpha=.23;bg.lineWidth=2;for(let i=0;i<9;i++){const x=180+i*115,y=110+(i%3)*8;bg.beginPath();bg.moveTo(x,y);bg.lineTo(x+10,y+12);bg.lineTo(x,y+24);bg.lineTo(x-10,y+12);bg.closePath();bg.stroke();}bg.globalAlpha=1;bg.restore();
  }
  // fine rune marks
  bg.strokeStyle=p.glow;bg.lineWidth=1;bg.globalAlpha=.15;
  for(let i=0;i<7;i++){const x=250+i*130,y=350+(i%2?18:-18);bg.beginPath();bg.moveTo(x,y-10);bg.lineTo(x+8,y);bg.lineTo(x,y+10);bg.lineTo(x-8,y);bg.closePath();bg.stroke();}
  bg.globalAlpha=1;bg.restore();
  // ornamental outer border
  bg.strokeStyle=p.accent;bg.globalAlpha=.25;bg.lineWidth=2;bg.beginPath();bg.roundRect(43,56,1194,628,42);bg.stroke();bg.globalAlpha=1;
  const shade=bg.createLinearGradient(0,0,0,H);shade.addColorStop(0,'rgba(4,10,8,.38)');shade.addColorStop(.25,'transparent');shade.addColorStop(.78,'transparent');shade.addColorStop(1,'rgba(4,10,8,.45)');bg.fillStyle=shade;bg.fillRect(0,0,W,H);
}

function spawnEnemy(kind,x,y,boss=false){
  const base={stalker:{hp:58,speed:80,damage:10,r:19,xp:17},archer:{hp:46,speed:58,damage:9,r:17,xp:20},brute:{hp:132,speed:44,damage:18,r:27,xp:29},wisp:{hp:38,speed:73,damage:8,r:15,xp:18}};
  if(boss){const hp=game.stage===0?900:game.stage===1?1120:1420;const e={kind:'boss',x,y,r:62,hp,maxHp:hp,speed:66,damage:22,xp:220,attackCd:2.6,state:'idle',stateT:0,flash:0,phase:1,seed:rand(0,10),boss:true,chargeVX:0,chargeVY:0};game.enemies.push(e);game.boss=e;return e;}
  const d=base[kind];const stageScale=1+game.stage*.28+(game.room===1?.16:0);const e={kind,x,y,r:d.r,hp:d.hp*stageScale,maxHp:d.hp*stageScale,speed:d.speed*(1+game.stage*.12),damage:d.damage*(1+game.stage*.18),xp:d.xp,attackCd:rand(.4,1.5),state:'idle',stateT:0,flash:0,seed:rand(0,10),chargeVX:0,chargeVY:0};game.enemies.push(e);return e;
}
function spawnAtEdge(kind){const side=Math.floor(rand(0,4));let x,y;if(side===0){x=rand(130,1150);y=rand(115,155);}else if(side===1){x=rand(130,1150);y=rand(575,615);}else if(side===2){x=rand(100,145);y=rand(170,580);}else{x=rand(1135,1180);y=rand(170,580);}return spawnEnemy(kind,x,y);}
function loadEncounter(){
  const p=realms[game.stage];game.enemies=[];game.projectiles=[];game.particles=[];game.pickups=[];game.floaters=[];game.portal=null;game.boss=null;game.roomCleared=false;game.roomTime=0;game.roomKills=0;player.x=640;player.y=515;player.vx=player.vy=0;player.combo=0;player.comboTimer=0;player.invuln=.65;
  buildBackground();
  const isBoss=game.room===2;
  if(isBoss){spawnEnemy('boss',640,290,true);const minions=game.stage===2?3:2;for(let i=0;i<minions;i++)spawnAtEdge(i%2?'wisp':'stalker');$('bossHud').style.display='block';$('objectiveLabel').textContent='DEFEAT THE WARDEN';}
  else {const count=(game.room===0?5:7)+game.stage;const pattern=game.stage===0?['stalker','stalker','archer','stalker','wisp','brute']:game.stage===1?['stalker','archer','brute','wisp','archer','brute','stalker','wisp']:['wisp','archer','brute','stalker','archer','wisp','brute','stalker','archer'];for(let i=0;i<count;i++)spawnAtEdge(pattern[i%pattern.length]);$('bossHud').style.display='none';$('objectiveLabel').textContent='CLEAR THE CORRUPTION';}
  $('locationLabel').textContent=p.name;$('roomLabel').textContent=p.roomNames[game.room];$('chapterPill').textContent=`CHAPTER ${['I','II','III'][game.stage]} · ${p.name}`;$('realmTag').textContent=p.tag;$('realmTitle').textContent=p.title;$('realmDesc').textContent=p.desc;$('objectiveTitle').textContent=p.objective;$('objectiveCopy').textContent=isBoss?'Break the guardian. The ember gate will carry you onward.':'Defeat every guardian in this chamber. Reach the glowing gate when it opens.';
  $('realmArt').dataset.stage=game.stage;$('progressSteps').innerHTML='<span class="step active"></span><span class="step"></span><span class="step"></span>';
  $('bottomHint').textContent=isBoss?'THE GUARDIAN STANDS BETWEEN YOU AND THE NEXT REALM':'DEFEAT THE GUARDIANS TO OPEN THE WAY';updateUI();
}
function openPortal(){
  if(game.roomCleared)return;game.roomCleared=true;$('bossHud').style.display='none';game.portal={x:640,y:151,r:48,pulse:0};$('objectiveLabel').textContent='GATE OPEN · APPROACH';$('bottomHint').textContent='APPROACH THE EMBER GATE AND PRESS E';$('interactionHint').style.display='flex';
  showToast(game.room===2?'THE GUARDIAN HAS FALLEN':'THE CHAMBER IS CLEARED',2);sound('portal');
  for(let i=0;i<34;i++)particle(640,151,choice(['#f0cf93','#9fcca1','#d49c68']),rand(1,4),rand(-2,2),rand(-3,-.2),rand(.5,1.6));
  player.hp=Math.min(player.maxHp,player.hp+Math.max(5,player.maxHp*.07));player.gold+=12+game.stage*7;persistCurrent();updateUI();
}
function persistCurrent(){meta.current=snapshotRun();persist();}
function interactPortal(){if(!game.portal||dist(player,game.portal)>105)return;sound('portal');game.pendingTransition=game.room===2&&game.stage===2?'victory':'next';openReward();}
function openReward(){
  game.rewardOptions=[];const candidates=[...relicPool];while(game.rewardOptions.length<3&&candidates.length){const i=Math.floor(Math.random()*candidates.length);game.rewardOptions.push(candidates.splice(i,1)[0]);}
  const cards=$('rewardCards');cards.innerHTML='';for(const relic of game.rewardOptions){const el=document.createElement('button');el.className='reward-card';el.innerHTML=`<span class="reward-icon">${relic.icon}</span><b>${relic.name}</b><p>${relic.desc}</p><span class="reward-rarity">${relic.rarity}</span>`;el.addEventListener('click',()=>chooseReward(relic));cards.appendChild(el);}
  $('rewardIntro').textContent=game.room===2?'The guardian’s core yields a fragment of its power.':'A quiet ember rises from the chamber floor.';setPhase('reward');
}
function chooseReward(relic){
  relic.apply();runRelics.push(relic);if(runRelics.length>6)runRelics.shift();sound('reward');
  if(game.pendingTransition==='victory'){finishRun(true);return;}
  if(game.room===2){game.stage++;game.room=0;}else game.room++;
  game.pendingTransition=null;loadEncounter();persistCurrent();setPhase('playing');showToast(`${relic.name.toUpperCase()} · BLESSING CLAIMED`,1.8);updateUI();
}
function finishRun(won){
  const time=player.runTime;const secs=Math.floor(time),minutes=Math.floor(secs/60),rest=secs%60;const pretty=`${String(minutes).padStart(2,'0')}:${String(rest).padStart(2,'0')}`;
  $('endSymbol').textContent=won?'✧':'✕';$('endKicker').textContent=won?'THE LIGHT ENDURES':'THE EMBERS FADE';$('endTitle').textContent=won?'The Hollow Crown is broken.':'The dark takes the path.';$('endCopy').textContent=won?'Three realms breathe again. Somewhere, a new hearth is kindled.':'Lyra falls, but the old fire remembers. Rise again and finish what you began.';
  $('runResults').innerHTML=`<div><b>${pretty}</b><small>TIME</small></div><div><b>${player.kills}</b><small>GUARDIANS</small></div><div><b>${player.level}</b><small>LEVEL</small></div><div><b>${player.gold}</b><small>SHARDS</small></div>`;
  if(won){if(!meta.bestTime||time<meta.bestTime)meta.bestTime=time;meta.bestKills=Math.max(meta.bestKills,player.kills);meta.current=null;}else{meta.current=null;}persist();$('continueBtn').disabled=!meta.current;$('continueMeta').textContent=meta.current?'SAVE FOUND':'— NO SAVE —';setPhase(won?'victory':'defeat');sound(won?'victory':'defeat');
}

function particle(x,y,color,size,vx,vy,life=0.6){game.particles.push({x,y,color,size,vx,vy,life,max:life,drag:.94});}
function burst(x,y,color,count=12,scale=1){for(let i=0;i<count;i++){const a=rand(0,TAU),s=rand(40,240)*scale;particle(x,y,color,rand(1.5,4)*scale,Math.cos(a)*s,Math.sin(a)*s,rand(.25,.8));}}
function floater(x,y,text,color='#ffe2a4',size=15){game.floaters.push({x,y,text,color,size,life:.8,max:.8,vy:-36});}
function dropLoot(e){game.pickups.push({x:e.x+rand(-11,11),y:e.y+rand(-11,11),kind:'xp',value:e.boss?e.xp:e.xp*.7,life:16,phase:rand(0,TAU)});if(Math.random()<.48||e.boss)game.pickups.push({x:e.x+rand(-17,17),y:e.y+rand(-17,17),kind:'gold',value:e.boss?28:4+Math.floor(rand(0,5)),life:15,phase:rand(0,TAU)});}
function killEnemy(e){const i=game.enemies.indexOf(e);if(i<0)return;game.enemies.splice(i,1);if(e===game.boss)game.boss=null;player.kills++;game.roomKills++;dropLoot(e);burst(e.x,e.y,e.boss?'#f0c27e':realms[game.stage].palette.glow,e.boss?40:16,e.boss?1.8:1);floater(e.x,e.y-18,e.boss?'WARDEN BROKEN':'+'+Math.round(e.xp)+' XP','#e8d59f',e.boss?18:12);sound('kill');if(game.enemies.length===0)openPortal();updateUI();}
function damageEnemy(e,amount,crit=false){if(e.hp<=0)return;e.hp-=amount;e.flash=.13;e.stateT=Math.max(e.stateT||0,0);floater(e.x+rand(-12,12),e.y-e.r,Math.round(amount),crit?'#fff1a5':'#e7d4ae',crit?17:13);for(let i=0;i<5;i++)particle(e.x,e.y,crit?'#ffe59d':'#d9bd8a',rand(1.5,3),rand(-85,85),rand(-95,35),.22);if(e.hp<=0)killEnemy(e);}
function damagePlayer(amount,sourceX,sourceY){if(player.invuln>0||game.phase!=='playing')return;player.hp-=amount;player.invuln=.65;game.shake=12;sound('hurt');burst(player.x,player.y,'#e88769',12,.65);floater(player.x,player.y-27,'-'+Math.round(amount),'#f08e75',18);if(sourceX!==undefined){const a=Math.atan2(player.y-sourceY,player.x-sourceX);player.vx+=Math.cos(a)*150;player.vy+=Math.sin(a)*150;}if(player.hp<=0){player.hp=0;updateUI();finishRun(false);}updateUI();}

function aimAtPointer(){if(input.pointer.inside){player.attackAngle=Math.atan2(input.pointer.y-player.y,input.pointer.x-player.x);}}
function nearestAngle(){let nearest=null,best=Infinity;for(const e of game.enemies){const d=dist(player,e);if(d<best){best=d;nearest=e;}}if(nearest)player.attackAngle=Math.atan2(nearest.y-player.y,nearest.x-player.x);}
function startAttack(){if(game.phase!=='playing'||player.attackCd>0||player.dashTime>0)return;aimAtPointer();if(!input.pointer.inside)nearestAngle();player.combo=player.comboTimer>0?(player.combo%3)+1:1;player.comboTimer=.62;player.attackTime=.26;player.attackApplied=false;player.attackCd=Math.max(.18,.38-(player.attackHaste||0)*.3);sound('slash');}
function useDash(){if(game.phase!=='playing'||player.dashCd>0)return;let dx=(input.keys.has('d')||input.keys.has('arrowright')?1:0)-(input.keys.has('a')||input.keys.has('arrowleft')?1:0)+input.joy.x;let dy=(input.keys.has('s')||input.keys.has('arrowdown')?1:0)-(input.keys.has('w')||input.keys.has('arrowup')?1:0)+input.joy.y;let l=Math.hypot(dx,dy);if(l<.1){dx=Math.cos(player.attackAngle);dy=Math.sin(player.attackAngle);l=1;}dx/=l;dy/=l;player.dashVX=dx*640;player.dashVY=dy*640;player.dashTime=.19;player.invuln=.32;player.dashCd=Math.max(.72,1.25-player.dodgeBonus*.75);sound('dash');burst(player.x,player.y,'#f2c27f',12,.6);}
function useSpecial(){if(game.phase!=='playing'||player.specialCd>0)return;player.specialCd=Math.max(3.8,8.5-player.solarBonus*2);const radius=170*(1+player.solarBonus*.35),dmg=38*(1+player.solarBonus);game.shake=16;burst(player.x,player.y,'#ffe4a5',54,1.55);sound('solar');for(const e of [...game.enemies]){const d=dist(player,e);if(d<radius+e.r){damageEnemy(e,dmg*(1-d/(radius*2)),true);const a=Math.atan2(e.y-player.y,e.x-player.x);e.x+=Math.cos(a)*28;e.y+=Math.sin(a)*28;}}for(let i=0;i<3;i++){const p={x:player.x,y:player.y,rr:0,max:radius,life:.36-i*.04,alpha:.6};game.particles.push({ring:p});}showToast('SOLAR BURST',.9);}
function interact(){if(game.phase==='playing')interactPortal();}

function updatePlayer(dt){
  player.attackCd=Math.max(0,player.attackCd-dt);player.attackTime=Math.max(0,player.attackTime-dt);player.comboTimer=Math.max(0,player.comboTimer-dt);if(player.comboTimer===0&&player.attackTime===0)player.combo=0;player.dashCd=Math.max(0,player.dashCd-dt);player.specialCd=Math.max(0,player.specialCd-dt);player.invuln=Math.max(0,player.invuln-dt);
  if(player.regen>0&&player.hp>0)player.hp=Math.min(player.maxHp,player.hp+player.regen*dt);
  if(player.dashTime>0){player.dashTime-=dt;player.vx=player.dashVX;player.vy=player.dashVY;player.x+=player.vx*dt;player.y+=player.vy*dt;for(let i=0;i<2;i++)particle(player.x,player.y,'#f2c27f',rand(2,4),rand(-30,30),rand(-25,25),.25);}
  else {let dx=(input.keys.has('d')||input.keys.has('arrowright')?1:0)-(input.keys.has('a')||input.keys.has('arrowleft')?1:0)+input.joy.x;let dy=(input.keys.has('s')||input.keys.has('arrowdown')?1:0)-(input.keys.has('w')||input.keys.has('arrowup')?1:0)+input.joy.y;const l=Math.hypot(dx,dy);if(l>1){dx/=l;dy/=l;}const targetX=dx*player.speed,targetY=dy*player.speed;const accel=1-Math.exp(-dt*12);player.vx=lerp(player.vx,targetX,accel);player.vy=lerp(player.vy,targetY,accel);if(Math.abs(dx)+Math.abs(dy)<.01){player.vx*=Math.pow(.03,dt);player.vy*=Math.pow(.03,dt);}player.x+=player.vx*dt;player.y+=player.vy*dt;}
  player.x=clamp(player.x,85,1195);player.y=clamp(player.y,100,632);
  if(player.attackTime>0&&!player.attackApplied&&player.attackTime<.175){player.attackApplied=true;const range=player.combo===3?127:103;const arc=player.combo===3?1.32:1.05;for(const e of [...game.enemies]){const d=dist(player,e);if(d<range+e.r){let a=Math.atan2(e.y-player.y,e.x-player.x);let diff=Math.atan2(Math.sin(a-player.attackAngle),Math.cos(a-player.attackAngle));if(Math.abs(diff)<arc){let crit=Math.random()<player.critBonus;let amount=player.damage*(1+player.damageBonus)*(player.combo===3?1.65:player.combo===2?1.2:1)*(crit?2.05:1);damageEnemy(e,amount,crit);const k=Math.atan2(e.y-player.y,e.x-player.x);e.x+=Math.cos(k)*(player.combo===3?33:17);e.y+=Math.sin(k)*(player.combo===3?33:17);}}}const sparks=player.combo===3?14:9;for(let i=0;i<sparks;i++){const a=player.attackAngle+rand(-arc,arc),s=rand(90,250);particle(player.x+Math.cos(a)*40,player.y+Math.sin(a)*40,'#f4d69b',rand(1,3),Math.cos(a)*s,Math.sin(a)*s,.3);}}
  if(input.attackHeld&&player.attackCd<=0)startAttack();
}

function updateEnemy(e,dt){
  const dx=player.x-e.x,dy=player.y-e.y,d=Math.max(1,Math.hypot(dx,dy)),nx=dx/d,ny=dy/d;e.attackCd-=dt;e.flash=Math.max(0,e.flash-dt);e.stateT=Math.max(0,e.stateT-dt);
  if(e.kind==='boss'){
    e.seed+=dt;const pct=e.hp/e.maxHp;e.phase=pct<.5?2:1;e.speed=66+(e.phase-1)*19;
    if(e.state==='windup'&&e.stateT<=0){
      if(e.attackPattern==='storm'){
        const count=e.phase===2?14:10;
        for(let i=0;i<count;i++){const a=i/count*TAU;spawnProjectile(e.x,e.y,Math.cos(a)*185,Math.sin(a)*185,11,'#efaa75');}
        e.state='idle';e.attackCd=e.phase===2?1.5:2.1;e.attackPattern='';
      }else{
        e.state='burst';e.stateT=.48;e.chargeVX=nx*340;e.chargeVY=ny*340;burst(e.x,e.y,'#f09a70',12,.7);
      }
    }else if(e.state==='burst'){
      e.x+=e.chargeVX*dt;e.y+=e.chargeVY*dt;e.chargeVX*=Math.pow(.14,dt);e.chargeVY*=Math.pow(.14,dt);
      if(e.stateT<=0){e.state='idle';e.attackCd=e.phase===2?1.5:2.1;}
    }else if(e.state==='idle'&&e.attackCd<=0){
      const pattern=Math.floor(rand(0,e.phase===2?3:2));e.state='windup';e.stateT=pattern===0?.82:.72;e.attackPattern=pattern===0?'charge':'storm';
      showToast(pattern===0?'WARDEN · ROOT CHARGE':'WARDEN · SHARD STORM',.65);e.attackCd=e.phase===2?1.75:2.6;
    }
    if(e.state==='idle'){e.x+=nx*e.speed*.42*dt;e.y+=ny*e.speed*.42*dt;}
    if(d<e.r+player.r+8&&e.state==='burst')damagePlayer(e.damage,e.x,e.y);
    e.x=clamp(e.x,160,1120);e.y=clamp(e.y,130,590);return;
  }
  if(e.kind==='stalker'){
    e.x+=nx*e.speed*dt;e.y+=ny*e.speed*dt;if(d<e.r+player.r+5&&e.attackCd<=0){damagePlayer(e.damage,e.x,e.y);e.attackCd=.95;}
  }else if(e.kind==='archer'){
    if(d>275){e.x+=nx*e.speed*dt*.8;e.y+=ny*e.speed*dt*.8;}else if(d<195){e.x-=nx*e.speed*dt*.8;e.y-=ny*e.speed*dt*.8;}
    if(e.state==='windup'){if(e.stateT<=0){const a=Math.atan2(player.y-e.y,player.x-e.x);spawnProjectile(e.x,e.y,Math.cos(a)*225,Math.sin(a)*225,10,'#e7ae77');e.state='idle';e.attackCd=1.8;}}
    else if(e.attackCd<=0){e.state='windup';e.stateT=.55;}
  }else if(e.kind==='brute'){
    if(e.state==='charge'){e.x+=e.chargeVX*dt;e.y+=e.chargeVY*dt;e.chargeVX*=Math.pow(.18,dt);e.chargeVY*=Math.pow(.18,dt);if(e.stateT<=0){e.state='idle';e.attackCd=1.9;}}
    else if(e.state==='windup'){if(e.stateT<=0){e.state='charge';e.stateT=.42;e.chargeVX=nx*440;e.chargeVY=ny*440;}}
    else{if(d>110){e.x+=nx*e.speed*dt;e.y+=ny*e.speed*dt;}if(e.attackCd<=0&&d<330){e.state='windup';e.stateT=.72;showToast('BRUTE · CHARGING',.5);}}
    if(d<e.r+player.r+4&&e.attackCd<1.2&&e.state==='charge')damagePlayer(e.damage,e.x,e.y);
  }else if(e.kind==='wisp'){
    const orbit=Math.sin(game.roomTime*2.2+e.seed)*.5;if(d>230){e.x+=nx*e.speed*dt;e.y+=ny*e.speed*dt;}else if(d<150){e.x-=nx*e.speed*dt*.8;e.y-=ny*e.speed*dt*.8;}e.x+=-ny*orbit*22*dt;e.y+=nx*orbit*22*dt;
    if(e.attackCd<=0){const a=Math.atan2(player.y-e.y,player.x-e.x);spawnProjectile(e.x,e.y,Math.cos(a)*150,Math.sin(a)*150,8,'#98cbb5',true);e.attackCd=2.25;}
  }
  e.x=clamp(e.x,75,1205);e.y=clamp(e.y,85,645);
}
function spawnProjectile(x,y,vx,vy,damage,color,homing=false){game.projectiles.push({x,y,vx,vy,damage,color,life:3,r:6,homing,trail:[]});}
function updateProjectiles(dt){for(let i=game.projectiles.length-1;i>=0;i--){const p=game.projectiles[i];if(p.homing){const a=Math.atan2(player.y-p.y,player.x-p.x);const speed=Math.hypot(p.vx,p.vy);p.vx=lerp(p.vx,Math.cos(a)*speed,.45*dt);p.vy=lerp(p.vy,Math.sin(a)*speed,.45*dt);}p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;if(Math.random()<.8)particle(p.x,p.y,p.color,rand(1,2.5),rand(-12,12),rand(-12,12),.2);if(Math.hypot(p.x-player.x,p.y-player.y)<p.r+player.r&&p.life>0){damagePlayer(p.damage,p.x,p.y);game.projectiles.splice(i,1);continue;}if(p.life<=0||p.x<-50||p.x>W+50||p.y<-50||p.y>H+50)game.projectiles.splice(i,1);}}
function updatePickups(dt){for(let i=game.pickups.length-1;i>=0;i--){const p=game.pickups[i];p.life-=dt;p.phase+=dt*3;const d=dist(player,p);if(d<140){const a=Math.atan2(player.y-p.y,player.x-p.x);const pull=(1-d/140)*260;p.x+=Math.cos(a)*pull*dt;p.y+=Math.sin(a)*pull*dt;}if(d<player.r+14){if(p.kind==='xp'){player.xp+=p.value;while(player.xp>=player.xpNeed){player.xp-=player.xpNeed;player.level++;player.xpNeed=Math.round(player.xpNeed*1.28);player.damage+=2;player.maxHp+=5;player.hp=Math.min(player.maxHp,player.hp+18);floater(player.x,player.y-34,'LEVEL '+player.level+'!','#f5d78c',20);sound('level');}}else{player.gold+=p.value;floater(p.x,p.y,'+'+p.value+' SHARDS','#e6c57f',12);}game.pickups.splice(i,1);updateUI();continue;}if(p.life<=0)game.pickups.splice(i,1);}}
function updateEffects(dt){for(let i=game.particles.length-1;i>=0;i--){const p=game.particles[i];if(p.ring){p.ring.rr+=(p.ring.max/p.ring.life)*dt;p.ring.life-=dt;if(p.ring.life<=0)game.particles.splice(i,1);continue;}p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.pow(p.drag||.93,dt*60);p.vy*=Math.pow(p.drag||.93,dt*60);p.life-=dt;if(p.life<=0)game.particles.splice(i,1);}for(let i=game.floaters.length-1;i>=0;i--){const f=game.floaters[i];f.y+=f.vy*dt;f.life-=dt;if(f.life<=0)game.floaters.splice(i,1);}game.shake=Math.max(0,game.shake-dt*28);game.toastTimer=Math.max(0,game.toastTimer-dt);if(game.toastTimer<=0)$('toast').classList.remove('show');}
function updateGame(dt){if(game.phase!=='playing')return;game.roomTime+=dt;player.runTime+=dt;updatePlayer(dt);for(const e of [...game.enemies])updateEnemy(e,dt);updateProjectiles(dt);updatePickups(dt);updateEffects(dt);if(game.portal){game.portal.pulse+=dt;if(dist(player,game.portal)<105)$('interactionHint').style.display='flex';else $('interactionHint').style.display='none';}else $('interactionHint').style.display='none';if(game.boss){$('bossFill').style.width=(game.boss.hp/game.boss.maxHp*100)+'%';$('bossPercent').textContent=Math.ceil(game.boss.hp/game.boss.maxHp*100)+'%';}if(Math.floor(player.runTime)%1===0)updateHUDLight();}
let hudTick=0;function updateHUDLight(){hudTick++;if(hudTick%8===0)updateUI();}

function drawWorld(){ctx.drawImage(background,0,0);const p=realms[game.stage].palette;
  // drifting motes and drifting haze bands
  const t=performance.now()/1000;ctx.save();ctx.globalAlpha=.08;for(let i=0;i<5;i++){const x=(i*287+t*7)%1400-60;const g=ctx.createRadialGradient(x,120+i*120,5,x,120+i*120,220);g.addColorStop(0,p.mist);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.fillRect(x-220,30+i*100,440,150);}ctx.restore();
  if(game.portal){const q=game.portal;const pulse=.5+Math.sin(q.pulse*3.2)*.08;ctx.save();ctx.translate(q.x,q.y);ctx.scale(pulse,1/pulse);const glow=ctx.createRadialGradient(0,0,8,0,0,95);glow.addColorStop(0,p.portal+'88');glow.addColorStop(.5,p.portal+'30');glow.addColorStop(1,'transparent');ctx.fillStyle=glow;ctx.beginPath();ctx.arc(0,0,100,0,TAU);ctx.fill();ctx.strokeStyle=p.portal;ctx.globalAlpha=.8;ctx.lineWidth=5;ctx.beginPath();ctx.ellipse(0,0,33,47,0,0,TAU);ctx.stroke();ctx.globalAlpha=.5;ctx.lineWidth=1.5;ctx.beginPath();ctx.ellipse(0,0,49,64,0,0,TAU);ctx.stroke();ctx.fillStyle='#f4daa3';ctx.globalAlpha=.8;ctx.font='12px DM Mono';ctx.textAlign='center';ctx.fillText('GATE',0,4);ctx.restore();for(let i=0;i<3;i++){const a=t*1.1+i*TAU/3;ctx.fillStyle=p.portal;ctx.globalAlpha=.8;ctx.beginPath();ctx.arc(q.x+Math.cos(a)*42,q.y+Math.sin(a)*57,2.5,0,TAU);ctx.fill();ctx.globalAlpha=1;}}
}
function drawSprite(name,x,y,w,h,angle=0,alpha=1,flash=false){const im=images[name];if(!im||!im.complete||!im.naturalWidth)return false;ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.globalAlpha=alpha;if(flash){ctx.shadowColor='#fff0c9';ctx.shadowBlur=20;}ctx.drawImage(im,-w/2,-h/2,w,h);ctx.restore();return true;}
function drawEnemy(e){const t=performance.now()/1000;const bob=Math.sin(t*4+e.seed)*2;ctx.save();ctx.fillStyle='#08100c';ctx.globalAlpha=.38;ctx.beginPath();ctx.ellipse(e.x,e.y+e.r*.68,e.r*1.12,e.r*.42,0,0,TAU);ctx.fill();ctx.restore();const angle=Math.atan2(player.y-e.y,player.x-e.x)+Math.PI/2;const name=e.kind==='stalker'?'thornling':e.kind;const size=e.kind==='boss'?142:e.kind==='brute'?84:e.kind==='wisp'?58:63;drawSprite(name,e.x,e.y+bob,size*(e.kind==='boss'?1.18:1),size,angle,1,e.flash>0);
  if(e.kind!=='boss'&&e.hp<e.maxHp){ctx.fillStyle='rgba(8,13,10,.72)';ctx.fillRect(e.x-e.r,e.y-e.r-12,e.r*2,4);ctx.fillStyle=e.kind==='brute'?'#d58a62':'#a9bd80';ctx.fillRect(e.x-e.r,e.y-e.r-12,e.r*2*clamp(e.hp/e.maxHp,0,1),4);}
  if(e.state==='windup'){ctx.save();ctx.strokeStyle=e.kind==='boss'?'#ee986e':'#efc178';ctx.globalAlpha=.6+.3*Math.sin(t*18);ctx.lineWidth=e.kind==='boss'?4:2;ctx.setLineDash([7,6]);ctx.beginPath();ctx.arc(e.x,e.y,e.r+17+Math.sin(t*10)*3,0,TAU);ctx.stroke();ctx.restore();}
}
function drawPlayer(){const t=performance.now()/1000;const moving=Math.hypot(player.vx,player.vy)>35;const bob=moving?Math.sin(t*13)*2:Math.sin(t*2.5)*1.2;const angle=player.attackTime>0?player.attackAngle:player.attackAngle;ctx.save();ctx.fillStyle='#07100b';ctx.globalAlpha=.42;ctx.beginPath();ctx.ellipse(player.x,player.y+14,27,12,0,0,TAU);ctx.fill();ctx.restore();if(player.dashTime>0){for(let i=0;i<4;i++){ctx.globalAlpha=.18-i*.035;drawSprite('hero',player.x-player.dashVX*.025*i,player.y-player.dashVY*.025*i,62,73,angle+Math.PI/2);ctx.globalAlpha=1;}}
  const blink=player.invuln>0&&Math.floor(t*18)%2===0;drawSprite('hero',player.x,player.y+bob,62,73,angle+Math.PI/2,blink?.52:1,player.invuln>0);
  if(player.attackTime>0){const progress=1-player.attackTime/.26;const start=player.attackAngle-(player.combo===3?1.1:.85);const end=player.attackAngle+(player.combo===3?1.1:.85);ctx.save();ctx.translate(player.x,player.y);ctx.globalAlpha=(1-progress)*.9;ctx.strokeStyle=player.combo===3?'#fff0b0':'#ebd09b';ctx.lineWidth=player.combo===3?9:6;ctx.lineCap='round';ctx.shadowColor='#f3b96f';ctx.shadowBlur=15;ctx.beginPath();ctx.arc(0,0,player.combo===3?100:82,start,end);ctx.stroke();ctx.globalAlpha=(1-progress)*.35;ctx.lineWidth=22;ctx.beginPath();ctx.arc(0,0,player.combo===3?100:82,start,end);ctx.stroke();ctx.restore();}
}
function drawEffects(){for(const p of game.pickups){const bob=Math.sin(p.phase)*4;ctx.save();ctx.translate(p.x,p.y+bob);ctx.shadowColor=p.kind==='xp'?'#b8db9e':'#f1c379';ctx.shadowBlur=14;ctx.fillStyle=p.kind==='xp'?'#a5c68b':'#dfb86f';ctx.beginPath();if(p.kind==='xp'){ctx.moveTo(0,-8);ctx.lineTo(7,0);ctx.lineTo(0,8);ctx.lineTo(-7,0);}else{ctx.arc(0,0,5,0,TAU);}ctx.fill();ctx.restore();}
  for(const p of game.projectiles){ctx.save();ctx.fillStyle=p.color;ctx.shadowColor=p.color;ctx.shadowBlur=15;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,TAU);ctx.fill();ctx.restore();}
  for(const p of game.particles){if(p.ring){ctx.save();ctx.globalAlpha=clamp(p.ring.life/.36,0,1)*.6;ctx.strokeStyle='#ffe0a2';ctx.lineWidth=5;ctx.beginPath();ctx.arc(p.ring.x,p.ring.y,p.ring.rr,0,TAU);ctx.stroke();ctx.restore();continue;}ctx.save();ctx.globalAlpha=clamp(p.life/p.max,0,1);ctx.fillStyle=p.color;ctx.shadowColor=p.color;ctx.shadowBlur=8;ctx.beginPath();ctx.arc(p.x,p.y,p.size*clamp(p.life/p.max,.25,1),0,TAU);ctx.fill();ctx.restore();}
  for(const f of game.floaters){ctx.save();ctx.globalAlpha=clamp(f.life/f.max,0,1);ctx.fillStyle=f.color;ctx.font=`700 ${f.size}px Barlow Condensed, sans-serif`;ctx.textAlign='center';ctx.shadowColor='#111';ctx.shadowBlur=5;ctx.fillText(f.text,f.x,f.y);ctx.restore();}}
function draw(){ctx.save();if(game.shake>0){ctx.translate(rand(-game.shake,game.shake),rand(-game.shake,game.shake));}drawWorld();for(const e of game.enemies)drawEnemy(e);drawEffects();drawPlayer();ctx.restore();}

function updateUI(){
  $('healthFill').style.width=clamp(player.hp/player.maxHp*100,0,100)+'%';$('xpFill').style.width=clamp(player.xp/player.xpNeed*100,0,100)+'%';$('healthText').textContent=`${Math.ceil(player.hp)} / ${player.maxHp}`;$('xpText').textContent=`${Math.floor(player.xp)} / ${player.xpNeed} XP`;$('levelLabel').textContent='LVL '+String(player.level).padStart(2,'0');$('goldLabel').textContent=player.gold;$('killsLabel').textContent=player.kills;$('comboLabel').textContent=player.combo?`×${player.combo}`:'—';
  $('dashCooldown').style.width=(player.dashCd>0?player.dashCd/Math.max(.72,1.25-player.dodgeBonus*.75)*100:0)+'%';$('specialCooldown').style.width=(player.specialCd>0?player.specialCd/Math.max(3.8,8.5-player.solarBonus*2)*100:0)+'%';
  $('relicCount').textContent=`${runRelics.length} / 6`;$('relicGrid').innerHTML='';for(let i=0;i<6;i++){const el=document.createElement('div');if(runRelics[i]){el.className='relic-item';el.textContent=runRelics[i].icon;el.title=runRelics[i].name;}else{el.className='relic-empty';el.textContent='+';} $('relicGrid').appendChild(el);} $('relicFoot').textContent=runRelics.length?runRelics.map(r=>r.name).join(' · '):'Ancient blessings alter your playstyle.';
  const stepEls=$('progressSteps').children;for(let i=0;i<3;i++){stepEls[i].className='step '+(i<game.room?'done':i===game.room?'active':'');$('objectiveChecks').children[i].className='check-dot '+(i<game.room?'done':i===game.room?'active':'');}
}
function updateTimer(){const secs=Math.floor(player.runTime),m=Math.floor(secs/60),s=secs%60;$('timerLabel').textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;}

let audio=null;
function initAudio(){if(muted)return;try{audio ||= new (window.AudioContext||window.webkitAudioContext)();if(audio.state==='suspended')audio.resume();}catch{}}
function tone(freq,duration,type='sine',volume=.06,slide=0){if(muted)return;initAudio();if(!audio)return;const o=audio.createOscillator(),g=audio.createGain();o.type=type;o.frequency.setValueAtTime(freq,audio.currentTime);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(20,freq+slide),audio.currentTime+duration);g.gain.setValueAtTime(volume,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+duration);}
function sound(name){if(muted)return;const sets={start:[[220,.12,'sine',.035,120],[330,.22,'triangle',.035,80],[440,.32,'sine',.025,-70]],slash:[[190,.09,'sawtooth',.035,280]],dash:[[300,.19,'sine',.055,560]],hurt:[[110,.22,'triangle',.07,-55]],kill:[[330,.08,'triangle',.045,220],[520,.12,'sine',.02,-80]],portal:[[220,.18,'sine',.05,330],[440,.3,'triangle',.035,180]],reward:[[440,.16,'sine',.04,220],[660,.22,'sine',.03,180]],solar:[[140,.24,'sawtooth',.035,520],[360,.45,'sine',.045,700]],level:[[520,.12,'sine',.04,160],[780,.17,'sine',.04,190]],victory:[[330,.22,'triangle',.04,220],[440,.27,'sine',.04,220],[660,.55,'sine',.035,320]],defeat:[[220,.4,'triangle',.04,-100],[110,.5,'sine',.035,-40]]};for(const [f,d,t,v,s] of (sets[name]||[]))tone(f,d,t,v,s);}

function loop(now){const dt=clamp((now-game.previousFrame)/1000||0,.001,.033);game.previousFrame=now;if(game.phase==='playing')updateGame(dt);else updateEffects(dt*.55);draw();updateTimer();requestAnimationFrame(loop);}

// Keyboard and pointer input
window.addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(['arrowup','arrowdown','arrowleft','arrowright',' '].includes(k))e.preventDefault();input.keys.add(k);if(k===' '&&!e.repeat)useDash();if(k==='q'&&!e.repeat)useSpecial();if(k==='e'&&!e.repeat)interact();if(k==='escape'||k==='p'){if(game.phase==='playing')setPhase('paused');else if(game.phase==='paused')setPhase('playing');}});
window.addEventListener('keyup',e=>input.keys.delete(e.key.toLowerCase()));
function pointerPosition(e){const r=canvas.getBoundingClientRect();input.pointer.x=(e.clientX-r.left)/r.width*W;input.pointer.y=(e.clientY-r.top)/r.height*H;input.pointer.inside=input.pointer.x>=0&&input.pointer.x<=W&&input.pointer.y>=0&&input.pointer.y<=H;}
canvas.addEventListener('pointermove',e=>{pointerPosition(e);if(game.phase==='playing')aimAtPointer();});canvas.addEventListener('pointerenter',e=>{pointerPosition(e);});canvas.addEventListener('pointerleave',()=>{input.pointer.inside=false;});canvas.addEventListener('pointerdown',e=>{if(e.button!==0)return;pointerPosition(e);if(game.phase==='playing'){input.pointer.down=true;input.attackHeld=true;startAttack();}});window.addEventListener('pointerup',()=>{input.pointer.down=false;input.attackHeld=false;});canvas.addEventListener('contextmenu',e=>e.preventDefault());
$('startBtn').addEventListener('click',()=>{initAudio();startJourney(false);});$('continueBtn').addEventListener('click',()=>{if(meta.current){initAudio();startJourney(true);}});$('continueBtn').disabled=!meta.current;$('continueMeta').textContent=meta.current?'SAVE FOUND':'— NO SAVE —';$('resumeBtn').addEventListener('click',()=>setPhase('playing'));$('restartBtn').addEventListener('click',()=>{if(confirm('Restart this journey from the beginning?')){clearRunSave();startJourney(false);}});$('playAgainBtn').addEventListener('click',()=>startJourney(false));$('returnMenuBtn').addEventListener('click',()=>setPhase('menu'));
$('helpBtn').addEventListener('click',()=>$('helpModal').classList.remove('hidden'));$('closeHelp').addEventListener('click',()=>$('helpModal').classList.add('hidden'));$('helpModal').addEventListener('click',e=>{if(e.target===$('helpModal'))$('helpModal').classList.add('hidden');});
$('soundToggle').addEventListener('click',()=>{muted=!muted;meta.sound=!muted;persist();$('soundToggle').textContent=muted?'♪̸':'♪';if(!muted){initAudio();tone(440,.08,'sine',.03,130);}});
$('soundToggle').textContent=muted?'♪̸':'♪';$('fullscreenBtn').addEventListener('click',()=>{if(!document.fullscreenElement)frame.requestFullscreen?.();else document.exitFullscreen?.();});

// Mobile touch controls
const joy=$('joystick'),knob=$('joyKnob');let joyPointer=null,joyCenter=null;
joy.addEventListener('pointerdown',e=>{joyPointer=e.pointerId;joy.setPointerCapture(e.pointerId);const r=joy.getBoundingClientRect();joyCenter={x:r.left+r.width/2,y:r.top+r.height/2};moveJoy(e);});
joy.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)moveJoy(e);});function moveJoy(e){if(!joyCenter)return;let dx=e.clientX-joyCenter.x,dy=e.clientY-joyCenter.y;const len=Math.hypot(dx,dy),max=36;if(len>max){dx=dx/len*max;dy=dy/len*max;}input.joy.x=dx/max;input.joy.y=dy/max;knob.style.left=`calc(50% + ${dx}px)`;knob.style.top=`calc(50% + ${dy}px)`;}
function endJoy(){joyPointer=null;joyCenter=null;input.joy.x=input.joy.y=0;knob.style.left='50%';knob.style.top='50%';}joy.addEventListener('pointerup',endJoy);joy.addEventListener('pointercancel',endJoy);joy.addEventListener('lostpointercapture',endJoy);
$('mobileAttack').addEventListener('pointerdown',e=>{e.preventDefault();if(game.phase==='playing'){nearestAngle();startAttack();input.attackHeld=true;}});$('mobileAttack').addEventListener('pointerup',()=>input.attackHeld=false);$('mobileAttack').addEventListener('pointercancel',()=>input.attackHeld=false);$('mobileDash').addEventListener('pointerdown',e=>{e.preventDefault();useDash();});$('mobileSpecial').addEventListener('pointerdown',e=>{e.preventDefault();nearestAngle();useSpecial();});

// Keep UI responsive on different device pixel ratios and update HUD safely.
window.addEventListener('resize',()=>{canvas.style.width='100%';});
if('ResizeObserver'in window)new ResizeObserver(()=>{canvas.style.width='100%';}).observe(frame);

// Boot into the title scene with a clean visual, without starting gameplay.
buildBackground();updateUI();setPhase('menu');requestAnimationFrame(loop);
