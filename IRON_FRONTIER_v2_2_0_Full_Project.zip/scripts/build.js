const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const out=path.join(root,'dist');
fs.rmSync(out,{recursive:true,force:true});
fs.mkdirSync(out,{recursive:true});
for(const item of ['index.html','style.css','src','assets','README.md']){
 const source=path.join(root,item);
 if(fs.existsSync(source)) fs.cpSync(source,path.join(out,item),{recursive:true});
}

// Produce a self-contained offline copy as part of the regular build.
let html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'style.css'),'utf8');
let js=fs.readFileSync(path.join(root,'src/game.js'),'utf8');
const mime={'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'};
for(const [asset,ext] of [['assets/rook.png','.png'],['assets/enemy.png','.png'],['assets/jungle-panorama.jpg','.jpg']]){
 const data=fs.readFileSync(path.join(root,asset)).toString('base64');
 const escaped=asset.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 js=js.replace(new RegExp(`(['\"])${escaped}\\1`,'g'), `'data:${mime[ext]};base64,${data}'`);
}
html=html.replace(/<link rel="stylesheet" href="style\.css">/,`<style>\n${css}\n</style>`);
html=html.replace(/<script src="src\/game\.js"><\/script>/,`<script>\n${js}\n</script>`);
fs.writeFileSync(path.join(root,'standalone.html'),html);
console.log('Built static game in dist/ and standalone.html');
