const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

class FakeClassList {
  add(){} remove(){} toggle(){} contains(){return false;}
}
class FakeElement {
  constructor(id='') { this.id=id; this.style={}; this.classList=new FakeClassList(); this.handlers={}; this.dataset={}; this.parentElement={disabled:false}; this.textContent=''; this.innerHTML=''; this.disabled=false; }
  addEventListener(name,fn){this.handlers[name]=fn;}
  setPointerCapture(){}
  click(){this.handlers.click?.({});}
}
class FakeCanvas extends FakeElement {
  constructor(){super('game');this.width=1600;this.height=900;this.ctx=new Proxy({}, {get:(o,k)=>{
    if(k==='createLinearGradient'||k==='createRadialGradient') return ()=>({addColorStop(){}});
    if(k==='measureText') return ()=>({width:0});
    return o[k] || (()=>{});
  },set:(o,k,v)=>{o[k]=v;return true;}});}
  getContext(){return this.ctx;}
}
class FakeImage { constructor(){this.complete=true;this.naturalWidth=300;this.naturalHeight=420;this.width=300;this.height=420;} set src(v){this._src=v;} get src(){return this._src;} }
class FakeOscillator { constructor(){this.frequency={setValueAtTime(){},exponentialRampToValueAtTime(){}};this.type='sine';} connect(){} start(){} stop(){} }
class FakeGain { constructor(){this.gain={setValueAtTime(){},exponentialRampToValueAtTime(){}};} connect(){} }
class FakeAudioContext { constructor(){this.currentTime=0;this.state='running';this.destination={};} createOscillator(){return new FakeOscillator();} createGain(){return new FakeGain();} resume(){} }

function runSimulation(){
  const elements = new Map();
  const get = id => {if(!elements.has(id))elements.set(id,id==='game'?new FakeCanvas():new FakeElement(id));return elements.get(id);};
  const canvas=get('game');
  const document={getElementById:get,querySelectorAll:()=>[],createElement:()=>new FakeElement('created')};
  const store=new Map();
  const localStorage={getItem:k=>store.has(k)?store.get(k):null,setItem:(k,v)=>store.set(k,String(v)),removeItem:k=>store.delete(k)};
  const window={__IF_TEST_MODE__:true,addEventListener(){},requestAnimationFrame(){return 1;}};
  const sandbox={document,window,localStorage,Image:FakeImage,AudioContext:FakeAudioContext,webkitAudioContext:FakeAudioContext,
    performance:{now:()=>1000},requestAnimationFrame:()=>1,setTimeout:()=>1,clearTimeout(){},console,Math,Date,
    navigator:{userAgent:'test'},addEventListener(){},innerWidth:1600,innerHeight:900};
  vm.createContext(sandbox);
  const code=fs.readFileSync(path.join(__dirname,'../src/game.js'),'utf8');
  vm.runInContext(code,sandbox,{filename:'src/game.js'});
  const api=window.__IF_TEST_API__;
  if(!api) throw new Error('Debug simulation API did not initialize');
  const results=[];
  const check=(name,fn)=>{try{const ok=fn();results.push({name,ok:!!ok});}catch(e){results.push({name,ok:false,error:e.message});}};

  check('main menu render path initializes without a missing-ghosts error',()=>{api.render(500);return true;});
  check('campaign begins with an on-screen first enemy wave',()=>{api.startGame();const g=api.game;return g.mode==='campaign'&&g.wave===1&&g.enemies.length>=3&&g.enemies[0].x-g.player.x<900;});
  check('canvas render path draws the opening campaign scene without exceptions',()=>{api.render(1200);return true;});
  check('Rook renders animated run, jump, slide, fire and melee poses',()=>{api.startGame();const p=api.game.player;p.vx=260;p.run=2.4;p.weapon=2;p.aimAngle=-.28;p.shotAnim=.09;p.meleeTime=.14;p.slideTime=.08;p.grounded=false;p.vy=-320;api.render(1450);return true;});
  check('enemy rig animates aimed fire, recoil and hit reaction',()=>{api.startGame();const e=api.game.enemies[0];e.windup=.24;e.aimAngle=-.18;e.muzzleFlash=.08;e.recoil=.12;e.hitReact=.2;api.update(.016);api.render(1500);return e.aimAngle!==undefined&&e.recoil>=0;});
  check('defeated trooper keeps a visible falling pose briefly, then is removed',()=>{api.startGame();const g=api.game,e=g.enemies[0];api.damageEnemy(e,999999,g.player.x);if(e.alive||e.deathTime!==0)return false;api.render(1600);for(let i=0;i<10;i++)api.update(.033);const stillFalling=g.enemies.includes(e)&&e.deathTime>.25;for(let i=0;i<36;i++)api.update(.033);return stillFalling&&!g.enemies.includes(e);});
  check('campaign reaches its warlord only after five waves and clears the sector',()=>{api.startGame();const g=api.game;g.player.x=4800;g.spawned=[0,1,2,3,4];g.enemies=[];api.update(.016);if(!g.boss)return false;api.damageBoss(999999);api.update(.016);return g.stageComplete===true;});
  check('kills award field credits to the career bank',()=>{api.startGame();const g=api.game,before=api.career.credits;api.damageEnemy(g.enemies[0],999999,g.player.x);return api.career.credits>before&&api.career.lifetimeKills>0;});
  check('career purchases permanently improve the next operator',()=>{const before=api.career.upgrades.armor||0;api.buyUpgrade('armor');api.startGame();return api.career.upgrades.armor===before+1&&api.game.player.maxHealth>=184&&store.has('iron_frontier_career_v2');});
  check('survival starts with a live encounter, not an empty arena',()=>{api.startSurvival('survival');const g=api.game;api.render(1400);return g.mode==='survival'&&g.survivalWave===1&&g.survivalInProgress&&g.enemies.length>=3;});
  check('survival difficulty scales as waves rise',()=>{api.startSurvival('survival');const g=api.game;const firstScale=g.survivalScale;g.enemies=[];g.survivalInProgress=false;g.survivalNextIn=0;for(let i=0;i<5;i++){g.enemies=[];g.boss=null;g.survivalInProgress=false;api.queueSurvivalWave();}return g.survivalWave===6&&g.survivalScale>firstScale&&g.survivalDamageScale>1;});
  check('a boss encounter is introduced every fifth survival wave',()=>{api.startSurvival('survival');const g=api.game;for(let i=0;i<4;i++){g.enemies=[];g.boss=null;g.survivalInProgress=false;api.queueSurvivalWave();}return g.survivalWave===5&&!!g.boss&&g.boss.hp>g.boss.maxHp*.9;});
  check('daily contract pays once after eight completed waves',()=>{api.startSurvival('daily');const g=api.game;for(let w=1;w<=8;w++){g.enemies=[];g.boss=null;g.survivalInProgress=true;g.survivalWave=w;api.survivalUpdate(.016);if(w<8){g.survivalNextIn=0;api.queueSurvivalWave();}}return api.career.dailyClaimed===true&&api.career.credits>=1200;});
  check('career record and daily claim persist to browser storage',()=>store.has('iron_frontier_career_v2')&&JSON.parse(store.get('iron_frontier_career_v2')).dailyClaimed===true);
  return results;
}

module.exports={runSimulation};
