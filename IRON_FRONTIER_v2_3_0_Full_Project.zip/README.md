# IRON FRONTIER — Operation Black Sun 2.3

A browser-based side-scrolling run-and-gun game built around both a four-operation campaign and a replayable survival loop.

## What changed in 2.0

- **The opening encounter is active immediately.** The first campaign enemy wave is spawned at the visible edge of the battlefield instead of waiting for the player to travel through an empty opening.
- **Endless Survival:** the run continues through escalating waves. Enemy health and damage increase as the run progresses, the battle zone rotates every five waves, and a boss arrives every fifth wave.
- **Daily Contract:** complete eight survival waves for a one-time daily reward of 1,200 field credits. The daily reset uses the player's local calendar date.
- **Persistent Command upgrades:** credits earned from kills, boss fights, campaign sectors and survival waves can be spent on five levels each of Armor Rig, Weapon Amplifier and Mobility. Credits, upgrades, lifetime kills, best wave and best score are stored in browser local storage.
- **More useful run feedback:** the game-over screen reports score, kills and credits earned. Survival waves are cleared and retired from memory before the next wave starts.
- **Visibility fix:** Rook has a high-contrast ground locator and a procedural fallback soldier if the player sprite fails to load. The main-menu hero's fallback animation state is initialized explicitly.

## Modes

1. **Campaign:** four themed operations, five enemy waves per operation, supply crates and a sector boss.
2. **Endless Survival:** no final wave; enemies scale up, zone themes rotate, and every fifth wave is a boss encounter.
3. **Daily Contract:** the same survival loop with an eight-wave daily objective and a one-time 1,200-credit reward.

## Permanent upgrades

- **Armor Rig:** +24 maximum health per level.
- **Weapon Amplifier:** +12% damage per level.
- **Mobility:** +5.5% movement speed per level.

Each track has five levels. Upgrade costs rise with each purchase. Progress is stored in local storage on the player's device/browser.

## Controls

- **A / D** or **← / →** — move
- **W / S** or **↑ / ↓** — aim vertically
- **Mouse** — aim and hold click to fire
- **J** — fire
- **Space** — jump / double jump
- **Shift** — dash / air dash (once per jump)
- **S + Shift** — ground slide
- **E** — close-range melee strike
- **K** — frag grenade
- **L** — overdrive pulse
- **1 / 2 / 3** — assault rifle / breach shotgun / arc plasma
- **P / Esc** — pause

Touch controls are included for mobile browsers. A wide 16:9 desktop window is recommended.

## Build and test

```bash
npm test
npm run build
```

`npm run build` creates the deployable static website in `dist/`. `standalone.html` is a self-contained offline copy.

The automated suite includes source checks plus a deterministic game-logic simulation for campaign opening encounters, the canvas render path, survival difficulty, fifth-wave bosses, daily rewards, permanent upgrades and local save persistence.


## v2.1 visual pass

- Filled the missing lower jungle backdrop with layered understory, trunks, hanging vines, leaf blades, and ground haze.
- Replaced rounded bubble-like canopy clusters with separated pointed foliage and visible stems.
- Replaced the repeated stage-name overlay with a short sector alert and wave engagement banner.


## v2.2 articulated combat animation pass

The full-body Rook and trooper/heavy cutouts are no longer translated as single sprites during gameplay. Player and humanoid enemies now render through a procedural articulated rig with separately posed thighs, shins, boots, torso, shoulders, elbows, hands, head, and weapon.

- Rook has distinct idle breathing, alternating run strides, tucked jump legs, low combat slide, weapon-specific aiming, recoil, melee punch, and hit-stagger poses.
- Troopers and heavy units track the player with their weapon arms, telegraph attacks, kick back on firing, flinch when hit, and play a short falling death animation before removal.
- Bosses now have animated hydraulic legs and independently moving arms; wind-up telegraphs pull the arms into a braced attack pose.
- Weapon recoil and muzzle flashes are attached to the weapon muzzle; plasma has its own glow, while shotgun and rifle silhouettes are distinct.
- Added simulation coverage for player action poses, enemy aiming/recoil/hit reactions, and enemy death animation.



## v2.3 soldier and environment art overhaul

- Switched Rook and humanoid troopers/heavies from the low-detail procedural mannequin render to the detailed transparent soldier artwork already shipped in `assets/rook.png` and `assets/enemy.png`.
- Soldier art responds to live action state: run cadence and bounce, facing direction, jump, slide, aim lean, weapon recoil, hit flash/stagger, dash afterimages, melee slash effects, enemy wind-up, muzzle flashes, and defeated-enemy fall/fade.
- Retained the procedural articulated renderer as a fallback if a sprite asset fails to load.
- The jungle panorama now fills the complete playable background height. Removed the former flat green understory and oversized repeating leaf canopy that caused the visible horizontal seam and obscured the combat lane.
- Added a restrained bottom-edge fern frame and atmospheric depth veil to blend the full-height panorama into the playable ground.

The 2.3 checks verify detailed sprite rendering, action-state transforms, and the full-height jungle background in addition to the existing campaign and survival simulation.
