/* Emberfall: The Last Hearth — Moss Gate 3D prototype
 * Runtime: Babylon.js loaded from the official CDN in index.html.
 * All characters, props, animation and effects are generated procedurally.
 */
(() => {
  'use strict';
  const B = window.BABYLON;
  const canvas = document.getElementById('renderCanvas');
  const $ = (id) => document.getElementById(id);
  if (!B || !canvas) {
    $('loading-note').textContent = 'The 3D engine could not load. Check your internet connection and refresh.';
    return;
  }

  const engine = new B.Engine(canvas, true, {
    preserveDrawingBuffer: false,
    stencil: true,
    antialias: true,
    powerPreference: 'high-performance',
    adaptToDeviceRatio: true
  });
  engine.setHardwareScalingLevel(Math.max(1, 1 / Math.min(window.devicePixelRatio || 1, 1.6)));

  const scene = new B.Scene(engine);
  scene.clearColor = new B.Color4(0.055, 0.085, 0.071, 1);
  scene.fogMode = B.Scene.FOGMODE_EXP2;
  scene.fogDensity = 0.009;
  scene.fogColor = new B.Color3(0.12, 0.17, 0.14);
  scene.collisionsEnabled = false;

  const camera = new B.FreeCamera('MossGate_ChaseCamera', new B.Vector3(0, 4, -15), scene);
  camera.fov = 0.88;
  camera.minZ = 0.08;
  camera.maxZ = 190;
  camera.inputs.clear();
  camera.setTarget(new B.Vector3(0, 1.3, 0));

  const hemi = new B.HemisphericLight('Forest_Ambient', new B.Vector3(0, 1, 0), scene);
  hemi.intensity = 0.68;
  hemi.diffuse = new B.Color3(0.72, 0.82, 0.74);
  hemi.groundColor = new B.Color3(0.19, 0.22, 0.17);

  const keyLight = new B.DirectionalLight('Warm_Canopy_Key', new B.Vector3(-0.42, -1, 0.38), scene);
  keyLight.position = new B.Vector3(-17, 27, -18);
  keyLight.intensity = 1.3;
  keyLight.diffuse = new B.Color3(1, 0.82, 0.61);
  keyLight.specular = new B.Color3(0.7, 0.66, 0.52);

  const shadows = new B.ShadowGenerator(2048, keyLight);
  shadows.usePercentageCloserFiltering = true;
  shadows.filteringQuality = B.ShadowGenerator.QUALITY_MEDIUM;
  shadows.bias = 0.0005;
  shadows.normalBias = 0.025;

  const pipeline = new B.DefaultRenderingPipeline('MossGate_CinematicPipeline', true, scene, [camera]);
  pipeline.fxaaEnabled = true;
  pipeline.bloomEnabled = true;
  pipeline.bloomThreshold = 0.72;
  pipeline.bloomWeight = 0.22;
  pipeline.bloomKernel = 48;
  pipeline.imageProcessingEnabled = true;
  pipeline.imageProcessing.toneMappingEnabled = true;
  pipeline.imageProcessing.exposure = 1.12;
  pipeline.imageProcessing.contrast = 1.12;

  const C = {
    dark: '#17251f', forest: '#263f32', moss: '#415b43', leaf: '#304d3a', olive: '#647451',
    stone: '#777569', stoneDark: '#4e5149', stoneLight: '#969080', path: '#8b8068',
    bronze: '#927347', gold: '#d1ad6e', goldHot: '#ffd38a', steel: '#b9c8c4',
    leather: '#334a40', wine: '#612d3d', skin: '#ba896d', enemy: '#435c47', enemyDark: '#283c30',
    ember: '#e77f43', red: '#c95d43', teal: '#5fc6ae'
  };

  const hex = (value) => B.Color3.FromHexString(value);
  function pbr(name, color, roughness = 0.82, metallic = 0.02, emissive = null) {
    const m = new B.PBRMaterial(name, scene);
    m.albedoColor = hex(color);
    m.roughness = roughness;
    m.metallic = metallic;
    if (emissive) m.emissiveColor = hex(emissive);
    return m;
  }
  const portalDiscMat = pbr('Portal_Disc_Translucent', '#173e3a', 0.32, 0.18, '#1d8b78');
  portalDiscMat.alpha = 0.72;
  portalDiscMat.transparencyMode = B.Material.MATERIAL_ALPHABLEND;
  const auraMat = pbr('Lyra_Subtle_Solar_Aura', '#173e3a', 0.62, 0.04, '#1d8b78');
  auraMat.alpha = 0.08;
  auraMat.transparencyMode = B.Material.MATERIAL_ALPHABLEND;
  const mats = {
    ground: pbr('Soil_Moss_Material', '#344337', 1),
    grass: pbr('Olive_Moss_Material', '#53664a', 1),
    path: pbr('Weathered_Limestone', '#817966', 0.93),
    pathLight: pbr('Pale_Worn_Stone', '#a0957c', 0.92),
    rock: pbr('River_Stone', '#73776b', 0.95),
    rockDark: pbr('Basalt_Stone', '#454c45', 0.94),
    bark: pbr('Old_Pine_Bark', '#4c3e2e', 0.98),
    pine1: pbr('Pine_Forest_Deep', '#1d382d', 0.97),
    pine2: pbr('Pine_Moss_Middle', '#2e4b39', 0.96),
    pine3: pbr('Pine_Tip', '#3c5a42', 0.96),
    stone: pbr('Gate_Stone', '#777467', 0.94),
    stoneTrim: pbr('Gate_Stone_Trim', '#a19883', 0.9),
    iron: pbr('Dark_Iron', '#323d37', 0.48, 0.72),
    bronze: pbr('Weathered_Bronze', '#987646', 0.42, 0.72),
    portal: pbr('Portal_Teal_Emissive', '#173e3a', 0.32, 0.22, '#1d8b78'),
    flame: pbr('Brazier_Ember', '#ff9c4d', 0.28, 0.05, '#ff7130'),
    heroLeather: pbr('Lyra_Forest_Leather', '#30483e', 0.68, 0.12),
    heroPlate: pbr('Lyra_Aged_Bronze', '#94754a', 0.4, 0.72),
    heroCloth: pbr('Lyra_Burgundy_Cape', '#632d3a', 0.88, 0.01),
    skin: pbr('Lyra_Warm_Skin', '#bf9279', 0.84, 0),
    hair: pbr('Lyra_Dark_Hair', '#241e20', 0.82, 0.02),
    blade: pbr('Solar_Edge_Steel', '#b8c9c4', 0.22, 0.92),
    bladeGlow: pbr('Solar_Rune_Glow', '#f4c56b', 0.25, 0.25, '#f5b54b'),
    enemyBody: pbr('Guardian_Moss_Skin', '#415b46', 0.86, 0.04),
    enemyArmor: pbr('Guardian_Root_Iron', '#544e3d', 0.72, 0.4),
    enemyHorn: pbr('Guardian_Bone_Horn', '#988765', 0.89, 0.02),
    enemyGlow: pbr('Guardian_Heart_Ember', '#ff8a45', 0.2, 0.08, '#ff652a')
  };

  function registerShadow(mesh, receive = true) {
    if (mesh && mesh.getTotalVertices && mesh.getTotalVertices() > 0) {
      shadows.addShadowCaster(mesh, true);
      mesh.receiveShadows = receive;
    }
    return mesh;
  }
  function matMesh(mesh, material, cast = true) {
    mesh.material = material;
    if (cast) registerShadow(mesh);
    return mesh;
  }
  function box(name, parent, pos, size, material, opts = {}) {
    const m = B.MeshBuilder.CreateBox(name, {
      width: size[0], height: size[1], depth: size[2],
      faceUV: opts.faceUV, wrap: true
    }, scene);
    m.position.set(pos[0], pos[1], pos[2]);
    if (opts.rotation) m.rotation.set(opts.rotation[0], opts.rotation[1], opts.rotation[2]);
    if (opts.scaling) m.scaling.set(opts.scaling[0], opts.scaling[1], opts.scaling[2]);
    if (parent) m.parent = parent;
    return matMesh(m, material, opts.cast !== false);
  }
  function sphere(name, parent, pos, scale, material, segments = 16) {
    const m = B.MeshBuilder.CreateSphere(name, { diameter: 1, segments }, scene);
    m.position.set(pos[0], pos[1], pos[2]);
    m.scaling.set(scale[0], scale[1], scale[2]);
    if (parent) m.parent = parent;
    return matMesh(m, material);
  }
  function cylinder(name, parent, pos, height, diameterTop, diameterBottom, material, tess = 12, rotation = null) {
    const m = B.MeshBuilder.CreateCylinder(name, { height, diameterTop, diameterBottom, tessellation: tess }, scene);
    m.position.set(pos[0], pos[1], pos[2]);
    if (rotation) m.rotation.set(rotation[0], rotation[1], rotation[2]);
    if (parent) m.parent = parent;
    return matMesh(m, material);
  }
  function torus(name, parent, pos, diameter, thickness, material, rotation = null) {
    const m = B.MeshBuilder.CreateTorus(name, { diameter, thickness, tessellation: 48 }, scene);
    m.position.set(pos[0], pos[1], pos[2]);
    if (rotation) m.rotation.set(rotation[0], rotation[1], rotation[2]);
    if (parent) m.parent = parent;
    return matMesh(m, material);
  }
  function node(name, parent, pos = [0, 0, 0]) {
    const n = new B.TransformNode(name, scene);
    n.position.set(pos[0], pos[1], pos[2]);
    if (parent) n.parent = parent;
    return n;
  }
  function addStatic(mesh) { scene.meshes.push(mesh); return mesh; }

  // ---------- Moss Gate environment ----------
  const floor = B.MeshBuilder.CreateGround('Moss_Gate_Terrain', { width: 104, height: 104, subdivisions: 48 }, scene);
  floor.position.y = -0.12;
  matMesh(floor, mats.ground);
  floor.receiveShadows = true;

  // Softly irregular moss patches to break the flat terrain colour.
  for (let i = 0; i < 34; i++) {
    const a = i * 2.399;
    const r = 11 + (i % 6) * 4.1;
    const patch = B.MeshBuilder.CreateDisc('Moss_Patch_' + i, { radius: 1, tessellation: 20 }, scene);
    patch.rotation.x = Math.PI / 2;
    patch.position.set(Math.cos(a) * r, -0.075, Math.sin(a) * r);
    patch.scaling.set(1.6 + (i % 3) * 0.9, 1, 0.9 + (i % 4) * 0.42);
    patch.material = mats.grass;
    patch.receiveShadows = true;
  }

  // Worn path from Lyra's spawn to the old gate.
  for (let i = 0; i < 22; i++) {
    const z = -17 + i * 1.72;
    const slab = box('Approach_Path_Slab_' + i, null, [0 + Math.sin(i * 1.1) * 0.12, 0.015 + (i % 3) * 0.008, z], [5.3 + (i % 4) * 0.24, 0.12, 1.68], i % 4 === 0 ? mats.pathLight : mats.path, {
      rotation: [0, Math.sin(i * 0.71) * 0.018, (i % 2 ? 0.01 : -0.01)]
    });
    slab.receiveShadows = true;
  }
  // Edge stones set into the path.
  for (let i = 0; i < 30; i++) {
    const side = i % 2 ? 1 : -1;
    const z = -19 + Math.floor(i / 2) * 2.15;
    const stone = sphere('Path_Edge_Stone_' + i, null, [side * (3.2 + (i % 3) * 0.25), 0.15, z], [0.34 + (i % 4) * 0.07, 0.25, 0.35 + (i % 3) * 0.05], mats.rock, 7);
    stone.rotation.y = i * 0.71;
  }

  function makeTree(name, x, z, scale = 1) {
    const root = node(name, null, [x, 0, z]);
    cylinder(name + '_Trunk', root, [0, 1.18 * scale, 0], 2.36 * scale, 0.28 * scale, 0.42 * scale, mats.bark, 9);
    for (let k = 0; k < 3; k++) {
      const h = 1.65 * scale;
      const dia = (2.25 - k * 0.43) * scale;
      const crown = cylinder(name + '_Bough_' + k, root, [0, (1.5 + k * 0.91) * scale, 0], h, 0.04 * scale, dia, k === 0 ? mats.pine1 : (k === 1 ? mats.pine2 : mats.pine3), 8);
      crown.rotation.y = (k % 2) * 0.3;
    }
    // Sparse branch stubs catch the rim light and make the silhouette less conical.
    for (let b = 0; b < 3; b++) {
      const side = b % 2 ? 1 : -1;
      cylinder(name + '_Branch_' + b, root, [side * 0.55 * scale, (1.8 + b * 0.37) * scale, 0], 0.82 * scale, 0.13 * scale, 0.17 * scale, mats.bark, 7, [0, 0, side * 0.86]);
    }
    return root;
  }
  const treePositions = [
    [-19,-19,1.4],[-25,-8,1.7],[-17,1,1.2],[-26,11,1.8],[-18,21,1.35],[-11,26,1.25],[-7,-26,1.2],
    [19,-19,1.55],[25,-8,1.75],[18,2,1.25],[26,13,1.7],[18,23,1.45],[9,27,1.1],[8,-26,1.25],
    [-28,0,1.2],[28,4,1.25],[-24,25,1.1],[24,26,1.2],[-14,-27,1.05],[14,-27,1.1]
  ];
  treePositions.forEach((p, i) => makeTree('Ancient_Pine_' + i, p[0], p[1], p[2]));

  // Rocks and root-like vegetation; clustered but kept outside the combat lane.
  for (let i = 0; i < 45; i++) {
    const a = i * 2.399;
    const r = 7 + (i % 7) * 2.35;
    const x = Math.cos(a) * r;
    const z = Math.sin(a) * r;
    if (Math.abs(x) < 4.3 && z > -18 && z < 11) continue;
    const s = 0.24 + (i % 5) * 0.09;
    const rock = B.MeshBuilder.CreatePolyhedron('Moss_Rubble_' + i, { type: 1 + (i % 4), size: 1 }, scene);
    rock.position.set(x, s * 0.72, z);
    rock.scaling.set(s * 1.4, s * (0.75 + (i % 3) * 0.15), s * (0.95 + (i % 2) * 0.3));
    rock.rotation.set(i * 0.21, i * 0.67, i * 0.13);
    matMesh(rock, i % 4 === 0 ? mats.rockDark : mats.rock);
  }
  for (let i = 0; i < 28; i++) {
    const side = i % 2 ? 1 : -1;
    const x = side * (4.1 + (i % 4) * 1.45);
    const z = -20 + Math.floor(i / 2) * 1.55;
    const bush = B.MeshBuilder.CreatePolyhedron('Fern_Clump_' + i, { type: 2, size: 1 }, scene);
    bush.position.set(x, 0.35, z);
    bush.scaling.set(0.34 + (i % 3) * 0.1, 0.42 + (i % 4) * 0.08, 0.32 + (i % 2) * 0.11);
    bush.rotation.y = i * 0.73;
    matMesh(bush, mats.pine2);
  }

  // Ancient Gate: layered masonry, lintel, carved details and a luminous seal.
  const gate = node('Moss_Gate_Ancient_Ruin');
  box('Gate_Left_Foundation', gate, [-4.35, 0.55, 19], [1.55, 1.1, 1.8], mats.stone);
  box('Gate_Right_Foundation', gate, [4.35, 0.55, 19], [1.55, 1.1, 1.8], mats.stone);
  box('Gate_Left_Pillar', gate, [-4.35, 3.25, 19], [1.12, 5.4, 1.25], mats.stone);
  box('Gate_Right_Pillar', gate, [4.35, 3.25, 19], [1.12, 5.4, 1.25], mats.stone);
  box('Gate_Left_Capital', gate, [-4.35, 6.15, 19], [1.8, 0.55, 1.75], mats.stoneTrim);
  box('Gate_Right_Capital', gate, [4.35, 6.15, 19], [1.8, 0.55, 1.75], mats.stoneTrim);
  box('Gate_Upper_Lintel', gate, [0, 6.65, 19], [10.3, 1.0, 1.75], mats.stoneTrim);
  box('Gate_Crown_Stone', gate, [0, 7.28, 19], [7.6, 0.36, 1.45], mats.stone);
  for (let s of [-1, 1]) {
    for (let j = 0; j < 5; j++) {
      box('Pillar_Block_' + s + '_' + j, gate, [s * 4.35, 1.05 + j * 1.0, 18.32], [1.2, 0.055, 1.31], mats.stoneDark);
    }
    box('Pillar_Rune_Inlay_' + s, gate, [s * 4.35, 3.15, 18.34], [0.13, 2.05, 0.04], mats.bronze);
  }
  for (let i = 0; i < 7; i++) {
    const x = -2.95 + i * 0.98;
    const y = 6.35 + Math.sin((i / 6) * Math.PI) * 0.42;
    const wedge = box('Arch_Voussoir_' + i, gate, [x, y, 19], [1.07, 0.75, 1.76], i % 2 ? mats.stone : mats.stoneTrim);
    wedge.rotation.z = (i - 3) * -0.075;
  }
  const portalDisk = cylinder('Dormant_Portal_Disc', gate, [0, 3.12, 19.78], 0.22, 5.2, 5.2, portalDiscMat, 64, [-Math.PI / 2, 0, 0]);
  const portalRing = torus('Ancient_Solar_Seal', gate, [0, 3.1, 19.55], 4.2, 0.14, mats.bladeGlow, [-Math.PI / 2, 0, 0]);
  const portalInner = torus('Portal_Inner_Rune', gate, [0, 3.1, 19.48], 3.48, 0.045, mats.portal, [-Math.PI / 2, 0, 0]);
  const runeCore = sphere('Portal_Heart', gate, [0, 3.1, 19.3], [0.35,0.35,0.22], mats.bladeGlow);
  const wardLines = [];
  for (let i = 0; i < 9; i++) {
    const a = (Math.PI * 2 * i) / 9;
    const rune = box('Gate_Rune_Shard_' + i, gate, [Math.cos(a) * 2.05, 3.1 + Math.sin(a) * 2.05, 19.32], [0.12, 0.72, 0.08], mats.bladeGlow);
    rune.rotation.z = -a;
    wardLines.push(rune);
  }

  // Gate braziers with firelight and metal stands.
  const torchLights = [];
  for (const side of [-1, 1]) {
    cylinder('Gate_Brazier_Stand_' + side, gate, [side * 5.9, 2.25, 17.6], 4.1, 0.14, 0.22, mats.iron, 10);
    cylinder('Gate_Brazier_Bowl_' + side, gate, [side * 5.9, 4.22, 17.6], 0.34, 0.72, 0.42, mats.bronze, 10);
    const flame = sphere('Gate_Brazier_Flame_' + side, gate, [side * 5.9, 4.75, 17.6], [0.25,0.52,0.25], mats.flame);
    const light = new B.PointLight('Gate_Firelight_' + side, new B.Vector3(side * 5.9, 4.8, 17.6), scene);
    light.diffuse = new B.Color3(1, 0.47, 0.19);
    light.intensity = 1.35;
    light.range = 11;
    torchLights.push({ light, flame, side });
  }
  // Guardian ward stones along both shoulders of the approach.
  for (let i = 0; i < 5; i++) {
    for (const side of [-1, 1]) {
      const z = -7 + i * 5.3;
      const h = 1.25 + (i % 3) * 0.48;
      box('Ward_Obelisk_' + side + '_' + i, null, [side * (5.1 + (i % 2) * 0.7), h, z], [0.76, h * 2, 0.66], mats.stoneDark, { rotation: [0, 0, side * 0.025] });
      sphere('Ward_Obelisk_Gem_' + side + '_' + i, null, [side * (5.1 + (i % 2) * 0.7), h * 2 + 0.13, z], [0.18,0.18,0.18], mats.bladeGlow, 12);
    }
  }

  // ---------- Detailed, procedural character rigs ----------
  function addCapsuleLimb(name, parent, length, radius, material) {
    const limb = node(name, parent, [0, 0, 0]);
    cylinder(name + '_Segment', limb, [0, -length * 0.48, 0], length * 0.84, radius * 1.55, radius * 1.8, material, 12);
    sphere(name + '_Joint', limb, [0, -length * 0.92, 0], [radius * 1.5, radius * 1.45, radius * 1.5], material, 12);
    return limb;
  }

  function createLyra() {
    const root = node('Lyra_Player_Root', null, [0, 0, -13]);
    const yawNode = node('Lyra_Facing', root);
    sphere('Lyra_Hips', yawNode, [0, 1.02, 0], [0.43,0.34,0.3], mats.heroLeather);
    sphere('Lyra_Torso', yawNode, [0, 1.47, 0], [0.46,0.58,0.31], mats.heroLeather);
    // Asymmetric breastplate panels, chest strap and shoulder pauldrons.
    box('Lyra_Breastplate', yawNode, [0,1.55,0.235], [0.55,0.62,0.17], mats.heroPlate);
    box('Lyra_Chest_Stripe', yawNode, [0,1.55,0.33], [0.075,0.5,0.025], mats.iron);
    sphere('Lyra_Solar_Brooch', yawNode, [0,1.54,0.37], [0.105,0.105,0.045], mats.bladeGlow, 14);
    box('Lyra_Waist_Belt', yawNode, [0,1.12,0.02], [0.88,0.13,0.56], mats.bronze);
    box('Lyra_Buckle', yawNode, [0,1.12,0.31], [0.18,0.18,0.06], mats.bladeGlow);

    // Head and hair are composed from distinct shapes for a readable silhouette.
    sphere('Lyra_Neck', yawNode, [0,1.94,0], [0.18,0.2,0.18], mats.skin);
    sphere('Lyra_Face', yawNode, [0,2.19,0.04], [0.255,0.34,0.235], mats.skin, 24);
    sphere('Lyra_Hair_Back', yawNode, [0,2.29,-0.11], [0.29,0.39,0.25], mats.hair, 18);
    sphere('Lyra_Hair_Cap', yawNode, [0,2.43,0.025], [0.28,0.18,0.25], mats.hair, 18);
    sphere('Lyra_Hair_Tail', yawNode, [0,2.12,-0.3], [0.16,0.46,0.14], mats.hair, 12).rotation.x = -0.25;
    for (const side of [-1,1]) {
      sphere('Lyra_Eye_' + side, yawNode, [side * 0.095,2.23,0.256], [0.027,0.032,0.018], mats.iron, 10);
      sphere('Lyra_Eyebrow_' + side, yawNode, [side * 0.095,2.29,0.256], [0.06,0.018,0.018], mats.hair, 10);
    }
    box('Lyra_Cape', yawNode, [0,1.34,-0.31], [0.62,0.92,0.07], mats.heroCloth, { rotation: [0.12,0,0] });
    box('Lyra_Cape_Lower', yawNode, [0,0.92,-0.34], [0.78,0.44,0.075], mats.heroCloth, { rotation: [0.18,0,0] });
    // Cape clasps.
    for (const side of [-1,1]) sphere('Lyra_Cape_Clasp_' + side, yawNode, [side * 0.29,1.82,-0.08], [0.07,0.09,0.07], mats.bronze, 10);

    const legs = [];
    for (const side of [-1,1]) {
      const hip = node('Lyra_Leg_Hip_' + side, yawNode, [side * 0.22,0.91,0]);
      sphere('Lyra_Thigh_Armor_' + side, hip, [0,-0.22,0], [0.23,0.39,0.25], mats.heroLeather);
      const thigh = cylinder('Lyra_Thigh_' + side, hip, [0,-0.28,0], 0.57, 0.31, 0.26, mats.heroLeather, 12);
      const knee = node('Lyra_Knee_' + side, hip, [0,-0.56,0]);
      sphere('Lyra_Knee_Guard_' + side, knee, [0,0,0.04], [0.17,0.14,0.2], mats.heroPlate);
      cylinder('Lyra_Shin_' + side, knee, [0,-0.25,0], 0.48, 0.25, 0.18, mats.heroLeather, 12);
      box('Lyra_Boot_' + side, knee, [0,-0.26,0.13], [0.3,0.2,0.52], mats.iron);
      box('Lyra_Boot_Guard_' + side, knee, [0,-0.14,0.235], [0.25,0.17,0.075], mats.bronze);
      legs.push({ hip, knee, side, thigh });
    }

    const arms = [];
    for (const side of [-1,1]) {
      const shoulder = node('Lyra_Shoulder_' + side, yawNode, [side * 0.48,1.72,0]);
      sphere('Lyra_Pauldron_' + side, shoulder, [side * 0.02,-0.06,0], [0.31,0.23,0.33], mats.heroPlate);
      const upper = cylinder('Lyra_UpperArm_' + side, shoulder, [0,-0.3,0], 0.56, 0.2, 0.17, mats.heroLeather, 12);
      const elbow = node('Lyra_Elbow_' + side, shoulder, [0,-0.58,0]);
      sphere('Lyra_Elbow_Plate_' + side, elbow, [0,0,0], [0.16,0.14,0.16], mats.bronze, 12);
      cylinder('Lyra_Forearm_' + side, elbow, [0,-0.25,0.035], 0.5, 0.17, 0.22, mats.heroLeather, 12);
      box('Lyra_Gauntlet_' + side, elbow, [0,-0.48,0.06], [0.2,0.14,0.24], mats.bronze);
      sphere('Lyra_Hand_' + side, elbow, [0,-0.58,0.08], [0.12,0.13,0.12], mats.skin, 12);
      arms.push({ shoulder, elbow, side });
    }

    // Sword: grip, crossguard, blade and a thin solar inlay. Attached to right hand.
    const sword = node('Lyra_Solar_Sword', arms[1].elbow, [0.02,-0.64,0.23]);
    cylinder('Sword_Leather_Grip', sword, [0,-0.06,0], 0.43, 0.08, 0.075, mats.iron, 10);
    box('Sword_Crossguard', sword, [0,0.17,0], [0.52,0.085,0.13], mats.bronze);
    const blade = B.MeshBuilder.CreateBox('Sword_Broad_Steel_Blade', { width: 0.28, height: 1.28, depth: 0.055 }, scene);
    blade.position.set(0,0.86,0);
    blade.parent = sword;
    blade.material = mats.blade;
    registerShadow(blade);
    cylinder('Sword_Pommel', sword, [0,-0.3,0], 0.12, 0.14, 0.14, mats.bladeGlow, 10);
    box('Sword_Solar_Inlay', sword, [0,0.88,0.035], [0.045,1.0,0.018], mats.bladeGlow);
    torus('Sword_Pommel_Ring', sword, [0,-0.27,0], 0.17, 0.035, mats.bladeGlow, [Math.PI/2,0,0]);

    const aura = sphere('Lyra_Solar_Aura', yawNode, [0,1.15,0], [0.95,1.25,0.75], auraMat, 16);
    aura.isPickable = false;
    return { root, facing: yawNode, arms, legs, sword, cape: yawNode.getChildMeshes().find(m => m.name === 'Lyra_Cape'), aura };
  }

  function createGuardian() {
    const root = node('Moss_Guardian_Root', null, [2.5,0,2.5]);
    const facing = node('Guardian_Facing', root);
    sphere('Guardian_Hips', facing, [0,1.05,0], [0.68,0.5,0.54], mats.enemyBody);
    sphere('Guardian_Torso', facing, [0,1.78,0], [0.82,0.78,0.63], mats.enemyBody, 20);
    sphere('Guardian_Back_Moss_Mantle', facing, [0,1.93,-0.38], [0.8,0.7,0.32], mats.pine2);
    box('Guardian_Chestplate', facing, [0,1.82,0.52], [1.05,0.7,0.2], mats.enemyArmor);
    sphere('Guardian_Heart_Core', facing, [0,1.78,0.67], [0.24,0.28,0.12], mats.enemyGlow, 16);
    const head = node('Guardian_Head', facing, [0,2.62,0.03]);
    sphere('Guardian_Skull', head, [0,0.08,0], [0.54,0.57,0.49], mats.enemyBody, 18);
    box('Guardian_Visor', head, [0,0.03,0.43], [0.74,0.24,0.13], mats.enemyArmor);
    for (const side of [-1,1]) {
      sphere('Guardian_Eye_' + side, head, [side * 0.19,0.04,0.51], [0.09,0.065,0.045], mats.enemyGlow, 12);
      const horn = cylinder('Guardian_Antler_' + side, head, [side * 0.39,0.53,-0.04], 0.94, 0.31, 0.055, mats.enemyHorn, 8);
      horn.rotation.z = side * -0.4;
      sphere('Guardian_Shoulder_' + side, facing, [side * 0.82,2.1,0], [0.48,0.42,0.5], mats.enemyBody);
    }

    const legs = [];
    for (const side of [-1,1]) {
      const hip = node('Guardian_Leg_' + side, facing, [side * 0.42,0.91,0]);
      cylinder('Guardian_Thigh_' + side, hip, [0,-0.28,0], 0.66, 0.38, 0.3, mats.enemyBody, 10);
      const knee = node('Guardian_Knee_' + side, hip, [0,-0.58,0]);
      sphere('Guardian_Knee_Plate_' + side, knee, [0,0,0.08], [0.25,0.21,0.27], mats.enemyArmor);
      cylinder('Guardian_Shin_' + side, knee, [0,-0.28,0], 0.58, 0.3, 0.24, mats.enemyBody, 10);
      box('Guardian_Foot_' + side, knee, [0,-0.2,0.2], [0.51,0.26,0.72], mats.enemyArmor);
      for (let toe = 0; toe < 2; toe++) sphere('Guardian_Toe_' + side + '_' + toe, knee, [side * (0.12 + toe * 0.13),-0.28,0.48], [0.13,0.12,0.24], mats.enemyBody, 10);
      legs.push({ hip, knee, side });
    }

    const arms = [];
    for (const side of [-1,1]) {
      const shoulder = node('Guardian_Arm_' + side, facing, [side * 0.83,2.12,0]);
      cylinder('Guardian_Upper_Arm_' + side, shoulder, [side * 0.1,-0.37,0], 0.78, 0.38, 0.32, mats.enemyBody, 10);
      const elbow = node('Guardian_Elbow_' + side, shoulder, [side * 0.17,-0.72,0.02]);
      sphere('Guardian_Elbow_Knot_' + side, elbow, [0,0,0], [0.31,0.3,0.3], mats.enemyArmor);
      cylinder('Guardian_Forearm_' + side, elbow, [side * 0.08,-0.34,0.04], 0.7, 0.33, 0.43, mats.enemyBody, 10);
      box('Guardian_Wrist_Bone_' + side, elbow, [side * 0.13,-0.69,0.09], [0.4,0.25,0.44], mats.enemyArmor);
      sphere('Guardian_Fist_' + side, elbow, [side * 0.15,-0.83,0.1], [0.32,0.25,0.32], mats.enemyBody);
      arms.push({ shoulder, elbow, side });
    }
    // Spine growths and root-barb details.
    for (let i = 0; i < 5; i++) {
      const x = (i - 2) * 0.24;
      const barb = cylinder('Guardian_Back_Root_' + i, facing, [x,2.28,-0.56], 0.65, 0.24, 0.04, mats.enemyHorn, 7);
      barb.rotation.x = -0.45;
      barb.rotation.z = (i - 2) * 0.12;
    }
    const telegraph = torus('Guardian_Windup_Ring', root, [0,0.06,0], 3.2, 0.075, mats.flame);
    telegraph.isVisible = false;
    return { root, facing, arms, legs, head, heart: scene.getMeshByName('Guardian_Heart_Core'), telegraph };
  }

  const hero = createLyra();
  const guardian = createGuardian();

  // ---------- Procedural particles and combat audio ----------
  const particleTexture = (() => {
    const tex = new B.DynamicTexture('Soft_Particle_Texture', { width: 64, height: 64 }, scene, false);
    const ctx = tex.getContext();
    const g = ctx.createRadialGradient(32,32,1,32,32,31);
    g.addColorStop(0, 'rgba(255,255,255,1)');
    g.addColorStop(0.2, 'rgba(255,255,255,.9)');
    g.addColorStop(0.55, 'rgba(255,255,255,.28)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0,0,64,64); tex.update();
    return tex;
  })();
  function burstParticles(position, color1, color2, count = 26, size = 0.28, power = 4) {
    const ps = new B.ParticleSystem('Combat_Sparks', 180, scene);
    ps.particleTexture = particleTexture;
    ps.emitter = position.clone();
    ps.minEmitBox = new B.Vector3(-0.08,-0.08,-0.08);
    ps.maxEmitBox = new B.Vector3(0.08,0.08,0.08);
    ps.color1 = B.Color4.FromHexString(color1 + 'ff');
    ps.color2 = B.Color4.FromHexString(color2 + 'ff');
    ps.colorDead = new B.Color4(0.1,0.12,0.1,0);
    ps.minSize = size * 0.35; ps.maxSize = size;
    ps.minLifeTime = 0.18; ps.maxLifeTime = 0.58;
    ps.emitRate = 0;
    ps.manualEmitCount = count;
    ps.blendMode = B.ParticleSystem.BLENDMODE_ADD;
    ps.minEmitPower = power * 0.35; ps.maxEmitPower = power;
    ps.direction1 = new B.Vector3(-1.2,0.2,-1.2);
    ps.direction2 = new B.Vector3(1.2,2.8,1.2);
    ps.gravity = new B.Vector3(0,-5.2,0);
    ps.start();
    ps.targetStopDuration = 0.05;
    setTimeout(() => { ps.dispose(); }, 1100);
  }

  let audioContext = null;
  let masterGain = null;
  let soundMuted = false;
  function initAudio() {
    if (audioContext) { audioContext.resume(); return; }
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    audioContext = new AudioCtx();
    masterGain = audioContext.createGain();
    masterGain.gain.value = soundMuted ? 0 : 0.16;
    masterGain.connect(audioContext.destination);
  }
  function tone(freq, duration = 0.12, type = 'triangle', sweep = null, gainValue = 0.2) {
    if (!audioContext || !masterGain || soundMuted) return;
    const t = audioContext.currentTime;
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(30, freq), t);
    if (sweep) osc.frequency.exponentialRampToValueAtTime(Math.max(30, sweep), t + duration);
    gain.gain.setValueAtTime(gainValue, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
    osc.connect(gain).connect(masterGain);
    osc.start(t); osc.stop(t + duration + 0.015);
  }
  function sfxLight() { tone(480,0.1,'triangle',185,0.13); }
  function sfxHeavy() { tone(185,0.22,'sawtooth',55,0.2); tone(95,0.16,'sine',48,0.16); }
  function sfxHit() { tone(142,0.16,'sawtooth',55,0.22); tone(610,0.07,'triangle',250,0.12); }
  function sfxDodge() { tone(260,0.17,'sine',760,0.14); }
  function sfxSolar() { tone(92,0.48,'sine',760,0.2); tone(310,0.4,'triangle',980,0.13); }
  function sfxWin() { [523,659,784,1046].forEach((f,i) => setTimeout(() => tone(f,0.3,'triangle',f*1.08,0.15), i*125)); }

  // ---------- Game state and UI ----------
  const STATE = { MENU: 'menu', PLAYING: 'playing', PAUSED: 'paused', OVER: 'over' };
  let gameState = STATE.MENU;
  let health = 100, enemyHealth = 240, solarCooldown = 0;
  let playerVelocity = new B.Vector3(0,0,0);
  let playerYaw = 0, verticalVelocity = 0, jumpHeight = 0;
  let moveAmount = 0, dashTime = 0, dashDirection = new B.Vector3(0,0,1);
  let invulnerability = 0, attackKind = '', attackTimer = 0, attackDuration = 0, attackHit = false, comboCount = 0, comboWindow = 0;
  let solarTime = 0, hitStop = 0;
  let enemyState = 'approach', enemyTimer = 0, enemyYaw = Math.PI;
  let gameTime = 0, hudClock = 0, toastClock = 0, lastFrame = performance.now(), accumulator = 0;
  const STEP = 1 / 120;
  const keys = new Set();
  const mobileInput = { x: 0, z: 0 };
  let joystickPointer = null;
  let bestWins = Number(localStorage.getItem('playzippy_moss_gate_proto_v1') || 0);

  function showScreen(which) {
    $('menu-screen').classList.toggle('hidden', which !== STATE.MENU);
    $('pause-screen').classList.toggle('hidden', which !== STATE.PAUSED);
    $('result-screen').classList.toggle('hidden', which !== STATE.OVER);
    $('hud').classList.toggle('hidden', which !== STATE.PLAYING);
    $('mobile-controls').classList.toggle('hidden', which !== STATE.PLAYING);
    gameState = which;
  }
  function toast(message) {
    $('toast').textContent = message;
    $('toast').classList.add('show');
    toastClock = 1.55;
  }
  function updateHUD() {
    $('hero-health-text').textContent = Math.max(0, Math.ceil(health)) + ' / 100';
    $('hero-health-bar').style.width = Math.max(0, health) + '%';
    $('enemy-health-text').textContent = Math.max(0, Math.ceil(enemyHealth)) + ' / 240';
    $('enemy-health-bar').style.width = Math.max(0, enemyHealth / 240 * 100) + '%';
    $('solar-status').textContent = solarCooldown <= 0 ? 'READY' : solarCooldown.toFixed(1) + 's';
    $('solar-charge-bar').style.width = (1 - Math.max(0, solarCooldown) / 8) * 100 + '%';
  }
  function setObjective(title, subtitle) {
    $('objective-title').textContent = title;
    $('objective-subtitle').textContent = subtitle;
  }
  function resetGame() {
    health = 100; enemyHealth = 240; solarCooldown = 0;
    playerVelocity.set(0,0,0); playerYaw = 0; verticalVelocity = 0; jumpHeight = 0;
    moveAmount = 0; dashTime = 0; dashDirection.set(0,0,1);
    invulnerability = 0; attackKind = ''; attackTimer = 0; attackHit = false; comboCount = 0; comboWindow = 0;
    solarTime = 0; hitStop = 0; enemyState = 'approach'; enemyTimer = 0; enemyYaw = Math.PI;
    gameTime = 0; hudClock = 0; accumulator = 0;
    hero.root.position.set(0,0,-13); hero.facing.rotation.set(0,0,0);
    guardian.root.position.set(2.5,0,2.5); guardian.facing.rotation.set(0,Math.PI,0); guardian.root.setEnabled(true);
    guardian.telegraph.isVisible = false;
    guardian.heart.material = mats.enemyGlow;
    portalRing.material = mats.bladeGlow;
    portalDiscMat.alpha = 0.72;
    runeCore.isVisible = true;
    wardLines.forEach((m) => m.isVisible = true);
    updateHUD();
    setObjective('DEFEAT THE MOSS GUARDIAN','Watch its shoulders. Dodge when the red ward flares.');
    updateCamera(0, true);
  }

  function startGame() {
    initAudio();
    if (audioContext) audioContext.resume();
    resetGame();
    showScreen(STATE.PLAYING);
    canvas.focus();
  }
  function finishGame(won) {
    if (gameState !== STATE.PLAYING) return;
    if (won) {
      bestWins += 1;
      localStorage.setItem('playzippy_moss_gate_proto_v1', String(bestWins));
      $('result-title').textContent = 'THE GATE REMEMBERS';
      $('result-copy').textContent = 'The guardian has fallen. The solar seal answers Lyra, and the passage into the hollow opens. Trial victories: ' + bestWins + '.';
      sfxWin();
    } else {
      $('result-title').textContent = 'THE HEARTH FADES';
      $('result-copy').textContent = 'The guardian overwhelms Lyra. Read its warning, evade the committed strike, and return with the light of the last hearth.';
      tone(260,0.35,'sawtooth',55,0.18);
    }
    showScreen(STATE.OVER);
  }

  function facePoint(actor, target) {
    const dx = target.x - actor.position.x;
    const dz = target.z - actor.position.z;
    return Math.atan2(dx, dz);
  }
  function shortestAngle(a, b) { let d = (b - a + Math.PI * 3) % (Math.PI * 2) - Math.PI; return d; }
  function dampAngle(a, b, rate, dt) { return a + shortestAngle(a,b) * (1 - Math.exp(-rate * dt)); }
  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function worldForward(yaw) { return new B.Vector3(Math.sin(yaw), 0, Math.cos(yaw)); }

  function beginAttack(kind) {
    if (gameState !== STATE.PLAYING || attackTimer > 0 || dashTime > 0) return;
    if (kind === 'light' && comboWindow > 0) comboCount = (comboCount % 3) + 1;
    else comboCount = kind === 'light' ? 1 : 0;
    attackKind = kind;
    attackDuration = kind === 'heavy' ? 0.82 : (0.48 + (comboCount - 1) * 0.035);
    attackTimer = attackDuration;
    attackHit = false;
    comboWindow = 0.72;
    if (kind === 'heavy') sfxHeavy(); else sfxLight();
  }
  function dodge() {
    if (gameState !== STATE.PLAYING || dashTime > 0) return;
    let d = new B.Vector3(playerVelocity.x,0,playerVelocity.z);
    if (d.lengthSquared() < 0.05) d = worldForward(playerYaw);
    d.normalize();
    dashDirection.copyFrom(d);
    dashTime = 0.29;
    invulnerability = 0.62;
    attackTimer = 0;
    sfxDodge();
  }
  function jump() {
    if (gameState === STATE.PLAYING && jumpHeight <= 0.001 && dashTime <= 0) {
      verticalVelocity = 6.8;
      tone(185,0.14,'sine',470,0.12);
    }
  }
  function solarBurst() {
    if (gameState !== STATE.PLAYING || solarCooldown > 0 || dashTime > 0) return;
    solarCooldown = 8;
    solarTime = 0.62;
    sfxSolar();
    const origin = hero.root.position.add(new B.Vector3(0,1.15,0));
    burstParticles(origin, '#ffd37a', '#f27b42', 82, 0.42, 7.5);
    const distance = B.Vector3.Distance(new B.Vector3(hero.root.position.x,0,hero.root.position.z), new B.Vector3(guardian.root.position.x,0,guardian.root.position.z));
    if (guardian.root.isEnabled() && distance < 5.8) damageGuardian(94, 2.15);
    toast('SOLAR BURST');
  }

  function damageGuardian(amount, knockback = 0.6) {
    if (!guardian.root.isEnabled() || enemyHealth <= 0) return;
    enemyHealth = Math.max(0, enemyHealth - amount);
    const fromHero = guardian.root.position.subtract(hero.root.position);
    fromHero.y = 0;
    if (fromHero.lengthSquared() > 0.001) {
      fromHero.normalize();
      guardian.root.position.addInPlace(fromHero.scale(knockback));
    }
    guardian.heart.material = mats.bladeGlow;
    setTimeout(() => { if (guardian.root.isEnabled() && enemyHealth > 0) guardian.heart.material = mats.enemyGlow; }, 120);
    burstParticles(guardian.root.position.add(new B.Vector3(0,1.7,0)), '#ffd58d', '#d56b43', 30, 0.26, 5.2);
    sfxHit();
    hitStop = 0.055;
    updateHUD();
    if (enemyHealth <= 0) {
      guardian.root.setEnabled(false);
      guardian.telegraph.isVisible = false;
      burstParticles(guardian.root.position.add(new B.Vector3(0,1.8,0)), '#f6d48c', '#5bc5a8', 115, 0.5, 8.5);
      portalDisk.material = portalDiscMat;
      portalDiscMat.alpha = 0.24;
      portalRing.material = mats.bladeGlow;
      runeCore.isVisible = true;
      setObjective('REACH THE MOSS GATE','The seal is awake. Walk forward to complete the trial.');
      toast('THE MOSS GUARDIAN HAS FALLEN');
    }
  }

  function tryMeleeHit() {
    if (attackHit) return;
    attackHit = true;
    const toEnemy = guardian.root.position.subtract(hero.root.position);
    toEnemy.y = 0;
    const dist = toEnemy.length();
    if (dist > (attackKind === 'heavy' ? 3.9 : 3.25)) return;
    const dir = toEnemy.normalize();
    const fwd = worldForward(playerYaw);
    const dot = B.Vector3.Dot(dir,fwd);
    if (dot < (attackKind === 'heavy' ? 0.05 : 0.2)) return;
    let damage = attackKind === 'heavy' ? 72 : (comboCount === 3 ? 51 : (comboCount === 2 ? 42 : 34));
    damageGuardian(damage, attackKind === 'heavy' ? 1.45 : 0.68);
    const origin = hero.root.position.add(fwd.scale(1.3)).add(new B.Vector3(0,1.5,0));
    burstParticles(origin, '#f3db9c', '#e98d54', attackKind === 'heavy' ? 34 : 19, 0.2, 4.6);
  }

  function updatePlayer(dt) {
    const xInput = (keys.has('KeyD') || keys.has('ArrowRight') ? 1 : 0) - (keys.has('KeyA') || keys.has('ArrowLeft') ? 1 : 0) + mobileInput.x;
    const zInput = (keys.has('KeyW') || keys.has('ArrowUp') ? 1 : 0) - (keys.has('KeyS') || keys.has('ArrowDown') ? 1 : 0) + mobileInput.z;
    const inputLength = Math.hypot(xInput,zInput);
    const ix = inputLength > 1 ? xInput / inputLength : xInput;
    const iz = inputLength > 1 ? zInput / inputLength : zInput;
    const camForward = new B.Vector3(Math.sin(playerYaw),0,Math.cos(playerYaw));
    const camRight = new B.Vector3(Math.cos(playerYaw),0,-Math.sin(playerYaw));
    let desired = camRight.scale(ix).add(camForward.scale(iz));
    if (desired.lengthSquared() > 0.001) desired.normalize();
    const speed = keys.has('ControlLeft') ? 3.5 : 4.9;

    if (dashTime > 0) {
      dashTime = Math.max(0,dashTime-dt);
      hero.root.position.addInPlace(dashDirection.scale(11.5*dt));
    } else {
      const targetV = desired.scale(speed);
      const smoothing = inputLength > 0.05 ? 13 : 16;
      playerVelocity.x += (targetV.x - playerVelocity.x) * (1 - Math.exp(-smoothing*dt));
      playerVelocity.z += (targetV.z - playerVelocity.z) * (1 - Math.exp(-smoothing*dt));
      hero.root.position.x += playerVelocity.x * dt;
      hero.root.position.z += playerVelocity.z * dt;
    }
    hero.root.position.x = clamp(hero.root.position.x,-13,13);
    hero.root.position.z = clamp(hero.root.position.z,-20,16.3);
    if (inputLength > 0.05 && dashTime <= 0) {
      const targetYaw = Math.atan2(desired.x, desired.z);
      playerYaw = dampAngle(playerYaw,targetYaw,14,dt);
    }
    if (jumpHeight > 0 || verticalVelocity > 0) {
      verticalVelocity -= 19.5*dt;
      jumpHeight += verticalVelocity*dt;
      if (jumpHeight < 0) { jumpHeight = 0; verticalVelocity = 0; }
    }
    moveAmount = clamp(inputLength,0,1);
    hero.root.position.y = jumpHeight;
    hero.facing.rotation.y = playerYaw;

    if (attackTimer > 0) {
      attackTimer = Math.max(0,attackTimer-dt);
      const progress = 1 - attackTimer/attackDuration;
      const impactAt = attackKind === 'heavy' ? 0.58 : 0.39;
      if (!attackHit && progress >= impactAt) tryMeleeHit();
      if (attackTimer <= 0) { attackKind = ''; comboWindow = 0.72; }
    }
    comboWindow = Math.max(0,comboWindow-dt);
    invulnerability = Math.max(0,invulnerability-dt);
    solarCooldown = Math.max(0,solarCooldown-dt);
    solarTime = Math.max(0,solarTime-dt);
  }

  function updateGuardian(dt) {
    if (!guardian.root.isEnabled()) return;
    const delta = hero.root.position.subtract(guardian.root.position);
    delta.y = 0;
    const dist = Math.max(0.001,delta.length());
    enemyYaw = Math.atan2(delta.x,delta.z);
    guardian.facing.rotation.y = dampAngle(guardian.facing.rotation.y,enemyYaw,10,dt);
    enemyTimer -= dt;
    guardian.telegraph.isVisible = enemyState === 'windup';
    if (enemyState === 'approach') {
      if (dist > 2.45) {
        const d = delta.normalize();
        guardian.root.position.addInPlace(d.scale(1.7*dt));
      } else {
        enemyState = 'windup'; enemyTimer = 0.93;
        toast('GUARDIAN WINDING UP — DODGE');
      }
    } else if (enemyState === 'windup') {
      if (enemyTimer <= 0) {
        enemyState = 'strike'; enemyTimer = 0.3;
        if (dist < 3.4 && invulnerability <= 0) {
          health = Math.max(0,health-21);
          invulnerability = 0.78;
          burstParticles(hero.root.position.add(new B.Vector3(0,1.25,0)), '#de7555', '#e8bd79', 26, 0.24, 4.5);
          tone(105,0.24,'sawtooth',40,0.2);
          toast('LYRA WAS HIT');
          updateHUD();
          if (health <= 0) finishGame(false);
        }
      }
    } else if (enemyState === 'strike') {
      const d = worldForward(enemyYaw);
      guardian.root.position.addInPlace(d.scale(3.4*dt));
      if (enemyTimer <= 0) { enemyState = 'recover'; enemyTimer = 1.1; }
    } else if (enemyState === 'recover') {
      if (enemyTimer <= 0) enemyState = 'approach';
    }
    guardian.root.position.x = clamp(guardian.root.position.x,-12,12);
    guardian.root.position.z = clamp(guardian.root.position.z,-16,13.3);
  }

  function updateAnimations(dt) {
    const t = gameTime;
    const walk = moveAmount > 0.04 && dashTime <= 0 ? Math.sin(t*10.2)*0.62*moveAmount : 0;
    const jumpTilt = jumpHeight > 0.1 ? -0.17 : 0;
    hero.legs.forEach(({hip,knee,side}) => {
      hip.rotation.x = (side === 1 ? -walk : walk) + jumpTilt;
      knee.rotation.x = Math.max(0,Math.sin(t*10.2 + (side===1?Math.PI:0))) * 0.65 * moveAmount;
    });
    hero.arms.forEach(({shoulder,elbow,side}) => {
      if (attackTimer > 0 && side === 1) {
        const p = 1 - attackTimer/attackDuration;
        const swing = Math.sin(p*Math.PI);
        shoulder.rotation.x = -1.05*swing + 0.25;
        shoulder.rotation.z = -0.18 - 0.5*swing;
        elbow.rotation.x = -0.65*swing;
      } else {
        shoulder.rotation.x = side===1 ? -walk*0.52 : walk*0.42;
        shoulder.rotation.z = side * 0.05;
        elbow.rotation.x = side===1 ? -0.16 : -0.08;
      }
    });
    if (attackTimer > 0) {
      const p = 1 - attackTimer/attackDuration;
      hero.sword.rotation.z = -Math.sin(p*Math.PI) * (attackKind==='heavy'?1.55:1.15);
      hero.sword.rotation.x = Math.sin(p*Math.PI) * 0.3;
    } else {
      hero.sword.rotation.z += (0 - hero.sword.rotation.z) * (1-Math.exp(-13*dt));
      hero.sword.rotation.x += (0 - hero.sword.rotation.x) * (1-Math.exp(-13*dt));
    }
    hero.cape.rotation.x = 0.12 + Math.sin(t*3.1)*0.055 + moveAmount*0.09;
    hero.cape.rotation.z = Math.sin(t*4.2)*0.025;
    const auraPulse = 0.96 + Math.sin(t*2.4)*0.025;
    hero.aura.scaling.set(0.95*auraPulse,1.25*auraPulse,0.75*auraPulse);

    if (guardian.root.isEnabled()) {
      const guardianWalk = enemyState === 'approach' ? Math.sin(t*6.5)*0.34 : 0;
      guardian.legs.forEach(({hip,knee,side}) => {
        hip.rotation.x = side===1 ? -guardianWalk : guardianWalk;
        knee.rotation.x = Math.max(0,Math.sin(t*6.5 + (side===1?Math.PI:0))) * 0.36;
      });
      guardian.arms.forEach(({shoulder,elbow,side}) => {
        if (enemyState === 'windup') {
          shoulder.rotation.x = -1.05 + Math.sin(t*16)*0.07;
          elbow.rotation.x = -0.5;
        } else if (enemyState === 'strike') {
          shoulder.rotation.x = 0.85;
          elbow.rotation.x = 0.45;
        } else {
          shoulder.rotation.x = side===1 ? guardianWalk*0.42 : -guardianWalk*0.42;
          elbow.rotation.x = 0.08;
        }
      });
      guardian.head.rotation.x = enemyState==='windup' ? 0.14 + Math.sin(t*14)*0.05 : Math.sin(t*1.6)*0.025;
      const corePulse = enemyState==='windup' ? 1.1 + Math.sin(t*15)*0.12 : 1 + Math.sin(t*3.4)*0.04;
      guardian.heart.scaling.set(0.24*corePulse,0.28*corePulse,0.12*corePulse);
      guardian.telegraph.scaling.setAll(1 + Math.sin(t*13)*0.07);
    }
    // The seal breathes; flames and firelight flicker independently.
    portalRing.rotation.z = Math.sin(t*0.55)*0.055;
    portalInner.rotation.z = -t*0.14;
    runeCore.scaling.setAll(0.9 + Math.sin(t*2.4)*0.1);
    torchLights.forEach(({light,flame,side}) => {
      const flicker = 0.92 + Math.sin(t*11 + side)*0.12 + Math.sin(t*19 + side*3)*0.05;
      light.intensity = 1.25*flicker;
      flame.scaling.y = 0.48*flicker;
      flame.position.y = 4.75 + Math.sin(t*8+side)*0.06;
    });
  }

  let camTarget = new B.Vector3(0,1.35,0);
  let camPosition = new B.Vector3(0,4,-15);
  function updateCamera(dt, snap = false) {
    const forward = worldForward(playerYaw);
    const desiredPos = hero.root.position.subtract(forward.scale(7.2)).add(new B.Vector3(0,3.2,0));
    const desiredTarget = hero.root.position.add(new B.Vector3(0,1.25,0)).add(forward.scale(1.3));
    if (snap) {
      camPosition.copyFrom(desiredPos);
      camTarget.copyFrom(desiredTarget);
    } else {
      const a = 1-Math.exp(-5.8*dt);
      camPosition = B.Vector3.Lerp(camPosition,desiredPos,a);
      camTarget = B.Vector3.Lerp(camTarget,desiredTarget,1-Math.exp(-8.5*dt));
    }
    camera.position.copyFrom(camPosition);
    camera.setTarget(camTarget);
  }

  function checkGateWin() {
    if (guardian.root.isEnabled() || enemyHealth > 0) return;
    const toGate = B.Vector3.Distance(new B.Vector3(hero.root.position.x,0,hero.root.position.z),new B.Vector3(0,0,19));
    if (toGate < 3.7) finishGame(true);
  }

  // ---------- Input ----------
  const pressedCodes = new Set(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','KeyJ','KeyK','KeyQ','Space','ShiftLeft','ShiftRight','Escape']);
  window.addEventListener('keydown',(e) => {
    if (pressedCodes.has(e.code)) e.preventDefault();
    if (e.repeat) return;
    keys.add(e.code);
    if (e.code==='KeyJ') beginAttack('light');
    if (e.code==='KeyK') beginAttack('heavy');
    if (e.code==='Space') dodge();
    if (e.code==='ShiftLeft'||e.code==='ShiftRight') jump();
    if (e.code==='KeyQ') solarBurst();
    if (e.code==='Escape' && gameState===STATE.PLAYING) showScreen(STATE.PAUSED);
  },{passive:false});
  window.addEventListener('keyup',(e) => keys.delete(e.code));
  window.addEventListener('blur',() => { keys.clear(); if(gameState===STATE.PLAYING) showScreen(STATE.PAUSED); });
  canvas.addEventListener('pointerdown',(e) => { if(gameState===STATE.PLAYING && e.button===0) beginAttack('light'); });
  $('start-button').addEventListener('click',startGame);
  $('resume-button').addEventListener('click',() => { initAudio(); showScreen(STATE.PLAYING); canvas.focus(); });
  $('restart-button').addEventListener('click',startGame);
  $('sound-button').addEventListener('click',() => {
    soundMuted = !soundMuted;
    $('sound-button').textContent = soundMuted ? 'SOUND OFF' : 'SOUND ON';
    if(masterGain) masterGain.gain.setTargetAtTime(soundMuted?0:0.16,audioContext.currentTime,0.035);
  });

  // Mobile virtual stick and action pads.
  const stick = $('move-stick'), knob = $('stick-knob');
  stick.addEventListener('pointerdown',(e) => { joystickPointer=e.pointerId; stick.setPointerCapture(e.pointerId); updateStick(e); });
  stick.addEventListener('pointermove',(e) => { if(e.pointerId===joystickPointer) updateStick(e); });
  function updateStick(e) {
    const r = stick.getBoundingClientRect();
    const cx = r.left+r.width/2, cy = r.top+r.height/2;
    let dx=e.clientX-cx, dy=e.clientY-cy;
    const max=38, len=Math.hypot(dx,dy);
    if(len>max){dx=dx/len*max;dy=dy/len*max;}
    knob.style.transform=`translate(${dx}px,${dy}px)`;
    mobileInput.x=dx/max;
    mobileInput.z=-dy/max;
  }
  function resetStick() { joystickPointer=null; mobileInput.x=0; mobileInput.z=0; knob.style.transform='translate(0,0)'; }
  stick.addEventListener('pointerup',resetStick);
  stick.addEventListener('pointercancel',resetStick);
  document.querySelectorAll('[data-action]').forEach(btn => {
    const action = btn.dataset.action;
    const run = (e) => {
      e.preventDefault();
      if(action==='light') beginAttack('light');
      else if(action==='heavy') beginAttack('heavy');
      else if(action==='dodge') dodge();
      else if(action==='jump') jump();
      else if(action==='solar') solarBurst();
    };
    btn.addEventListener('pointerdown',run,{passive:false});
  });

  // ---------- Main fixed-step loop ----------
  function simulate(dt) {
    gameTime += dt;
    updatePlayer(dt);
    updateGuardian(dt);
    updateAnimations(dt);
    updateCamera(dt);
    checkGateWin();
    if (toastClock > 0) {
      toastClock -= dt;
      if (toastClock <= 0) $('toast').classList.remove('show');
    }
    hudClock += dt;
    if (hudClock >= 0.1) { hudClock = 0; updateHUD(); }
  }

  // Initial staging and browser runtime.
  resetGame();
  $('loading-note').textContent = 'MOSS GATE · 3D WORLD READY';
  setTimeout(() => $('loading-note').style.opacity = '0', 1700);
  engine.runRenderLoop(() => {
    const now = performance.now();
    const dt = Math.min((now-lastFrame)/1000,0.05);
    lastFrame = now;
    if (gameState === STATE.PLAYING) {
      accumulator += dt;
      let steps = 0;
      while (accumulator >= STEP && steps < 7) {
        if (hitStop > 0) hitStop = Math.max(0,hitStop-STEP);
        else simulate(STEP);
        accumulator -= STEP;
        steps++;
      }
    } else if (gameState === STATE.MENU || gameState === STATE.PAUSED || gameState === STATE.OVER) {
      // Ambient scene life continues behind the overlays.
      gameTime += dt*0.35;
      updateAnimations(dt*0.35);
    }
    scene.render();
  });
  window.addEventListener('resize',() => engine.resize());

  // Helpful global debug handle for browser QA; does not affect normal play.
  window.EmberfallMossGate = { scene, engine, hero, guardian, startGame, getState:()=>gameState };
})();
