# Emberfall: The Last Hearth — Moss Gate 3D Prototype

A browser-first, full-3D third-person action RPG prototype. The project is deliberately self-contained and uses procedural geometry for its characters, environment, animation, particles and combat. It does not require Blender, Unity, Unreal Engine, Node.js or a local 3D editor.

## Run it

1. Extract this ZIP.
2. Open `index.html` in a modern desktop browser, or serve the folder as a static website.
3. An internet connection is required because Babylon.js is loaded from its official CDN (`https://cdn.babylonjs.com/babylon.js`). There is no install or build step.

For local testing, a static file server is recommended because browsers may apply stricter restrictions to files opened directly from disk. Any static server will work; no project build is necessary.

## Controls

| Action | Keyboard / mouse |
|---|---|
| Move | W A S D / arrow keys |
| Light sword combo | J / left mouse click |
| Heavy strike | K |
| Dodge | Space |
| Jump | Shift |
| Solar Burst | Q |
| Pause | Esc |

Touch devices get an on-screen movement stick and action buttons.

## Included in this prototype

- Third-person chase camera with smooth follow and aim.
- Procedurally assembled Lyra character with hierarchical limb pivots, locomotion, attack, dodge and jump poses.
- Moss Guardian with approach, wind-up, strike and recovery AI states, visible warning ring and animated limbs.
- Three-hit light combo, heavy strike, dodge invulnerability, jump, Solar Burst, enemy health, player health and defeat / victory flows.
- Moss Gate arena with ancient stone arch, sealed solar portal, ward stones, pine forest, rubble, moss patches, braziers, dynamic lighting, fog, shadows, bloom and hit particles.
- Synthesized browser sound effects (unlocked on Start) and mute control.
- Separate local progress key: `playzippy_moss_gate_proto_v1`.

## Structure

- `index.html` — game shell and HUD.
- `style.css` — title screen, HUD, pause/result screens and mobile controls.
- `src/game.js` — Babylon.js scene, procedural models, enemy AI, combat, animation, effects and input.

## Important scope note

This is a self-contained playable prototype/blockout for the Moss Gate encounter, not the completed Emberfall campaign. Character shapes and motion are procedurally authored stand-ins, not externally generated or motion-captured production assets. The current prototype is independent of the stable Emberfall v3.0.2 release and does not overwrite its save data.
