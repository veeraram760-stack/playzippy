# PlayZippy

A responsive HTML5 browser gaming portal built with React, Vite and Phaser.

## Included games
- Panda Dash — Phaser endless runner prototype
- Block Master — block placement puzzle
- Traffic Rush — lane-dodging arcade game
- Memory Match — card matching game
- Coin Factory — idle clicker

## Requirements
- Node.js 20 LTS or newer
- npm

## Upload to GitHub (browser method)
1. Open `https://github.com/veeraram760-stack/playzippy`.
2. Since the repository is empty, select **uploading an existing file** on the Quick setup page. (Once files exist, use **Add file → Upload files**.)
3. Extract the project ZIP on your computer first.
4. Upload the extracted files and folders (not the ZIP archive itself).
5. Commit the upload to the `main` branch.

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite (usually http://localhost:5173).

## Production build
```bash
npm run build
npm run preview
```
The production site is generated in `dist/`.

## Deploy to Cloudflare Pages
1. Push this project to a Git repository you control.
2. In Cloudflare Pages, create a project and connect the repository.
3. Framework preset: Vite.
4. Build command: `npm run build`.
5. Build output directory: `dist`.
6. Deploy. The free `pages.dev` subdomain can be used initially.

## Before public launch
- Replace `YOUR-DOMAIN.example` in `index.html`, `public/robots.txt` and `public/sitemap.xml` with the final canonical domain.
- Replace publisher contact placeholders in the privacy, terms and contact pages.
- Review legal policies for your actual business, analytics, ad providers, audience and applicable jurisdictions.
- Add the chosen analytics provider only after creating the account and reviewing consent/privacy obligations.
- Keep `VITE_ADS_ENABLED` unset/false until an ad provider approves the property and supplies approved ad code. Never invent publisher IDs.
- Test every game on current mobile and desktop browsers.
- Add real original screenshots and social preview artwork before outreach.
- Check game ad network SDK terms before submitting any portal-specific build.

## Ads
Ad slots are intentionally disabled by default. The `AdSlot` component only renders if `VITE_ADS_ENABLED=true`; it is a placeholder, not a working ad integration. Add the provider's exact approved script and placement code after signup and approval.

## Notes
- Scores and progress are stored locally in the player's browser.
- No accounts, backend, payment processing or multiplayer are included in this first release.
- This project is a starting release and should be tested before production use.
