# Upload PlayZippy to GitHub

The ChatGPT GitHub connection can read repositories but cannot push code. Upload the project through GitHub's website instead.

1. Open https://github.com/veeraram760-stack/playzippy
2. Because the repository is empty, click the **uploading an existing file** link on GitHub's Quick setup page. (After files exist, the equivalent route is **Add file** → **Upload files**.)
3. On Windows, right-click `PlayZippy_GitHub_Upload.zip` and choose **Extract All**.
4. Open the extracted folder. Drag its contents (files and folders such as `src` and `public`) into GitHub's upload area. GitHub supports uploading files and folders from the browser. Do not upload only the ZIP file.
5. Scroll down, keep the branch as `main`, enter the commit message `Add PlayZippy starter project`, and click **Commit changes**.
6. Refresh the repository page. You should see `src`, `public`, `package.json`, and the README.

After upload, the project still needs a dependency install and production build test. From the project folder run:

```bash
npm install
npm run build
```

The privacy, terms, contact and domain placeholders in the project must be reviewed before public launch. Ad slots remain disabled until an ad provider approves the site.
