export const games = [
  { id:"panda-dash", title:"Panda Dash", category:"Arcade", emoji:"🐼", color:"violet", description:"Run through a green forest, jump over obstacles and see how long you can survive.", controls:"Space / ↑ / tap to jump", featured:true, status:"Playable" },
  { id:"block-master", title:"Block Master", category:"Puzzle", emoji:"🧩", color:"blue", description:"Place colorful blocks, complete full rows and columns, and keep the board clear.", controls:"Select a piece, then tap a starting cell on the board", featured:true, status:"Playable" },
  { id:"traffic-rush", title:"Traffic Rush", category:"Racing", emoji:"🏎️", color:"orange", description:"Switch lanes, dodge traffic and survive for as long as possible.", controls:"← → or tap left/right", featured:true, status:"Playable" },
  { id:"memory-match", title:"Memory Match", category:"Brain", emoji:"🧠", color:"pink", description:"Flip cards, find matching pairs and finish with as few moves as possible.", controls:"Tap or click two cards", featured:false, status:"Playable" },
  { id:"coin-factory", title:"Coin Factory", category:"Idle", emoji:"🏭", color:"green", description:"Tap to make coins, buy upgrades and grow your tiny factory.", controls:"Tap the coin and purchase upgrades", featured:false, status:"Playable" }
];
