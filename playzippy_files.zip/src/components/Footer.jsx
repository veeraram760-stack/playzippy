import React from "react";
import { Link } from "react-router-dom";
export default function Footer() {
  return <footer className="footer">
    <div><Link to="/" className="brand"><span className="brand-mark">▶</span><span>play<span className="brand-accent">zippy</span></span></Link><p>Little games. Big fun. Play instantly in your browser.</p></div>
    <div className="footer-links"><Link to="/about">About</Link><Link to="/privacy">Privacy</Link><Link to="/terms">Terms</Link><Link to="/contact">Contact</Link></div>
    <small>© {new Date().getFullYear()} PlayZippy. All rights reserved.</small>
  </footer>;
}
