import React, { useEffect, useRef, useState } from "react";
import Phaser from "phaser";

export default function PandaDash() {
  const host = useRef(null);
  const gameRef = useRef(null);
  const [score,setScore] = useState(0);
  const [best,setBest] = useState(()=>Number(localStorage.getItem("pz-panda-best")||0));
  const [running,setRunning] = useState(false);

  useEffect(()=>{
    if (!host.current || gameRef.current) return;
    class RunnerScene extends Phaser.Scene {
      constructor(){ super("runner"); }
      create(){
        this.score=0; this.speed=260; this.over=false; this.started=false;
        this.cameras.main.setBackgroundColor("#d9f6e8");
        this.add.rectangle(450,365,900,70,0x79c66b);
        this.add.rectangle(450,400,900,8,0x397a49);
        for(let i=0;i<9;i++){ const x=i*120+30; this.add.rectangle(x,265,18,150,0x57a86a).setAlpha(.35); this.add.circle(x,190,42,0x70c984).setAlpha(.5); }
        this.player=this.add.text(110,285,"🐼",{fontSize:"54px"}).setOrigin(.5);
        this.ground=365;
        this.obstacles=[];
        this.spawn=this.time.addEvent({delay:1450,loop:true,callback:()=>this.addObstacle()});
        this.scoreText=this.add.text(22,20,"SCORE  0",{fontSize:"20px",fontStyle:"bold",color:"#163d2c"});
        this.add.text(450,55,"PANDA DASH",{fontSize:"16px",fontStyle:"bold",color:"#397a49"}).setOrigin(.5);
        this.hint=this.add.text(450,125,"PRESS SPACE OR TAP TO START",{fontSize:"16px",fontStyle:"bold",color:"#24583a"}).setOrigin(.5);
        this.physics.world.setBounds(0,0,900,430);
        this.physics.add.existing(this.player);
        this.player.body.setSize(42,48).setOffset(6,5);
        this.player.body.setCollideWorldBounds(true);
        this.player.body.setGravityY(1200);
        this.player.body.setBounce(0);
        this.player.body.setAllowGravity(false);
        this.groundBody=this.add.rectangle(450,397,900,20,0x397a49,0); this.physics.add.existing(this.groundBody,true); this.physics.add.collider(this.player,this.groundBody);
        this.input.keyboard.on("keydown-SPACE",()=>this.jump());
        this.input.keyboard.on("keydown-UP",()=>this.jump());
        this.input.on("pointerdown",()=>this.jump());
      }
      addObstacle(){
        if(!this.started||this.over)return;
        const cactus=this.add.text(940,315,Math.random()>.5?"🌵":"🪵",{fontSize:"36px"}).setOrigin(.5);
        this.obstacles.push(cactus);
      }
      jump(){
        if(this.over){this.scene.restart();return;}
        if(!this.started){this.started=true;this.player.body.setAllowGravity(true);this.hint.setText("");}
        if(this.player.body.blocked.down||this.player.y>=this.ground-35){this.player.body.setVelocityY(-590);}
      }
      update(_,delta){
        if(!this.started||this.over)return;
        const step=delta/1000;
        this.score+=step*10; this.scoreText.setText("SCORE  "+Math.floor(this.score));
        this.obstacles=this.obstacles.filter(o=>{
          o.x-=this.speed*step;
          if(this.player.y>300 && Math.abs(this.player.x-o.x)<42 && o.x>65 && o.x<160){this.over=true;this.physics.pause();this.hint.setText("GAME OVER — TAP TO RESTART");this.events.emit("gameover",Math.floor(this.score));return false;}
          if(o.x < -50){o.destroy();return false;} return true;
        });
      }
    }
    const game=new Phaser.Game({type:Phaser.AUTO,width:900,height:430,parent:host.current,backgroundColor:"#d9f6e8",physics:{default:"arcade",arcade:{debug:false}},scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH},scene:[RunnerScene]});
    game.events.on("ready",()=>{});
    gameRef.current=game;
    const sceneReady=()=>{ const s=game.scene.getScene("runner"); if(s){s.events.on("gameover",v=>{setScore(v);setRunning(false);setBest(old=>{const n=Math.max(old,v);localStorage.setItem("pz-panda-best",String(n));return n;});});} };
    const timer=setTimeout(sceneReady,500);
    setRunning(true);
    return ()=>{clearTimeout(timer);game.destroy(true);gameRef.current=null;};
  },[]);
  const restart=()=>{ if(gameRef.current){gameRef.current.scene.stop("runner");gameRef.current.scene.start("runner");setScore(0);setRunning(true);} };
  return <div className="game-wrap"><div className="game-hud"><span>🐼 Panda Dash</span><span>Best: {best}</span><button onClick={restart}>Restart</button></div><div ref={host} className="phaser-host"/><p className="game-tip">Press <b>Space</b>, <b>↑</b> or tap the game to jump. Avoid obstacles and beat your best score.</p></div>;
}
