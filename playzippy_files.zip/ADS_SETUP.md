# Advertising setup checklist (owner action required)

Advertising is intentionally disabled in the source project. Do not enable ads until the relevant provider has reviewed and approved the actual live website.

## Google AdSense
1. Publish the site on its final domain and replace all `YOUR-DOMAIN.example` placeholders.
2. Replace the privacy/contact placeholders with accurate business details and publish complete legal disclosures.
3. Apply for AdSense using your own Google account and accurate payee/tax/payment information.
4. Complete Google's site ownership and review steps.
5. Only after approval, add the exact AdSense script and ad unit code supplied in your account. Do not use guessed publisher IDs.
6. Verify consent requirements for visitors in relevant regions before setting advertising cookies or using personalized ads.

## H5 Games Ads
H5 Games Ads is a separate application/integration path and may require an approved AdSense account. Apply separately and use the current official SDK and implementation requirements supplied by Google. Do not assume regular display ad approval automatically grants H5 Games Ads access.

## External portals
For each portal, create the developer account yourself, review its current commercial terms, submit only original/licensed content, and integrate its official SDK into a portal-specific build where required. Never mix portal advertising SDKs with the site's own ad tags unless the platform explicitly permits it.

## Before requesting approval
- Site is live, stable, and has useful original games.
- About, Contact, Privacy and Terms pages are complete and accurate.
- No placeholder email, example domain, broken links or empty pages remain.
- Ads are not placed where accidental clicks are likely.
- No purchased, automated, incentivized or otherwise invalid traffic is used.
