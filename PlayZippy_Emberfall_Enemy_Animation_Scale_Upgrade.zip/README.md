# Emberfall: The Last Hearth — Enemy Animation & Scale Update 2.1

This update addresses the enemy animation and character-size issues in the cinematic 2.5D version. Lyra's movement, combo poses, arenas, controls, relics, room progression, local saves, and existing visual effects are retained.

## Enemy animation and behavior
- **Thornlings / stalkers:** visible run bounce and lean, footstep dust, timed forward claw lunge, slash cue, and recovery pose.
- **Archers:** lateral strafing to maintain range, a readable draw/aim wind-up, projectile release flash, and recoil/recovery movement.
- **Brutes:** heavy stomping gait, deeper crouch telegraph, forward charge with motion streaks, impact ring, and recovery.
- **Guardian:** larger breathing/stomp motion, raised wind-up pose, directional charge, radial shard storm, and ground-slam feedback.
- **Wisps:** orbiting movement with a stronger pulse when firing.
- All enemies now track velocity and facing direction for movement cues and footstep particles. Enemy attack timings and telegraphs remain part of the AI state machine rather than being only decorative effects.

## Character scale balance
Lyra's rendered height has been reduced from 232 to 168 depth-scaled units. Enemy render heights are now 128 (stalker), 140 (archer), 210 (brute), 86 (wisp), and 276 (guardian), all adjusted by floor depth. This makes standard enemies smaller than Lyra and heavy enemies clearly larger.

## Controls
- `WASD` / arrow keys: move
- Mouse 1 / `J`: blade combo
- `Shift`: jump / leap
- `Space`: dodge
- `Q`: Solar Burst
- `E`: interact with gate
- `Esc` / `P`: pause

## Build and checks
- `npm test` runs isolated AI-state checks for stalker melee, archer ranged release, brute charge/recovery, and guardian attack cycles.
- `npm run build` assembles the static site in `dist/`.
- JavaScript syntax validation: `node --check src/main.js`.

A local Chromium navigation attempt was blocked by the container's browser policy, so this update is not represented as fully interactive-browser-playtested.

No AdSense or advertising integration is included.
