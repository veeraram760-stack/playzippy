# Emberfall: The Last Hearth — Cinematic 2.5D Combat Update 2.0

This update moves Emberfall toward the supplied action-RPG reference: a cinematic, angled fantasy arena, larger readable characters, action-specific character frames, depth-aware rendering, and a game-style control HUD.

## Visual and animation changes
- Replaces the three realm backgrounds with 16:9 illustrated forest, forge, and moonlit arenas.
- Adds a 4×4 transparent Lyra animation atlas: run cycle, jump sequence, sword-combo poses, and dodge-roll/recovery poses.
- Adds a separate standing idle pose.
- Character animation uses real pose-frame changes; the whole hero is not rotated to face the cursor. Left/right facing is handled by horizontal mirroring.
- Jump animation lifts Lyra above a ground-anchored shadow; dodge frames sequence through a low evasive roll; attack frames are timed to the existing three-hit combo and slash VFX.
- Enemies remain upright, face Lyra by mirroring, receive depth-based scale, and display readable health bars.
- Player and enemies are drawn in floor-depth order so foreground actors overlap background actors naturally.
- Adds an action guide strip and a visible attack skill control, retaining desktop and mobile controls.

## Gameplay preserved
The existing encounter logic, enemy AI, damage, relic choices, progression, local saves, room gates, and sound effects are retained. No AdSense or advertising integration is included.

## Controls
- `WASD` / arrow keys: move
- Mouse 1 / `J`: blade combo
- `Shift`: jump / leap
- `Space`: dodge
- `Q`: Solar Burst
- `E`: interact with gate
- `Esc` / `P`: pause

## Build and checks
Run `npm run build`. This assembles the static site in `dist/`.

The update was checked with `node --check src/main.js`, a production build, CSS parsing, and verification that all referenced static art files are present. A local headless-browser screenshot attempt was blocked by the container's Chromium process, so this package is not represented as fully browser-playtested.
