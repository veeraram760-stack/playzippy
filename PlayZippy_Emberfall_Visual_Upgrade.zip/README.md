# PlayZippy — Emberfall: The Last Hearth (Visual Upgrade 1.1)

A self-contained browser action-adventure built for the PlayZippy arcade portal. This update keeps the existing combat and progression and replaces the placeholder-looking visual layer with custom painted arena art and detailed character illustrations.

## Visual upgrade

- Three full-screen painted arenas: Verdant Hollow, Ashen Foundry, and Moonwell Keep.
- New detailed transparent character art for Lyra, thornlings, archers, brutes, and the guardian.
- Larger character silhouettes, improved shadows/readability, and realm-specific field-note artwork.
- Existing animated combat feedback, HUD, abilities, boss telegraphs, and controls are preserved.

## Gameplay retained

- Three realms, each with two combat chambers and a guardian encounter.
- Direct movement, mouse-aimed three-strike blade combos, timed dodge invulnerability, and a rechargeable Solar Burst.
- Four enemy behaviors: pursuing thornlings, ranged acolytes, charging brutes, and homing wisps.
- Three guardian fights with wind-up attacks, charges, and projectile patterns.
- XP, levels, shards, room rewards, relic upgrades, and a saved continue point.
- Pause/resume, sound toggle, fullscreen, keyboard/mouse controls, and touch controls for mobile.

## Controls

| Input | Action |
|---|---|
| W A S D / Arrow keys | Move |
| Mouse left click / hold | Aim and strike; time clicks to chain a three-hit combo |
| Space | Dodge with brief invulnerability |
| Q | Solar Burst area attack |
| E | Enter the ember gate after clearing a chamber |
| Esc / P | Pause or resume |

On touch devices, use the left virtual stick and the three action buttons on the right.

## Build

Cloudflare Pages build command:

```sh
unzip -o PlayZippy_Emberfall_Visual_Upgrade.zip -d . && npm install --no-audit --no-fund && npm run build
```

The build script copies the static site to `dist/`. The project has no runtime package dependencies and contains no ad scripts.

## Progress storage

Run progress and sound preference are stored in local storage on the player's device. Clearing site data removes that local save.
