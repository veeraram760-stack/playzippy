# PlayZippy — Rift Swing: Skyline Flow

## New flagship game

Replaces the featured Neon Breakout card with **Rift Swing**, an original grappling-hook momentum arcade platformer.

### Gameplay
- Manual running, jumping, grapple attachment, swing pumping and release.
- Grapple attaches only while the player holds the control and a valid anchor is in range.
- Momentum carries through the pendulum arc; release converts swing speed into a launch.
- Dash is a limited cooldown ability for line correction and gap recovery.
- Aerial tricks award style points when performed in the air while swinging or moving quickly.
- Collect at least two of three shards to unlock the exit gate.
- Checkpoints, timed medals, deaths, best times, and a local progression economy.

### Campaign and replayability
- 12 campaign trials across Skyline, Harbor and Afterglow themes.
- Moving anchors, varied rooftop gaps, float platforms, spike beds, timed lasers and patrol drones.
- Daily seeded run, unlocked level select, local best times and four cosmetic trail colors.

### Input and safety
- Desktop keyboard and mobile touch controls.
- Player remains stationary until the player supplies input; no autonomous player movement or auto-grapple.
- Advertising remains disabled. No ad SDKs are loaded.

### Known scope limits
- Local saves only; no account sync or global leaderboard.
- No real-time multiplayer.
- Requires broader human playtesting and tuning after deployment.
