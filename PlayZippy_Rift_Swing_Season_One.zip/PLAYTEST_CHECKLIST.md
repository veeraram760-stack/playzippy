# Rift Swing playtest checklist

## First 60 seconds
- The runner stands still until movement input is provided.
- Hold A/D or the touch arrows to move along the rooftop.
- Jump, then hold E/J or the GRAPPLE touch button when a nearby anchor is in range.
- Keep directional input to pump the swing; release grapple to launch forward.
- Use dash to correct a trajectory and Q/TRICK while airborne at speed to score style.

## Full level loop
- Avoid rooftop spikes, active laser gates and patrol drones.
- Collect at least two of the three Rift Shards.
- Touch the exit gate to complete the trial.
- Checkpoint beacons save the return point after a fall.
- Medal, time, deaths, credits and unlock progress are saved locally.

## QA status for this source package
- JSX/JavaScript syntax scan: passed for all 18 source files.
- ZIP integrity test: passed.
- Physics smoke test: idle player remains stationary; directional input moves; grapple attaches when held; release detaches and preserves momentum.
- Full Vite production build: not run locally because package installation timed out in this environment. Cloudflare Pages must perform the production build after the ZIP is committed.
- Human playtest across desktop and mobile: still required.
