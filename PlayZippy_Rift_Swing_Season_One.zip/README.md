# PlayZippy — Rift Swing: Skyline Flow

This release makes **Rift Swing** the featured PlayZippy game. It is an original momentum-based grappling arcade platformer built with React, Canvas 2D and Vite.

## Game loop

Run across rooftops, jump into a line, hold the grapple control to catch a nearby neon anchor, pump your swing with directional input, then release to carry momentum across gaps. Use dash to correct a line, perform aerial tricks for style points, collect at least two of three Rift Shards, and reach the exit gate.

The player character is fully input-driven. It does not walk, swing, auto-attach or complete levels by itself. Rival or autopilot movement is not part of this game.

## Content

- 12 campaign trials across three visual zones.
- Moving grapple anchors, rooftop gaps, raised catch platforms, spikes, timed laser gates and patrol drones.
- Manual grapple attach/release and pendulum momentum.
- Run, jump, air control, dash and aerial trick actions.
- Rift Shards, checkpoints, gate conditions, medal times and style scoring.
- Daily seeded challenge and unlocked-level selection.
- Local best times, campaign unlocks, credits and cosmetic trail unlocks.
- Desktop keyboard controls and touch-friendly mobile buttons.
- No ad scripts, ad SDKs or active ad placements.

## Controls

| Action | Desktop | Touch |
|---|---|---|
| Run / pump swing | A / D or ← / → | ◀ / ▶ |
| Jump | Space or W / ↑ | JUMP |
| Grapple | Hold E or J; release to let go | Hold GRAPPLE; release to let go |
| Dash | Shift or X | DASH |
| Aerial trick | Q | TRICK |
| Pause | Esc or pause button | Pause button |

## Local development

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
```

Vite writes production assets to `dist/`.

## Cloudflare Pages

Build command:

```bash
unzip -o PlayZippy_Rift_Swing_Season_One.zip -d . && npm install --no-audit --no-fund && npm run build
```

Build output directory: `dist`.

## Progress and limitations

Progress is stored in browser `localStorage` on the same device/browser. There are no player accounts, cross-device saves, online multiplayer, or global leaderboard in this release. The daily challenge is local/seeded. The current build has not yet received a full human playtest across multiple browsers and mobile devices.
