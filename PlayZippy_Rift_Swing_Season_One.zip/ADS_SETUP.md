# Advertising status

Advertising is intentionally disabled for this PlayZippy release. The AdSlot component remains hidden unless `VITE_ADS_ENABLED=true`, and no advertising SDKs or ad placements are enabled. Do not enable advertising until the site owner approves the gameplay and completes the relevant ad-network review.
