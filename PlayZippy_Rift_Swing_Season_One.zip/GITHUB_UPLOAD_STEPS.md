# Upload Rift Swing to GitHub

1. Open https://github.com/veeraram760-stack/playzippy
2. Choose **Add file → Upload files**.
3. Upload `PlayZippy_Rift_Swing_Season_One.zip` to the repository root. Do not extract it.
4. Commit the upload to `main` with message `Add Rift Swing flagship game`.
5. Cloudflare Pages is configured to extract this ZIP and run `npm run build` with `dist` as its output directory.

The live site changes only after the Cloudflare build and deployment succeed.
