import React, { useCallback, useEffect, useRef, useState } from "react";

const W = 960, H = 540, GRAVITY = 1540, HOOK_RANGE = 360;
const SAVE_KEY = "playzippy.riftswing.v1";
const palettes = [
  { name: "Skyline", sky: ["#10162f", "#281e4a", "#542b59"], glow: "#73f5e7", hot: "#ff7db8", platform: "#1a3152", accent: "#244e68", shard: "#a1fff0" },
  { name: "Harbor", sky: ["#0c1c32", "#123b52", "#1b5264"], glow: "#5ce8ff", hot: "#ffab70", platform: "#16425a", accent: "#1a6370", shard: "#8ff7ff" },
  { name: "Afterglow", sky: ["#211a3b", "#48254e", "#873b61"], glow: "#ffd078", hot: "#ff708a", platform: "#3b2852", accent: "#69405d", shard: "#ffe7a1" },
];
const trails = [
  { id: "cyan", name: "Ion Blue", color: "#7af7ed", cost: 0 },
  { id: "violet", name: "Nova Violet", color: "#b49aff", cost: 420 },
  { id: "gold", name: "Solar Gold", color: "#ffd278", cost: 760 },
  { id: "pink", name: "Pulse Pink", color: "#ff83c6", cost: 1100 },
];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (r) => { r.seed = (r.seed * 1664525 + 1013904223) >>> 0; return r.seed / 4294967296; };
const nowKey = () => new Date().toISOString().slice(0, 10);
function loadSave() {
  try {
    const s = JSON.parse(localStorage.getItem(SAVE_KEY) || "null");
    return { unlocked: Math.max(1, s?.unlocked || 1), shards: s?.shards || 0, credits: s?.credits || 0, best: s?.best || {}, medals: s?.medals || {}, trail: s?.trail || "cyan", daily: s?.daily || {} };
  } catch { return { unlocked: 1, shards: 0, credits: 0, best: {}, medals: {}, trail: "cyan", daily: {} }; }
}
function saveData(s) { try { localStorage.setItem(SAVE_KEY, JSON.stringify(s)); } catch {} }

function makeLevel(index, daily = false) {
  const seed = daily ? Number(nowKey().replaceAll("-", "")) + 817 : 7719 + index * 911;
  const r = { seed: seed >>> 0 };
  const world = daily ? (seed % 3) : Math.floor(index / 4) % 3;
  const palette = palettes[world];
  const difficulty = daily ? 2 : Math.floor(index / 3);
  const length = 2860 + Math.min(index, 11) * 95;
  const platforms = [];
  // Continuous and broken rooftop sections create deliberate jump/swing decisions.
  let x = 0;
  while (x < length - 160) {
    const w = 410 + rand(r) * 155;
    platforms.push({ x, y: 458, w: Math.min(w, length - x), h: 90, kind: "ground" });
    x += w + 62 + rand(r) * (56 + difficulty * 9);
  }
  // Raised catch platforms and small momentum-reset islands.
  for (let i = 0; i < 5 + Math.floor(index / 2); i++) {
    const px = 390 + i * (430 + rand(r) * 80);
    if (px < length - 260) platforms.push({ x: px, y: 365 - rand(r) * 44, w: 100 + rand(r) * 70, h: 18, kind: "float" });
  }
  platforms.push({ x: Math.max(0, length - 360), y: 458, w: 360, h: 90, kind: "ground" });
  const anchors = [];
  for (let i = 0, ax = 255; ax < length - 150; i++, ax += 320 + rand(r) * 42) {
    anchors.push({ id: i, x: ax, y: 138 + rand(r) * 95, baseX: ax, baseY: 138 + rand(r) * 95, move: i % 4 === 2, phase: rand(r) * 6.2, radius: 13 });
    anchors[i].baseY = anchors[i].y;
  }
  const shards = [];
  const shardPositions = [430, 1085, 1760, 2450, 2850];
  for (let i = 0; i < 3; i++) {
    const sx = Math.min(length - 230, shardPositions[i] + rand(r) * 100);
    shards.push({ id: i, x: sx, y: 296 - rand(r) * 62, got: false, phase: rand(r) * 7 });
  }
  const hazards = [];
  for (let i = 0, hx = 620; hx < length - 260; i++, hx += 615 + rand(r) * 90) {
    hazards.push({ x: hx, y: 440, w: 68 + rand(r) * 48, h: 18, kind: "spikes" });
    if (difficulty >= 1 && i % 2 === 0) hazards.push({ x: hx + 180, y: 280 + rand(r) * 62, w: 12, h: 125, kind: "laser", phase: rand(r) * 6, period: 2.6 + rand(r) * 1.2 });
  }
  const drones = [];
  for (let i = 0, ex = 900; ex < length - 250; i++, ex += 780 + rand(r) * 100) {
    if (difficulty > 0 || i === 0) drones.push({ x: ex, y: 315 + rand(r) * 70, min: ex - 85, max: ex + 85, vx: (rand(r) > .5 ? 1 : -1) * (70 + difficulty * 18), phase: rand(r) * 5, alive: true });
  }
  const checkpoints = [1000, 1980, length - 480].filter(n => n < length - 250);
  return { index, daily, world, palette, length, platforms, anchors, shards, hazards, drones, checkpoints, exit: { x: length - 105, y: 365, w: 48, h: 88 }, elapsed: 0, time: 0, complete: false, hint: false, toast: "", toastTime: 0 };
}

function makeGame(index = 0, daily = false, trailColor = "#7af7ed") {
  const level = makeLevel(index, daily);
  return {
    level, time: 0, camera: 0, particles: [], shake: 0, flash: 0, combo: 0, comboTimer: 0, style: 0,
    player: { x: 76, y: 414, w: 22, h: 42, vx: 0, vy: 0, facing: 1, onGround: true, coyote: .12, jumpBuffer: 0, jumps: 0, grapple: null, ropeLength: 0, dash: 0, dashCd: 0, invuln: 0, checkpoint: 76, deaths: 0, shards: 0, airTime: 0, trick: 0, trickName: "", landedClean: false, trailColor },
    trailColor,
  };
}

function addBurst(g, x, y, color, count = 12, power = 180) {
  for (let i = 0; i < count; i++) {
    const a = Math.random() * Math.PI * 2, s = 40 + Math.random() * power;
    g.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: .35 + Math.random() * .42, max: .77, color, size: 1.5 + Math.random() * 3.5 });
  }
}
function chooseAnchor(g) {
  const p = g.player, cx = p.x + p.w / 2, cy = p.y + p.h / 2;
  let best = null, bestScore = Infinity;
  for (const a of g.level.anchors) {
    const dx = a.x - cx, dy = a.y - cy, d = Math.hypot(dx, dy);
    if (d > HOOK_RANGE || dx < -100 || dy > 95) continue;
    // Prefer an anchor ahead and above, but don't select a far-away point over a useful nearby one.
    const score = d + (dx < 0 ? 90 : 0) + (dy > 0 ? 80 : 0);
    if (score < bestScore) { bestScore = score; best = a; }
  }
  return best;
}
function sound(freq = 480, duration = .065, type = "sine") {
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    const ctx = sound.ctx || (sound.ctx = new Ctx());
    const osc = ctx.createOscillator(), gain = ctx.createGain();
    osc.type = type; osc.frequency.value = freq;
    gain.gain.setValueAtTime(.045, ctx.currentTime); gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + duration);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime + duration);
  } catch {}
}

function updateGame(g, dt, keys, just, onHud, onFinish, onToast) {
  const l = g.level, p = g.player;
  g.time += dt; l.elapsed = g.time;
  for (const a of l.anchors) if (a.move) { a.x = a.baseX + Math.sin(g.time * .9 + a.phase) * 34; a.y = a.baseY + Math.cos(g.time * 1.15 + a.phase) * 17; }
  g.shake = Math.max(0, g.shake - dt * 2.4); g.flash = Math.max(0, g.flash - dt * 2.5);
  p.invuln = Math.max(0, p.invuln - dt); p.dashCd = Math.max(0, p.dashCd - dt); p.jumpBuffer = Math.max(0, p.jumpBuffer - dt); p.coyote = Math.max(0, p.coyote - dt); p.dash = Math.max(0, p.dash - dt); p.trick = Math.max(0, p.trick - dt);
  const axis = (keys.has("right") ? 1 : 0) - (keys.has("left") ? 1 : 0);
  if (axis) p.facing = axis;
  if (just.has("jump")) p.jumpBuffer = .16;
  if (just.has("jump") && p.grapple !== null) { p.grapple = null; p.vy -= 70; }

  // The grapple is opt-in: the runner never attaches or moves without player input.
  if (keys.has("swing") && p.grapple === null) {
    const target = chooseAnchor(g);
    if (target) {
      const d = Math.hypot(target.x - (p.x + p.w / 2), target.y - (p.y + p.h / 2));
      p.grapple = target.id; p.ropeLength = Math.max(105, Math.min(275, d));
      addBurst(g, target.x, target.y, l.palette.glow, 7, 95); sound(690, .08, "triangle");
    }
  }
  if (!keys.has("swing")) p.grapple = null;

  if (p.jumpBuffer > 0 && (p.onGround || p.coyote > 0 || p.jumps < 1)) {
    p.vy = -625; p.onGround = false; p.coyote = 0; p.jumpBuffer = 0; p.jumps++;
    p.grapple = null; addBurst(g, p.x + p.w / 2, p.y + p.h, l.palette.glow, 5, 70); sound(510, .075, "square");
  }
  if (just.has("dash") && p.dashCd <= 0) {
    p.grapple = null; p.dash = .19; p.dashCd = 1.05; p.invuln = .22;
    p.vx = p.facing * 675; p.vy = Math.min(p.vy, 25); addBurst(g, p.x + p.w / 2, p.y + p.h / 2, p.trailColor, 18, 180); sound(220, .13, "sawtooth");
  }
  if (just.has("trick") && !p.onGround && (p.grapple !== null || Math.abs(p.vx) > 240)) {
    p.trick = .48; p.trickName = ["NEON FLIP", "SKYLINE SPIN", "RIFT TWIST"][g.combo % 3]; g.style += 90 + Math.round(Math.abs(p.vx) * .12); g.combo++; g.comboTimer = 2.4; addBurst(g, p.x + p.w / 2, p.y + p.h / 2, "#ffd27b", 9, 120); sound(920, .08, "triangle");
  }

  if (p.dash <= 0) {
    const accel = p.onGround ? 1680 : 700;
    if (axis) p.vx += axis * accel * dt;
    else p.vx *= Math.pow(p.onGround ? .0015 : .22, dt);
    p.vx = clamp(p.vx, -560, 560);
  }
  p.vy += GRAVITY * dt; p.vy = Math.min(p.vy, 1050);

  // Move and resolve horizontal platform collisions.
  const prevX = p.x, prevY = p.y;
  p.x += p.vx * dt;
  for (const b of l.platforms) {
    if (p.y + p.h < b.y + 4 || p.y > b.y + b.h - 2 || p.x + p.w <= b.x || p.x >= b.x + b.w) continue;
    if (p.vx > 0 && prevX + p.w <= b.x + 5) { p.x = b.x - p.w; p.vx = 0; }
    else if (p.vx < 0 && prevX >= b.x + b.w - 5) { p.x = b.x + b.w; p.vx = 0; }
  }
  p.y += p.vy * dt; p.onGround = false;
  for (const b of l.platforms) {
    const overlap = p.x + p.w > b.x + 2 && p.x < b.x + b.w - 2;
    if (!overlap) continue;
    if (p.vy >= 0 && prevY + p.h <= b.y + 16 && p.y + p.h >= b.y) {
      p.y = b.y - p.h; p.vy = 0; p.onGround = true; p.jumps = 0; p.coyote = .13;
      if (p.airTime > .25 && Math.abs(p.vx) > 330) { g.style += Math.round(Math.abs(p.vx) * .07); p.landedClean = true; }
      p.airTime = 0;
    } else if (p.vy < 0 && prevY >= b.y + b.h - 4 && p.y < b.y + b.h) { p.y = b.y + b.h; p.vy = 35; }
  }
  if (!p.onGround) p.airTime += dt;

  // Pendulum constraint: gravity and player pumping create swing momentum.
  if (p.grapple !== null) {
    const a = l.anchors.find(n => n.id === p.grapple);
    if (!a) p.grapple = null;
    else {
      const dx = p.x + p.w / 2 - a.x, dy = p.y + p.h / 2 - a.y, d = Math.hypot(dx, dy) || 1;
      if (axis) p.vx += axis * 255 * dt;
      if (d > p.ropeLength) {
        const nx = dx / d, ny = dy / d;
        p.x = a.x + nx * p.ropeLength - p.w / 2; p.y = a.y + ny * p.ropeLength - p.h / 2;
        const radial = p.vx * nx + p.vy * ny;
        if (radial > 0) { p.vx -= radial * nx; p.vy -= radial * ny; }
      }
      p.vx *= Math.pow(.992, dt * 60); p.vy *= Math.pow(.995, dt * 60);
      if (Math.abs(p.vx) > 310) { g.style += dt * Math.abs(p.vx) * .16; }
    }
  }
  // Keep the runner in the playable world and handle falls.
  p.x = clamp(p.x, 0, l.length - 30);
  const respawn = () => {
    p.deaths++; p.x = p.checkpoint; p.y = 390; p.vx = 0; p.vy = 0; p.grapple = null; p.dash = 0; p.invuln = 1.05; p.jumps = 0; p.onGround = false; g.shake = .65; g.flash = .4;
    addBurst(g, p.x + p.w / 2, p.y + p.h / 2, "#ff7b9e", 22, 220); sound(125, .18, "sawtooth"); onToast("CHECKPOINT RESTORED");
  };
  if (p.y > H + 100) respawn();

  for (const s of l.shards) if (!s.got && Math.hypot(p.x + p.w / 2 - s.x, p.y + p.h / 2 - s.y) < 30) {
    s.got = true; p.shards++; g.combo++; g.comboTimer = 2.2; addBurst(g, s.x, s.y, l.palette.shard, 16, 150); sound(840 + p.shards * 75, .09, "triangle"); onToast(`RIFT SHARD ${p.shards}/3`);
  }
  for (const cp of l.checkpoints) if (p.x > cp && p.checkpoint < cp) { p.checkpoint = cp; addBurst(g, cp, 420, l.palette.glow, 18, 120); onToast("CHECKPOINT SYNCED"); sound(720, .12); }

  const hitBox = (x, y, w, h) => p.x + p.w - 4 > x && p.x + 4 < x + w && p.y + p.h - 3 > y && p.y + 3 < y + h;
  if (p.invuln <= 0) {
    for (const h of l.hazards) {
      if (h.kind === "laser") {
        const active = Math.sin((g.time + h.phase) * Math.PI * 2 / h.period) > -.08;
        if (active && hitBox(h.x, h.y, h.w, h.h)) { respawn(); break; }
      } else if (hitBox(h.x, h.y, h.w, h.h)) { respawn(); break; }
    }
  }
  for (const d of l.drones) {
    if (!d.alive) continue;
    d.x += d.vx * dt; if (d.x < d.min || d.x > d.max) { d.vx *= -1; d.x = clamp(d.x, d.min, d.max); }
    d.phase += dt * 4;
    if (p.invuln <= 0 && Math.hypot(p.x + p.w / 2 - d.x, p.y + p.h / 2 - d.y) < 24) { respawn(); break; }
  }
  g.comboTimer = Math.max(0, g.comboTimer - dt); if (!g.comboTimer) g.combo = 0;
  for (const a of g.particles) { a.x += a.vx * dt; a.y += a.vy * dt; a.vy += 310 * dt; a.life -= dt; a.vx *= Math.pow(.2, dt); }
  g.particles = g.particles.filter(a => a.life > 0);
  g.camera = lerp(g.camera, clamp(p.x - W * .34, 0, l.length - W), 1 - Math.pow(.001, dt));
  if (g.toastTime > 0) g.toastTime -= dt;
  const ex = l.exit;
  if (!g.level.complete && hitBox(ex.x, ex.y, ex.w, ex.h)) {
    if (p.shards >= 2) onFinish(g);
    else if (!l.hint) { l.hint = true; onToast("FIND 2 RIFT SHARDS TO OPEN THE GATE"); }
  }
  if (g.time % .12 < dt) onHud({ time: g.time, shards: p.shards, deaths: p.deaths, speed: Math.round(Math.hypot(p.vx, p.vy)), style: Math.floor(g.style), combo: g.combo, grapple: p.grapple !== null, dash: p.dashCd <= 0 });
  just.clear();
}

function drawGame(ctx, g, active) {
  const l = g.level, p = g.player, theme = l.palette, t = g.time;
  ctx.clearRect(0, 0, W, H);
  const sky = ctx.createLinearGradient(0, 0, 0, H); sky.addColorStop(0, theme.sky[0]); sky.addColorStop(.58, theme.sky[1]); sky.addColorStop(1, theme.sky[2]); ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
  // Atmospheric moon and drifting cloud bands.
  ctx.save(); ctx.globalAlpha = .55; ctx.shadowColor = theme.glow; ctx.shadowBlur = 44; const moon = ctx.createRadialGradient(755, 115, 8, 755, 115, 78); moon.addColorStop(0, "#ffffff"); moon.addColorStop(.18, theme.glow); moon.addColorStop(1, "#ffffff00"); ctx.fillStyle = moon; ctx.beginPath(); ctx.arc(755, 115, 78, 0, Math.PI * 2); ctx.fill(); ctx.restore();
  for (let i = 0; i < 55; i++) { const sx = ((i * 179 + t * (5 + i % 5)) % (W + 40)) - 20, sy = 24 + (i * 73) % 320; ctx.fillStyle = "#e6ffff"; ctx.globalAlpha = .16 + .35 * Math.abs(Math.sin(t * 1.3 + i)); ctx.fillRect(sx, sy, i % 8 === 0 ? 2 : 1, i % 8 === 0 ? 2 : 1); } ctx.globalAlpha = 1;
  // Parallax city silhouettes.
  for (let layer = 0; layer < 3; layer++) {
    const speed = [.12, .23, .38][layer], base = [385, 425, 455][layer];
    for (let i = 0; i < 18; i++) {
      const bw = 40 + (i * 17 % 44), bh = 75 + (i * 41 % 150), bx = ((i * 107 - g.camera * speed) % (W + 130) + W + 130) % (W + 130) - 65;
      ctx.fillStyle = ["#111a36", "#152447", "#1a2b48"][layer]; ctx.fillRect(bx, base - bh, bw, bh);
      if (layer > 0) { ctx.fillStyle = theme.glow; ctx.globalAlpha = .13; for (let wy = base - bh + 15; wy < base - 8; wy += 18) for (let wx = bx + 8; wx < bx + bw - 5; wx += 15) ctx.fillRect(wx, wy, 4, 6); ctx.globalAlpha = 1; }
    }
  }
  ctx.save();
  if (g.shake > 0) ctx.translate((Math.random() - .5) * 8 * g.shake, (Math.random() - .5) * 6 * g.shake);
  ctx.translate(-g.camera, 0);
  // Ground and floating catch platforms.
  for (const b of l.platforms) {
    const grad = ctx.createLinearGradient(0, b.y, 0, b.y + b.h); grad.addColorStop(0, b.kind === "float" ? "#294966" : theme.platform); grad.addColorStop(1, "#0d1830");
    ctx.fillStyle = grad; ctx.strokeStyle = theme.glow; ctx.lineWidth = 2; ctx.shadowColor = theme.glow; ctx.shadowBlur = 12;
    ctx.beginPath(); ctx.roundRect(b.x, b.y, b.w, b.h, b.kind === "float" ? 8 : 4); ctx.fill(); ctx.stroke(); ctx.shadowBlur = 0;
    ctx.fillStyle = "#ffffff30"; ctx.fillRect(b.x + 7, b.y + 4, Math.max(0, b.w - 14), 2);
    if (b.kind === "ground") { ctx.fillStyle = "#0b1428"; for (let j = 0; j < b.w; j += 34) ctx.fillRect(b.x + j + 6, b.y + 20, 18, 3); }
  }
  // Tether anchors, each with a pulsing acquisition ring.
  for (const a of l.anchors) {
    const pulse = 1 + Math.sin(t * 3 + a.phase) * .12;
    ctx.save(); ctx.translate(a.x, a.y); ctx.shadowColor = theme.glow; ctx.shadowBlur = 18; ctx.strokeStyle = theme.glow; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0, 0, 10 * pulse, 0, Math.PI * 2); ctx.stroke(); ctx.fillStyle = "#ecffff"; ctx.beginPath(); ctx.arc(0, 0, 3.5, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = .35; ctx.beginPath(); ctx.arc(0, 0, 19 * pulse, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
  }
  if (p.grapple !== null) {
    const a = l.anchors.find(n => n.id === p.grapple);
    if (a) { ctx.save(); ctx.strokeStyle = theme.glow; ctx.lineWidth = 3; ctx.shadowColor = theme.glow; ctx.shadowBlur = 17; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.quadraticCurveTo((a.x + p.x + p.w / 2) / 2 + 20, (a.y + p.y + p.h / 2) / 2, p.x + p.w / 2, p.y + p.h / 2); ctx.stroke(); ctx.restore(); }
  }
  // Spike beds.
  for (const h of l.hazards) {
    if (h.kind === "laser") {
      const activeBeam = Math.sin((t + h.phase) * Math.PI * 2 / h.period) > -.08;
      ctx.save(); ctx.fillStyle = activeBeam ? "#ff6b91" : "#ff6b9140"; ctx.shadowColor = "#ff507f"; ctx.shadowBlur = activeBeam ? 18 : 3; ctx.fillRect(h.x, h.y, h.w, h.h); ctx.fillStyle = "#fff"; ctx.globalAlpha = activeBeam ? .8 : .18; ctx.fillRect(h.x + 4, h.y, 3, h.h); ctx.restore();
    } else {
      ctx.save(); ctx.fillStyle = "#ff6388"; ctx.shadowColor = "#ff527c"; ctx.shadowBlur = 11; for (let x = h.x; x < h.x + h.w; x += 17) { ctx.beginPath(); ctx.moveTo(x, h.y + h.h); ctx.lineTo(x + 8, h.y - 15); ctx.lineTo(x + 16, h.y + h.h); ctx.fill(); } ctx.restore();
    }
  }
  // Drones.
  for (const d of l.drones) if (d.alive) {
    ctx.save(); ctx.translate(d.x, d.y + Math.sin(d.phase) * 7); ctx.shadowColor = "#ff9c82"; ctx.shadowBlur = 17; ctx.fillStyle = "#ff926f"; ctx.beginPath(); ctx.roundRect(-15, -10, 30, 20, 8); ctx.fill(); ctx.fillStyle = "#15233f"; ctx.fillRect(-7, -3, 14, 5); ctx.fillStyle = "#fff1d0"; ctx.fillRect(-5, -2, 4, 3); ctx.fillRect(2, -2, 4, 3); ctx.strokeStyle = "#ffb19e"; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-11, -9); ctx.lineTo(-17, -18); ctx.moveTo(11, -9); ctx.lineTo(17, -18); ctx.stroke(); ctx.restore();
  }
  // Rifts.
  for (const s of l.shards) if (!s.got) {
    ctx.save(); ctx.translate(s.x, s.y + Math.sin(t * 3 + s.phase) * 6); ctx.rotate(Math.sin(t * 2 + s.phase) * .22); ctx.shadowColor = theme.shard; ctx.shadowBlur = 22; ctx.fillStyle = theme.shard; ctx.beginPath(); ctx.moveTo(0, -15); ctx.lineTo(10, -2); ctx.lineTo(5, 14); ctx.lineTo(-5, 14); ctx.lineTo(-10, -2); ctx.closePath(); ctx.fill(); ctx.strokeStyle = "#fff"; ctx.lineWidth = 1.5; ctx.stroke(); ctx.restore();
  }
  // Exit gate, locked until two shards are gathered.
  const gate = l.exit, unlocked = p.shards >= 2;
  ctx.save(); ctx.translate(gate.x + 24, gate.y + 44); ctx.shadowColor = unlocked ? theme.glow : "#ff719a"; ctx.shadowBlur = 24; ctx.strokeStyle = unlocked ? theme.glow : "#ff719a"; ctx.lineWidth = 5; ctx.beginPath(); ctx.ellipse(0, 0, 21, 42, 0, 0, Math.PI * 2); ctx.stroke(); ctx.fillStyle = unlocked ? "#77fff122" : "#ff719a1c"; ctx.beginPath(); ctx.ellipse(0, 0, 17 + Math.sin(t * 3) * 2, 37, 0, 0, Math.PI * 2); ctx.fill(); ctx.restore();
  // Checkpoint beacons.
  for (const cp of l.checkpoints) { ctx.save(); ctx.translate(cp, 423); ctx.strokeStyle = p.checkpoint >= cp ? "#fff0a6" : theme.glow; ctx.shadowColor = ctx.strokeStyle; ctx.shadowBlur = 13; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -54); ctx.stroke(); ctx.beginPath(); ctx.arc(0, -57, 7 + Math.sin(t * 4) * 1.5, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); }
  // Motion trail.
  if (Math.hypot(p.vx, p.vy) > 180) { ctx.save(); ctx.globalAlpha = .24; ctx.strokeStyle = p.trailColor; ctx.lineWidth = 7; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(p.x + p.w / 2, p.y + p.h / 2); ctx.lineTo(p.x + p.w / 2 - p.vx * .09, p.y + p.h / 2 - p.vy * .03); ctx.stroke(); ctx.restore(); }
  // Stylized runner sprite, with the limb pose reacting to velocity/swing.
  const cx = p.x + p.w / 2, cy = p.y + p.h / 2, run = Math.sin(t * 12 + p.x * .035) * Math.min(1, Math.abs(p.vx) / 220), angle = p.grapple !== null ? Math.atan2(p.vy, Math.max(1, p.vx)) * .16 : (p.onGround ? 0 : clamp(p.vx / 900, -.35, .35));
  ctx.save(); ctx.translate(cx, cy); ctx.rotate(angle + (p.trick > 0 ? (1 - p.trick / .48) * Math.PI * 2 : 0));
  if (p.invuln > 0 && Math.floor(t * 18) % 2 === 0) ctx.globalAlpha = .45;
  ctx.shadowColor = p.trailColor; ctx.shadowBlur = 18;
  ctx.strokeStyle = p.trailColor; ctx.lineWidth = 6; ctx.lineCap = "round"; ctx.lineJoin = "round";
  // Legs
  ctx.beginPath(); ctx.moveTo(-2, 9); ctx.lineTo(-7 + run * 6, 22); ctx.lineTo(-12 + run * 12, 31); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(3, 9); ctx.lineTo(8 - run * 6, 21); ctx.lineTo(13 - run * 12, 31); ctx.stroke();
  // Arms
  ctx.beginPath(); ctx.moveTo(-5, -8); ctx.lineTo(-14, -2 + run * 5); ctx.lineTo(-19, 6 + run * 7); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(5, -8); ctx.lineTo(13, -14 - run * 5); ctx.lineTo(19, -18); ctx.stroke();
  // Body and helmet
  ctx.fillStyle = "#f0fbff"; ctx.beginPath(); ctx.roundRect(-7, -13, 14, 26, 6); ctx.fill(); ctx.fillStyle = p.trailColor; ctx.beginPath(); ctx.arc(0, -20, 10, 0, Math.PI * 2); ctx.fill(); ctx.fillStyle = "#14243f"; ctx.beginPath(); ctx.arc(4, -20, 4, -.7, .9); ctx.fill(); ctx.restore();
  // Particles
  for (const a of g.particles) { ctx.save(); ctx.globalAlpha = clamp(a.life / a.max, 0, 1); ctx.fillStyle = a.color; ctx.shadowColor = a.color; ctx.shadowBlur = 10; ctx.beginPath(); ctx.arc(a.x, a.y, a.size, 0, Math.PI * 2); ctx.fill(); ctx.restore(); }
  // Hook range indicator on a live input, subtle enough not to clutter.
  ctx.restore();
  // Finish flags at the horizon and progress track.
  ctx.save(); ctx.fillStyle = "#ffffff28"; ctx.fillRect(0, 0, l.length, 3); ctx.fillStyle = theme.glow; ctx.fillRect(0, 0, Math.min(l.length, p.x + g.camera) / l.length * l.length, 3); ctx.restore();
  ctx.restore();
  if (g.flash > 0) { ctx.fillStyle = `rgba(255,255,255,${g.flash * .35})`; ctx.fillRect(0, 0, W, H); }
  // Hook distance hint is rendered in screen space.
  if (active && p.grapple === null) { const a = chooseAnchor(g); if (a) { const sx = a.x - g.camera; ctx.save(); ctx.strokeStyle = theme.glow; ctx.globalAlpha = .3 + Math.sin(t * 6) * .1; ctx.setLineDash([4, 7]); ctx.beginPath(); ctx.arc(sx, a.y, 21, 0, Math.PI * 2); ctx.stroke(); ctx.restore(); } }
}

export default function RiftSwing() {
  const canvasRef = useRef(null), gameRef = useRef(makeGame()), keysRef = useRef(new Set()), justRef = useRef(new Set()), screenRef = useRef("menu"), rafRef = useRef(0), toastTimer = useRef(0);
  const [screen, setScreen] = useState("menu"), [save, setSave] = useState(loadSave), [levelIndex, setLevelIndex] = useState(0), [dailyMode, setDailyMode] = useState(false);
  const [hud, setHud] = useState({ time: 0, shards: 0, deaths: 0, speed: 0, style: 0, combo: 0, grapple: false, dash: true });
  const [toast, setToast] = useState(""), [result, setResult] = useState(null), [pausedFrom, setPausedFrom] = useState("playing");
  const trail = trails.find(t => t.id === save.trail) || trails[0];
  const setGameScreen = useCallback((s) => { screenRef.current = s; setScreen(s); }, []);
  const announce = useCallback((message) => { setToast(message); clearTimeout(toastTimer.current); toastTimer.current = window.setTimeout(() => setToast(""), 1200); }, []);

  const startLevel = useCallback((idx = 0, daily = false) => {
    const chosenTrail = trails.find(t => t.id === save.trail) || trails[0];
    gameRef.current = makeGame(idx, daily, chosenTrail.color);
    setLevelIndex(idx); setDailyMode(daily); setResult(null); setHud({ time: 0, shards: 0, deaths: 0, speed: 0, style: 0, combo: 0, grapple: false, dash: true });
    keysRef.current.clear(); justRef.current.clear(); setGameScreen("playing"); sound(620, .1, "triangle");
  }, [save.trail, setGameScreen]);

  const finishLevel = useCallback((g) => {
    if (g.level.complete) return;
    g.level.complete = true;
    const medals = g.time < 48 + g.level.index * 2 ? 3 : g.time < 72 + g.level.index * 3 ? 2 : 1;
    const earned = 180 + g.player.shards * 55 + medals * 60 + Math.max(0, 220 - Math.floor(g.time * 2)) + Math.floor(g.style / 6);
    const key = g.level.daily ? nowKey() : String(g.level.index);
    const next = { ...save, unlocked: g.level.daily ? save.unlocked : Math.max(save.unlocked, g.level.index + 2), shards: save.shards + g.player.shards, credits: save.credits + earned, best: { ...save.best, [key]: Math.min(save.best[key] || Infinity, g.time) }, medals: { ...save.medals, [key]: Math.max(save.medals[key] || 0, medals) }, daily: g.level.daily ? { ...save.daily, [nowKey()]: true } : save.daily };
    setSave(next); saveData(next);
    setResult({ time: g.time, shards: g.player.shards, deaths: g.player.deaths, style: Math.floor(g.style), medals, earned, index: g.level.index, daily: g.level.daily });
    setGameScreen("complete"); sound(940, .25, "triangle");
  }, [save, setGameScreen]);

  useEffect(() => {
    let last = performance.now(), hudClock = 0;
    const canvas = canvasRef.current, ctx = canvas?.getContext("2d"); if (!canvas || !ctx) return;
    const resize = () => { const dpr = Math.min(window.devicePixelRatio || 1, 2); canvas.width = W * dpr; canvas.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); };
    resize(); window.addEventListener("resize", resize);
    const loop = (stamp) => {
      const dt = Math.min(.033, Math.max(0, (stamp - last) / 1000)); last = stamp;
      const g = gameRef.current;
      if (screenRef.current === "playing") {
        updateGame(g, dt, keysRef.current, justRef.current, (v) => { if (stamp - hudClock > 90) { hudClock = stamp; setHud(v); } }, finishLevel, announce);
      } else {
        g.time += dt * .35;
      }
      drawGame(ctx, g, screenRef.current === "playing");
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    const mapKey = (e) => {
      const k = e.key.toLowerCase();
      if (k === "escape" && screenRef.current === "playing") { e.preventDefault(); setGameScreen("paused"); return; }
      const mapping = { a: "left", arrowleft: "left", d: "right", arrowright: "right", w: "jump", arrowup: "jump", " ": "jump", e: "swing", j: "swing", shift: "dash", x: "dash", q: "trick" };
      const v = mapping[k]; if (!v) return;
      e.preventDefault();
      if (!keysRef.current.has(v)) justRef.current.add(v);
      keysRef.current.add(v);
      if (k === "escape" && screenRef.current === "playing") setGameScreen("paused");
    };
    const keyUp = (e) => {
      const mapping = { a: "left", arrowleft: "left", d: "right", arrowright: "right", w: "jump", arrowup: "jump", " ": "jump", e: "swing", j: "swing", shift: "dash", x: "dash", q: "trick" };
      const v = mapping[e.key.toLowerCase()]; if (v) { keysRef.current.delete(v); if (v === "swing") gameRef.current.player.grapple = null; }
    };
    const blur = () => { keysRef.current.clear(); justRef.current.clear(); gameRef.current.player.grapple = null; };
    window.addEventListener("keydown", mapKey); window.addEventListener("keyup", keyUp); window.addEventListener("blur", blur);
    return () => { cancelAnimationFrame(rafRef.current); window.removeEventListener("resize", resize); window.removeEventListener("keydown", mapKey); window.removeEventListener("keyup", keyUp); window.removeEventListener("blur", blur); clearTimeout(toastTimer.current); };
  }, [finishLevel, announce, setGameScreen]);

  const hold = (name) => ({ onPointerDown: (e) => { e.preventDefault(); e.currentTarget.setPointerCapture?.(e.pointerId); if (!keysRef.current.has(name)) justRef.current.add(name); keysRef.current.add(name); }, onPointerUp: (e) => { e.preventDefault(); keysRef.current.delete(name); if (name === "swing") gameRef.current.player.grapple = null; }, onPointerCancel: () => { keysRef.current.delete(name); if (name === "swing") gameRef.current.player.grapple = null; }, onContextMenu: e => e.preventDefault() });
  const pauseGame = () => { keysRef.current.clear(); justRef.current.clear(); setPausedFrom("playing"); setGameScreen("paused"); };
  const resume = () => { setGameScreen("playing"); sound(500, .06); };
  const buyTrail = (t) => {
    if (save.trail === t.id) return;
    if (save.credits < t.cost) { announce("NOT ENOUGH CREDITS YET"); return; }
    const next = { ...save, credits: save.credits - t.cost, trail: t.id }; setSave(next); saveData(next); gameRef.current.player.trailColor = t.color; announce(`${t.name.toUpperCase()} EQUIPPED`);
  };
  const bestFor = (idx) => save.best[String(idx)];

  return <section className="rs-shell">
    <div className="rs-topbar"><div><span className="rs-mark">R</span><div><b>RIFT SWING</b><small>SKYLINE FLOW PROJECT</small></div></div><div className="rs-currency"><span>✦ {save.shards} SHARDS</span><b>◈ {save.credits} CR</b></div></div>
    {screen === "playing" || screen === "paused" ? <div className="rs-hud"><div><small>STAGE</small><b>{dailyMode ? "DAILY RIFT" : `0${(levelIndex % 12) + 1} / 12`}</b></div><div><small>TIME</small><b>{hud.time.toFixed(1)}s</b></div><div><small>SHARDS</small><b>{hud.shards}/3</b></div><div><small>FLOW</small><b>{Math.min(999, hud.style).toString().padStart(3, "0")}</b></div><button onClick={pauseGame} className="rs-pause" aria-label="Pause game">Ⅱ</button></div> : null}
    <div className="rs-stage">
      <canvas ref={canvasRef} className="rs-canvas" width={W} height={H} aria-label="Rift Swing game field" />
      {toast && screen === "playing" && <div className="rs-toast">{toast}</div>}
      {screen === "menu" && <div className="rs-overlay rs-menu-overlay"><div className="rs-menu-card"><span className="rs-kicker">HOOK IN · BUILD MOMENTUM · LET GO</span><h2>Find your <em>flow.</em></h2><p>Grapple between skyline anchors, carry your momentum across impossible gaps and land clean. Every move is yours. The runner never moves unless you do.</p><div className="rs-hero-stats"><span><b>12</b><small>TRIALS</small></span><i/><span><b>3</b><small>WORLDS</small></span><i/><span><b>∞</b><small>LINES</small></span></div><div className="rs-menu-actions"><button className="rs-primary" onClick={() => startLevel(Math.min(11, save.unlocked - 1), false)}>CONTINUE CAMPAIGN <b>→</b></button><button className="rs-secondary" onClick={() => startLevel(0, true)}>DAILY RIFT <span>✦</span></button><button className="rs-secondary" onClick={() => setGameScreen("levels")}>LEVEL SELECT</button></div><div className="rs-menu-footer"><span>BEST RUN: {save.best[String(Math.max(0, save.unlocked - 2))] ? `${save.best[String(Math.max(0, save.unlocked - 2))].toFixed(1)}s` : "NOT SET"}</span><span>TRAIL: {trail.name.toUpperCase()}</span></div></div><div className="rs-control-legend"><b>DESKTOP</b><span>A / D MOVE</span><span>SPACE JUMP</span><span>HOLD E GRAPPLE</span><span>SHIFT DASH</span><span>Q TRICK</span></div></div>}
      {screen === "levels" && <div className="rs-overlay"><div className="rs-panel rs-levels-panel"><div className="rs-panel-head"><div><span className="rs-kicker">CAMPAIGN MAP</span><h2>Choose a <em>trial.</em></h2></div><button className="rs-close" onClick={() => setGameScreen("menu")}>✕</button></div><div className="rs-level-grid">{Array.from({ length: 12 }, (_, i) => { const locked = i + 1 > save.unlocked; return <button key={i} disabled={locked} className={`rs-level-tile ${locked ? "locked" : ""}`} onClick={() => startLevel(i, false)}><span>TRIAL {String(i + 1).padStart(2, "0")}</span><b>{["FIRST LINE", "TWIN TOWERS", "BROKEN SKY", "HARBOR RUN", "LOW TIDE", "STORM RIG", "AFTERGLOW", "GOLDEN HOUR", "THE LONG DROP", "HIGH VOLTAGE", "NO SAFETY", "THE LAST RIFT"][i]}</b><small>{locked ? "LOCKED" : save.medals[String(i)] ? `${"★".repeat(save.medals[String(i)])}` : "OPEN"}</small></button>; })}</div><div className="rs-panel-foot">{save.unlocked} / 12 TRIALS UNLOCKED · BEST TIMES SAVED LOCALLY</div></div></div>}
      {screen === "paused" && <div className="rs-overlay"><div className="rs-panel rs-pause-panel"><span className="rs-kicker">TAKE A BREATHER</span><h2>Game <em>paused.</em></h2><p>Keep your line. Your checkpoint and collected shards are safe.</p><button className="rs-primary" onClick={resume}>RESUME RUN <b>→</b></button><button className="rs-secondary" onClick={() => startLevel(levelIndex, dailyMode)}>RESTART TRIAL</button><button className="rs-secondary" onClick={() => setGameScreen("menu")}>RETURN TO HANGAR</button></div></div>}
      {screen === "complete" && result && <div className="rs-overlay"><div className="rs-panel rs-result-panel"><span className="rs-kicker">LINE COMPLETE</span><h2>Clean <em>landing.</em></h2><div className="rs-medal">{"★".repeat(result.medals)}{"☆".repeat(3 - result.medals)}</div><div className="rs-result-stats"><span><small>TIME</small><b>{result.time.toFixed(1)}s</b></span><span><small>RIFT SHARDS</small><b>{result.shards}/3</b></span><span><small>STYLE</small><b>{result.style}</b></span><span><small>REWARDS</small><b>+{result.earned} CR</b></span></div><div className="rs-menu-actions"><button className="rs-primary" onClick={() => result.daily ? setGameScreen("menu") : startLevel(Math.min(11, result.index + 1), false)}>NEXT TRIAL <b>→</b></button><button className="rs-secondary" onClick={() => startLevel(result.index, result.daily)}>RUN IT BACK</button><button className="rs-secondary" onClick={() => setGameScreen("levels")}>LEVEL MAP</button></div></div></div>}
    </div>
    {screen === "playing" && <div className="rs-touchbar">
      <div className="rs-pad-left"><button {...hold("left")} aria-label="Move left">◀</button><button {...hold("right")} aria-label="Move right">▶</button></div>
      <div className="rs-pad-right"><button {...hold("trick")} className="rs-trick-btn">TRICK</button><button {...hold("jump")} className="rs-jump-btn">JUMP</button><button {...hold("swing")} className="rs-hook-btn">GRAPPLE</button><button {...hold("dash")} className="rs-dash-btn">DASH</button></div>
    </div>}
    <div className="rs-bottom"><div><span className={hud.grapple ? "on" : ""}>● {hud.grapple ? "LINE ATTACHED" : "HOOK READY"}</span><span>◈ {Math.round(hud.speed)} PX/S</span><span>✦ {hud.combo ? `${hud.combo}× FLOW` : "BUILD A COMBO"}</span></div><p>RUN → JUMP → HOLD GRAPPLE → RELEASE AT THE SWING APEX</p></div>
    <div className="rs-footer-row"><div><span className="rs-kicker">YOUR STYLE. YOUR LINE.</span><b>Make the skyline your playground.</b><small>Local progress · No account · No ads</small></div><div className="rs-trails">{trails.map(t => <button key={t.id} onClick={() => buyTrail(t)} className={`${save.trail === t.id ? "selected" : ""} ${save.credits < t.cost && save.trail !== t.id ? "unaffordable" : ""}`} title={`${t.name} · ${t.cost} credits`}><i style={{ background: t.color }} />{t.cost ? `${t.cost} CR` : "FREE"}</button>)}</div></div>
  </section>;
}
