import React, { useCallback, useEffect, useRef, useState } from "react";

const W = 960, H = 540, STORE = "pz-neon-breakout-v1";
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const rand = (a,b) => a + Math.random()*(b-a);
const worlds = [
  {name:"NEON DISTRICT",sub:"Rooftops above the sleeping city",sky:["#09162b","#201b48"],glow:"#55e8ef",accent:"#a58cff",platform:"#263b61",hazard:"#ff638e"},
  {name:"REACTOR CORE",sub:"The power grid is unstable",sky:["#160e26","#3a163a"],glow:"#ff8b68",accent:"#ffd36c",platform:"#54334b",hazard:"#ff6b5f"},
  {name:"CRYSTAL CAVERNS",sub:"Beautiful things can still cut",sky:["#071d34","#123d58"],glow:"#69f5dc",accent:"#8eabff",platform:"#22546a",hazard:"#ff8eaa"},
  {name:"SKYBRIDGE",sub:"One wrong step is a long fall",sky:["#10172f","#34325e"],glow:"#9eb8ff",accent:"#ffadf2",platform:"#38476f",hazard:"#ff7eae"},
  {name:"OVERGROWTH",sub:"The old city has come alive",sky:["#081d24","#123d39"],glow:"#83f39a",accent:"#d0f17b",platform:"#28554c",hazard:"#ff8b68"},
  {name:"THE RIFT",sub:"The rules of gravity are breaking",sky:["#130d2b","#321b50"],glow:"#d1a0ff",accent:"#6ce9ff",platform:"#48345f",hazard:"#ff668f"}
];
const LEVEL_COUNT = 30;
const emptySave = () => ({unlocked:1, totalShards:0, bestTime:{}, bestDeaths:{}, clears:0, dailyBest:null});
function loadSave(){try{return {...emptySave(),...JSON.parse(localStorage.getItem(STORE)||"{}")};}catch{return emptySave();}}
function seeded(seed){let x=seed>>>0;return()=>{x=(x*1664525+1013904223)>>>0;return x/4294967296;};}
function makeLevel(index, dailySeed=0){
  const world=Math.floor(index/5), stage=index%5, rng=seeded((index+1)*9127+dailySeed*7717+54), length=2780+stage*180+world*90;
  const platforms=[{x:0,y:464,w:300,h:76,type:"solid"},{x:length-300,y:464,w:300,h:76,type:"solid"}];
  const hazards=[],shards=[],enemies=[],lasers=[],moving=[];
  const templates=[
    [405,360,415,325,390,345,405,315,380,355,400],
    [390,330,370,310,405,340,370,300,395,325,390],
    [420,370,320,390,335,410,315,385,325,400,340],
    [360,410,335,385,315,405,330,375,305,395,345],
    [410,345,390,315,365,405,320,380,300,365,330]
  ];
  const heights=templates[stage];
  let x=270;
  for(let i=0;i<heights.length+Math.floor(world/2);i++){
    const gap=stage===0?72+(rng()*35):88+rng()*55;
    const width=stage===4?105+rng()*35:128+rng()*48;
    x+=gap;
    const y=clamp(heights[i%heights.length]+(world%2?((i%2)*-18):0)+(rng()-.5)*26,245,424);
    const type=(stage>=2&&i%5===2)?"crumble":(stage>=1&&i%6===3)?"moving":"solid";
    const p={x,y,w:width,h:22,type,phase:rng()*Math.PI*2,baseX:x,baseY:y,range:50+rng()*35,axis:i%2?"x":"y",fall:0};
    platforms.push(p); if(type==="moving")moving.push(p);
    if(i%3!==1 || stage===4)shards.push({x:x+width*(.35+rng()*.3),y:y-42-(i%4===0?42:0),got:false,phase:rng()*6});
    if(i>1 && i%4===2 && stage>=1) enemies.push({x:x+width*.55,y:y-28,min:x+12,max:x+width-18,vx:70+world*8,alive:true,phase:rng()*6,elite:stage===4&&i%8===2});
    if(stage>=2&&i%5===4)hazards.push({x:x+width*.45,y:y-12,w:Math.min(54,width*.42),h:12,type:"spikes"});
    if(stage>=3&&i%6===3)lasers.push({x:x+width*.45,y:y-70,w:8,h:65,phase:rng()*4,period:1.7+rng()*.8});
    x+=width;
    if(x>length-360)break;
  }
  // A few alternate paths reward confident jumps with extra shards.
  if(shards.length<3){for(let i=0;i<3;i++)shards.push({x:430+i*480,y:280-(i%2)*48,got:false,phase:i});}
  hazards.push({x:680+stage*34,y:464-10,w:78,h:14,type:"spikes"});
  hazards.push({x:Math.min(length-740,1420+world*28),y:464-10,w:92,h:14,type:"spikes"});
  const checkpoints=[Math.floor(length*.52)];
  const exit={x:length-142,y:376,w:48,h:88};
  return {index,world,stage,length,platforms,hazards,shards,enemies,lasers,moving,checkpoints,exit,elapsed:0,seed:dailySeed};
}
function newPlayer(){return {x:72,y:410,w:26,h:42,vx:0,vy:0,onGround:false,jumps:0,coyote:0,jumpBuffer:0,dash:0,dashCd:0,facing:1,hp:3,invuln:0,shards:0,checkpoint:72,checkpointY:410,deaths:0,trail:[]};}
const keyAliases={ArrowLeft:"left",KeyA:"left",ArrowRight:"right",KeyD:"right",ArrowUp:"jump",KeyW:"jump",Space:"jump",KeyX:"dash",ShiftLeft:"dash",ShiftRight:"dash",KeyR:"restart",Escape:"pause"};

function NeonBreakout(){
  const canvasRef=useRef(null), gameRef=useRef(null), inputRef=useRef(new Set()), justRef=useRef(new Set()), screenRef=useRef("menu"), lastHud=useRef(0), soundRef=useRef(false);
  const [screen,setScreen]=useState("menu"),[save,setSave]=useState(loadSave),[levelIndex,setLevelIndex]=useState(0),[hud,setHud]=useState({time:0,shards:0,deaths:0,dash:1,world:"NEON DISTRICT"}),[result,setResult]=useState(null),[daily,setDaily]=useState(false),[sound,setSound]=useState(false),[notice,setNotice]=useState("");
  const saveRef=useRef(save); useEffect(()=>{saveRef.current=save;},[save]);
  const writeSave=(next)=>{saveRef.current=next;setSave(next);try{localStorage.setItem(STORE,JSON.stringify(next));}catch{}};
  const beep=(f=520,d=.07,type="sine")=>{if(!soundRef.current)return;try{const AC=window.AudioContext||window.webkitAudioContext;if(!gameRef.current?.audio)gameRef.current.audio=new AC();const ac=gameRef.current.audio;if(ac.state==="suspended")ac.resume();const o=ac.createOscillator(),g=ac.createGain();o.type=type;o.frequency.value=f;g.gain.setValueAtTime(.04,ac.currentTime);g.gain.exponentialRampToValueAtTime(.0001,ac.currentTime+d);o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+d);}catch{}};
  const announce=(t)=>{setNotice(t);window.clearTimeout(announce.id);announce.id=window.setTimeout(()=>setNotice(""),1500);};
  const startLevel=useCallback((index, dailyMode=false)=>{const seed=dailyMode?Number(new Date().toISOString().slice(0,10).replaceAll("-","")):0;const level=makeLevel(index,seed);gameRef.current={level,player:newPlayer(),state:"playing",camera:0,particles:[],time:0,checkpointIndex:0,complete:false,daily:dailyMode,shake:0,flash:0,combo:0,comboTimer:0};inputRef.current.clear();justRef.current.clear();setLevelIndex(index);setDaily(dailyMode);setHud({time:0,shards:0,deaths:0,dash:1,world:worlds[level.world].name});setResult(null);setScreen("playing");screenRef.current="playing";beep(680,.12);},[]);
  const finishLevel=(g)=>{if(g.complete)return;g.complete=true;g.state="complete";const p=g.player,l=g.level, key=String(l.index);const old=saveRef.current;const prev=old.bestTime[key]||Infinity;const bestTime=Math.min(prev,g.time);const medals=(g.time<42+l.world*4?3:g.time<65+l.world*6?2:1);const next={...old,unlocked:Math.max(old.unlocked,l.index+2),clears:old.clears+1,totalShards:old.totalShards+p.shards,bestTime:{...old.bestTime,[key]:bestTime},bestDeaths:{...old.bestDeaths,[key]:Math.min(old.bestDeaths[key]??999,p.deaths)}};writeSave(next);setResult({time:g.time,shards:p.shards,medals,deaths:p.deaths,index:l.index,daily:g.daily});setScreen("complete");screenRef.current="complete";beep(880,.22);};
  const respawn=(g)=>{const p=g.player;p.deaths++;p.x=p.checkpoint;p.y=p.checkpointY;p.vx=0;p.vy=0;p.jumps=0;p.invuln=1.1;p.dash=0;p.dashCd=0;g.shake=.24;g.flash=.16;beep(110,.15,"triangle");};
  const restart=()=>{if(!gameRef.current)return;const idx=gameRef.current.level.index,d=gameRef.current.daily;startLevel(idx,d);};
  const pause=()=>{if(screenRef.current==="playing"){setScreen("paused");screenRef.current="paused";inputRef.current.clear();}else if(screenRef.current==="paused"){setScreen("playing");screenRef.current="playing";}};
  const step=(g,dt)=>{
    const l=g.level,p=g.player,keys=inputRef.current,just=justRef.current;g.time+=dt;l.elapsed+=dt;g.shake=Math.max(0,g.shake-dt);g.flash=Math.max(0,g.flash-dt);p.invuln=Math.max(0,p.invuln-dt);p.dashCd=Math.max(0,p.dashCd-dt);p.jumpBuffer=Math.max(0,p.jumpBuffer-dt);p.coyote=Math.max(0,p.coyote-dt);
    for(const m of l.moving){m.prevX=m.x;m.prevY=m.y;const t=g.time+m.phase;m.x=m.baseX+(m.axis==="x"?Math.sin(t*1.35)*m.range:0);m.y=m.baseY+(m.axis==="y"?Math.sin(t*1.15)*m.range*.55:0);}
    for(const e of l.enemies){if(!e.alive)continue;e.x+=e.vx*dt;if(e.x<e.min||e.x>e.max){e.vx*=-1;e.x=clamp(e.x,e.min,e.max);}e.phase+=dt*5;}
    const dir=(keys.has("right")?1:0)-(keys.has("left")?1:0);if(dir)p.facing=dir;
    if(just.has("jump"))p.jumpBuffer=.15;
    if(p.jumpBuffer>0&&(p.onGround||p.coyote>0||p.jumps<2||p.wallSide)){
      if(p.wallSide){p.vy=-610;p.vx=p.wallSide*390;p.facing=p.wallSide;p.jumps=1;}
      else{p.vy=p.jumps===0?-650:-590;p.jumps++;}
      p.onGround=false;p.coyote=0;p.jumpBuffer=0;beep(p.jumps===1?510:740,.07);
    }
    if(just.has("dash")&&p.dashCd<=0){p.dash=.16;p.dashCd=.88;p.invuln=Math.max(p.invuln,.18);p.vx=p.facing*720;p.vy*=.15;for(let i=0;i<10;i++)g.particles.push({x:p.x+rand(0,p.w),y:p.y+rand(0,p.h),vx:-p.facing*rand(80,260),vy:rand(-100,100),life:.25,color:worlds[l.world].glow,size:rand(2,5)});beep(250,.12,"sawtooth");}
    if(p.dash>0){p.dash-=dt;}else{const accel=p.onGround?2100:1350; if(dir)p.vx+=dir*accel*dt;else p.vx*=Math.pow(p.onGround?.0008:.11,dt);p.vx=clamp(p.vx,-350,350);}
    p.vy+=1800*dt;p.vy=Math.min(p.vy,950);p.wallSide=0;
    // X collision against solid platforms.
    p.x+=p.vx*dt;for(const b of l.platforms){if(b.type==="crumble"&&b.fall<0)continue;if(p.x+p.w>b.x&&p.x<b.x+b.w&&p.y+p.h>b.y+2&&p.y<b.y+b.h-2){if(p.vx>0){p.x=b.x-p.w;p.wallSide=-1;}else if(p.vx<0){p.x=b.x+b.w;p.wallSide=1;}p.vx=0;}}
    // Y collision; only top surfaces catch the player, so jumps stay predictable.
    p.y+=p.vy*dt;p.onGround=false;let ground=null;for(const b of l.platforms){if(b.type==="crumble"&&b.fall<0)continue;const overlap=p.x+p.w>b.x+3&&p.x<b.x+b.w-3;if(overlap&&p.vy>=0&&p.y+p.h>=b.y&&p.y+p.h-p.vy*dt<=b.y+16){p.y=b.y-p.h;p.vy=0;p.onGround=true;p.jumps=0;p.coyote=.12;ground=b; if(b.type==="crumble"){b.fall=(b.fall||1)-dt;if(b.fall<0)b.fall=-1;}}else if(overlap&&p.vy<0&&p.y<b.y+b.h&&p.y-p.vy*dt>=b.y+b.h-10){p.y=b.y+b.h;p.vy=80;}}
    if(ground?.type==="moving"&&ground.prevX!==undefined){p.x+=ground.x-ground.prevX;p.y+=ground.y-ground.prevY;}
    if(p.y>H+90||p.x< -30){respawn(g);} else p.x=clamp(p.x,0,l.length-p.w);
    // Checkpoint beacon.
    for(const cp of l.checkpoints){if(p.x>cp&&p.checkpoint<cp){p.checkpoint=cp+8;p.checkpointY=365;g.flash=.2;announce("CHECKPOINT LOCKED");beep(900,.14);}}
    // Shards.
    for(const s of l.shards){if(!s.got&&Math.hypot((p.x+p.w/2)-s.x,(p.y+p.h/2)-s.y)<30){s.got=true;p.shards++;g.combo++;g.comboTimer=2.4;for(let i=0;i<14;i++)g.particles.push({x:s.x,y:s.y,vx:rand(-150,150),vy:rand(-190,80),life:.5,color:"#bafff2",size:rand(2,4)});beep(850+Math.min(p.shards,4)*80,.09);}}
    g.comboTimer=Math.max(0,g.comboTimer-dt);if(g.comboTimer===0)g.combo=0;
    // Hazards and beams.
    const hurt=(x,y,w,h)=>{if(p.invuln<=0&&p.x<x+w&&p.x+p.w>x&&p.y<y+h&&p.y+p.h>y){respawn(g);return true;}return false;};
    for(const h of l.hazards){if(hurt(h.x,h.y,h.w,h.h))break;}
    for(const z of l.lasers){const active=Math.sin((g.time+z.phase)*Math.PI*2/z.period)>.15;if(active&&hurt(z.x-3,z.y,z.w+6,z.h))break;}
    // Patrol drones: land on top to destroy, touch from side to respawn.
    for(const e of l.enemies){if(!e.alive)continue;const ex=e.x,ey=e.y;if(p.x+p.w>ex-16&&p.x<ex+16&&p.y+p.h>ey-16&&p.y<ey+18){if(p.vy>120&&p.y+p.h<ey+12){e.alive=false;p.vy=-430;g.combo++;g.comboTimer=2.4;beep(230,.1,"square");for(let i=0;i<12;i++)g.particles.push({x:ex,y:ey,vx:rand(-100,100),vy:rand(-120,50),life:.4,color:"#ffb77e",size:3});}else if(p.invuln<=0){respawn(g);break;}}}
    for(const a of g.particles){a.x+=a.vx*dt;a.y+=a.vy*dt;a.life-=dt;a.vx*=Math.pow(.12,dt);a.vy+=250*dt;}g.particles=g.particles.filter(a=>a.life>0);
    for(let i=0;i<4;i++)p.trail.push({x:p.x+p.w/2,y:p.y+p.h*.65,life:.18});p.trail=p.trail.filter(t=>{t.life-=dt;return t.life>0;});
    const exit=l.exit;if(p.x+p.w>exit.x&&p.x<exit.x+exit.w&&p.y+p.h>exit.y&&p.y<exit.y+exit.h){if(p.shards>=2)finishLevel(g);else if(!g.hintShown){g.hintShown=true;announce("COLLECT 2 SHARDS TO OPEN THE EXIT");}}
    if(performance.now()-lastHud.current>100){lastHud.current=performance.now();setHud({time:g.time,shards:p.shards,deaths:p.deaths,dash:p.dashCd<=0?1:1-p.dashCd/.88,world:worlds[l.world].name});}
    just.clear();
  };
  const draw=(ctx,g)=>{
    const l=g.level,p=g.player,theme=worlds[l.world],t=g.time;ctx.clearRect(0,0,W,H);
    const grad=ctx.createLinearGradient(0,0,0,H);grad.addColorStop(0,theme.sky[0]);grad.addColorStop(1,theme.sky[1]);ctx.fillStyle=grad;ctx.fillRect(0,0,W,H);
    // Parallax skyline and distant lights.
    ctx.save();for(let i=0;i<26;i++){const x=((i*173-g.camera*.16)%(W+190)+W+190)%(W+190)-90,bh=70+((i*37)%125);ctx.fillStyle=i%3?"#0b1831":"#14264b";ctx.fillRect(x,H-bh-26,68,bh);for(let wy=H-bh+15;wy<H-38;wy+=18)for(let wx=x+10;wx<x+60;wx+=17){ctx.fillStyle=theme.glow;ctx.globalAlpha=.12+((i+Math.floor(wy/18))%4)*.045;ctx.fillRect(wx,wy,5,7);}}ctx.globalAlpha=1;ctx.restore();
    ctx.save();ctx.translate(-g.camera,0);
    // Decorative energy rails.
    ctx.strokeStyle=theme.glow;ctx.globalAlpha=.14;ctx.lineWidth=1;for(let x=0;x<l.length;x+=100){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}ctx.globalAlpha=1;
    for(const b of l.platforms){if(b.type==="crumble"&&b.fall<0)continue;ctx.save();ctx.shadowColor=theme.glow;ctx.shadowBlur=10;ctx.fillStyle=b.type==="moving"?theme.accent:theme.platform;ctx.strokeStyle=theme.glow;ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(b.x,b.y,b.w,b.h,7);ctx.fill();ctx.stroke();ctx.shadowBlur=0;ctx.fillStyle="#ffffff22";ctx.fillRect(b.x+7,b.y+5,b.w-14,3);if(b.type==="crumble"){ctx.strokeStyle="#ffffff70";ctx.setLineDash([5,5]);ctx.beginPath();ctx.moveTo(b.x+8,b.y+13);ctx.lineTo(b.x+b.w-8,b.y+13);ctx.stroke();}if(b.type==="moving"){ctx.globalAlpha=.7;ctx.fillStyle="#071225";for(let i=0;i<3;i++){ctx.beginPath();ctx.moveTo(b.x+b.w/2-12+i*10,b.y+8);ctx.lineTo(b.x+b.w/2-7+i*10,b.y+11);ctx.lineTo(b.x+b.w/2-12+i*10,b.y+14);ctx.fill();}}ctx.restore();}
    for(const h of l.hazards){ctx.save();ctx.fillStyle=theme.hazard;ctx.shadowColor=theme.hazard;ctx.shadowBlur=14;const n=Math.max(2,Math.floor(h.w/18));for(let i=0;i<n;i++){const x=h.x+i*h.w/n;ctx.beginPath();ctx.moveTo(x,h.y+h.h);ctx.lineTo(x+h.w/n/2,h.y);ctx.lineTo(x+h.w/n,h.y+h.h);ctx.closePath();ctx.fill();}ctx.restore();}
    for(const z of l.lasers){const active=Math.sin((t+z.phase)*Math.PI*2/z.period)>.15;ctx.save();ctx.fillStyle=active?"#ff557b":"#ff557b33";ctx.shadowColor="#ff557b";ctx.shadowBlur=active?20:3;ctx.fillRect(z.x,z.y,z.w,z.h);ctx.fillStyle=active?"#fff":"#ffb6c7";ctx.globalAlpha=active?.9:.25;ctx.fillRect(z.x+2,z.y,z.w-4,z.h);ctx.restore();}
    for(const s of l.shards){if(s.got)continue;ctx.save();ctx.translate(s.x,s.y+Math.sin(t*3+s.phase)*5);ctx.rotate(Math.sin(t*2+s.phase)*.2);ctx.shadowColor="#bafff2";ctx.shadowBlur=18;ctx.fillStyle="#8affeb";ctx.beginPath();ctx.moveTo(0,-14);ctx.lineTo(11,0);ctx.lineTo(0,14);ctx.lineTo(-11,0);ctx.closePath();ctx.fill();ctx.strokeStyle="#eaffff";ctx.lineWidth=2;ctx.stroke();ctx.restore();}
    for(const e of l.enemies){if(!e.alive)continue;ctx.save();ctx.translate(e.x,e.y+Math.sin(e.phase)*4);ctx.shadowColor="#ff906d";ctx.shadowBlur=18;ctx.fillStyle=e.elite?"#ffb56b":"#ff7b7d";ctx.beginPath();ctx.roundRect(-15,-12,30,24,8);ctx.fill();ctx.fillStyle="#14203b";ctx.fillRect(-7,-4,14,5);ctx.fillStyle="#fff1cb";ctx.fillRect(-4,-3,4,3);ctx.fillRect(2,-3,4,3);ctx.strokeStyle="#ffd3a1";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-10,-11);ctx.lineTo(-17,-20+Math.sin(e.phase)*3);ctx.moveTo(10,-11);ctx.lineTo(17,-20-Math.sin(e.phase)*3);ctx.stroke();ctx.restore();}
    // Exit portal.
    const ex=l.exit;ctx.save();ctx.translate(ex.x+ex.w/2,ex.y+ex.h/2);ctx.shadowColor=theme.glow;ctx.shadowBlur=28;ctx.strokeStyle=theme.glow;ctx.lineWidth=6;ctx.beginPath();ctx.ellipse(0,0,23,41,0,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=.25;ctx.fillStyle=theme.glow;ctx.beginPath();ctx.ellipse(0,0,18+Math.sin(t*3)*3,35+Math.sin(t*3)*3,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;ctx.restore();
    // Player trail and avatar — only this character responds to player input.
    for(const tr of p.trail){ctx.globalAlpha=tr.life/.18*.25;ctx.fillStyle=theme.glow;ctx.beginPath();ctx.arc(tr.x,tr.y,4,0,Math.PI*2);ctx.fill();}ctx.globalAlpha=1;
    if(p.invuln<=0||Math.floor(t*12)%2===0){ctx.save();ctx.translate(p.x+p.w/2,p.y+p.h/2);ctx.scale(p.facing,1);const glow=ctx.createRadialGradient(0,0,3,0,0,40);glow.addColorStop(0,theme.glow+"66");glow.addColorStop(1,theme.glow+"00");ctx.fillStyle=glow;ctx.fillRect(-42,-42,84,84);ctx.shadowColor=theme.glow;ctx.shadowBlur=18;ctx.fillStyle="#e8fbff";ctx.beginPath();ctx.roundRect(-11,-15,22,26,7);ctx.fill();ctx.fillStyle=theme.accent;ctx.beginPath();ctx.roundRect(-12,-20,24,15,7);ctx.fill();ctx.fillStyle="#14233b";ctx.fillRect(2,-15,7,5);ctx.fillStyle=theme.glow;ctx.fillRect(-9,11,7,12);ctx.fillRect(3,11,7,12);ctx.strokeStyle="#dffcff";ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-9,-4);ctx.lineTo(-17,5);ctx.moveTo(9,-4);ctx.lineTo(15,4);ctx.stroke();ctx.restore();}
    ctx.restore();
    // Top HUD and control guidance.
    ctx.fillStyle="#071225b9";ctx.beginPath();ctx.roundRect(16,14,300,56,12);ctx.fill();ctx.fillStyle=theme.glow;ctx.font="900 10px system-ui";ctx.fillText(`WORLD ${l.world+1} · LEVEL ${l.index+1}`,30,34);ctx.fillStyle="#fff";ctx.font="800 17px system-ui";ctx.fillText(`${theme.name}`,30,56);ctx.fillStyle="#e9ffff";ctx.font="900 12px system-ui";ctx.fillText(`◆ ${p.shards}/3`,W-94,35);ctx.fillStyle="#aac1d5";ctx.font="10px system-ui";ctx.fillText(`${g.time.toFixed(1)}s  ·  ${p.deaths} falls`,W-165,56);
    // Dash cooldown bar.
    ctx.fillStyle="#081427cc";ctx.beginPath();ctx.roundRect(W-175,H-30,145,10,5);ctx.fill();ctx.fillStyle=theme.accent;ctx.beginPath();ctx.roundRect(W-175,H-30,145*(1-p.dashCd/.88),10,5);ctx.fill();ctx.fillStyle="#dbefff";ctx.font="9px system-ui";ctx.fillText("DASH",W-210,H-21);
    if(g.flash>0){ctx.fillStyle="#cafff2";ctx.globalAlpha=g.flash*1.8;ctx.fillRect(0,0,W,H);ctx.globalAlpha=1;}
  };
  useEffect(()=>{const canvas=canvasRef.current;if(!canvas)return;const ctx=canvas.getContext("2d");let raf=0,last=0;const resize=()=>{const dpr=Math.min(window.devicePixelRatio||1,2),r=canvas.getBoundingClientRect();canvas.width=Math.round(r.width*dpr);canvas.height=Math.round(r.height*dpr);ctx.setTransform(canvas.width/W,0,0,canvas.height/H,0,0);};resize();const ro=new ResizeObserver(resize);ro.observe(canvas);
    const press=(e)=>{const k=keyAliases[e.code]||keyAliases[e.key]||keyAliases[e.key.toLowerCase()];if(!k)return;if(["left","right","jump","dash"].includes(k)){e.preventDefault();if(!inputRef.current.has(k))justRef.current.add(k);inputRef.current.add(k);}if(k==="restart"&&screenRef.current==="playing")restartRef.current?.();if(k==="pause")pauseRef.current?.();};
    const release=(e)=>{const k=keyAliases[e.code]||keyAliases[e.key]||keyAliases[e.key.toLowerCase()];if(k)inputRef.current.delete(k);};
    const clear=()=>{inputRef.current.clear();justRef.current.clear();};
    window.addEventListener("keydown",press,{passive:false});window.addEventListener("keyup",release);window.addEventListener("blur",clear);document.addEventListener("visibilitychange",()=>{if(document.hidden)clear();});
    const loop=(ts)=>{const dt=Math.min(.032,(ts-(last||ts))/1000);last=ts;const g=gameRef.current;if(g&&g.state==="playing"&&screenRef.current==="playing"){stepRef.current?.(g,dt);g.camera=clamp(g.player.x-W*.34,0,g.level.length-W);draw(ctx,g);}else if(g){draw(ctx,g);}else{ctx.clearRect(0,0,W,H);drawMenuCanvas(ctx,ts);}raf=requestAnimationFrame(loop);};
    raf=requestAnimationFrame(loop);return()=>{cancelAnimationFrame(raf);ro.disconnect();window.removeEventListener("keydown",press);window.removeEventListener("keyup",release);window.removeEventListener("blur",clear);};
  },[]);
  const stepRef=useRef(step),restartRef=useRef(restart),pauseRef=useRef(pause);useEffect(()=>{stepRef.current=step;restartRef.current=restart;pauseRef.current=pause;});
  useEffect(()=>{screenRef.current=screen;},[screen]);useEffect(()=>{soundRef.current=sound;},[sound]);
  const control=(name,on)=>{if(on){if(!inputRef.current.has(name))justRef.current.add(name);inputRef.current.add(name);}else inputRef.current.delete(name);};
  const setModeScreen=(s)=>{setScreen(s);screenRef.current=s;inputRef.current.clear();justRef.current.clear();};
  const beginDaily=()=>startLevel((new Date().getUTCDate()*7+new Date().getUTCMonth()*3)%LEVEL_COUNT,true);
  const next=()=>{const g=gameRef.current;if(g?.daily){setModeScreen("menu");return;}startLevel(Math.min(LEVEL_COUNT-1,(g?.level.index??0)+1),false);};
  const dailyKey=new Date().toISOString().slice(0,10);
  return <div className="neon-breakout-shell">
    <div className="nb-top"><div><span className="nb-live-dot"/> PLAYZIPPY ORIGINAL · NEON BREAKOUT</div><div className="nb-stats"><span>✦ {save.totalShards} SHARDS</span><span>✓ {save.clears} CLEARS</span></div></div>
    <div className="nb-stage">
      <canvas ref={canvasRef} className="nb-canvas" aria-label="Neon Breakout platform game. Move with A and D or arrow keys. Jump with Space. Dash with Shift."/>
      {screen!=="playing"&&<div className="nb-overlay">
        {screen==="menu"&&<div className="nb-panel nb-menu"><div className="nb-eyebrow">30 HANDCRAFTED-STYLE TRIALS · 6 WORLDS</div><h2>NEON <em>BREAKOUT</em></h2><p className="nb-tagline">NO AUTOPILOT. EVERY JUMP IS YOURS.</p><div className="nb-menu-flex"><div className="nb-copy"><h3>RUN THE SKYLINE</h3><p>Read the gaps. Time the lasers. Stomp drones. Chain jumps and dashes to reach the rift gate. Find at least two shards on every level to open the exit.</p><div className="nb-controls"><div><kbd>A</kbd><kbd>D</kbd><span>MOVE</span></div><div><kbd>SPACE</kbd><span>JUMP / DOUBLE JUMP</span></div><div><kbd>SHIFT</kbd><span>DASH</span></div><div><kbd>R</kbd><span>RESTART CHECKPOINT</span></div></div><div className="nb-medals"><span>🥉 BRONZE · FINISH</span><span>🥈 SILVER · FAST</span><span>🥇 GOLD · MASTER</span></div></div><div className="nb-world-card"><div className="nb-world-number">01—06</div><b>CAMPAIGN</b><span>30 LEVELS · SAVE YOUR BEST TIMES</span><div className="nb-progress"><i style={{width:`${(save.unlocked-1)/LEVEL_COUNT*100}%`}}/></div><small>{Math.min(LEVEL_COUNT,save.unlocked-1)} / {LEVEL_COUNT} UNLOCKED</small><button className="nb-primary" onClick={()=>startLevel(Math.max(0,save.unlocked-1),false)}> {save.clears?"CONTINUE CAMPAIGN":"START CAMPAIGN"} <b>→</b></button><button className="nb-secondary" onClick={()=>beginDaily()}>DAILY RIFT · {dailyKey}</button></div></div><div className="nb-worlds">{worlds.map((w,i)=><div key={w.name} className={i<=Math.floor((save.unlocked-1)/5)?"unlocked":"locked"}><i style={{background:w.glow}}/><span>{String(i+1).padStart(2,"0")} {w.name}</span><small>{i*5+1}–{i*5+5}</small></div>)}</div><div className="nb-level-heading"><b>LEVEL SELECT</b><span>Replay unlocked trials · beat your best time</span></div><div className="nb-level-grid">{Array.from({length:LEVEL_COUNT},(_,i)=>{const open=i<save.unlocked;const rec=save.bestTime[String(i)];return <button key={i} disabled={!open} onClick={()=>startLevel(i,false)} className={open?"open":"locked"}><b>{String(i+1).padStart(2,"0")}</b><small>{rec?`${rec.toFixed(1)}s`:open?"NEW":"LOCKED"}</small></button>;})}</div></div>}
        {screen==="paused"&&<div className="nb-panel nb-result"><div className="nb-eyebrow">TAKE A BREATHER</div><h2>PAUSED</h2><p>Your runner is safe. Resume when ready.</p><button className="nb-primary" onClick={()=>setModeScreen("playing")}>RESUME RUN →</button><button className="nb-secondary" onClick={()=>setModeScreen("menu")}>QUIT TO HUB</button></div>}
        {screen==="complete"&&result&&<div className="nb-panel nb-result"><div className="nb-eyebrow">LEVEL {result.index+1} CLEARED</div><h2>{result.medals===3?"PERFECT RUN":result.medals===2?"CLEAN RUN":"RIFT CLEARED"}</h2><div className="nb-trophy">{"★".repeat(result.medals)}<span>{"☆".repeat(3-result.medals)}</span></div><div className="nb-complete-stats"><div><b>{result.time.toFixed(1)}s</b><small>TIME</small></div><div><b>{result.shards}/3</b><small>SHARDS</small></div><div><b>{result.deaths}</b><small>FALLS</small></div></div><div className="nb-result-actions"><button className="nb-primary" onClick={next}>{result.daily?"BACK TO HUB":"NEXT LEVEL"} →</button><button className="nb-secondary" onClick={()=>setModeScreen("menu")}>WORLD MAP</button></div></div>}
      </div>}
      {screen==="playing"&&<button className="nb-pause" onClick={pause}>Ⅱ</button>}
    </div>
    <div className="nb-controlbar"><div className="nb-move-controls"><button onPointerDown={e=>{e.preventDefault();control("left",true);}} onPointerUp={()=>control("left",false)} onPointerLeave={()=>control("left",false)} onPointerCancel={()=>control("left",false)}>◀</button><button onPointerDown={e=>{e.preventDefault();control("right",true);}} onPointerUp={()=>control("right",false)} onPointerLeave={()=>control("right",false)} onPointerCancel={()=>control("right",false)}>▶</button></div><div className="nb-hint">MOVE <b>A / D</b> OR <b>← / →</b> · JUMP / DOUBLE / WALL JUMP <b>SPACE</b> · DASH <b>SHIFT</b> · RESTART <b>R</b></div><div className="nb-action-controls"><button className="jump" onPointerDown={e=>{e.preventDefault();control("jump",true);}} onPointerUp={()=>control("jump",false)} onPointerLeave={()=>control("jump",false)} onPointerCancel={()=>control("jump",false)}>JUMP</button><button className="dash" onPointerDown={e=>{e.preventDefault();control("dash",true);}} onPointerUp={()=>control("dash",false)} onPointerLeave={()=>control("dash",false)} onPointerCancel={()=>control("dash",false)}>DASH</button></div></div>
    {notice&&<div className="nb-notice">{notice}</div>}
    <div className="nb-bottom"><span>PLAYER-CONTROLLED PLATFORMER · NO AI DRIVING</span><button onClick={()=>setSound(v=>!v)}>{sound?"SOUND ON ♫":"SOUND OFF ×"}</button><button onClick={restart}>RESTART LEVEL ↻</button></div>
  </div>;
}
function drawMenuCanvas(ctx,ts){ctx.clearRect(0,0,W,H);const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,"#09162b");g.addColorStop(1,"#221d4b");ctx.fillStyle=g;ctx.fillRect(0,0,W,H);for(let i=0;i<44;i++){const x=(i*137)%W,y=(i*89)%H;ctx.globalAlpha=.25+.25*Math.sin(ts/800+i);ctx.fillStyle="#b5ecff";ctx.fillRect(x,y,2,2);}ctx.globalAlpha=1;for(let i=0;i<7;i++){const x=80+i*145,y=445-Math.sin(ts/900+i)*35;ctx.fillStyle=i%2?"#283b63":"#314d72";ctx.beginPath();ctx.roundRect(x,y,105,18,6);ctx.fill();ctx.fillStyle="#66e7ed";ctx.fillRect(x+12,y+5,25,3);}const x=460+Math.sin(ts/1100)*100,y=350+Math.sin(ts/700)*24;ctx.shadowColor="#6ce8ef";ctx.shadowBlur=25;ctx.fillStyle="#eaffff";ctx.beginPath();ctx.roundRect(x-12,y-24,24,35,8);ctx.fill();ctx.fillStyle="#a58cff";ctx.beginPath();ctx.roundRect(x-13,y-30,26,16,7);ctx.fill();ctx.shadowBlur=0;}
export default NeonBreakout;
