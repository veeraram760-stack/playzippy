# IRON FRONTIER — Operation Black Sun 2.0

A browser-based side-scrolling run-and-gun game built around both a four-operation campaign and a replayable survival loop.

## What changed in 2.0

- **The opening encounter is active immediately.** The first campaign enemy wave is spawned at the visible edge of the battlefield instead of waiting for the player to travel through an empty opening.
- **Endless Survival:** the run continues through escalating waves. Enemy health and damage increase as the run progresses, the battle zone rotates every five waves, and a boss arrives every fifth wave.
- **Daily Contract:** complete eight survival waves for a one-time daily reward of 1,200 field credits. The daily reset uses the player's local calendar date.
- **Persistent Command upgrades:** credits earned from kills, boss fights, campaign sectors and survival waves can be spent on five levels each of Armor Rig, Weapon Amplifier and Mobility. Credits, upgrades, lifetime kills, best wave and best score are stored in browser local storage.
- **More useful run feedback:** the game-over screen reports score, kills and credits earned. Survival waves are cleared and retired from memory before the next wave starts.
- **Visibility fix:** Rook has a high-contrast ground locator and a procedural fallback soldier if the player sprite fails to load. The main-menu hero's fallback animation state is initialized explicitly.

## Modes

1. **Campaign:** four themed operations, five enemy waves per operation, supply crates and a sector boss.
2. **Endless Survival:** no final wave; enemies scale up, zone themes rotate, and every fifth wave is a boss encounter.
3. **Daily Contract:** the same survival loop with an eight-wave daily objective and a one-time 1,200-credit reward.

## Permanent upgrades

- **Armor Rig:** +24 maximum health per level.
- **Weapon Amplifier:** +12% damage per level.
- **Mobility:** +5.5% movement speed per level.

Each track has five levels. Upgrade costs rise with each purchase. Progress is stored in local storage on the player's device/browser.

## Controls

- **A / D** or **← / →** — move
- **W / S** or **↑ / ↓** — aim vertically
- **Mouse** — aim and hold click to fire
- **J** — fire
- **Space** — jump / double jump
- **Shift** — dash / air dash (once per jump)
- **S + Shift** — ground slide
- **E** — close-range melee strike
- **K** — frag grenade
- **L** — overdrive pulse
- **1 / 2 / 3** — assault rifle / breach shotgun / arc plasma
- **P / Esc** — pause

Touch controls are included for mobile browsers. A wide 16:9 desktop window is recommended.

## Build and test

```bash
npm test
npm run build
```

`npm run build` creates the deployable static website in `dist/`. `standalone.html` is a self-contained offline copy.

The automated suite includes source checks plus a deterministic game-logic simulation for campaign opening encounters, the canvas render path, survival difficulty, fifth-wave bosses, daily rewards, permanent upgrades and local save persistence.
