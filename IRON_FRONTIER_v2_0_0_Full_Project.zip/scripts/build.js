const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const out=path.join(root,'dist');
fs.rmSync(out,{recursive:true,force:true});
fs.mkdirSync(out,{recursive:true});
for(const item of ['index.html','style.css','src','assets','README.md']){
 const source=path.join(root,item); if(fs.existsSync(source)) fs.cpSync(source,path.join(out,item),{recursive:true});
}
console.log('Built static game in dist/');
