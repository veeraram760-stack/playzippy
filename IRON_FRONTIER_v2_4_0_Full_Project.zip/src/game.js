(() => {
'use strict';
const W=1600,H=900,GROUND=738,GRAVITY=1900;
const canvas=document.getElementById('game'),ctx=canvas.getContext('2d',{alpha:false});
const $=id=>document.getElementById(id);
function syncVisualAssetStatus(){
 const bgReady=imageReady(art.jungle),rookReady=imageReady(art.rook),enemyReady=imageReady(art.enemy);
 const bgFailed=artLoadErrors.has(art.jungle);
 const status=$('asset-status');
 if(status){
  status.textContent=bgFailed?'BATTLEFIELD ART FAILED TO LOAD · REFRESH OR CHECK ASSETS':(!bgReady?'LOADING BATTLEFIELD ART…':(!rookReady||!enemyReady?'BATTLEFIELD READY · SOLDIER FALLBACK ACTIVE':'VISUAL ASSETS READY · DEPLOYMENT READY'));
  status.dataset.state=bgFailed?'error':(!bgReady?'loading':(!rookReady||!enemyReady?'warning':'ready'));
 }
 for(const id of ['start-btn','survival-btn','daily-btn']){const button=$(id);if(button)button.disabled=!bgReady;}
}
const art={jungle:new Image(),rook:new Image(),enemy:new Image()};
// Versioned names prevent stale CDN/browser caches from mixing old art with the new renderer.
art.jungle.src='assets/jungle-panorama-full-v24.jpg';
art.rook.src='assets/rook-v24.png';
art.enemy.src='assets/enemy-v24.png';
function imageReady(img){return !!img&&img.complete&&img.naturalWidth>0&&img.naturalHeight>0;}
const artLoadErrors=new Set();
for(const img of Object.values(art)){img.onload=syncVisualAssetStatus;img.onerror=()=>{artLoadErrors.add(img);syncVisualAssetStatus();};}
function visualAssetsReady(){return imageReady(art.jungle);}
let renderFailure=null;
const screens=['menu-screen','pause-screen','manual-screen','stage-screen','gameover-screen','victory-screen'];
const LEVELS=[
 {name:'JUNGLE RELAY',chapter:'OPERATION BLACK SUN · 01',place:'KORUAN GREEN ZONE',boss:'THE IRON WARDEN',bossType:'warden',theme:'jungle',length:4850,sky:['#203b3c','#779a83','#d3b88b'],accent:'#efbd65',description:'A fallen relay station swallowed by the green.'},
 {name:'IRONWORKS 09',chapter:'OPERATION BLACK SUN · 02',place:'INDUSTRIAL EXCLUSION BELT',boss:'SIEGE WALKER MK-II',bossType:'walker',theme:'foundry',length:5050,sky:['#202a31','#7b5a46','#e7a46d'],accent:'#ffab65',description:'Break the weapons line before the convoy launches.'},
 {name:'FROSTLINE',chapter:'OPERATION BLACK SUN · 03',place:'NORTH RIDGE PERIMETER',boss:'GLACIER BEHEMOTH',bossType:'behemoth',theme:'frost',length:5100,sky:['#182f42','#7196a9','#d1e3df'],accent:'#9be5f0',description:'A frozen weapons lab is powering the Black Sun.'},
 {name:'BLACK SUN CITADEL',chapter:'OPERATION BLACK SUN · 04',place:'EXTRATERRESTRIAL CORE',boss:'THE ECLIPSE ENGINE',bossType:'engine',theme:'alien',length:5350,sky:['#170f26','#592b52','#d16a54'],accent:'#ff8b75',description:'Reach the core. End the invasion.'}
];
const input={keys:new Set(),pointer:{x:1050,y:380,down:false,inside:false},touch:new Set()};
const CAREER_KEY='iron_frontier_career_v2';
function freshCareer(){return {credits:450,upgrades:{armor:0,power:0,agility:0},bestWave:0,bestScore:0,lifetimeKills:0,campaignStages:0,dailyDate:'',dailyClaimed:false};}
function loadCareer(){try{const raw=JSON.parse(localStorage.getItem(CAREER_KEY)||'null');if(!raw)return freshCareer();const d=freshCareer();return {...d,...raw,upgrades:{...d.upgrades,...(raw.upgrades||{})}};}catch(e){return freshCareer();}}
const career=loadCareer();
function saveCareer(){try{localStorage.setItem(CAREER_KEY,JSON.stringify(career));localStorage.setItem('if_best',String(Math.max(best,career.bestScore||0)));}catch(e){}}
function dayKey(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;}
function refreshDaily(){const today=dayKey();if(career.dailyDate!==today){career.dailyDate=today;career.dailyClaimed=false;saveCareer();}}
function upgradeCost(type){const levels=career.upgrades[type]||0;return [260,380,540,760,1040][levels]||0;}
function renderCareerUI(){refreshDaily();const credits=$('career-credits');if(credits)credits.textContent=career.credits.toLocaleString('en-IN');const stat=$('career-record');if(stat)stat.textContent=`BEST WAVE ${career.bestWave} · ${career.lifetimeKills.toLocaleString('en-IN')} LIFETIME KILLS`;
 for(const type of ['armor','power','agility']){const lvl=career.upgrades[type]||0,el=$(`upgrade-${type}`),price=$(`cost-${type}`);if(el){el.textContent=`LEVEL ${lvl}/5`;el.parentElement.disabled=lvl>=5||career.credits<upgradeCost(type);}if(price)price.textContent=lvl>=5?'MAXED':`${upgradeCost(type)} CR`;}
 const daily=$('daily-status');if(daily)daily.textContent=career.dailyClaimed?'CONTRACT COMPLETE · COME BACK TOMORROW':'CLEAR 8 SURVIVAL WAVES · REWARD 1,200 CR';}
let game=null,last=0,raf=0,audio=null,shake=0,stageBanner=0,screenFlash=0,gameState='menu',best=Number(localStorage.getItem('if_best')||0),muted=false,dailyToastUntil=0;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rand=(a,b)=>a+Math.random()*(b-a);
const dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
function sound(type){if(muted)return;try{audio ||= new (window.AudioContext||window.webkitAudioContext)();if(audio.state==='suspended')audio.resume();const o=audio.createOscillator(),g=audio.createGain();o.connect(g);g.connect(audio.destination);const now=audio.currentTime;const presets={shot:[120,70,.055,'square'],heavy:[82,42,.12,'sawtooth'],laser:[560,140,.12,'sawtooth'],boom:[75,24,.22,'triangle'],hit:[160,80,.07,'square'],pickup:[640,920,.12,'sine'],dash:[220,90,.09,'triangle'],boss:[65,35,.4,'sawtooth'],pulse:[140,880,.3,'sine']};const p=presets[type]||presets.shot;o.type=p[3];o.frequency.setValueAtTime(p[0],now);o.frequency.exponentialRampToValueAtTime(Math.max(20,p[1]),now+p[2]);g.gain.setValueAtTime(.08,now);g.gain.exponentialRampToValueAtTime(.001,now+p[2]);o.start(now);o.stop(now+p[2]+.015);}catch(e){}}
function setScreen(id){for(const s of screens)$(s).classList.toggle('visible',s===id);}
function resetInput(){input.keys.clear();input.touch.clear();input.pointer.down=false;}
function playerFactory(){const armor=career.upgrades.armor||0,power=career.upgrades.power||0,agility=career.upgrades.agility||0;const maxHealth=160+armor*24;return {x:130,y:GROUND,vx:0,vy:0,w:62,h:124,health:maxHealth,maxHealth,damageMult:1+power*.12,moveMult:1+agility*.055,grounded:true,facing:1,aimY:0,aimAngle:0,fireCd:0,invuln:0,jumpCount:0,airDashUsed:false,weapon:0,ammo:{0:Infinity,1:80,2:24},grenades:5,grenadeCd:0,pulse:100,pulseCd:0,dashCd:0,dashTime:0,slideTime:0,slideCd:0,meleeTime:0,meleeCd:0,ghostTimer:0,ghosts:[],flash:0,run:0,score:0,kills:0,xp:0,rank:1,combo:0,comboTimer:0,crouch:false,hitStop:0,shotAnim:0,hurtTime:0,hitDirection:1};}
function createGame(){return {mode:'campaign',stage:0,player:playerFactory(),enemies:[],bullets:[],enemyBullets:[],grenades:[],crates:[],particles:[],pickups:[],shells:[],explosions:[],world:0,spawned:[],wave:0,score:0,kills:0,time:0,boss:null,bossDead:false,stageComplete:false,shake:0,checkpoint:0,highScore:best,elapsed:0,survivalWave:0,survivalInProgress:false,survivalNextIn:0,survivalBoss:false,sessionCredits:0,dailyRewarded:false};}
function level(){return LEVELS[game.stage];}
function makeWaveList(index){const layouts=[
 [{x:520,types:['trooper','trooper','drone']},{x:1120,types:['trooper','heavy','trooper']},{x:1810,types:['drone','trooper','trooper','heavy']},{x:2600,types:['turret','trooper','heavy']},{x:3350,types:['trooper','trooper','drone','heavy']}],
 [{x:500,types:['trooper','heavy','drone']},{x:1200,types:['turret','trooper','trooper']},{x:1920,types:['heavy','heavy','drone']},{x:2750,types:['trooper','turret','drone','trooper']},{x:3550,types:['heavy','heavy','trooper']}],
 [{x:520,types:['drone','trooper','trooper']},{x:1220,types:['heavy','drone','heavy']},{x:2000,types:['turret','trooper','drone']},{x:2800,types:['heavy','heavy','drone','trooper']},{x:3600,types:['trooper','drone','turret','heavy']}],
 [{x:520,types:['trooper','drone','trooper']},{x:1290,types:['heavy','heavy','drone']},{x:2090,types:['turret','trooper','trooper','drone']},{x:2920,types:['heavy','drone','heavy']},{x:3750,types:['trooper','turret','drone','heavy']}]
];
 return layouts[index].map((v,i)=>({at:v.x,types:v.types,label:`WAVE ${i+1}`}));}
function spawnEnemy(type,x,extra={}){const cfg={trooper:{hp:105,speed:rand(86,120),w:84,h:148,range:470,damage:10,color:'#bca48c'},heavy:{hp:285,speed:55,w:104,h:166,range:530,damage:17,color:'#817e78'},drone:{hp:72,speed:145,w:60,h:54,range:580,damage:9,color:'#a4b6a7'},turret:{hp:180,speed:0,w:70,h:90,range:640,damage:12,color:'#b18b68'}}[type];
 const hp=cfg.hp*(extra.hpScale||1)*(extra.survivalElite?1.65:1),damage=cfg.damage*(extra.damageScale||1)*(extra.survivalElite?1.25:1);const e={id:Math.random(),type,x,y:type==='drone'?GROUND-260:GROUND,vx:0,vy:0,w:cfg.w*(extra.survivalElite?1.08:1),h:cfg.h*(extra.survivalElite?1.08:1),hp,maxHp:hp,speed:cfg.speed*(extra.survivalElite?.92:1),range:cfg.range,damage,color:cfg.color,dir:-1,fireCd:rand(.5,1.5),windup:0,attack:0,stun:0,flash:0,walk:rand(0,6),alive:true,grounded:true,phase:0,shield:type==='heavy'?0.22:0,aimAngle:0,recoil:0,hitReact:0,hitDirection:1,deathTime:null,...extra};game.enemies.push(e);return e;}
function spawnBoss(){const l=level();const hp=[1100,1500,1750,2300][game.stage];const b={id:Math.random(),type:l.bossType,name:l.boss,x:game.world+960,y:GROUND,w:game.stage===3?260:game.stage===2?220:200,h:game.stage===1?250:game.stage===3?300:230,hp,maxHp:hp,fireCd:1.2,windup:0,phase:0,flash:0,stun:0,alive:true,entered:false,attack:0,walk:0,recoil:0,hitReact:0};game.boss=b;game.bossDead=false;stageBanner=2.8;sound('boss');}
function loadStage(index,heal=true){game.stage=index;game.world=0;game.enemies=[];game.bullets=[];game.enemyBullets=[];game.grenades=[];game.crates=[900,1680,2510,3240,4110].map((x,i)=>({x,y:GROUND-44,w:82,h:44,hp:90,alive:true,flash:0,drop:i%2?'ammo':'health'}));game.particles=[];game.pickups=[];game.shells=[];game.explosions=[];game.spawned=[];game.wave=0;game.boss=null;game.bossDead=false;game.stageComplete=false;game.player.x=130;game.player.y=GROUND;game.player.vx=0;game.player.vy=0;game.player.grounded=true;game.player.slideTime=0;game.player.dashTime=0;game.player.ghosts=[];game.player.airDashUsed=false;game.player.invuln=2.4;game.player.pulse=100;if(heal)game.player.health=Math.min(game.player.maxHealth,game.player.health+48);stageBanner=3.6;if(game.mode==='campaign'){const first=makeWaveList(index)[0];game.spawned=[0];spawnWave(first);}updateHud(true);}
function enterPlay(){gameState='playing';setScreen(null);$('hud').classList.remove('hidden');resetInput();last=performance.now();updateHud(true);}
function startGame(){if(!visualAssetsReady()){syncVisualAssetStatus();return;}game=createGame();game.mode='campaign';loadStage(0,false);enterPlay();}
function startSurvival(mode='survival'){if(!visualAssetsReady()){syncVisualAssetStatus();return;}refreshDaily();game=createGame();game.mode=mode;loadStage(0,false);game.survivalWave=0;game.survivalInProgress=false;game.survivalNextIn=0;game.survivalBoss=false;game.wave=0;enterPlay();queueSurvivalWave();}
function buyUpgrade(type){const lvl=career.upgrades[type]||0,cost=upgradeCost(type);if(lvl>=5||career.credits<cost)return;career.credits-=cost;career.upgrades[type]=lvl+1;saveCareer();renderCareerUI();sound('pickup');}

function goMenu(){gameState='menu';$('hud').classList.add('hidden');setScreen('menu-screen');resetInput();renderCareerUI();}
function pauseGame(){if(gameState==='playing'){gameState='paused';setScreen('pause-screen');resetInput();}}
function resumeGame(){if(gameState==='paused'){gameState='playing';setScreen(null);last=performance.now();}}
function updateHud(force=false){if(!game)return;const p=game.player,l=level();$('level-label').textContent=`STAGE 0${game.stage+1}`;$('health-value').textContent=`${Math.ceil(p.health)} / ${p.maxHealth}`;$('health-fill').style.width=`${100*p.health/p.maxHealth}%`;$('rank-value').textContent=`${String(p.rank).padStart(2,'0')} · ${['RECRUIT','VANGUARD','ELITE','PHANTOM','SENTINEL','ACE','COMMANDO','LEGEND','APEX','BLACK SUN'][Math.min(9,p.rank-1)]}`;$('xp-fill').style.width=`${p.xp%100}%`;$('stage-name').textContent=l.name;$('chapter-kicker').textContent=l.chapter;$('wave-label').textContent=game.mode==='survival'||game.mode==='daily'?(game.boss?'WARLORD ENGAGED · SURVIVAL':`${game.mode==='daily'?'DAILY CONTRACT':'ENDLESS SURVIVAL'} · WAVE ${game.survivalWave}${game.mode==='daily'?' · '+Math.min(8,game.survivalWave)+'/8':''}`):(game.boss?`WARLORD ENGAGED · ${l.place}`:`${l.place} · WAVE ${Math.min(game.wave,5)} / 5`);$('enemy-count').textContent=game.enemies.filter(e=>e.alive).length+(game.boss&&game.boss.alive?1:0);const weapon=[['ASSAULT RIFLE','∞ · RIFLE','✦'],['BREACH SHOTGUN',`${p.ammo[1]} · SHELLS`,'▤'],['ARC PLASMA',`${p.ammo[2]} · CELLS`,'⚡']][p.weapon];$('weapon-name').textContent=weapon[0];$('ammo-value').innerHTML=weapon[1].replace(' · ',' <em>· ')+ (weapon[1].includes(' · ')?'</em>':'');$('weapon-icon').textContent=weapon[2];$('boss-meter').classList.toggle('hidden',!(game.boss&&game.boss.alive));if(game.boss&&game.boss.alive){$('boss-name').textContent=game.boss.name;$('boss-fill').style.width=`${100*game.boss.hp/game.boss.maxHp}%`;}}
function spawnWave(w){const base=Math.max(game.player.x+620,game.world+760);w.types.forEach((type,i)=>spawnEnemy(type,base+i*92,{lane:0}));game.wave++;stageBanner=1.65;updateHud();}
function stageUpdate(dt){if(game.mode==='survival'||game.mode==='daily'){survivalUpdate(dt);return;}const p=game.player,lv=level();const waves=makeWaveList(game.stage);for(let i=1;i<waves.length;i++){if(!game.spawned.includes(i)&&p.x>waves[i].at){game.spawned.push(i);spawnWave(waves[i]);}}
 if(p.x>lv.length-1100&&!game.boss&&!game.bossDead&&!game.stageComplete&&game.spawned.length>=5)spawnBoss();
 if(game.boss&&game.boss.alive&&game.boss.x<game.world+W-120)game.boss.x=game.world+W-120;
 if(game.bossDead&&!game.enemies.some(e=>e.alive)&&!game.stageComplete){game.stageComplete=true;career.credits+=500+game.stage*150;game.sessionCredits+=500+game.stage*150;career.campaignStages=Math.max(career.campaignStages,game.stage+1);saveCareer();setTimeout(()=>{if(gameState!=='playing'||!game||!game.stageComplete)return;showStageClear();},900);}
}
function queueSurvivalWave(){if(!game||gameState!=='playing')return;game.survivalWave++;game.wave=game.survivalWave;game.stage=Math.floor((game.survivalWave-1)/5)%LEVELS.length;game.survivalScale=1+(game.survivalWave-1)*.095;game.survivalDamageScale=1+(game.survivalWave-1)*.035;game.survivalInProgress=true;game.survivalBoss=game.survivalWave%5===0;game.survivalNextIn=0;game.spawned=[];const n=Math.min(10,3+Math.floor(game.survivalWave*.72));const pool=game.survivalWave<3?['trooper','trooper','drone','heavy']:['trooper','heavy','drone','turret'];const base=game.player.x+620;for(let i=0;i<n;i++){const type=pool[Math.floor(Math.random()*pool.length)];const scale=game.survivalScale;spawnEnemy(type,base+i*86,{hpScale:scale,damageScale:game.survivalDamageScale,survivalElite:game.survivalWave>=4&&i===n-1});}
 if(game.survivalBoss){spawnBoss();const bossScale=1+Math.floor(game.survivalWave/5)*.42;game.boss.hp*=bossScale;game.boss.maxHp*=bossScale;game.boss.x=game.world+W-320;}
 stageBanner=2.1;updateHud(true);}
function survivalUpdate(dt){if(game.survivalInProgress){const alive=game.enemies.some(e=>e.alive)||(game.boss&&game.boss.alive);if(!alive){game.survivalInProgress=false;game.enemies=[];game.enemyBullets=[];game.bullets=[];game.grenades=[];const reward=130+game.survivalWave*28+(game.survivalBoss?420:0);career.credits+=reward;game.sessionCredits+=reward;game.score+=reward*2;career.bestWave=Math.max(career.bestWave,game.survivalWave);career.bestScore=Math.max(career.bestScore,game.score);saveCareer();if(game.mode==='daily'&&game.survivalWave>=8&&!career.dailyClaimed){refreshDaily();career.dailyClaimed=true;career.credits+=1200;game.sessionCredits+=1200;saveCareer();stageBanner=4.2;dailyToastUntil=performance.now()+4500;}
 game.survivalNextIn=game.survivalBoss?4.5:2.7;updateHud(true);}}
 else if(game.survivalNextIn>0){game.survivalNextIn=Math.max(0,game.survivalNextIn-dt);if(game.survivalNextIn===0)queueSurvivalWave();}
}
function showStageClear(){if(!game||gameState!=='playing')return;gameState='stageclear';const rank=game.player.health>110?'S':game.player.health>70?'A':game.player.health>35?'B':'C';$('stage-result-kicker').textContent=game.stage===3?'OPERATION BLACK SUN · COMPLETE':'SECTOR CLEARED';$('stage-result-title').textContent=game.stage===3?'BLACK SUN DESTROYED':`${level().name} SECURED`;$('result-score').textContent=game.score.toLocaleString('en-IN');$('result-kills').textContent=game.kills;$('result-rank').textContent=rank;$('next-stage-btn').innerHTML=game.stage===3?'RETURN TO COMMAND':'NEXT OPERATION <span>▶</span>';setScreen('stage-screen');}
function advanceStage(){if(game.stage===3){$('final-score').textContent=`FINAL SCORE · ${String(game.score).padStart(6,'0')}`;best=Math.max(best,game.score);career.bestScore=Math.max(career.bestScore,game.score);career.credits+=900;game.sessionCredits+=900;saveCareer();gameState='victory';setScreen('victory-screen');return;}gameState='playing';setScreen(null);loadStage(game.stage+1,true);last=performance.now();}
function levelComplete(){game.bossDead=true;game.boss=null;screenFlash=0.6;shake=18;for(let i=0;i<7;i++)explode(game.world+W*.76,GROUND-80,level().accent,1.2);}
function firePlayer(){const p=game.player;if(p.fireCd>0||p.hitStop>0)return;const weapon=p.weapon;if(weapon!==0&&p.ammo[weapon]<=0){p.weapon=0;sound('hit');updateHud();return;}p.fireCd=[.105,.47,.62][weapon];p.shotAnim=.12;p.comboTimer=2.8;p.combo=Math.min(99,p.combo+1);let a=p.aimAngle;if(!input.pointer.inside){a=p.facing*Math.PI*(p.aimY<-.2?-.16:p.aimY>.2?.16:0);}const spread=weapon===1?0.28:weapon===0?0.025:0.05;const n=weapon===1?6:1;for(let i=0;i<n;i++){const ang=a+rand(-spread,spread);const sp=weapon===0?1060:weapon===1?810:780;const vx=Math.cos(ang)*sp,vy=Math.sin(ang)*sp;game.bullets.push({x:p.x+p.facing*76,y:p.y-118,vx,vy,r:weapon===1?5:weapon===2?8:3.4,dmg:(weapon===0?29:weapon===1?24:140)*(p.damageMult||1),life:weapon===2?1.7:1.25,type:weapon,color:weapon===2?'#8ce6ef':weapon===1?'#ffd39a':'#ffe2a0',pierce:weapon===2?1:0});}
 if(weapon!==0)p.ammo[weapon]--;for(let i=0;i<(weapon===1?2:1);i++)game.shells.push({x:p.x-p.facing*13,y:p.y-60,vx:rand(-130,130)-p.facing*60,vy:rand(-220,-80),life:1.2});for(let i=0;i<6;i++)particle(p.x+p.facing*42,p.y-78,level().accent,rand(50,250),rand(-90,90),.12,.24);sound(weapon===2?'laser':weapon===1?'heavy':'shot');updateHud();}
function throwGrenade(){const p=game.player;if(p.grenadeCd>0||p.grenades<=0)return;p.grenadeCd=.65;p.grenades--;game.grenades.push({x:p.x+p.facing*36,y:p.y-65,vx:p.facing*590,vy:-720,life:2.2,fuse:.8,r:9});sound('heavy');updateHud();}
function overdrive(){const p=game.player;if(p.pulse<100||p.pulseCd>0)return;p.pulse=0;p.pulseCd=7;screenFlash=.25;shake=12;for(const e of game.enemies){if(!e.alive||Math.abs(e.x-p.x)>520)continue;damageEnemy(e,110*(p.damageMult||1),p.x);e.stun=1.2;}if(game.boss&&game.boss.alive&&Math.abs(game.boss.x-p.x)<700){damageBoss(210*(p.damageMult||1));game.boss.stun=1;}for(let i=0;i<80;i++)particle(p.x+rand(-450,450),p.y-60+rand(-150,80),i%2?'#b9f2f4':level().accent,rand(-380,380),rand(-360,160),rand(.3,.8),rand(2,5));sound('pulse');}
function dash(){const p=game.player;if(p.dashCd>0)return;const down=input.keys.has('KeyS')||input.keys.has('ArrowDown')||input.touch.has('ArrowDown');if(!p.grounded&&!down&&p.airDashUsed)return;p.dashCd=.88;if(p.grounded&&down){p.slideTime=.42;p.vx=p.facing*690*(p.moveMult||1);p.invuln=Math.max(p.invuln,.28);for(let i=0;i<14;i++)particle(p.x-p.facing*rand(0,80),p.y-8,level().accent,rand(-150,150),rand(-70,-10),.28,rand(3,8));}else{p.dashTime=.24;p.vx=p.facing*880*(p.moveMult||1);if(!p.grounded)p.airDashUsed=true;p.invuln=Math.max(p.invuln,.34);for(let i=0;i<16;i++)particle(p.x-p.facing*rand(0,90),p.y-55, '#b9dfe2',rand(-130,130),rand(-80,80),.25,rand(3,8));}sound('dash');}
function doJump(){const p=game.player;if(p.grounded){p.vy=-740;p.grounded=false;p.jumpCount=1;p.airDashUsed=false;sound('dash');}else if(p.jumpCount<2){p.vy=-640;p.jumpCount++;for(let i=0;i<8;i++)particle(p.x,p.y,level().accent,rand(-150,150),rand(40,190),.2,rand(3,6));}}
function melee(){const p=game.player;if(p.meleeCd>0)return;p.meleeCd=.58;p.meleeTime=.24;let target=null,best=145;for(const e of game.enemies){if(!e.alive)continue;const dx=e.x-p.x,dy=(e.y-e.h*.5)-(p.y-70);if(Math.abs(dy)>125||dx*p.facing< -18)continue;const d=Math.abs(dx);if(d<best){best=d;target=e;}}if(target){damageEnemy(target,118*(p.damageMult||1),p.x);target.stun=Math.max(target.stun,.58);target.vx=p.facing*410;}if(game.boss&&game.boss.alive&&Math.abs(game.boss.x-p.x)<170&&Math.abs(game.boss.y-p.y)<160)damageBoss(95*(p.damageMult||1));for(let i=0;i<11;i++)particle(p.x+p.facing*62,p.y-85,level().accent,rand(70,330)*p.facing,rand(-190,80),.22,rand(3,7));shake=Math.max(shake,target?4:1);sound('heavy');}
function particle(x,y,color,vx,vy,life,r){game.particles.push({x,y,vx,vy,life,max:life,r,color,drag:.96});}
function explode(x,y,color='#ffb45e',scale=1){game.explosions.push({x,y,t:0,max:.55,scale,color});for(let i=0;i<30*scale;i++)particle(x,y,Math.random()<.4?'#ffe2a2':color,rand(-490,490)*scale,rand(-500,260)*scale,rand(.3,.8),rand(2,10)*scale);shake=Math.max(shake,10*scale);sound('boom');}
function damageEnemy(e,dmg,fromX){if(!e.alive)return;let actual=dmg*(game.player.damageMult||1)*(e.shield||1);e.hp-=actual;e.flash=.15;e.hitReact=.24;e.hitDirection=Math.sign(e.x-fromX)||1;e.stun=Math.max(e.stun,.12);e.vx=Math.sign(e.x-fromX)*170;for(let i=0;i<5;i++)particle(e.x,e.y-e.h*.55,'#f6d18b',rand(-130,130),rand(-170,70),.22,rand(2,4));if(e.hp<=0){e.alive=false;e.deathTime=0;e.deathDirection=e.hitDirection||1;game.kills++;game.score+=e.type==='heavy'?280:e.type==='turret'?230:e.type==='drone'?180:140;game.player.xp+=e.type==='heavy'?22:12;const creditDrop=e.type==='heavy'?42:e.type==='turret'?34:e.type==='drone'?26:22;career.credits+=creditDrop;game.sessionCredits+=creditDrop;career.lifetimeKills++;saveCareer();game.player.pulse=Math.min(100,game.player.pulse+8);if(game.player.xp>=100){game.player.xp-=100;game.player.rank=Math.min(10,game.player.rank+1);game.player.maxHealth+=10;game.player.health=Math.min(game.player.maxHealth,game.player.health+30);}explode(e.x,e.y-e.h*.4,e.type==='drone'?'#9be9e5':'#ffb46d',e.type==='heavy'?1.1:.72);if(Math.random()<.19)game.pickups.push({x:e.x,y:GROUND-40,type:Math.random()<.55?'ammo':'health',life:12});updateHud();}}
function damageBoss(dmg){const b=game.boss;if(!b||!b.alive)return;b.hp-=dmg;b.flash=.16;b.hitReact=.2;b.recoil=.12;for(let i=0;i<8;i++)particle(b.x+rand(-b.w*.35,b.w*.35),b.y-b.h*.5+rand(-55,55),level().accent,rand(-180,180),rand(-200,120),.28,rand(3,7));if(b.hp<=0){b.alive=false;game.score+=2500;game.kills++;game.player.xp+=100;career.credits+=240;game.sessionCredits+=240;career.lifetimeKills++;saveCareer();explode(b.x,b.y-b.h*.4,'#ffe6a0',3);for(let i=0;i<4;i++)setTimeout(()=>explode(b.x+rand(-100,100),b.y-rand(30,b.h*.6),level().accent,1.5),i*110);levelComplete();updateHud();}}
function hurtPlayer(dmg,knock=1){const p=game.player;if(p.invuln>0||gameState!=='playing')return;p.health=Math.max(0,p.health-dmg);p.invuln=1.0;p.flash=.25;p.hurtTime=.34;p.hitDirection=-p.facing;p.vx-=p.facing*220*knock;p.vy=-220;shake=8;screenFlash=.12;sound('hit');updateHud();if(p.health<=0){career.bestScore=Math.max(career.bestScore,game.score);if(game.mode==='survival'||game.mode==='daily')career.bestWave=Math.max(career.bestWave,game.survivalWave);saveCareer();const summary=$('run-summary');if(summary)summary.textContent=`SCORE ${game.score.toLocaleString('en-IN')} · KILLS ${game.kills} · EARNED ${game.sessionCredits.toLocaleString('en-IN')} CR`;gameState='gameover';setTimeout(()=>{if(gameState==='gameover')setScreen('gameover-screen');},600);}}
function updatePlayer(dt){const p=game.player;const left=input.keys.has('KeyA')||input.keys.has('ArrowLeft')||input.touch.has('ArrowLeft');const right=input.keys.has('KeyD')||input.keys.has('ArrowRight')||input.touch.has('ArrowRight');const up=input.keys.has('KeyW')||input.keys.has('ArrowUp');const down=input.keys.has('KeyS')||input.keys.has('ArrowDown')||input.touch.has('ArrowDown');p.crouch=down&&p.grounded;p.aimY=up?-1:down?1:0;if(input.pointer.inside){const dx=input.pointer.x-(p.x-game.world),dy=input.pointer.y-(p.y-80);if(Math.abs(dx)>10){p.facing=dx>0?1:-1;p.aimAngle=Math.atan2(dy,dx);}}else{if(left)p.facing=-1;if(right)p.facing=1;p.aimAngle=Math.atan2(p.aimY*0.45,p.facing);}
 p.slideTime=Math.max(0,p.slideTime-dt);p.dashTime=Math.max(0,p.dashTime-dt);const move=(right?1:0)-(left?1:0);if(p.slideTime>0){p.vx=p.facing*690*(p.moveMult||1);}else if(p.dashTime>0){p.vx=p.facing*880*(p.moveMult||1);}else if(move){p.vx=move*360*(p.moveMult||1);p.facing=move;}else{p.vx*=Math.pow(.0004,dt);if(Math.abs(p.vx)<5)p.vx=0;}p.x+=p.vx*dt;p.x=clamp(p.x,55,level().length+130);if(!p.grounded){p.vy+=GRAVITY*dt;p.y+=p.vy*dt;if(p.y>=GROUND){p.y=GROUND;p.vy=0;p.grounded=true;p.jumpCount=0;p.airDashUsed=false;for(let i=0;i<7;i++)particle(p.x,p.y-4,'#b4b49a',rand(-80,80),rand(-150,-30),.2,rand(2,4));}}p.run+=Math.abs(p.vx)*dt*.018;p.fireCd=Math.max(0,p.fireCd-dt);p.grenadeCd=Math.max(0,p.grenadeCd-dt);p.pulseCd=Math.max(0,p.pulseCd-dt);p.dashCd=Math.max(0,p.dashCd-dt);p.meleeCd=Math.max(0,p.meleeCd-dt);p.meleeTime=Math.max(0,p.meleeTime-dt);p.ghostTimer=Math.max(0,p.ghostTimer-dt);for(let i=p.ghosts.length-1;i>=0;i--){p.ghosts[i].life-=dt;if(p.ghosts[i].life<=0)p.ghosts.splice(i,1);}if(p.dashTime>0&&p.ghostTimer<=0){p.ghostTimer=.045;p.ghosts.push({x:p.x,y:p.y,facing:p.facing,life:.18});}p.invuln=Math.max(0,p.invuln-dt);p.flash=Math.max(0,p.flash-dt);p.hurtTime=Math.max(0,(p.hurtTime||0)-dt);p.shotAnim=Math.max(0,p.shotAnim-dt);p.comboTimer=Math.max(0,p.comboTimer-dt);if(p.comboTimer===0)p.combo=0;p.pulse=Math.min(100,p.pulse+dt*1.55);if(input.keys.has('KeyJ')||input.pointer.down||input.touch.has('KeyJ'))firePlayer();if(input.keys.has('KeyK'))throwGrenade();if(input.keys.has('KeyL'))overdrive();if(input.touch.has('KeyE'))melee();}
function enemyShoot(e,angle){e.aimAngle=angle;e.recoil=.16;const speed=e.type==='heavy'?520:e.type==='turret'?660:e.type==='drone'?440:510;game.enemyBullets.push({x:e.x+(angle>0?e.w*.3:-e.w*.3),y:e.y-e.h*.55,vx:Math.cos(angle)*speed,vy:Math.sin(angle)*speed,r:e.type==='heavy'?7:5,dmg:e.damage,life:2.5,color:e.type==='drone'?'#a8def0':'#ff9b70'});e.muzzleFlash=.11;sound('shot');}
function updateEnemies(dt){const p=game.player;for(let ei=game.enemies.length-1;ei>=0;ei--){const e=game.enemies[ei];if(!e.alive){if(e.deathTime!==null&&e.deathTime!==undefined){e.deathTime+=dt;if(e.deathTime>1.35)game.enemies.splice(ei,1);}continue;}e.walk+=dt*(e.speed>0?e.speed*.02:1.5);e.flash=Math.max(0,e.flash-dt);e.muzzleFlash=Math.max(0,(e.muzzleFlash||0)-dt);e.recoil=Math.max(0,(e.recoil||0)-dt);e.hitReact=Math.max(0,(e.hitReact||0)-dt);e.aimAngle=Math.atan2((p.y-78)-(e.y-e.h*.55),p.x-e.x);e.fireCd-=dt;e.stun=Math.max(0,e.stun-dt);if(e.type==='drone'){e.y=GROUND-230+Math.sin(game.time*2.4+e.id*8)*28;e.dir=p.x>e.x?1:-1;if(e.stun===0){const dx=p.x-e.x;if(Math.abs(dx)>e.range*.7)e.x+=Math.sign(dx)*e.speed*dt*.45;}}
 else if(e.type!=='turret'&&e.stun===0){const dx=p.x-e.x;e.dir=Math.sign(dx)||-1;const range=Math.abs(dx);if(range>e.range*.8)e.x+=e.dir*e.speed*dt;else e.x+=e.vx*dt*.2;}
 e.vx*=Math.pow(.07,dt);const dx=p.x-e.x,dy=(p.y-75)-(e.y-e.h*.5),d=Math.hypot(dx,dy);if(e.fireCd<=0&&d<e.range&&Math.abs(dx)>130&&e.stun<=0){e.windup=.38+(e.type==='heavy'?.25:0);e.attack=1.1;e.fireCd=e.type==='drone'?1.7:e.type==='heavy'?2.3:e.type==='turret'?1.65:1.8;}
 if(e.windup>0){e.windup-=dt;if(e.windup<=0&&d<e.range+80){const angle=Math.atan2(dy,dx);enemyShoot(e,angle);if(e.type==='heavy'){enemyShoot(e,angle-.12);enemyShoot(e,angle+.12);}}} }
 if(game.boss&&game.boss.alive)updateBoss(dt);
}
function updateBoss(dt){const b=game.boss,p=game.player;if(!b||!b.alive)return;b.flash=Math.max(0,b.flash-dt);b.hitReact=Math.max(0,(b.hitReact||0)-dt);b.recoil=Math.max(0,(b.recoil||0)-dt);b.stun=Math.max(0,b.stun-dt);b.walk+=dt*2.2;b.fireCd-=dt;if(!b.entered){b.entered=true;b.x=Math.max(b.x,game.world+W-340);stageBanner=2.5;}if(b.stun>0)return;const target=game.world+W-260;const dx=p.x-b.x;b.x+=clamp(target-b.x,-45,45)*dt*.55;
 if(b.fireCd<=0){b.fireCd=b.type==='engine'?1.45:b.type==='behemoth'?1.8:1.6;b.windup=b.type==='engine'?.72:.55;b.attack++;}
 if(b.windup>0){b.windup-=dt;if(b.windup<=0){const angle=Math.atan2((p.y-70)-(b.y-b.h*.6),p.x-b.x);if(b.type==='warden'){for(let i=-1;i<=1;i++)enemyShoot({x:b.x,y:b.y,w:b.w,h:b.h,type:'heavy',damage:16},angle+i*.18);}else if(b.type==='walker'){for(let i=0;i<5;i++)enemyShoot({x:b.x+rand(-60,60),y:b.y,w:b.w,h:b.h,type:'turret',damage:18},angle+rand(-.34,.34));}else if(b.type==='behemoth'){for(let i=0;i<7;i++)enemyShoot({x:b.x,y:b.y,w:b.w,h:b.h,type:'heavy',damage:18},angle+(i-3)*.17);}else{for(let i=0;i<9;i++)enemyShoot({x:b.x,y:b.y,w:b.w,h:b.h,type:'drone',damage:21},angle+(i-4)*.12);}if(b.type==='walker'||b.type==='behemoth'){const impactX=p.x+rand(-100,100);game.explosions.push({x:impactX,y:GROUND-5,t:0,max:.5,scale:1.3,color:level().accent});if(Math.abs(impactX-p.x)<95)hurtPlayer(23,.7);}}}
 if(Math.random()<dt*2.2&&b.type==='engine')particle(b.x+rand(-b.w*.4,b.w*.4),b.y-b.h*.5+rand(-40,50),level().accent,rand(-45,45),rand(-90,30),.45,rand(3,8));}
function updateProjectiles(dt){const p=game.player;
 for(let i=game.bullets.length-1;i>=0;i--){const b=game.bullets[i];b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;let hit=false;for(const e of game.enemies){if(!e.alive)continue;if(Math.abs(b.x-e.x)<e.w*.48+b.r&&Math.abs(b.y-(e.y-e.h*.55))<e.h*.52+b.r){damageEnemy(e,b.dmg,p.x);hit=true;if(b.pierce>0)b.pierce--;else break;}}if(!hit&&game.boss&&game.boss.alive){const boss=game.boss;if(Math.abs(b.x-boss.x)<boss.w*.46+b.r&&Math.abs(b.y-(boss.y-boss.h*.54))<boss.h*.43+b.r){damageBoss(b.dmg);hit=true;}}
 if(!hit){for(const c of game.crates){if(!c.alive)continue;if(b.x>c.x&&b.x<c.x+c.w&&b.y>c.y&&b.y<c.y+c.h){c.hp-=b.dmg;c.flash=.12;hit=true;if(c.hp<=0){c.alive=false;game.score+=60;game.pickups.push({x:c.x+c.w/2,y:c.y-5,type:c.drop,life:18});explode(c.x+c.w/2,c.y,'#d9b77a',.55);}break;}}}
 if(hit&&b.pierce<=0||b.life<=0||b.x<game.world-200||b.x>game.world+W+300){if(hit)for(let q=0;q<3;q++)particle(b.x,b.y,b.color,rand(-60,60),rand(-70,70),.1,2);game.bullets.splice(i,1);}}
 for(let i=game.enemyBullets.length-1;i>=0;i--){const b=game.enemyBullets[i];b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;if(Math.abs(b.x-p.x)<p.w*.43+b.r&&Math.abs(b.y-(p.y-68))<52+b.r){hurtPlayer(b.dmg,1);game.enemyBullets.splice(i,1);continue;}if(b.life<=0||b.x<game.world-100||b.x>game.world+W+200||b.y>GROUND+30){game.enemyBullets.splice(i,1);}}
 for(let i=game.grenades.length-1;i>=0;i--){const g=game.grenades[i];g.vy+=GRAVITY*.72*dt;g.x+=g.vx*dt;g.y+=g.vy*dt;g.vx*=Math.pow(.5,dt);g.fuse-=dt;g.life-=dt;if(g.y>=GROUND-10){g.y=GROUND-10;g.vy*=-.42;g.vx*=.72;}if(g.fuse<=0||g.life<=0){for(const e of game.enemies)if(e.alive&&Math.hypot(e.x-g.x,e.y-e.h*.5-g.y)<260)damageEnemy(e,240*(p.damageMult||1),g.x);if(game.boss&&game.boss.alive&&Math.hypot(game.boss.x-g.x,game.boss.y-game.boss.h*.5-g.y)<300)damageBoss(300*(p.damageMult||1));explode(g.x,g.y,'#ffb76a',1.5);game.grenades.splice(i,1);}}
}
function updatePickups(dt){const p=game.player;for(let i=game.pickups.length-1;i>=0;i--){const it=game.pickups[i];it.life-=dt;if(Math.abs(it.x-p.x)<55&&Math.abs((it.y-20)-(p.y-55))<70){if(it.type==='health')p.health=Math.min(p.maxHealth,p.health+38);else{p.ammo[1]=Math.min(120,p.ammo[1]+32);p.ammo[2]=Math.min(36,p.ammo[2]+8);p.grenades=Math.min(7,p.grenades+1);}sound('pickup');game.pickups.splice(i,1);updateHud();continue;}if(it.life<=0)game.pickups.splice(i,1);}}
function updateEffects(dt){for(const a of [game.particles,game.shells])for(let i=a.length-1;i>=0;i--){const p=a[i];p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;if(p.vy!==undefined)p.vy+=GRAVITY*.34*dt;if(p.drag)p.vx*=Math.pow(p.drag,dt*60);if(p.life<=0)a.splice(i,1);}for(let i=game.explosions.length-1;i>=0;i--){game.explosions[i].t+=dt;if(game.explosions[i].t>=game.explosions[i].max)game.explosions.splice(i,1);}shake=Math.max(0,shake-dt*24);screenFlash=Math.max(0,screenFlash-dt);stageBanner=Math.max(0,stageBanner-dt);}
function update(dt){if(gameState!=='playing'||!game)return;dt=Math.min(.033,dt);game.time+=dt;game.elapsed+=dt;updatePlayer(dt);stageUpdate(dt);updateEnemies(dt);updateProjectiles(dt);updatePickups(dt);updateEffects(dt);game.world=clamp(game.player.x-470,0,Math.max(0,level().length-W+240));if(Math.floor(game.elapsed*4)!==Math.floor((game.elapsed-dt)*4))updateHud();}
function rounded(x,y,w,h,r,color){ctx.fillStyle=color;ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill();}
function polygon(points,color){ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(points[0][0],points[0][1]);for(let i=1;i<points.length;i++)ctx.lineTo(points[i][0],points[i][1]);ctx.closePath();ctx.fill();}
function drawSky(cam,l,t){const theme=l.theme;const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,l.sky[0]);g.addColorStop(.58,l.sky[1]);g.addColorStop(1,l.sky[2]);ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 const sunX=W*.72-(cam*.08%1800);const sunY=theme==='frost'?165:theme==='alien'?185:theme==='foundry'?220:190;const sun=ctx.createRadialGradient(sunX,sunY,4,sunX,sunY,theme==='alien'?190:160);sun.addColorStop(0,theme==='frost'?'#e2f7f2aa':theme==='alien'?'#f48a8c77':'#ffdfa177');sun.addColorStop(1,'transparent');ctx.fillStyle=sun;ctx.fillRect(sunX-200,sunY-200,400,400);ctx.fillStyle=theme==='frost'?'#d8f0f0bb':theme==='alien'?'#df8a98aa':'#ffd9a0aa';ctx.beginPath();ctx.arc(sunX,sunY,theme==='alien'?56:42,0,Math.PI*2);ctx.fill();
 for(let i=0;i<6;i++){const x=((i*360-cam*.15)%2100+2100)%2100-250;const y=120+(i%3)*62;ctx.fillStyle=theme==='frost'?'#d9edf022':'#d9e1d022';ctx.beginPath();ctx.ellipse(x,y,95+(i%2)*28,17,0,0,Math.PI*2);ctx.fill();}
 // distant mountain silhouettes
 for(let layer=0;layer<3;layer++){const par=.12+layer*.13,base=theme==='jungle'?470+layer*75:theme==='foundry'?500+layer*70:theme==='frost'?470+layer*85:490+layer*70;const shift=(cam*par)%(W+420);ctx.fillStyle=theme==='jungle'?['#294b49','#31524a','#526753'][layer]:theme==='foundry'?['#34383a','#48413e','#665146'][layer]:theme==='frost'?['#436277','#55788c','#78939a'][layer]:['#2e2440','#4a3150','#66374f'][layer];ctx.beginPath();ctx.moveTo(-420,base);for(let x=-450;x<W+500;x+=100){const xx=x-shift;const peak=base-randDet(x+layer*117,95+layer*20);ctx.lineTo(xx,peak);ctx.lineTo(xx+50,base+15);}ctx.lineTo(W+500,H);ctx.lineTo(-500,H);ctx.closePath();ctx.fill();}
 if(theme==='jungle')drawJungleDistant(cam);if(theme==='foundry')drawFactoryDistant(cam);if(theme==='frost')drawFrostDistant(cam);if(theme==='alien')drawAlienDistant(cam);
}
function randDet(n,s){const v=Math.sin(n*12.9898+s*78.233)*43758.5453;return (v-Math.floor(v))*(60+s*.24);}
function drawJungleDistant(cam){for(let i=0;i<13;i++){const x=((i*180-cam*.28)%(W+300)+W+300)%(W+300)-80;const y=500+(i%4)*22;ctx.fillStyle=i%2?'#223e37':'#2e5142';ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+55,y-170-(i%3)*25);ctx.lineTo(x+112,y);ctx.closePath();ctx.fill();ctx.fillStyle='#496f52';ctx.fillRect(x+50,y-24,10,80);}}
function drawFactoryDistant(cam){for(let i=0;i<8;i++){const x=((i*245-cam*.3)%(W+450)+W+450)%(W+450)-120;const h=145+(i*57)%180;ctx.fillStyle=i%2?'#252e33':'#343638';ctx.fillRect(x,530-h,120,h);ctx.fillStyle='#e3a26766';for(let y=550-h;y<525;y+=34)ctx.fillRect(x+15,y,8,4);ctx.fillStyle='#59636a';ctx.fillRect(x+80,530-h-90,12,90);}}
function drawFrostDistant(cam){for(let i=0;i<10;i++){const x=((i*200-cam*.28)%(W+300)+W+300)%(W+300)-80;const y=560+(i%3)*25;polygon([[x,y],[x+70,y-195-(i%2)*55],[x+130,y]],i%2?'#a9ced2':'#7296a7');polygon([[x+70,y-195-(i%2)*55],[x+58,y-105],[x+86,y-92]],'#edf7f2aa');}}
function drawAlienDistant(cam){for(let i=0;i<9;i++){const x=((i*220-cam*.3)%(W+360)+W+360)%(W+360)-100;const h=170+(i*37)%210;ctx.fillStyle=i%2?'#291e39':'#3c2544';polygon([[x,555],[x+18,555-h],[x+92,555-h-45],[x+143,555-h+10],[x+155,555]],ctx.fillStyle);ctx.fillStyle='#ef799a55';ctx.fillRect(x+37,555-h+35,5,h-70);}}
function drawJungleProps(cam){for(let i=0;i<20;i++){const x=((i*260-cam*.46)%(W+300)+W+300)%(W+300)-130;const h=150+(i*61)%230;ctx.fillStyle=i%2?'#152e27':'#1e3d30';ctx.fillRect(x,GROUND-h+20,22,h);ctx.fillStyle=i%2?'#42664a':'#315942';for(let j=0;j<3;j++){ctx.beginPath();ctx.moveTo(x-52+j*7,GROUND-h+50-j*36);ctx.lineTo(x+11,GROUND-h-90-j*30);ctx.lineTo(x+75-j*7,GROUND-h+50-j*36);ctx.closePath();ctx.fill();}if(i%4===0){ctx.strokeStyle='#a3a46b';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x+23,GROUND-h+20);ctx.bezierCurveTo(x-20,GROUND-h+75,x+50,GROUND-h+100,x+16,GROUND-h+150);ctx.stroke();}}}
function drawFactoryProps(cam){for(let i=0;i<12;i++){const x=((i*340-cam*.5)%(W+500)+W+500)%(W+500)-150;const h=220+(i*49)%230;ctx.fillStyle='#252c31';ctx.fillRect(x,GROUND-h,150,h);ctx.fillStyle='#424e52';ctx.fillRect(x+12,GROUND-h+15,126,13);ctx.fillStyle='#e49b57';for(let j=0;j<4;j++){ctx.fillStyle=j%2?'#e19b5b':'#ffce88';ctx.fillRect(x+22+j*28,GROUND-h+55,12,14);ctx.fillStyle='#343c40';}ctx.fillStyle='#5f6562';ctx.fillRect(x-15,GROUND-h-12,180,14);ctx.fillStyle='#b66f44';ctx.fillRect(x+116,GROUND-h-70,8,70);}}
function drawFrostProps(cam){for(let i=0;i<14;i++){const x=((i*300-cam*.48)%(W+400)+W+400)%(W+400)-100;polygon([[x,GROUND],[x+15,GROUND-190],[x+75,GROUND-240],[x+120,GROUND]],i%2?'#688b9a':'#547688');polygon([[x+75,GROUND-240],[x+60,GROUND-135],[x+89,GROUND-116]],'#c7e8e7');}}
function drawAlienProps(cam){for(let i=0;i<12;i++){const x=((i*330-cam*.48)%(W+440)+W+440)%(W+440)-100;const h=220+(i*33)%180;ctx.fillStyle='#21182d';polygon([[x,GROUND],[x+10,GROUND-h],[x+50,GROUND-h-30],[x+116,GROUND-h],[x+135,GROUND]],'#251a31');ctx.fillStyle='#8d3e67';ctx.fillRect(x+28,GROUND-h+30,5,h-80);ctx.fillStyle='#ff9f9477';ctx.fillRect(x+70,GROUND-h+65,12,6);}}
function jungleLeaf(x,y,len,width,angle,color,vein=true){
 ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(-len*.5,0);ctx.bezierCurveTo(-len*.26,-width*.8,len*.19,-width*.82,len*.5,0);ctx.bezierCurveTo(len*.18,width*.75,-len*.25,width*.72,-len*.5,0);ctx.closePath();ctx.fill();
 if(vein){ctx.strokeStyle='rgba(190,205,132,.24)';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(-len*.39,0);ctx.quadraticCurveTo(0,-1,len*.43,0);ctx.stroke();}ctx.restore();
}
function drawJungleUnderstory(cam){
 // Continue the shallow cinematic panorama down to the playable lane with layered forest depth.
 const top=330,g=ctx.createLinearGradient(0,top,0,GROUND);g.addColorStop(0,'rgba(57,91,68,.02)');g.addColorStop(.18,'rgba(44,82,58,.34)');g.addColorStop(.56,'rgba(26,62,44,.72)');g.addColorStop(1,'rgba(10,31,24,.94)');ctx.fillStyle=g;ctx.fillRect(0,top,W,GROUND-top);
 // Warm sun shafts fade naturally into the middle distance.
 for(let i=0;i<6;i++){const x=((i*330-cam*.12)%(W+500)+W+500)%(W+500)-180;const glow=ctx.createRadialGradient(x,top+35,4,x,top+100,210);glow.addColorStop(0,'rgba(222,190,119,.12)');glow.addColorStop(1,'rgba(222,190,119,0)');ctx.fillStyle=glow;ctx.fillRect(x-220,top-80,440,410);}
 // Far trunks and separated leaf blades create an organic tree line without a hard flat color band.
 for(let i=0;i<13;i++){const x=((i*171-cam*.22)%(W+260)+W+260)%(W+260)-120,h=180+(i*47)%210,crownY=top+35+(i%4)*44,tw=10+(i%4)*5;const trunk=ctx.createLinearGradient(x,0,x+tw,0);trunk.addColorStop(0,'#142e25');trunk.addColorStop(.5,'#456044');trunk.addColorStop(1,'#182f25');ctx.fillStyle=trunk;ctx.beginPath();ctx.moveTo(x,GROUND);ctx.lineTo(x+tw*.25,crownY+45);ctx.quadraticCurveTo(x+tw*.45,crownY-15,x+tw,crownY+20);ctx.lineTo(x+tw+8,GROUND);ctx.closePath();ctx.fill();for(let j=0;j<7;j++){const bx=x+tw*.5+(j-3)*18,by=crownY+(j%3)*22;jungleLeaf(bx,by,76+(j%3)*18,22+(j%2)*8,-.7+j*.22,j%2?'#254934':'#31583e',false);}}
 // Hanging vines and a soft ground haze connect the art to the combat plane.
 for(let i=0;i<12;i++){const x=((i*139-cam*.31)%(W+220)+W+220)%(W+220)-80,len=95+(i%5)*28;ctx.strokeStyle='rgba(20,55,37,.7)';ctx.lineWidth=2+(i%3);ctx.beginPath();ctx.moveTo(x,top-6);ctx.bezierCurveTo(x-24,top+len*.28,x+27,top+len*.58,x-5,top+len);ctx.stroke();for(let j=0;j<4;j++)jungleLeaf(x+(j%2?14:-12),top+20+j*len/4,31,10,j%2?.55:-.6,j%2?'#55784a':'#375d3d',false);}
 const mist=ctx.createLinearGradient(0,GROUND-125,0,GROUND+8);mist.addColorStop(0,'rgba(163,183,128,0)');mist.addColorStop(.72,'rgba(153,176,116,.10)');mist.addColorStop(1,'rgba(7,23,18,.22)');ctx.fillStyle=mist;ctx.fillRect(0,GROUND-130,W,140);
}
function drawJungleFoliage(cam){
 // Foreground palms: visible stems and pointed leaves rather than rounded bubble clusters.
 for(let i=0;i<9;i++){const span=W+620,raw=i*310-cam*.34,x=((raw%span)+span)%span-260,trunkW=18+(i%3)*7,top=345+(i%4)*43;const tg=ctx.createLinearGradient(x,0,x+trunkW,0);tg.addColorStop(0,'#101f1b');tg.addColorStop(.48,'#34493a');tg.addColorStop(1,'#182a24');ctx.fillStyle=tg;ctx.beginPath();ctx.moveTo(x+4,GROUND);ctx.lineTo(x+8,top+55);ctx.quadraticCurveTo(x+trunkW*.4,top,x+trunkW,top+46);ctx.lineTo(x+trunkW+9,GROUND);ctx.closePath();ctx.fill();ctx.strokeStyle='#8b9a5e44';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x+trunkW*.65,GROUND-30);ctx.bezierCurveTo(x+trunkW*.2,top+150,x+trunkW*1.3,top+90,x+trunkW*.65,top+25);ctx.stroke();for(let j=0;j<9;j++){const side=j%2?1:-1,spread=28+(j%4)*13,yy=top+35+Math.floor(j/2)*12;jungleLeaf(x+trunkW*.5+side*spread*.48,yy,80+(j%3)*20,20+(j%2)*7,side*(.24+(j%3)*.15),j%3===0?'#597b48':j%2?'#2e583d':'#3d6842');}}
 // Ferns along the ground edge use individual narrow leaflets.
 for(let i=0;i<15;i++){const x=((i*143-cam*.53)%(W+200)+W+200)%(W+200)-70,h=65+(i%4)*24;ctx.strokeStyle='#1a3829';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x,GROUND-4);ctx.quadraticCurveTo(x-18,GROUND-h*.55,x+Math.sin(i)*8,GROUND-h);ctx.stroke();for(let j=0;j<8;j++){const yy=GROUND-h+j*h/9,side=j%2?1:-1,len=16+(j%3)*7;jungleLeaf(x+side*len*.38,yy,len,7,side*.27,j%2?'#476b42':'#68824b',false);}}
}
function drawBackground(cam,l){
 if(l.theme==='jungle'){
  if(imageReady(art.jungle)){
   // Source asset is 1800x738: preserve its authored 2.44:1 composition at the exact combat-lane height.
   const tileW=art.jungle.naturalWidth,tileH=GROUND,period=tileW*2,off=(cam*.14)%period;
   for(let x=-off-period;x<W+period;x+=period){
    ctx.drawImage(art.jungle,x,0,tileW,tileH);
    ctx.save();ctx.translate(x+period,0);ctx.scale(-1,1);ctx.drawImage(art.jungle,0,0,tileW,tileH);ctx.restore();
   }
   const haze=ctx.createLinearGradient(0,GROUND*.40,0,GROUND);haze.addColorStop(0,'rgba(150,184,155,0)');haze.addColorStop(.62,'rgba(25,54,42,.07)');haze.addColorStop(1,'rgba(7,23,20,.30)');ctx.fillStyle=haze;ctx.fillRect(0,GROUND*.38,W,GROUND*.62);
  }else{
   // Never silently substitute the old polygon forest when the photographic asset is missing.
   const g=ctx.createLinearGradient(0,0,0,GROUND);g.addColorStop(0,'#172a30');g.addColorStop(1,'#263d35');ctx.fillStyle=g;ctx.fillRect(0,0,W,GROUND);
   ctx.fillStyle='#f2d39c';ctx.textAlign='center';ctx.font='800 26px Rajdhani';ctx.fillText('LOADING JUNGLE BATTLEFIELD…',W/2,H*.42);
  }
 }else{
  drawSky(cam,l);
  if(l.theme==='foundry')drawFactoryProps(cam);else if(l.theme==='frost')drawFrostProps(cam);else drawAlienProps(cam);
 }
 // restrained atmospheric particles; the jungle panorama itself supplies the full scene depth.
 for(let i=0;i<26;i++){const x=((i*137-cam*.38)%(W+100)+W+100)%(W+100)-30;const y=190+(i*79)%460;ctx.fillStyle=i%2?`${l.accent}28`:'#f8e5bd20';ctx.beginPath();ctx.arc(x,y,1.5+(i%3),0,Math.PI*2);ctx.fill();}
}
function drawGround(cam,l){const theme=l.theme;const g=ctx.createLinearGradient(0,GROUND-30,0,H);g.addColorStop(0,theme==='jungle'?'#495443':theme==='foundry'?'#36383a':theme==='frost'?'#829da1':'#392b3d');g.addColorStop(1,theme==='jungle'?'#1a2822':theme==='foundry'?'#171c20':theme==='frost'?'#344d5b':'#160f21');ctx.fillStyle=g;ctx.fillRect(0,GROUND,W,H-GROUND);
 ctx.fillStyle=theme==='jungle'?'#a1a06e':theme==='foundry'?'#8e7563':theme==='frost'?'#d5e5d9':'#a25e70';ctx.fillRect(0,GROUND,W,4);
 for(let i=0;i<50;i++){const x=((i*83-cam*.9)%(W+100)+W+100)%(W+100)-30;const y=GROUND+14+(i*31)%150;ctx.fillStyle=i%3? '#ffffff10':'#00000022';ctx.fillRect(x,y,18+(i%5)*7,2);}
 for(let i=0;i<10;i++){const x=((i*185-cam*.84)%(W+260)+W+260)%(W+260)-70;drawDebris(x,GROUND+4,l,i);}
 if(theme==='jungle'){
  // Layered stone shelf with bevels, cracks, moss and grass; no flat rectangle ground.
  const top=GROUND+16;
  const dirt=ctx.createLinearGradient(0,GROUND-2,0,GROUND+54);dirt.addColorStop(0,'#554b35');dirt.addColorStop(.26,'#34382c');dirt.addColorStop(1,'#18241f');ctx.fillStyle=dirt;ctx.fillRect(0,GROUND-3,W,65);
  for(let i=0;i<22;i++){
   const x=((i*91-cam*.88)%(W+170)+W+170)%(W+170)-65,w=58+(i%4)*17,h=24+(i%3)*19,y=top+(i%3)*17;
   const rock=ctx.createLinearGradient(x,y,x+w,y+h);rock.addColorStop(0,i%2?'#77765a':'#686a50');rock.addColorStop(.42,'#444a3c');rock.addColorStop(1,'#232d27');
   ctx.fillStyle=rock;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+w*.22,y-5);ctx.lineTo(x+w*.76,y+2);ctx.lineTo(x+w,y+h*.35);ctx.lineTo(x+w*.84,y+h);ctx.lineTo(x+w*.18,y+h*.92);ctx.lineTo(x-4,y+h*.47);ctx.closePath();ctx.fill();
   ctx.strokeStyle='#a0a07855';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x+8,y+5);ctx.lineTo(x+w*.38,y+8);ctx.lineTo(x+w*.53,y+h*.5);ctx.stroke();
   ctx.strokeStyle='#253d2a';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x+10,y+2);ctx.lineTo(x+24,y-5);ctx.moveTo(x+w*.65,y+3);ctx.lineTo(x+w*.82,y-3);ctx.stroke();
  }
  for(let i=0;i<170;i++){
   const x=((i*47-cam*.95)%(W+50)+W+50)%(W+50)-20, height=4+(i%5)*2;
   ctx.strokeStyle=i%3?'#718550':'#9ca36a';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x,GROUND+2);ctx.quadraticCurveTo(x-4,GROUND-height,x+((i%2)?5:-5),GROUND-height-3);ctx.stroke();
  }
 }
}
function drawDebris(x,y,l,i){if(l.theme==='jungle'){ctx.fillStyle=i%2?'#4b5542':'#5d6149';ctx.fillRect(x,y+randDet(i,35),55+(i%4)*15,12);ctx.fillStyle='#8a8965';ctx.fillRect(x+8,y+3,24,3);}else if(l.theme==='foundry'){ctx.fillStyle='#55585a';ctx.fillRect(x,y+7,65+(i%3)*18,12);ctx.fillStyle='#c1804f';ctx.fillRect(x+18,y+5,4,15);}else if(l.theme==='frost'){ctx.fillStyle='#a4c8ce';polygon([[x,y+15],[x+22,y],[x+70,y+15]],'#b9dce0');}else{ctx.fillStyle='#503249';polygon([[x,y+19],[x+25,y],[x+54,y+12],[x+72,y+19]],'#674057');}}
function drawCrates(cam){for(const c of game.crates){if(!c.alive)continue;c.flash=Math.max(0,c.flash-.016);const x=c.x-cam;if(x<-100||x>W+100)continue;ctx.save();
 const face=ctx.createLinearGradient(x,c.y,x+c.w,c.y+c.h);face.addColorStop(0,c.flash>0?'#cba66e':'#8b6947');face.addColorStop(.48,c.flash>0?'#9c8058':'#684d36');face.addColorStop(1,'#3a3027');
 ctx.shadowColor='#0009';ctx.shadowBlur=12;ctx.shadowOffsetY=7;rounded(x,c.y,c.w,c.h,5,face);ctx.shadowBlur=0;ctx.shadowOffsetY=0;
 ctx.strokeStyle='#bd9b6d';ctx.lineWidth=5;ctx.strokeRect(x+5,c.y+5,c.w-10,c.h-10);
 ctx.strokeStyle='#382f29';ctx.lineWidth=8;ctx.beginPath();ctx.moveTo(x+10,c.y+10);ctx.lineTo(x+c.w-10,c.y+c.h-10);ctx.moveTo(x+c.w-10,c.y+10);ctx.lineTo(x+10,c.y+c.h-10);ctx.stroke();
 ctx.strokeStyle='#a78c62';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x+10,c.y+10);ctx.lineTo(x+c.w-10,c.y+c.h-10);ctx.moveTo(x+c.w-10,c.y+10);ctx.lineTo(x+10,c.y+c.h-10);ctx.stroke();
 ctx.fillStyle='#303a3b';ctx.fillRect(x+8,c.y+7,8,c.h-14);ctx.fillRect(x+c.w-16,c.y+7,8,c.h-14);ctx.fillRect(x+7,c.y+7,c.w-14,7);ctx.fillRect(x+7,c.y+c.h-14,c.w-14,7);
 ctx.fillStyle='#d4b27a';for(const [rx,ry] of [[12,12],[c.w-12,12],[12,c.h-12],[c.w-12,c.h-12]]){ctx.beginPath();ctx.arc(x+rx,c.y+ry,3,0,Math.PI*2);ctx.fill();}
 ctx.fillStyle='#1f2929';ctx.font='bold 10px Rajdhani';ctx.textAlign='center';ctx.fillText(c.drop==='health'?'FIELD MED':'AMMO',x+c.w/2,c.y+c.h/2+4);ctx.restore();}}
function hmm(p){return p.slideTime>0?142:p.crouch?158:164;}
function drawBone(ax,ay,bx,by,width,fill,edge='#151d1e',shine=null){
 ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle=edge;ctx.lineWidth=width+5;ctx.beginPath();ctx.moveTo(ax,ay);ctx.lineTo(bx,by);ctx.stroke();
 ctx.strokeStyle=fill;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(ax,ay);ctx.lineTo(bx,by);ctx.stroke();
 if(shine){ctx.save();ctx.strokeStyle=shine;ctx.globalAlpha=.45;ctx.lineWidth=Math.max(2,width*.22);ctx.beginPath();ctx.moveTo(ax-width*.12,ay-width*.12);ctx.lineTo(bx-width*.12,by-width*.12);ctx.stroke();ctx.restore();}
}
function drawBoot(x,y,angle,palette){ctx.save();ctx.translate(x,y);ctx.rotate(angle);rounded(-5,-8,30,14,5,palette.bootEdge||'#182321');rounded(-3,-10,26,10,4,palette.boot||'#504b3b');ctx.fillStyle=palette.bootHi||'#a18d61';ctx.fillRect(1,-8,13,2);ctx.fillStyle='#121a19';ctx.fillRect(-4,3,31,3);ctx.restore();}
function drawWeaponRig(pivotX,pivotY,angle,weapon,recoil,flash,enemy=false){
 ctx.save();ctx.translate(pivotX-recoil*13,pivotY+recoil*3);ctx.rotate(angle);
 const plasma=weapon===2,shotgun=weapon===1;
 ctx.shadowColor=plasma?'#7bdce8':'#000b';ctx.shadowBlur=plasma?12:4;
 // stock and receiver
 rounded(-21,-7,25,12,3,enemy?'#282e30':'#343a32');
 rounded(0,-11,shotgun?49:57,17,3,plasma?'#263b47':enemy?'#313b3d':'#39433a');
 ctx.fillStyle=enemy?'#6d7770':'#87906a';ctx.fillRect(8,-9,27,3);ctx.fillStyle='#111a1e';ctx.fillRect(20,-2,12,4);
 // rail, sight and magazine
 ctx.fillStyle='#1b2529';ctx.fillRect(7,-15,41,4);ctx.fillRect(24,-20,8,5);
 polygon([[17,5],[34,5],[31,30],[22,30]],enemy?'#202a2b':'#242d29');ctx.fillStyle='#8a876c';ctx.fillRect(22,9,10,3);
 if(shotgun){ctx.fillStyle='#20292c';ctx.fillRect(42,-8,25,6);ctx.fillRect(43,0,26,5);ctx.fillStyle='#b0a184';ctx.fillRect(63,-8,7,5);}
 else{ctx.fillStyle=plasma?'#64cbd9':'#202a2d';ctx.fillRect(43,-7,31,7);ctx.fillStyle=plasma?'#a5f4ed':'#8a8e7a';ctx.fillRect(53,-5,13,2);ctx.fillStyle='#182126';ctx.fillRect(68,-9,9,11);}
 ctx.shadowBlur=0;
 if(plasma){ctx.globalCompositeOperation='lighter';ctx.fillStyle='#77dfe8';ctx.globalAlpha=.7;ctx.beginPath();ctx.arc(69,-3,5+Math.sin(performance.now()*.02)*1.4,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';}
 if(flash>0){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=Math.min(1,flash*11);const tip=shotgun?70:78;const glow=ctx.createRadialGradient(tip,0,1,tip,0,38);glow.addColorStop(0,'#fff');glow.addColorStop(.2,plasma?'#b6ffff':'#fff1bd');glow.addColorStop(.55,plasma?'#62e7f2':'#ffad54');glow.addColorStop(1,'#ff8a2b00');ctx.fillStyle=glow;ctx.beginPath();ctx.ellipse(tip,0,39,17,0,0,Math.PI*2);ctx.fill();for(let i=-1;i<=1;i++){ctx.strokeStyle=plasma?'#aafaff':'#ffe0a0';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(tip,0);ctx.lineTo(tip+24,-i*9);ctx.stroke();}ctx.restore();}
 ctx.restore();
}
function drawRiggedSoldier(actor,t,options={}){
 const player=!!options.player,heavy=!!options.heavy,scale=options.scale||1;
 const facing=(options.facing||1)<0?-1:1;
 const dead=options.deadProgress||0;
 const grounded=actor.grounded!==false;
 const moving=grounded&&Math.abs(actor.vx||0)>24;
 const phase=(actor.run!==undefined?actor.run:actor.walk||0)*(player?3.25:2.8);
 const gait=moving?Math.sin(phase):Math.sin(t*(player?1.65:1.35)+(actor.id||0)*8)*.055;
 const bounce=moving?Math.abs(Math.sin(phase))*3.8:Math.sin(t*2.1+(actor.id||0))*1.4;
 const slide=player&&(actor.slideTime||0)>.02;
 const crouch=player&&actor.crouch&&!slide;
 const airborne=!grounded;
 const jumpTuck=airborne?clamp(-(actor.vy||0)/820,0,1):0;
 const hurt=clamp((actor.hitReact||actor.hurtTime||0)/.25,0,1);
 const fire=player?clamp((actor.shotAnim||0)/.12,0,1):clamp((actor.recoil||0)/.16,0,1);
 const palette=player?{skin:'#bd825b',skinHi:'#e4b18a',shirt:'#344333',vest:'#526044',vestDark:'#25352d',pants:'#596045',pantsDark:'#343c30',metal:'#343d3d',red:'#b83c32',boot:'#5a4936',bootHi:'#9c8058'}:{skin:'#ad876e',skinHi:'#d0a68a',shirt:heavy?'#363d40':'#3c4548',vest:heavy?'#5a5044':'#465255',vestDark:'#202b30',pants:'#343e42',pantsDark:'#202a2e',metal:'#30393d',red:'#a74338',boot:'#333b3c',bootHi:'#858575'};
 ctx.save();ctx.translate(options.x,options.y);ctx.scale(facing*scale,scale);
 if(dead>0){ctx.globalAlpha=1-dead*.5;}
 const shadow=ctx.createRadialGradient(0,0,3,0,0,heavy?72:60);shadow.addColorStop(0,'#020807aa');shadow.addColorStop(1,'#02080700');ctx.fillStyle=shadow;ctx.beginPath();ctx.ellipse(0,1,heavy?72:61,15,0,0,Math.PI*2);ctx.fill();
 // Motion pose is articulated at hips, knees, shoulders and elbows, rather than scaling a full-body cutout.
 const hipY=slide?-43:crouch?-56:-70;
 const shoulderY=slide?-91:crouch?-111:-143;
 const headY=slide?-128:crouch?-148:-177;
 const torsoLean=slide?-.28:crouch?-.12:airborne?clamp((actor.vy||0)*-.00026,-.1,.22):moving?-.035+gait*.045:0;
 const recoilLean=fire*.075,hitLean=hurt*(player?.18*(actor.hitDirection||-1):-.13*(actor.hitDirection||1)),deathLean=dead*.95;
 const upperLean=torsoLean+recoilLean+hitLean+deathLean;
 const stride=slide?1.15:airborne?.18+jumpTuck*.35:gait*.7;
 const liftA=airborne?6+jumpTuck*8:Math.max(0,Math.sin(phase))*13;
 const liftB=airborne?9+jumpTuck*7:Math.max(0,Math.sin(phase+Math.PI))*13;
 const spread=dead*.65;
 // Back leg: thigh, knee joint, shin and boot each animate around their own joints.
 let kx1=-12+stride*24-spread*10, ky1=hipY+30-(airborne?jumpTuck*12:liftA*.25);
 let fx1=-20+stride*36-spread*19, fy1=-5-liftA+(airborne?jumpTuck*10:0);
 let kx2=12-stride*24+spread*8, ky2=hipY+31-(airborne?jumpTuck*10:liftB*.25);
 let fx2=20-stride*36+spread*18, fy2=-5-liftB+(airborne?jumpTuck*8:0);
 if(slide){kx1=22;ky1=-30;kx2=-5;ky2=-37;fx1=65;fy1=-8;fx2=25;fy2=-8;}
 drawBone(-11,hipY,kx1,ky1,heavy?23:20,palette.pants,palette.pantsDark,'#87906a');ctx.fillStyle=palette.vestDark;ctx.beginPath();ctx.arc(kx1,ky1,11,0,Math.PI*2);ctx.fill();ctx.fillStyle=palette.pants;ctx.beginPath();ctx.arc(kx1,ky1,7,0,Math.PI*2);ctx.fill();
 drawBone(kx1,ky1,fx1,fy1,heavy?17:15,palette.pantsDark,'#1e2827','#8b8a62');drawBoot(fx1,fy1,clamp((fx1-kx1)*.018,-.4,.4),palette);
 drawBone(11,hipY,kx2,ky2,heavy?23:20,palette.pants,palette.pantsDark,'#87906a');ctx.fillStyle=palette.vestDark;ctx.beginPath();ctx.arc(kx2,ky2,11,0,Math.PI*2);ctx.fill();ctx.fillStyle=palette.pants;ctx.beginPath();ctx.arc(kx2,ky2,7,0,Math.PI*2);ctx.fill();
 drawBone(kx2,ky2,fx2,fy2,heavy?17:15,palette.pantsDark,'#1e2827','#8b8a62');drawBoot(fx2,fy2,clamp((fx2-kx2)*.018,-.4,.4),palette);
 // Torso, head and arms share a shoulder pivot, so the operator bends as one articulated rig.
 const upperPivotY=shoulderY+10+bounce+(slide?8:0);ctx.save();ctx.translate(0,upperPivotY);ctx.rotate(upperLean);ctx.translate(0,-upperPivotY);
 const torsoH=Math.max(44,hipY-shoulderY-13);
 rounded(-29,0,58,torsoH,10,palette.shirt);polygon([[-28,8],[-20,-4],[19,-4],[29,9],[23,torsoH-5],[-22,torsoH-5]],palette.vest);
 ctx.strokeStyle=palette.vestDark;ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-18,3);ctx.lineTo(-9,torsoH-3);ctx.moveTo(17,3);ctx.lineTo(9,torsoH-3);ctx.stroke();
 ctx.fillStyle=palette.vestDark;rounded(-25,torsoH-27,50,12,3,palette.vestDark);
 for(let i=0;i<3;i++){rounded(-23+i*17,torsoH-22,13,16,3,player?'#68724b':'#303b3e');ctx.fillStyle=player?'#abb07c':'#8b8874';ctx.fillRect(-19+i*17,torsoH-18,6,2);}
 ctx.fillStyle=palette.metal;ctx.fillRect(-28,torsoH-5,56,7);ctx.fillStyle=player?'#c99b54':'#ae7b55';ctx.fillRect(-5,torsoH-5,10,7);
 if(player){ctx.strokeStyle='#b79e6b';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-21,11);ctx.lineTo(20,torsoH-11);ctx.stroke();ctx.fillStyle='#31392b';rounded(-31,torsoH-42,11,23,3,'#303d31');rounded(20,torsoH-40,12,22,3,'#303d31');}
 else{ctx.fillStyle=palette.red;polygon([[-27,7],[-17,7],[-22,24]],palette.red);polygon([[27,7],[17,7],[22,24]],palette.red);ctx.fillStyle='#b6a68a';ctx.fillRect(-9,16,18,4);}
 // Rear arm reaches to the rifle stock/trigger. The forearm has a separate elbow pivot.
 const localAim=Number.isFinite(options.aimAngle)?Math.atan2(Math.sin(options.aimAngle),Math.cos(options.aimAngle)*facing):0;
 const aim=clamp(localAim,-.72,.58);
 const meleeProgress=player&&(actor.meleeTime||0)>0?1-(actor.meleeTime/.24):0;
 const px=12,py=slide?-86:crouch?-106:-128+(meleeProgress>0?18:0);
 const recoilKick=fire*11+(actor.recoil||0)*22;
 const grip=(d)=>({x:px+d*Math.cos(aim)-recoilKick,y:py+d*Math.sin(aim)});
 const rearHand=grip(21),frontHand=grip(56);
 const rearShoulder={x:-22,y:shoulderY+15},frontShoulder={x:22,y:shoulderY+15};
 let rearElbow={x:-2+Math.cos(aim)*9,y:shoulderY+34+Math.sin(aim)*12};
 let frontElbow={x:35+Math.cos(aim)*7,y:shoulderY+30+Math.sin(aim)*9};
 if(meleeProgress>0){frontElbow={x:42+Math.sin(meleeProgress*Math.PI)*11,y:shoulderY+31-meleeProgress*18};frontHand.x=68+Math.sin(meleeProgress*Math.PI)*31;frontHand.y=shoulderY+31-meleeProgress*36;}
 if(hurt){rearElbow.y-=hurt*8;frontElbow.y+=hurt*8;}
 // Shoulder pads, upper arms, bracers and hands move independently.
 drawBone(rearShoulder.x,rearShoulder.y,rearElbow.x,rearElbow.y,player?17:19,palette.skin,palette.vestDark,palette.skinHi);
 drawBone(rearElbow.x,rearElbow.y,rearHand.x,rearHand.y,player?13:15,palette.skin,palette.vestDark,palette.skinHi);
 ctx.fillStyle=palette.vestDark;ctx.beginPath();ctx.arc(rearElbow.x,rearElbow.y,8,0,Math.PI*2);ctx.fill();
 // Neck and head, with a moving head turn and recognizable red bandana for Rook.
 rounded(-8,shoulderY-2,16,18,4,player?'#996b50':'#5a5b54');
 ctx.save();ctx.translate(0,headY);ctx.rotate(upperLean*.25+aim*.1);
 ctx.fillStyle=palette.skin;ctx.beginPath();ctx.ellipse(0,0,17,21,0,0,Math.PI*2);ctx.fill();
 if(player){ctx.fillStyle='#171e1d';ctx.beginPath();ctx.arc(0,-7,18,Math.PI,Math.PI*2);ctx.fill();ctx.fillStyle='#9f2e2c';ctx.beginPath();ctx.moveTo(-18,-12);ctx.lineTo(17,-14);ctx.lineTo(18,-5);ctx.lineTo(-16,-4);ctx.closePath();ctx.fill();ctx.strokeStyle='#d95b48';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-14,-12);ctx.lineTo(-26,-23);ctx.lineTo(-39,-21);ctx.stroke();ctx.fillStyle='#242524';ctx.beginPath();ctx.moveTo(-13,8);ctx.quadraticCurveTo(0,27,14,8);ctx.lineTo(10,17);ctx.lineTo(-8,18);ctx.closePath();ctx.fill();ctx.fillStyle='#f1d6ae';ctx.fillRect(6,-3,5,3);}
 else{ctx.fillStyle='#252d31';ctx.beginPath();ctx.arc(0,-8,19,Math.PI,Math.PI*2);ctx.fill();ctx.fillStyle='#a83d34';rounded(-13,-4,26,9,3,'#a83d34');ctx.fillStyle='#e4b16a';ctx.fillRect(2,-1,7,3);ctx.fillStyle='#232b2f';rounded(-14,7,28,10,3,'#252d30');}
 ctx.restore();
 // Weapon rests between both hands. Kickback visibly moves it and the arms on every shot.
 drawWeaponRig(px,py,aim+(meleeProgress>0?.52:0),player?actor.weapon||0:0,fire+(actor.recoil||0),player?(meleeProgress>0?0:actor.shotAnim||0):actor.muzzleFlash||0,!player);
 // Front forearm is drawn over the handguard, with a glove at the grip.
 drawBone(frontShoulder.x,frontShoulder.y,frontElbow.x,frontElbow.y,player?16:18,palette.skin,palette.vestDark,palette.skinHi);
 drawBone(frontElbow.x,frontElbow.y,frontHand.x,frontHand.y,player?13:15,palette.skin,palette.vestDark,palette.skinHi);
 ctx.fillStyle=palette.vestDark;ctx.beginPath();ctx.arc(frontHand.x,frontHand.y,7,0,Math.PI*2);ctx.fill();ctx.fillStyle=player?'#b98e55':'#b84b3d';ctx.fillRect(frontHand.x-4,frontHand.y-3,8,3);
 // Rook throws a full-body punch through the same shoulder/elbow/hand chain.
 if(player&&meleeProgress>0){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.85;ctx.strokeStyle='#f9d69a';ctx.lineWidth=7;ctx.beginPath();ctx.arc(frontHand.x-14,frontHand.y,34,-.8,.75);ctx.stroke();ctx.restore();ctx.fillStyle='#e8c18c';ctx.beginPath();ctx.arc(frontHand.x,frontHand.y,11,0,Math.PI*2);ctx.fill();}
 // Enemy wind-up pose is readable before the projectile leaves the barrel.
 if(!player&&actor.windup>0){ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=`rgba(255,135,91,${.45+.35*Math.sin(t*23)})`;ctx.lineWidth=3;ctx.beginPath();ctx.arc(px+38*Math.cos(aim),py+38*Math.sin(aim),13+Math.sin(t*17)*2,0,Math.PI*2);ctx.stroke();ctx.restore();}
 if(!player&&actor.survivalElite){ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle='#f3cc75';ctx.globalAlpha=.7;ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(0,-92,42,93,0,0,Math.PI*2);ctx.stroke();ctx.restore();}
 ctx.restore();
 if(options.healthRatio!==undefined&&options.healthRatio<.999){ctx.fillStyle='#10191d';ctx.fillRect(-35,-(player?218:188)-13,70,5);ctx.fillStyle='#df7159';ctx.fillRect(-35,-(player?218:188)-13,70*clamp(options.healthRatio,0,1),5);}
 ctx.restore();
}
function drawAnimatedSoldierSprite(img,width,height,legAngle=0){
 // Keep the detailed torso/head/rifle artwork intact while swinging the lower-body layer at the hips.
 // The 8px source overlap hides the seam during stride and landing poses.
 const sw=img.naturalWidth,sh=img.naturalHeight,split=Math.round(sh*.59),overlap=8;
 const upperH=split+overlap,lowerY=Math.max(0,split-overlap),lowerH=sh-lowerY;
 ctx.drawImage(img,0,0,sw,upperH,-width*.5,-height,width,height*(upperH/sh));
 // Rotate the lower crop around the source-space hip line; its overlap matches the torso crop exactly.
 const hipY=-height+(height*split/sh);
 ctx.save();ctx.translate(0,hipY);ctx.rotate(legAngle);
 ctx.drawImage(img,0,lowerY,sw,lowerH,-width*.5,-overlap*height/sh,width,height*(lowerH/sh));
 ctx.restore();
}
function drawHero(t){
 const p=game.player,x=p.x-game.world,y=p.y,facing=p.facing<0?-1:1;
 const flicker=p.invuln>0&&Math.floor(t*18)%2===0;
 if(!imageReady(art.rook)){
  drawRiggedSoldier(p,t,{player:true,x,y,facing,scale:1,aimAngle:p.aimAngle,deadProgress:0});
  return;
 }
 const run=p.grounded&&Math.abs(p.vx||0)>24;
 const phase=(p.run||0)*3.25;
 const slide=(p.slideTime||0)>.02, crouch=!!p.crouch&&!slide, airborne=!p.grounded;
 const recoil=clamp((p.shotAnim||0)/.12,0,1),hurt=clamp((p.hurtTime||0)/.25,0,1);
 const melee=(p.meleeTime||0)>0?1-p.meleeTime/.24:0;
 const gait=run?Math.sin(phase):Math.sin(t*1.6)*.035;
 const bounce=run?Math.abs(Math.sin(phase))*3.2:Math.sin(t*2.1)*1.2;
 const bob=airborne?0:bounce;
 const width=slide?156:150,height=slide?174:204;
 const lean=(run?-.045+gait*.025:0)+clamp(p.aimAngle||0,-.55,.55)*.1-recoil*.055+hurt*.12*(p.hitDirection||-1);
 const tilt=slide?.26:airborne?clamp(-(p.vy||0)*.00012,-.12,.12):crouch?.10:lean;
 const scaleX=slide?1.10:1+(run?Math.sin(phase)*.015:0);
 const scaleY=slide?.84:airborne?.98:1+(run?Math.abs(Math.sin(phase))*.018:0);
 const legAngle=slide?.34:airborne?-.22+clamp((p.vy||0)*.00018,-.12,.12):run?Math.sin(phase)*.24:Math.sin(t*1.6)*.025;
 const drawAt=(px,py,alpha,ghost=false)=>{
  ctx.save();ctx.globalAlpha*=alpha;ctx.translate(px,py);ctx.rotate(tilt+(ghost?0:gait*.012));ctx.scale(facing*scaleX,scaleY);
  ctx.shadowColor='#06100d';ctx.shadowBlur=ghost?0:13;ctx.shadowOffsetY=7;
  drawAnimatedSoldierSprite(art.rook,width,height,ghost?legAngle*.5:legAngle);
  ctx.shadowBlur=0;ctx.shadowOffsetY=0;
  // Tiny live bandana tails reinforce motion without replacing the detailed artwork.
  if(run&&!ghost){ctx.strokeStyle='#a62e2b';ctx.lineCap='round';ctx.lineWidth=4;const flutter=Math.sin(t*18)*5;ctx.beginPath();ctx.moveTo(-width*.22,-height*.91);ctx.quadraticCurveTo(-width*.42,-height*.97+flutter,-width*.56,-height*.90+flutter);ctx.stroke();}
  ctx.restore();
 };
 ctx.save();if(flicker)ctx.globalAlpha=.58;
 // A soft contact shadow anchors the sprite to the playable ground.
 const sh=ctx.createRadialGradient(x,y-1,3,x,y-1,66);sh.addColorStop(0,'#030a08aa');sh.addColorStop(1,'#030a0800');ctx.fillStyle=sh;ctx.beginPath();ctx.ellipse(x,y-1,65,13,0,0,Math.PI*2);ctx.fill();
 for(const g of p.ghosts||[]){drawAt(g.x-game.world,g.y,.16*(g.life/.18),true);}
 drawAt(x,y-bob,1,false);
 // Shot effects are aligned to the muzzle on the sprite and kick outward with each weapon action.
 if(recoil>0){
  const mx=x+facing*width*.47,my=y-height*.62;
  ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=Math.min(1,recoil*1.25);
  const glow=ctx.createRadialGradient(mx,my,1,mx,my,34);glow.addColorStop(0,'#fff9de');glow.addColorStop(.2,'#ffe3a1');glow.addColorStop(.62,'#ff9d42aa');glow.addColorStop(1,'#ff8b2800');ctx.fillStyle=glow;ctx.beginPath();ctx.ellipse(mx,my,36,17,0,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='#fff0c1';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(mx-5,my);ctx.lineTo(mx+28,my);ctx.moveTo(mx+2,my-6);ctx.lineTo(mx+21,my-16);ctx.moveTo(mx+2,my+6);ctx.lineTo(mx+21,my+16);ctx.stroke();ctx.restore();
 }
 if(melee>0){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.78;ctx.strokeStyle='#ffe0a0';ctx.lineWidth=7;ctx.beginPath();ctx.arc(x+facing*53,y-105,42,-.95,.72);ctx.stroke();ctx.restore();}
 if(hurt>0){ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=hurt*.36;ctx.fillStyle='#fff0d1';ctx.fillRect(x-64,y-190,128,190);ctx.restore();}
 if(p.flash>0){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=p.flash*1.4;const g=ctx.createRadialGradient(x,y-102,2,x,y-102,32);g.addColorStop(0,'#fff2c4');g.addColorStop(1,'#ffe09b00');ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y-102,32,0,Math.PI*2);ctx.fill();ctx.restore();}
 ctx.restore();
}
function drawEnemy(e){
 const x=e.x-game.world,y=e.y;
 if(e.type==='trooper'||e.type==='heavy'){
  const heavy=e.type==='heavy',dead=e.deathTime!==null&&e.deathTime!==undefined?clamp(e.deathTime/1.35,0,1):0;
  if(imageReady(art.enemy)){
   const w=heavy?122:104,h=heavy?226:210,wind=clamp((e.windup||0)/.55,0,1),recoil=clamp((e.recoil||0)/.16,0,1),hit=clamp((e.hitReact||0)/.22,0,1);
   const walk=game.time*(heavy?2.8:3.8)+(e.id||0)*9,bob=Math.abs(Math.sin(walk))*3.2,legAngle=dead>0?dead*.42:Math.sin(walk)*.19;
   const fall=dead>0?dead*1.12:0,face=e.dir||-1;
   ctx.save();ctx.translate(x,y-bob);ctx.rotate((face<0?1:-1)*(fall*.95+hit*.09-recoil*.025));ctx.scale(face<0?1:-1,1);
   ctx.globalAlpha=dead>0?1-dead*.58:1;
   const sh=ctx.createRadialGradient(0,0,2,0,0,52);sh.addColorStop(0,'#020806aa');sh.addColorStop(1,'#02080600');ctx.fillStyle=sh;ctx.beginPath();ctx.ellipse(0,0,54,11,0,0,Math.PI*2);ctx.fill();
   ctx.shadowColor='#050b0b';ctx.shadowBlur=12;ctx.shadowOffsetY=6;
   drawAnimatedSoldierSprite(art.enemy,w,h,legAngle);ctx.shadowBlur=0;ctx.shadowOffsetY=0;
   // Helmet optics and armor lamps keep the hostile silhouette legible at play scale.
   if(!dead){ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=heavy?'#ff5145':'#ff6b48';ctx.globalAlpha=.65+.2*Math.sin(game.time*8+(e.id||0));ctx.shadowBlur=10;ctx.shadowColor=ctx.fillStyle;ctx.beginPath();ctx.ellipse(-w*.19,-h*.88,4,2.5,-.12,0,Math.PI*2);ctx.fill();ctx.restore();}
   if(recoil>0){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=recoil*.85;ctx.strokeStyle='#fff0c4';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(-w*.53,-h*.55);ctx.lineTo(-w*.74,-h*.55);ctx.moveTo(-w*.55,-h*.59);ctx.lineTo(-w*.68,-h*.67);ctx.stroke();ctx.restore();}
   if(wind>0){ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=wind*.6;ctx.strokeStyle='#ff9b64';ctx.lineWidth=3;ctx.beginPath();ctx.arc(-w*.38,-h*.58,10+Math.sin(game.time*18)*2,0,Math.PI*2);ctx.stroke();ctx.restore();}
   if(e.flash>0){ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=Math.min(.7,e.flash*4);ctx.fillStyle='#fff0d0';ctx.fillRect(-w*.5,-h,w,h);ctx.restore();}
   if(e.hp<e.maxHp){ctx.fillStyle='#111a1c';ctx.fillRect(-34,-h-15,68,5);ctx.fillStyle=heavy?'#ed9a61':'#df7159';ctx.fillRect(-34,-h-15,68*clamp(e.hp/e.maxHp,0,1),5);}
   ctx.restore();
  }else drawRiggedSoldier(e,game.time,{player:false,heavy,x,y,facing:e.dir||-1,scale:heavy?1.04:.91,aimAngle:e.aimAngle||0,deadProgress:dead,healthRatio:e.hp/e.maxHp});
  return;
 }
 // Mechanical enemies retain dedicated articulated silhouettes.
 ctx.save();ctx.translate(x,y);ctx.scale(e.dir||-1,1);if(e.flash>0){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.8;}const bob=e.type==='drone'?Math.sin(e.walk*.7)*7:Math.sin(e.walk)*2;
 ctx.fillStyle='#0008';ctx.beginPath();ctx.ellipse(0,0,e.w*.55,9,0,0,Math.PI*2);ctx.fill();
 if(e.type==='drone'){const dg=ctx.createLinearGradient(-25,-e.h*.5,25,-e.h*.5);dg.addColorStop(0,'#263a42');dg.addColorStop(.5,'#819399');dg.addColorStop(1,'#26363c');ctx.fillStyle=dg;ctx.beginPath();ctx.ellipse(0,-e.h*.5+bob,e.w*.46,e.h*.42,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#e4b76f';ctx.beginPath();ctx.arc(0,-e.h*.5+bob,7,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#28363d';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-22,-e.h*.5+bob);ctx.lineTo(-39,-e.h*.5-11+bob);ctx.moveTo(22,-e.h*.5+bob);ctx.lineTo(39,-e.h*.5-11+bob);ctx.stroke();ctx.strokeStyle='#9dc7c2';ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,-e.h*.5+bob,34,Math.PI,Math.PI*2);ctx.stroke();}
 else{const leg=Math.sin(e.walk)*8;const tg=ctx.createLinearGradient(-25,0,25,0);tg.addColorStop(0,'#2a3539');tg.addColorStop(.5,'#87908a');tg.addColorStop(1,'#303b3d');ctx.strokeStyle=tg;ctx.lineWidth=18;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-12,-27);ctx.lineTo(-13+leg,-7);ctx.moveTo(12,-27);ctx.lineTo(12-leg,-7);ctx.stroke();ctx.fillStyle='#222d32';ctx.fillRect(-25,-12,23,11);ctx.fillRect(4,-12,23,11);ctx.fillStyle='#3a494b';rounded(-25,-e.h+29,e.w-1,e.h-46,8,'#4b5b5d');ctx.fillStyle='#29363a';ctx.fillRect(-18,-e.h+45,35,10);ctx.fillStyle='#d0ad68';ctx.fillRect(-7,-e.h+49,14,6);ctx.fillStyle='#b99a7d';ctx.beginPath();ctx.arc(0,-e.h+18,16,0,Math.PI*2);ctx.fill();ctx.fillStyle='#252e35';ctx.beginPath();ctx.arc(0,-e.h+10,18,Math.PI,Math.PI*2);ctx.fill();ctx.fillStyle='#1c272d';ctx.fillRect(10,-e.h+54,43,9);ctx.fillStyle='#9b7956';ctx.fillRect(19,-e.h+49,9,5);}
 if(e.windup>0){ctx.strokeStyle=`rgba(255,133,94,${.55+.35*Math.sin(game.time*22)})`;ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,-e.h*.55,24+Math.sin(game.time*17)*3,0,Math.PI*2);ctx.stroke();}
 if(e.hp<e.maxHp){ctx.fillStyle='#182126';ctx.fillRect(-e.w*.5,-e.h-17,e.w,5);ctx.fillStyle='#d96e54';ctx.fillRect(-e.w*.5,-e.h-17,e.w*(e.hp/e.maxHp),5);}ctx.restore();
}
function drawBoss(b){const x=b.x-game.world,y=b.y;ctx.save();ctx.translate(x,y);if(b.flash>0){ctx.globalCompositeOperation='lighter';ctx.globalAlpha=.85;}const pulse=1+Math.sin(game.time*3)*.025;ctx.scale(pulse,1);
 ctx.fillStyle='#0009';ctx.beginPath();ctx.ellipse(0,0,b.w*.65,18,0,0,Math.PI*2);ctx.fill();
 // Each warlord has moving hydraulic legs and independent arms; wind-up pulls the arms back before firing.
 const step=Math.sin(b.walk*2.4)*13,brace=b.windup>0?Math.sin(game.time*17)*9:0,hit=(b.hitReact||0)*15;
 for(const side of [-1,1]){const hipX=side*b.w*.23,kneeX=hipX+side*11+step*side*.35,footX=hipX+step*side;drawBone(hipX,-64,kneeX,-34,26,'#303b40','#182226','#87908a');drawBone(kneeX,-34,footX,-5,21,'#465358','#182226','#9ca49a');ctx.fillStyle='#202b30';rounded(footX-22,-10,48,11,4,'#202b30');const shX=side*b.w*.39,elX=shX+side*(25+brace),handX=elX+side*(28+hit);drawBone(shX,-b.h*.72,elX,-b.h*.48,28,'#465359','#1e292e','#87938a');drawBone(elX,-b.h*.48,handX,-b.h*.30,22,'#596461','#20292c','#a49a7e');ctx.fillStyle='#c08b5d';ctx.beginPath();ctx.arc(handX,-b.h*.30,11,0,Math.PI*2);ctx.fill();}
 if(b.type==='warden'){ctx.fillStyle='#39484c';rounded(-b.w*.42,-b.h+44,b.w*.84,b.h-55,22,'#425358');ctx.fillStyle='#68766d';rounded(-b.w*.3,-b.h+8,b.w*.6,76,20,'#69796f');ctx.fillStyle='#1e292e';ctx.fillRect(-b.w*.22,-b.h+60,b.w*.44,68);ctx.fillStyle='#eac47b';ctx.beginPath();ctx.arc(0,-b.h+85,22,0,Math.PI*2);ctx.fill();ctx.fillStyle='#20282b';ctx.fillRect(-b.w*.54,-b.h+85,40,25);ctx.fillRect(b.w*.33,-b.h+85,40,25);ctx.fillStyle='#b06e4c';ctx.fillRect(-b.w*.48,-47,45,32);ctx.fillRect(b.w*.15,-47,45,32);}
 else if(b.type==='walker'){ctx.fillStyle='#32383b';rounded(-b.w*.5,-b.h+50,b.w,b.h-62,19,'#424e50');polygon([[-b.w*.48,-b.h+100],[-b.w*.34,-b.h-15],[b.w*.33,-b.h-15],[b.w*.47,-b.h+100]],'#5b6561');ctx.fillStyle='#d48d53';ctx.fillRect(-b.w*.32,-b.h+92,b.w*.64,17);ctx.fillStyle='#172329';ctx.fillRect(-b.w*.15,-b.h+50,b.w*.3,62);ctx.fillStyle='#ffce8a';ctx.beginPath();ctx.arc(0,-b.h+75,27,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#202a31';ctx.lineWidth=24;ctx.beginPath();ctx.moveTo(-b.w*.4,-b.h+90);ctx.lineTo(-b.w*.68,-b.h+130);ctx.lineTo(-b.w*.68,-70);ctx.moveTo(b.w*.4,-b.h+90);ctx.lineTo(b.w*.68,-b.h+130);ctx.lineTo(b.w*.68,-70);ctx.stroke();ctx.fillStyle='#1b252a';ctx.fillRect(-b.w*.5,-54,b.w,24);}
 else if(b.type==='behemoth'){ctx.fillStyle='#426477';rounded(-b.w*.47,-b.h+35,b.w*.94,b.h-44,34,'#5e8390');polygon([[-b.w*.42,-b.h+67],[-b.w*.25,-b.h-18],[0,-b.h+55],[b.w*.26,-b.h-18],[b.w*.43,-b.h+67]],'#badde0');ctx.fillStyle='#d2eff0';ctx.beginPath();ctx.arc(0,-b.h+82,34,0,Math.PI*2);ctx.fill();ctx.fillStyle='#1f3644';ctx.fillRect(-25,-b.h+76,50,13);ctx.fillStyle='#b6f4ef';ctx.fillRect(-19,-b.h+74,38,5);ctx.fillStyle='#344d5c';ctx.fillRect(-b.w*.42,-62,60,62);ctx.fillRect(b.w*.18,-62,60,62);}
 else{ctx.fillStyle='#2b1f37';ctx.beginPath();ctx.moveTo(-b.w*.5,0);ctx.lineTo(-b.w*.42,-b.h*.65);ctx.lineTo(-b.w*.22,-b.h);ctx.lineTo(0,-b.h*.78);ctx.lineTo(b.w*.22,-b.h);ctx.lineTo(b.w*.42,-b.h*.65);ctx.lineTo(b.w*.5,0);ctx.closePath();ctx.fill();ctx.strokeStyle='#9a4e7b';ctx.lineWidth=7;ctx.stroke();ctx.fillStyle='#e7a0a6';ctx.beginPath();ctx.arc(0,-b.h*.56,62+Math.sin(game.time*4)*5,0,Math.PI*2);ctx.fill();ctx.fillStyle='#461d45';ctx.beginPath();ctx.arc(0,-b.h*.56,38,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff1d1';ctx.beginPath();ctx.arc(0,-b.h*.56,19,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#ed8db5';ctx.lineWidth=5;for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(-b.w*.36+i*50,-b.h*.25);ctx.lineTo(-b.w*.5+i*70,-b.h*.06);ctx.stroke();}}
 // armor accent and damage glow
 if(b.windup>0){ctx.globalCompositeOperation='lighter';ctx.strokeStyle='#ffac77';ctx.lineWidth=7;ctx.beginPath();ctx.arc(0,-b.h*.56,b.w*.48+Math.sin(game.time*20)*8,0,Math.PI*2);ctx.stroke();}
 ctx.restore();}
function drawWeather(cam,l){
 const theme=l.theme;ctx.save();
 for(let i=0;i<52;i++){
  const drift=(theme==='frost'?26:theme==='foundry'?18:theme==='alien'?12:8);
  const x=((i*137-cam*.19+Math.sin(game.time*.7+i)*28)%(W+60)+W+60)%(W+60)-30;
  const y=((i*71+game.time*drift*(.55+(i%5)*.13))%(H+40))-20;
  if(theme==='frost'){
   ctx.globalAlpha=.22+(i%4)*.1;ctx.fillStyle='#e8f7ff';ctx.beginPath();ctx.arc(x,y,1.5+(i%3)*.65,0,Math.PI*2);ctx.fill();
  }else if(theme==='foundry'||theme==='alien'){
   ctx.globalAlpha=.23+(i%4)*.11;ctx.fillStyle=theme==='foundry'?'#ffb56e':'#f38cbd';ctx.fillRect(x,y,2+(i%2),4+(i%3));
  }else{
   ctx.globalAlpha=.16+(i%4)*.08;ctx.fillStyle='#d0e4a2';ctx.beginPath();ctx.arc(x,y,1.5+(i%2),0,Math.PI*2);ctx.fill();
  }
 }
 ctx.restore();
}
function drawProjectiles(){for(const b of game.bullets){const x=b.x-game.world;ctx.save();ctx.globalCompositeOperation='lighter';ctx.strokeStyle=b.color;ctx.lineWidth=b.r*1.4;ctx.beginPath();ctx.moveTo(x-b.vx*.035,b.y-b.vy*.035);ctx.lineTo(x,b.y);ctx.stroke();ctx.fillStyle='#fff8d6';ctx.beginPath();ctx.arc(x,b.y,b.r*.7,0,Math.PI*2);ctx.fill();ctx.restore();}for(const b of game.enemyBullets){const x=b.x-game.world;ctx.save();ctx.globalCompositeOperation='lighter';ctx.shadowBlur=14;ctx.shadowColor=b.color;ctx.fillStyle=b.color;ctx.beginPath();ctx.arc(x,b.y,b.r,0,Math.PI*2);ctx.fill();ctx.restore();}for(const g of game.grenades){const x=g.x-game.world;ctx.fillStyle='#2e433c';ctx.beginPath();ctx.arc(x,g.y,g.r,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#e7ca8c';ctx.lineWidth=2;ctx.stroke();ctx.fillStyle='#ffba72';ctx.beginPath();ctx.arc(x+3,g.y-4,2,0,Math.PI*2);ctx.fill();}}
function drawEffects(){for(const e of game.explosions){const p=e.t/e.max,r=(20+p*180)*e.scale;const x=e.x-game.world;ctx.save();ctx.globalCompositeOperation='lighter';ctx.globalAlpha=1-p;const g=ctx.createRadialGradient(x,e.y,2,x,e.y,r);g.addColorStop(0,'#fff5c7');g.addColorStop(.22,e.color);g.addColorStop(1,'transparent');ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,e.y,r,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#ffe5ac';ctx.lineWidth=3*(1-p);ctx.beginPath();ctx.arc(x,e.y,r*.6,0,Math.PI*2);ctx.stroke();ctx.restore();}for(const p of game.particles){ctx.save();ctx.globalAlpha=clamp(p.life/p.max,0,1);ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x-game.world,p.y,p.r,0,Math.PI*2);ctx.fill();ctx.restore();}for(const s of game.shells){ctx.save();ctx.fillStyle='#e6be76';ctx.fillRect(s.x-game.world,s.y,4,2);ctx.restore();}for(const it of game.pickups){const x=it.x-game.world,y=it.y+Math.sin(game.time*5)*5;ctx.save();ctx.globalCompositeOperation='lighter';ctx.fillStyle=it.type==='health'?'#ef786c':'#91d5d4';ctx.shadowBlur=16;ctx.shadowColor=ctx.fillStyle;ctx.beginPath();ctx.arc(x,y,15,0,Math.PI*2);ctx.fill();ctx.fillStyle='#152228';ctx.font='bold 17px Rajdhani';ctx.textAlign='center';ctx.fillText(it.type==='health'?'+':'▣',x,y+6);ctx.restore();}}
function drawStageMarkers(){const lv=level();const p=game.player;for(let i=0;i<makeWaveList(game.stage).length;i++){const x=makeWaveList(game.stage)[i].at-game.world;if(x>80&&x<W-80){ctx.fillStyle='#eacb8a55';ctx.fillRect(x,GROUND-45,2,45);ctx.fillStyle='#f3d49b';ctx.font='bold 11px Rajdhani';ctx.textAlign='center';ctx.fillText(`WAVE ${i+1}`,x,GROUND-57);}}if(game.boss&&game.boss.alive){const x=game.boss.x-game.world;ctx.fillStyle='#ffbc8266';ctx.fillRect(x,GROUND-50,2,50);}}
function drawOverlays(){if(stageBanner>0){ctx.save();ctx.globalAlpha=Math.min(1,stageBanner*1.8);ctx.textAlign='center';ctx.fillStyle='#f3d9a7';ctx.font='800 14px Rajdhani';ctx.letterSpacing='4px';ctx.fillText(game.boss?`BOSS CONTACT · ${level().boss}`:'SECTOR ALERT · HOSTILES INBOUND',W/2,H*.285);ctx.font='900 38px \"Barlow Condensed\"';ctx.fillStyle='#fff0d3';ctx.shadowColor='#000';ctx.shadowBlur=22;ctx.fillText(game.boss?'ELIMINATE THE WARLORD':`WAVE ${game.wave} · ENGAGE`,W/2,H*.34);ctx.restore();}if(screenFlash>0){ctx.fillStyle=`rgba(255,234,192,${screenFlash*.55})`;ctx.fillRect(0,0,W,H);}if(dailyToastUntil>performance.now()){ctx.save();ctx.textAlign='center';ctx.font='900 34px \"Barlow Condensed\"';ctx.fillStyle='#ffe7ad';ctx.shadowColor='#000';ctx.shadowBlur=20;ctx.fillText('DAILY CONTRACT COMPLETE  +1,200 CR',W/2,H*.45);ctx.restore();}if(shake>0&&game){ctx.fillStyle=`rgba(255,100,73,${Math.min(.15,shake/80)})`;ctx.fillRect(0,0,W,H);}}
function render(t){ctx.save();ctx.clearRect(0,0,W,H);let sx=0,sy=0;if(shake>0){sx=rand(-shake,shake);sy=rand(-shake*.45,shake*.45);}ctx.translate(sx,sy);if(game){const lv=level();drawBackground(game.world,lv);drawGround(game.world,lv);drawStageMarkers();drawCrates(game.world);for(const e of game.enemies)if(e.alive||(e.deathTime!==null&&e.deathTime!==undefined&&e.deathTime<1.35))drawEnemy(e);if(game.boss&&game.boss.alive)drawBoss(game.boss);drawHero(t/1000);drawProjectiles();drawEffects();drawWeather(game.world,lv);drawOverlays();}else{ctx.fillStyle='#15252b';ctx.fillRect(0,0,W,H);drawMenuScene(t/1000);}ctx.restore();}
function drawMenuScene(t){
 const fake={theme:'jungle',sky:['#1d353b','#607e78','#c7a47c']};
 // The menu has its own complete render state; it must never borrow a half-built gameplay object.
 if(imageReady(art.jungle))drawBackground(0,fake);else drawSky(0,fake);
 drawGround(0,fake);
 for(let i=0;i<5;i++){const x=760+i*160;ctx.fillStyle='#18262a';ctx.fillRect(x,GROUND-210,28,210);ctx.fillStyle='#66716a';ctx.fillRect(x-28,GROUND-215,85,16);}
 ctx.save();ctx.translate(1100,GROUND);ctx.scale(1.45,1.45);
 if(imageReady(art.rook)){ctx.drawImage(art.rook,-74,-202,148,202);}
 else{drawRiggedSoldier({grounded:true,vx:0,vy:0,run:t*1.7,slideTime:0,crouch:false,shotAnim:0,meleeTime:0,flash:0},t,{player:true,x:0,y:0,facing:1,scale:1,aimAngle:0});}
 ctx.restore();
 for(let i=0;i<9;i++){const x=980+i*65+Math.sin(t*1.7+i)*8;ctx.fillStyle='#23313a';ctx.beginPath();ctx.arc(x,GROUND-75-(i%3)*9,17,0,Math.PI*2);ctx.fill();ctx.fillStyle='#dfc187';ctx.fillRect(x-5,GROUND-80-(i%3)*9,10,5);}
}
function frame(now){
 const dt=Math.min(.04,(now-last)/1000||0);last=now;
 try{
  if(gameState==='playing')update(dt);
  render(now);
  renderFailure=null;
 }catch(error){
  const message=String(error&&error.message||error);
  if(renderFailure!==message)console.error('IRON FRONTIER frame recovered:',error);
  renderFailure=message;
  // Reset the drawing state so one malformed frame cannot permanently stop gameplay rendering.
  canvas.width=W;canvas.height=H;
  ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  ctx.fillStyle='#101a20';ctx.fillRect(0,0,W,H);ctx.fillStyle='#f4d08b';ctx.textAlign='center';ctx.font='800 25px Rajdhani';ctx.fillText('RENDER RECOVERED · RETRYING FRAME',W/2,H/2);
 }finally{raf=requestAnimationFrame(frame);}
}
function pointerPos(ev){const r=canvas.getBoundingClientRect();input.pointer.x=(ev.clientX-r.left)*W/r.width;input.pointer.y=(ev.clientY-r.top)*H/r.height;input.pointer.inside=true;}
function keyDown(e){if(['Space','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.code))e.preventDefault();if(e.repeat)return;input.keys.add(e.code);if(e.code==='Escape'||e.code==='KeyP'){if(gameState==='playing')pauseGame();else if(gameState==='paused')resumeGame();}if(gameState==='playing'){if(e.code==='Space')doJump();if(e.code==='ShiftLeft'||e.code==='ShiftRight')dash();if(e.code==='KeyE')melee();if(e.code==='Digit1'){game.player.weapon=0;updateHud();}if(e.code==='Digit2'){game.player.weapon=1;updateHud();}if(e.code==='Digit3'){game.player.weapon=2;updateHud();}if(e.code==='KeyK')throwGrenade();if(e.code==='KeyL')overdrive();}}
function keyUp(e){input.keys.delete(e.code);}
canvas.addEventListener('pointermove',e=>pointerPos(e));canvas.addEventListener('pointerdown',e=>{pointerPos(e);input.pointer.down=true;canvas.setPointerCapture?.(e.pointerId);});window.addEventListener('pointerup',()=>{input.pointer.down=false;});window.addEventListener('keydown',keyDown,{passive:false});window.addEventListener('keyup',keyUp);window.addEventListener('blur',()=>{if(gameState==='playing')pauseGame();});
$('start-btn').addEventListener('click',startGame);$('survival-btn').addEventListener('click',()=>startSurvival('survival'));$('daily-btn').addEventListener('click',()=>startSurvival('daily'));for(const b of document.querySelectorAll('[data-upgrade]'))b.addEventListener('click',()=>buyUpgrade(b.dataset.upgrade));renderCareerUI();$('pause-btn').addEventListener('click',pauseGame);$('resume-btn').addEventListener('click',resumeGame);$('restart-btn').addEventListener('click',()=>{if(game){gameState='playing';setScreen(null);loadStage(game.stage,false);last=performance.now();}});$('quit-btn').addEventListener('click',()=>{renderCareerUI();goMenu();});$('controls-btn').addEventListener('click',()=>setScreen('manual-screen'));$('manual-close').addEventListener('click',()=>setScreen('menu-screen'));$('next-stage-btn').addEventListener('click',advanceStage);$('retry-btn').addEventListener('click',()=>{const mode=game?.mode||'campaign',n=game?.stage||0;if(mode==='survival'||mode==='daily')startSurvival(mode);else{game=createGame();loadStage(n,false);enterPlay();}});$('gameover-menu-btn').addEventListener('click',goMenu);$('victory-menu-btn').addEventListener('click',goMenu);
for(const btn of document.querySelectorAll('.mobile-controls button')){const code=btn.dataset.key;btn.addEventListener('pointerdown',e=>{e.preventDefault();input.touch.add(code);if(code==='Space')doJump();if(code==='KeyK')throwGrenade();if(code==='KeyL')overdrive();});btn.addEventListener('pointerup',()=>input.touch.delete(code));btn.addEventListener('pointerleave',()=>input.touch.delete(code));btn.addEventListener('pointercancel',()=>input.touch.delete(code));}
// Make the pointer fire button and key map coexist with keyboard play.
function boot(){setScreen('menu-screen');$('hud').classList.add('hidden');syncVisualAssetStatus();last=performance.now();raf=requestAnimationFrame(frame);}
if(typeof window!=='undefined'&&window.__IF_TEST_MODE__){window.__IF_TEST_API__={get game(){return game;},get career(){return career;},get gameState(){return gameState;},startGame,startSurvival,queueSurvivalWave,survivalUpdate,buyUpgrade,damageEnemy,damageBoss,saveCareer,renderCareerUI,loadStage,spawnEnemy,render,update};}
boot();
})();
