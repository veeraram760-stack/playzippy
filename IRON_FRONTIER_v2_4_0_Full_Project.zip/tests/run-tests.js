const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'src/game.js'),'utf8');
const css=fs.readFileSync(path.join(root,'style.css'),'utf8');
const checks=[
 ['campaign has four different operations', (js.match(/name:'[^']+'/g)||[]).length>=4],
 ['weapons include rifle, shotgun and plasma', js.includes('BREACH SHOTGUN')&&js.includes('ARC PLASMA')],
 ['enemy classes include trooper, heavy, drone and turret', ['trooper','heavy','drone','turret'].every(x=>js.includes(x))],
 ['boss class supports all four warlords', ['warden','walker','behemoth','engine'].every(x=>js.includes(`'${x}'`))],
 ['grenades and overdrive ability are wired', js.includes('function throwGrenade')&&js.includes('function overdrive')],
 ['stage progression and victory state are wired', js.includes('function advanceStage')&&js.includes("gameState='victory'")],
 ['mobile touch controls are present', html.includes('mobile-controls')&&js.includes('input.touch')],
 ['save data is persisted', js.includes("localStorage.setItem('if_best'")],
 ['canvas and responsive layout exist', html.includes('<canvas id="game"')&&css.includes('@media(max-width:760px)')],
 ['detailed Rook and enemy sprite assets are included', fs.existsSync(path.join(root,'assets/rook.png'))&&fs.existsSync(path.join(root,'assets/enemy.png'))],
 ['jungle stage uses the high-detail panorama', js.includes("art.jungle.src='assets/jungle-panorama-full-v24.jpg'")],
 ['hero and enemy use detailed transparent soldier art with action-aware transforms', js.includes('function drawRiggedSoldier')&&js.includes('function drawAnimatedSoldierSprite')&&js.includes('function drawBone')&&js.includes('drawBoot(')&&!js.includes('ctx.drawImage(art.rook,-w*.5')&&!js.includes('ctx.drawImage(art.soldier,-w*.5')],
 ['HUD has a compact tablet layout', css.includes('@media(max-width:1100px)')&&css.includes('hud-top-center strong{font-size:clamp(17px')]
];
checks.push(['player has an articulated fallback rig for run, jump, slide, recoil, melee and hurt states', js.includes('function drawRiggedSoldier')&&js.includes('const jumpTuck=')&&js.includes('const slide=')&&js.includes('const recoilLean=')&&js.includes('actor.meleeTime')&&js.includes('actor.hurtTime')]);
checks.push(['enemy combat states retain aim, recoil, flinch and falling-death logic', js.includes('e.aimAngle=')&&js.includes('e.hitReact=')&&js.includes('e.deathTime=0')&&js.includes('deadProgress:dead')]);
checks.push(['bosses have moving articulated limbs and telegraphed attacks', js.includes('const step=Math.sin(b.walk*2.4)')&&js.includes('brace=b.windup>0')]);
checks.push(['ground slide and air dash actions are implemented', js.includes('slideTime')&&js.includes('airDashUsed')&&js.includes('function dash')]);
checks.push(['close-range melee attack is wired', js.includes('function melee')&&js.includes("e.code==='KeyE'")]);
checks.push(['dash afterimages and enemy muzzle flashes are rendered', js.includes('p.ghosts')&&js.includes('muzzleFlash')]);
checks.push(['stage-specific weather effects are rendered', js.includes('function drawWeather')&&js.includes('drawWeather(game.world,lv)')]);
checks.push(['career credits and three permanent upgrade tracks are saved', js.includes('CAREER_KEY')&&['armor','power','agility'].every(x=>js.includes(x))&&js.includes('function saveCareer')]);
checks.push(['endless survival escalates enemy stats and cycles boss encounters', js.includes('function queueSurvivalWave')&&js.includes('game.survivalWave%5===0')&&js.includes('survivalScale')]);
checks.push(['daily contract has an eight-wave objective and one-time reward', js.includes("game.survivalWave>=8&&!career.dailyClaimed")&&js.includes('1200')]);
checks.push(['first campaign encounter spawns immediately in visible range', js.includes('const first=makeWaveList(index)[0]')&&js.includes('game.player.x+620')]);
checks.push(['game over records best wave, score and run earnings', js.includes('career.bestWave=Math.max')&&js.includes('run-summary')]);

checks.push(['Rook uses the detailed transparent soldier artwork in normal gameplay', js.includes('art.rook.src=')&&js.includes('drawAnimatedSoldierSprite(art.rook,width,height,ghost?legAngle*.5:legAngle)')&&js.includes('const drawAt=')]);
checks.push(['troopers and heavies use detailed armored soldier artwork', js.includes("art.enemy.src='assets/enemy-v24.png'")&&js.includes('drawAnimatedSoldierSprite(art.enemy,w,h,legAngle)')&&js.includes('wind=clamp')]);
checks.push(['soldier sprites react to movement, jump, slide, recoil, damage and melee', js.includes('const run=p.grounded')&&js.includes('const legAngle=slide?.34')&&js.includes('airborne=!p.grounded')&&js.includes('const slide=')&&js.includes('const recoil=')&&js.includes('const hurt=')&&js.includes('if(melee>0)')]);
checks.push(['jungle panorama fills the entire playfield with no flat understory or leaf canopy pass', js.includes('const tileW=art.jungle.naturalWidth,tileH=GROUND')&&js.includes('ctx.drawImage(art.jungle,x,0,tileW,tileH)')&&!js.includes('drawJungleUnderstory(cam);')&&!js.includes('drawJungleFoliage(cam);')]);
checks.push(['menu preview no longer invokes gameplay renderer with an incomplete mock game object', js.includes('function drawMenuScene(t)')&&js.includes('ctx.drawImage(art.rook,-74,-202,148,202)')&&!js.includes('const old=game;game={player:')]);
checks.push(['animation loop always schedules the next frame after renderer errors', js.includes('function frame(now){')&&js.includes('finally{raf=requestAnimationFrame(frame);}')]);
checks.push(['jungle visual asset is required before campaign or survival starts', js.includes('function visualAssetsReady()')&&js.includes('if(!visualAssetsReady())')&&js.includes('LOADING BATTLEFIELD ART')]);
checks.push(['versioned v2.4 art assets are used to avoid stale CDN cache files', js.includes('assets/rook-v24.png')&&js.includes('assets/enemy-v24.png')&&js.includes('assets/jungle-panorama-full-v24.jpg')]);
const sim=require('./gameplay-sim').runSimulation();
for(const result of sim)checks.push([`simulation: ${result.name}`,result.ok]);
let failed=0; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);if(!ok)failed++;}
if(failed)process.exit(1);console.log(`\n${checks.length}/${checks.length} checks passed.`);
