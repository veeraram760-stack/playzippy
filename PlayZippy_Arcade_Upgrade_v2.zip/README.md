# PlayZippy — Arcade Upgrade v2.0

A responsive browser-game portal built with React and Vite. The v2.0 upgrade focuses on more expressive arcade visuals, responsive touch controls, score progression, local best-score tracking and polished game cabinets.

## Games

- **Starfall Assault** — a canvas space shooter with enemy waves, boss encounters, particles, lives and auto-fire.
- **Neon Drift** — an endless neon racer with traffic, energy shards, increasing speed and keyboard/touch steering.
- **Crystal Cascade** — a timed match-three puzzle with cascades, score multipliers and a personal best.
- **Panda Dash** — a jungle runner with a drawn panda, parallax scenery, double-jump, obstacles and bamboo collectibles.
- **Block Master** — a block-placement puzzle.
- **Memory Match** — a quick card-matching challenge.

## Run locally

Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

Vite outputs the production site into `dist/`.

## Deploy

The Cloudflare Pages project is configured to extract the project archive from the repository root and run `npm install && npm run build`, publishing `dist/`.

## Notes

- Game progress and personal-best scores are saved in browser local storage on the player's device.
- No ad network scripts are enabled. Add an approved publisher ID and consent controls before enabling monetization.
- The publisher contact details in the legal pages must be replaced before a public commercial launch.
- All game visuals are drawn in canvas/CSS; no third-party game assets are bundled.
