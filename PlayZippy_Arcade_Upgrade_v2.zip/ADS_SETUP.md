# Advertising setup notes

Ad slots are intentionally disabled by default. Do not enable them until an ad provider approves the site and supplies the correct publisher identifiers and ad code.

Before placing ads:

1. Publish accurate contact and privacy details.
2. Add a consent-management flow appropriate for the visitors and ad provider.
3. Use only the exact provider script and slot IDs issued to this publisher.
4. Keep ads away from game controls and avoid accidental-click layouts.
5. Test desktop and mobile layouts after enabling ads.
