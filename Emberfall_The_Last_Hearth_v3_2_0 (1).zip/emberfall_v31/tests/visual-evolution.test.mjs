import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const main=readFileSync(new URL('../src/main.js',import.meta.url),'utf8');
const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
const css=readFileSync(new URL('../src/style.css',import.meta.url),'utf8');
for (const token of ['const eliteScale=e.elite?1.14:1','ELITE','fx.type===\'spawnRift\'','fx.type===\'eliteDeath\'','fx.type===\'bossPhase\'','e.phase<e.lastPhase','spawnAtEdge(kind,phase===3&&i===0)','game.stage===1? t*']) assert.ok(main.includes(token), 'Missing visual upgrade: '+token);
assert.ok(html.includes('id="waveHud"') && html.includes('id="waveCurrent"'));
assert.ok(css.includes('.wave-hud{display:none'));
console.log('Visual evolution checks passed: elite aura/rank/healthbar, spawn rifts, elite shatter, boss phase shockwaves/reinforcements, realm weather and wave HUD.');
