# Emberfall 3.1.0 — The Last Hearth (PlayZippy)

This release changes the camera/presentation layer to match the provided reference: an elevated three-quarter arena view with a visible rear wall, receding floor plane, horizontal facing characters, perspective-scaled sprites, and floor shadows. The simulation remains on its existing gameplay plane; rendering uses an oblique projection and mouse targeting is inverse-projected back into the gameplay plane.

## Character rendering
- Lyra keeps the existing authored run, jump, attack-combo, and dodge atlas.
- Thornling, archer, and brute now use separate 4×4 authored animation atlases. The enemy AI state selects idle, run, attack, or hit/recoil frames.
- Enemies are drawn upright and face left/right; the enemy renderer no longer rotates and squashes a single static image to imply animation.
- Depth sorting, sprite sizing, shadows, floor telegraphs, projectiles, and combat effects are projected into the same camera space.

## Controls
- WASD / arrow keys: move
- Mouse / J: attack combo
- Shift: jump
- Space: dodge
- Q: Solar Burst
- E: enter the gate
- Esc: pause

## Emberfall 3.1 combat progression
- Regular chambers now run three successive enemy waves; the gate opens after the final wave.
- Elite enemies appear in the final wave with increased health, movement speed, damage and XP rewards.
- Existing Lyra, Thornling, archer, brute and boss animation atlases are preserved.
- All three realms retain their original chamber layouts, art, camera projection and save progression.

## Build and checks
```bash
npm install --no-audit --no-fund
npm test
npm run build
```

The automated checks cover enemy AI actions, presentation projection, inverse pointer mapping, animation atlas presence/shape, projected depth sorting, and the three-wave compositions across all realms. They are not a substitute for extended human playtesting.


## Emberfall 3.0 — The Last Hearth

The Verdant Hollow now unfolds across four chambers: Moss Gate, Rootbound Chapel, Hanging Orchard, and the Rootbound Warden. The later realms keep their existing three-room structure.

### Combat controls
- **WASD / Arrow keys:** move
- **Mouse 1 / J:** four-hit light chain
- **Hold K / right mouse button:** charge Sunbreaker; release to strike
- **F:** grab and throw a nearby foe
- **Shift:** jump; use J in the air for Sky Rend or K for Falling Star
- **Space:** Ember Dodge; a well-timed dodge triggers an automatic counter
- **C:** cycle Solar Nova, Lance, and Rupture
- **Q:** cast the selected Solar aspect
- **E:** enter an open ember gate
- **Esc / P:** pause

The raised terraces and connecting ramps use elevation-aware oblique projection. Root blooms can be detonated for area damage; hearthblooms restore health. The Hanging Orchard hides a root cache. The Verdant Warden has three combat phases, including a late-phase root sweep. Style actions contribute to the run grade.

### Build and tests
`npm test` runs the enemy behavior, 2.5D presentation, combat-data, and chamber-geometry checks. `npm run build` assembles the production site into `dist/`.


## 3.0.1 visual and AI corrections
- Removed the large duplicate control-preview strip below the arena; controls remain available in the Controls dialog.
- Increased enemy pursuit and repositioning so stalkers, archers, brutes, wisps, and the Warden visibly move during active combat.
- Lowered the locomotion animation threshold so side-stepping and close-range repositioning use the run animation instead of appearing idle.


## 3.0.2 combat balance and visual cleanup
- Removed placeholder terrace slabs from the foreground renderer; the authored realm background now remains unobstructed while the underlying elevation/ramp data still drives movement and hit checks.
- Increased regular enemy health and kept realm, room, and Risk Mode scaling. A fresh enemy now survives a basic sword contact, a critical light finisher, and a fully charged heavy critical at the starting damage value.
- Reduced Lyra's starting damage from 23 to 18 and increased the visible hit-stagger window so nonlethal contacts read as proper impacts.
- Held attacks now wait for the current swing animation to finish before starting the next strike, avoiding clipped/overlapping sword swings.
- Added combat-tuning regression checks for single-hit survivability, progression scaling, attack overlap, and scene-overlay cleanup.


## Emberfall 3.2 — Visual and encounter evolution
- Elite variants now read as elite in combat: enlarged presentation, gold aura/rune ring, orbiting motes, a distinct rank label and gold health bars.
- Enemy waves arrive through visible realm-coloured rifts; elite defeats trigger a larger shatter burst and improved shard reward.
- Each realm has its own animated atmospheric layer: verdant fireflies, rising foundry embers, and moonwell crystal motes, with subtle realm colour grading.
- Bosses visibly transition between phases, with a large shockwave, hit-stop/camera response and additional guards. The final phase brings an elite brute reinforcement.
- An in-arena wave HUD shows the active wave, living hostile count, and wave progression.
- Original Lyra and enemy animation atlases, realm backdrops, camera, combat systems, relic progression, and save format are preserved.
