# IRON FRONTIER: OPERATION BLACK SUN — Action Upgrade 1.2

An original, single-player browser run-and-gun campaign inspired by classic side-scrolling action games. This release replaces the earlier procedural stick-figure hero/enemy rendering with detailed cut-out character art, preserves the original 4-stage campaign and combat systems, and uses a high-detail jungle panorama for the opening operation.

## Action and visual changes in 1.2
- Stronger run, jump, slide and recoil poses with dash afterimages.
- Ground slide (hold S and press Shift), one air dash per jump, and close-range melee strike (E).
- Enemy gait, stagger and muzzle-flash feedback are more visible.
- Stage-specific snow, spores, ash and ember particles add atmosphere.

## Visual changes retained from 1.1
- Replaced the old primitive player rendering with a detailed, proportion-correct Rook sprite.
- Replaced human trooper/heavy primitives with an armored soldier sprite and grounded shadows.
- Added muzzle flash and recoil placement aligned to the sprite's rifle.
- Added subtle run bob, hit lean and enemy wind-up treatment.
- Removed vertical stretching from the jungle panorama.
- Tightened HUD widths and title sizing at tablet and desktop sizes to prevent panel collisions.

## Campaign
1. **Jungle Relay** — overgrown communications outpost; boss: The Iron Warden.
2. **Ironworks 09** — industrial weapons plant; boss: Siege Walker MK-II.
3. **Frostline** — frozen research perimeter; boss: Glacier Behemoth.
4. **Black Sun Citadel** — alien fortress; boss: The Eclipse Engine.

Each operation has five enemy-wave triggers, multiple enemy archetypes, a boss encounter, supply drops, and stage progression. Player score and best score persist in browser storage.

## Controls
- **A / D** or **← / →** — move
- **W / S** or **↑ / ↓** — aim vertically
- **Mouse** — aim and hold click to fire
- **J** — fire
- **Space** — jump / double jump
- **Shift** — dash / air dash (once per jump)
- **S + Shift** — ground slide
- **E** — close-range melee strike
- **K** — frag grenade
- **L** — overdrive pulse
- **1 / 2 / 3** — assault rifle / breach shotgun / arc plasma
- **P / Esc** — pause

Mobile touch buttons are included. Best played in a wide 16:9 browser window or fullscreen. The build is designed for keyboard/mouse and includes touch controls.

## Run locally
Open `standalone.html` for the one-file offline version, or open `index.html` with its adjacent `style.css`, `src/`, and `assets/` files.

## Build / test
```bash
npm test
npm run build
```
The deployable static site is in `dist/`.
