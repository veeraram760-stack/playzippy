const fs=require('node:fs');
const path=require('node:path');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'src/game.js'),'utf8');
const css=fs.readFileSync(path.join(root,'style.css'),'utf8');
const checks=[
 ['campaign has four different operations', (js.match(/name:'[^']+'/g)||[]).length>=4],
 ['weapons include rifle, shotgun and plasma', js.includes('BREACH SHOTGUN')&&js.includes('ARC PLASMA')],
 ['enemy classes include trooper, heavy, drone and turret', ['trooper','heavy','drone','turret'].every(x=>js.includes(x))],
 ['boss class supports all four warlords', ['warden','walker','behemoth','engine'].every(x=>js.includes(`'${x}'`))],
 ['grenades and overdrive ability are wired', js.includes('function throwGrenade')&&js.includes('function overdrive')],
 ['stage progression and victory state are wired', js.includes('function advanceStage')&&js.includes("gameState='victory'")],
 ['mobile touch controls are present', html.includes('mobile-controls')&&js.includes('input.touch')],
 ['save data is persisted', js.includes("localStorage.setItem('if_best'")],
 ['canvas and responsive layout exist', html.includes('<canvas id="game"')&&css.includes('@media(max-width:760px)')],
 ['detailed Rook and enemy sprite assets are included', fs.existsSync(path.join(root,'assets/rook.png'))&&fs.existsSync(path.join(root,'assets/enemy.png'))],
 ['jungle stage uses the high-detail panorama', js.includes("art.jungle.src='assets/jungle-panorama.jpg'")],
 ['hero and enemy sprites preserve image proportions', js.includes('art.rook.naturalWidth/art.rook.naturalHeight')&&js.includes('art.soldier.naturalWidth/art.soldier.naturalHeight')],
 ['HUD has a compact tablet layout', css.includes('@media(max-width:1100px)')&&css.includes('hud-top-center strong{font-size:clamp(17px')]
];
let failed=0; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);if(!ok)failed++;}
if(failed)process.exit(1);console.log(`\n${checks.length}/${checks.length} checks passed.`);
