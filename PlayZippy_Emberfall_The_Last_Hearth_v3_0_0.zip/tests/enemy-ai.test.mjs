import fs from 'node:fs';
import vm from 'node:vm';
const src=fs.readFileSync('./src/main.js','utf8');
function getFn(name){const start=src.indexOf(`function ${name}(`);if(start<0)throw Error(`missing ${name}`);let i=src.indexOf('{',start),depth=0,inStr=null,escape=false;for(;i<src.length;i++){const c=src[i];if(inStr){if(escape)escape=false;else if(c==='\\')escape=true;else if(c===inStr)inStr=null;continue;}if(c==='"'||c==="'"||c==='`'){inStr=c;continue;}if(c==='{')depth++;else if(c==='}'&&--depth===0)return src.slice(start,i+1);}throw Error('unclosed fn '+name);}
const calls={projectiles:[],damages:[],fx:[],particles:[],toasts:[]};
const sandbox={
  Math,TAU:Math.PI*2, player:{x:640,y:360,r:17,vx:0,vy:0}, game:{stage:0,roomTime:1,dodgeStreak:0,chamberLayout:null},
  surfaceHeightAt:()=>0,
  clamp:(v,a,b)=>Math.max(a,Math.min(b,v)), rand:(a,b)=>a+(b-a)*.37,
  particle:(...a)=>calls.particles.push(a), spawnProjectile:(...a)=>calls.projectiles.push(a),
  damagePlayer:(...a)=>calls.damages.push(a),addCombatFX:(...a)=>calls.fx.push(a),
  burst:(...a)=>calls.fx.push(['burst',...a]),showToast:(...a)=>calls.toasts.push(a)
};
vm.createContext(sandbox);
vm.runInContext(getFn('finishEnemyMotion')+'\n'+getFn('updateEnemy'),sandbox);
const make=(kind,x,y,extra={})=>({kind,x,y,r:kind==='brute'?27:kind==='boss'?62:19,hp:100,maxHp:100,speed:kind==='brute'?44:kind==='archer'?58:80,damage:10,attackCd:0.01,state:'idle',stateT:0,flash:0,seed:.4,anim:0,chargeVX:0,chargeVY:0,knockVX:0,knockVY:0,hitStun:0,aimX:x,aimY:y,stepTimer:0,strafeTimer:.8,strafeDir:1,facingSign:1,windupDuration:.8,attackApplied:false,...extra});
function update(e,n=1,dt=.05){for(let i=0;i<n;i++)sandbox.updateEnemy(e,dt);}
// Stalker closes distance, starts a visible melee state, and damages once when its swipe lands.
sandbox.player={x:370,y:300,r:17};const stalker=make('stalker',220,300);update(stalker,25,.05);if(stalker.x<=220)throw Error('stalker did not pursue player');stalker.x=350;stalker.y=300;stalker.attackCd=0;update(stalker,1,.016);if(stalker.state!=='melee')throw Error('stalker did not enter melee attack');update(stalker,8,.05);if(!calls.damages.length)throw Error('stalker melee never hit');
// Archer repositions, telegraphs, and releases a projectile.
calls.projectiles.length=0;sandbox.player={x:620,y:300,r:17};const archer=make('archer',350,300);update(archer,1,.016);if(archer.state!=='windup')throw Error('archer did not wind up');update(archer,20,.05);if(!calls.projectiles.length)throw Error('archer did not fire');
// Brute telegraphs, charges, and enters recovery.
sandbox.player={x:620,y:300,r:17};const brute=make('brute',500,300);update(brute,1,.016);if(brute.state!=='windup')throw Error('brute did not wind up');update(brute,20,.05);if(!['charge','recover','idle'].includes(brute.state))throw Error('brute charge state missing');
// Boss cycles between telegraph, charge/storm and recovery.
sandbox.player={x:620,y:300,r:17};const boss=make('boss',500,300,{boss:true,phase:1,attackCd:0.01});update(boss,1,.016);if(boss.state!=='windup')throw Error('boss did not telegraph');update(boss,25,.05);if(!['burst','recover','idle'].includes(boss.state))throw Error('boss attack sequence missing');
console.log('Enemy AI checks passed: stalker melee, archer ranged release, brute charge/recovery, and guardian attack sequence.');
