# Emberfall: The Last Hearth — v4.0.0 Third-Person Campaign

Emberfall v4.0 replaces the former elevated 2D arena renderer with a Babylon.js third-person 3D action runtime. Lyra is followed from behind by a controllable chase camera. Enemy combatants use 3D humanoid rigs, telegraphed attacks, strike and recovery states, stagger, knockback, projectiles and boss phases.

## Campaign

The campaign contains sixteen named battlefields across four realms:

1. **Verdant Hollow** — Moss Gate, Rootbound Chapel, Hanging Orchard, Rootbound Warden.
2. **Ashen Foundry** — Cinder Walk, Broken Furnace, Ironworks Depths, Ashen Colossus.
3. **Moonwell Keep** — Silver Approach, Flooded Archive, Mirror Court, Hollow Crown.
4. **Starfall Bastion** — Fallen Causeway, Astral Forge, Eclipse Sanctum, Starfall Regent.

Each realm has its own lighting, fog, materials, architecture, hazards and arena layout. Standard battlefields run successive enemy waves. The fourth battlefield of each realm is a guardian encounter. Clearing the room activates the gate to the next battlefield. Campaign progress is saved locally in the browser.

## Combat

- **WASD / Arrow keys** — camera-relative movement.
- **Right mouse drag** — orbit the third-person camera.
- **Left mouse / J** — three-strike sword combo.
- **K** — heavy sword strike.
- **Space** — evasive dodge with a short invulnerability window.
- **Shift** — jump / vault.
- **F** — lock on to the nearest hostile.
- **Q** — Solar Nova area attack.
- **V** — Rift Step, a fast gap-closing phase dash.
- **T** — Aether Snare, an area slow and damage field.
- **E** — enter an unlocked realm gate.
- **Esc** — pause.

On touch devices, a movement stick and action buttons appear automatically.

## Enemy roster

Thornlings, Root Stalkers, Ashen Archers, Iron Brutes, Veil Wisps, Shade Assassins, Astral Sentinels and four realm guardians. Melee enemies telegraph before committing to a strike; ranged enemies fire projectiles; assassins phase-step; heavy enemies use slower, wider attacks; bosses transition through three health phases.

## Build and tests

```bash
npm test
npm run build
```

The project loads the Babylon.js browser engine from the official CDN, so an internet connection is required when launching the game. The seven automated tests are source-level regression checks for the campaign, controls, enemy AI, combat powers and 3D presentation. They do not replace interactive browser playtesting.

## Visual and gameplay scope

This release moves combat into a 3D third-person camera and replaces the top-down presentation with modeled 3D characters, realm geometry, lighting, shadows, bloom and hit effects. Character and environment models are procedural game assets; this is not a photorealistic AAA character scan or motion-capture production.
