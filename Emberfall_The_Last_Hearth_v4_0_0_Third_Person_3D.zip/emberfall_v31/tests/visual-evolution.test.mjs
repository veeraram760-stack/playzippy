import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const src = await readFile(new URL('../src/main.js', import.meta.url), 'utf8');
for (const token of ['DefaultRenderingPipeline','bloomEnabled=true','ShadowGenerator','PBRMaterial','function createHero()', 'function makeEnemyModel(', 'function burst(', 'function ringBurst(', 'function updateCamera(']) assert.ok(src.includes(token), `Missing 3D presentation component ${token}`);
assert.ok(!src.includes("const ctx = canvas.getContext('2d')"), 'Legacy flat canvas renderer is still used');
console.log('PASS 3D visual runtime: PBR meshes, shadows, bloom, particles and third-person camera');
