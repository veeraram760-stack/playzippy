import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const src = await readFile(new URL('../src/main.js', import.meta.url), 'utf8');
for (const token of ['function waveBlueprint(stage,room,wave)', 'function addWave()', 'campaign.wave<total', "if(room===3){return wave===0?['boss','wisp','thornling']", "['assassin','archer']", 'function setPortalReady()']) assert.ok(src.includes(token), `Missing encounter flow ${token}`);
console.log('PASS encounters: sequential waves, boss chambers, reinforcements and exit unlock');
