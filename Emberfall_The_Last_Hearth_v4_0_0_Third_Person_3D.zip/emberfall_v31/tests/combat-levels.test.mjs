import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const src = await readFile(new URL('../src/main.js', import.meta.url), 'utf8');
for (const realm of ['VERDANT HOLLOW','ASHEN FOUNDRY','MOONWELL KEEP','STARFALL BASTION']) assert.ok(src.includes(realm), `Missing realm ${realm}`);
for (const token of ['function buildLevel(stage,room)', 'function beginLevel()', 'function advanceLevel()', 'function setPortalReady()', 'HANGING ORCHARD', 'BROKEN FURNACE', 'FLOODED ARCHIVE', 'ECLIPSE SANCTUM']) assert.ok(src.includes(token), `Missing level system ${token}`);
assert.ok(src.includes('levelConfigs[stage]'), 'Realm chamber data is missing');
console.log('PASS campaign levels: four realms, sixteen named arenas and unlock progression');
