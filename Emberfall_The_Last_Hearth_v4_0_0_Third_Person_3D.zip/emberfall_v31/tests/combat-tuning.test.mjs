import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const src = await readFile(new URL('../src/main.js', import.meta.url), 'utf8');
for (const token of ['function beginAttack(kind)', 'function tryAttackHit(kind)', 'function dodge()', 'function jump()', 'function solar()', 'function riftStep()', 'function snare()', 'player.invuln=.58', 'function damageEnemy(e,amount,knock=1.1']) assert.ok(src.includes(token), `Missing combat feature ${token}`);
assert.ok(src.includes("player.combo=player.comboWindow>0?player.combo%3+1:1"), 'Three-hit combo chaining is missing');
console.log('PASS combat tuning: combo chain, heavy strike, dodge i-frames, jump and three powers');
