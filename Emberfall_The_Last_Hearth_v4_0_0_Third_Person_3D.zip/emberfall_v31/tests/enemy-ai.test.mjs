import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const src = await readFile(new URL('../src/main.js', import.meta.url), 'utf8');
for (const token of ['function updateEnemy(', "e.state==='approach'", "e.state==='windup'", "e.state==='strike'", "e.state==='recover'", 'enemyPhaseStep(e)', 'enemyHitPlayer(e,', 'e.stun', 'e.slow']) assert.ok(src.includes(token), `Missing enemy combat behaviour: ${token}`);
for (const type of ['thornling','stalker','archer','brute','wisp','assassin','sentinel','boss']) assert.ok(src.includes(`${type}:`), `Missing enemy archetype ${type}`);
console.log('PASS enemy AI: multiple archetypes, telegraphs, strike/recover, stun and phase-step');
