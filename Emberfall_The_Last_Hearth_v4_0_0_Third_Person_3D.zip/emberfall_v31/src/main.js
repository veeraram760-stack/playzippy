/* Emberfall: The Last Hearth — third-person campaign runtime v4.0
 * Babylon.js / procedural 3D arena campaign.  No flat top-down sprites are used in combat.
 */
(() => {
  'use strict';
  const B = window.BABYLON;
  const $ = (id) => document.getElementById(id);
  const canvas = $('renderCanvas');
  if (!B || !canvas) {
    const loading = $('loading');
    if (loading) loading.innerHTML = '<b>3D ENGINE UNAVAILABLE</b><span>Check your connection and refresh to load Babylon.js.</span>';
    return;
  }

  const engine = new B.Engine(canvas, true, { antialias:true, stencil:true, preserveDrawingBuffer:false, powerPreference:'high-performance', adaptToDeviceRatio:true });
  engine.setHardwareScalingLevel(Math.max(1, 1 / Math.min(window.devicePixelRatio || 1, 1.5)));
  const scene = new B.Scene(engine);
  scene.collisionsEnabled = false;
  scene.clearColor = new B.Color4(.035,.055,.047,1);
  scene.fogMode = B.Scene.FOGMODE_EXP2;
  scene.fogDensity = .009;
  scene.fogColor = new B.Color3(.11,.16,.12);

  const camera = new B.FreeCamera('Lyra_ThirdPerson_Camera', new B.Vector3(0,4,-8), scene);
  camera.fov = .82; camera.minZ=.08; camera.maxZ=220; camera.inputs.clear(); camera.speed=0;
  const hemi = new B.HemisphericLight('World_Ambient',new B.Vector3(0,1,0),scene);
  hemi.intensity=.72; hemi.diffuse=new B.Color3(.8,.85,.79); hemi.groundColor=new B.Color3(.18,.2,.16);
  const sun = new B.DirectionalLight('Cinematic_Key',new B.Vector3(-.38,-1,.42),scene);
  sun.position.set(-18,30,-22); sun.intensity=1.5; sun.diffuse=new B.Color3(1,.86,.68);
  const shadowGen = new B.ShadowGenerator(1536,sun);
  shadowGen.usePercentageCloserFiltering=true; shadowGen.filteringQuality=B.ShadowGenerator.QUALITY_MEDIUM; shadowGen.bias=.00045; shadowGen.normalBias=.025;
  const pipeline = new B.DefaultRenderingPipeline('Emberfall_Cinematic_Render',true,scene,[camera]);
  pipeline.fxaaEnabled=true; pipeline.bloomEnabled=true; pipeline.bloomThreshold=.78; pipeline.bloomWeight=.24; pipeline.bloomKernel=42;
  pipeline.imageProcessingEnabled=true; pipeline.imageProcessing.toneMappingEnabled=true; pipeline.imageProcessing.exposure=1.08; pipeline.imageProcessing.contrast=1.12;

  const TAU=Math.PI*2;
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const lerp=(a,b,t)=>a+(b-a)*t;
  const rand=(a,b)=>a+Math.random()*(b-a);
  const choose=(a)=>a[Math.floor(Math.random()*a.length)];
  const v3=(x=0,y=0,z=0)=>new B.Vector3(x,y,z);
  const c3=(hex)=>B.Color3.FromHexString(hex);
  const dist2=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
  const forward=(yaw)=>new B.Vector3(Math.sin(yaw),0,Math.cos(yaw));
  const angleDiff=(a,b)=>Math.atan2(Math.sin(b-a),Math.cos(b-a));
  const dampAngle=(a,b,k,dt)=>a+angleDiff(a,b)*(1-Math.exp(-k*dt));
  const SAVE_KEY='playzippy_emberfall_3d_campaign_v4';
  let saved={}; try{saved=JSON.parse(localStorage.getItem(SAVE_KEY)||'{}')||{};}catch{}

  const realms=[
    {name:'VERDANT HOLLOW',tag:'CHAPTER I · THE ROOTBOUND OATH',desc:'A forest swallowed by a living blight.',objective:'Break the root seals',sky:'#253d31',fog:'#24392f',ground:'#354535',stone:'#777765',trim:'#b2a17b',glow:'#b8dc83',hot:'#f1bd6d',architecture:'forest',levels:['Moss Gate','Rootbound Chapel','Hanging Orchard','The Rootbound Warden']},
    {name:'ASHEN FOUNDRY',tag:'CHAPTER II · THE EMBER CROWN',desc:'A kingdom of black iron and sleeping furnaces.',objective:'Quench the furnace heart',sky:'#452c28',fog:'#422b27',ground:'#44342f',stone:'#5e5148',trim:'#a07a61',glow:'#ff9c59',hot:'#ff693e',architecture:'forge',levels:['Cinder Walk','Broken Furnace','Ironworks Depths','The Ashen Colossus']},
    {name:'MOONWELL KEEP',tag:'CHAPTER III · THE DROWNED VEIL',desc:'A drowned palace caught between moonlight and shadow.',objective:'Shatter the Hollow Crown',sky:'#292f4e',fog:'#343b5a',ground:'#3c4561',stone:'#767b9a',trim:'#b4bad0',glow:'#c1d8ff',hot:'#8ee7e8',architecture:'moon',levels:['Silver Approach','Flooded Archive','Mirror Court','The Hollow Crown']},
    {name:'STARFALL BASTION',tag:'CHAPTER IV · THE LAST SKY',desc:'A fortress suspended above a broken sky.',objective:'Defeat the Starfall Regent',sky:'#151d3d',fog:'#202b4b',ground:'#222e4b',stone:'#485b7e',trim:'#9eb9d9',glow:'#8de9ff',hot:'#ce9aff',architecture:'astral',levels:['Fallen Causeway','Astral Forge','Eclipse Sanctum','The Starfall Regent']}
  ];
  const enemyProfiles={
    thornling:{name:'THORNLING',hp:125,speed:3.15,damage:12,range:2.55,wind:.62,recover:.82,scale:1,kind:'melee',xp:24,color:'#526b48',dark:'#293b2b',glow:'#cf9b53'},
    stalker:{name:'ROOT STALKER',hp:170,speed:3.9,damage:17,range:2.7,wind:.55,recover:.7,scale:1.08,kind:'melee',xp:32,color:'#384e3b',dark:'#172b22',glow:'#d07b48'},
    archer:{name:'ASHEN ARCHER',hp:105,speed:2.6,damage:14,range:9,wind:.82,recover:1.05,scale:.94,kind:'ranged',xp:28,color:'#65473a',dark:'#2c2527',glow:'#ff9b5d'},
    brute:{name:'IRON BRUTE',hp:310,speed:1.8,damage:28,range:3.2,wind:1.05,recover:1.3,scale:1.42,kind:'heavy',xp:58,color:'#68604e',dark:'#282a28',glow:'#ff784d'},
    wisp:{name:'VEIL WISP',hp:92,speed:3.1,damage:13,range:10,wind:.7,recover:.95,scale:.8,kind:'caster',xp:34,color:'#526d89',dark:'#252b49',glow:'#b5e5ff'},
    assassin:{name:'SHADE ASSASSIN',hp:230,speed:4.8,damage:22,range:2.5,wind:.46,recover:.58,scale:1.02,kind:'assassin',xp:72,color:'#34334c',dark:'#171927',glow:'#d59bff'},
    sentinel:{name:'ASTRAL SENTINEL',hp:265,speed:2.75,damage:22,range:3,wind:.76,recover:.9,scale:1.2,kind:'heavy',xp:66,color:'#405a76',dark:'#182640',glow:'#8de9ff'},
    boss:{name:'REALM GUARDIAN',hp:1150,speed:2.35,damage:30,range:4,wind:.9,recover:1.05,scale:1.9,kind:'boss',xp:230,color:'#455744',dark:'#202c29',glow:'#ff9859'}
  };
  const levelConfigs=[
    [{name:'MOSS GATE',layout:'gate'},{name:'ROOTBOUND CHAPEL',layout:'chapel'},{name:'HANGING ORCHARD',layout:'orchard'},{name:'ROOTBOUND WARDEN',layout:'boss'}],
    [{name:'CINDER WALK',layout:'walk'},{name:'BROKEN FURNACE',layout:'furnace'},{name:'IRONWORKS DEPTHS',layout:'depths'},{name:'ASHEN COLOSSUS',layout:'boss'}],
    [{name:'SILVER APPROACH',layout:'approach'},{name:'FLOODED ARCHIVE',layout:'archive'},{name:'MIRROR COURT',layout:'court'},{name:'HOLLOW CROWN',layout:'boss'}],
    [{name:'FALLEN CAUSEWAY',layout:'causeway'},{name:'ASTRAL FORGE',layout:'astralforge'},{name:'ECLIPSE SANCTUM',layout:'sanctum'},{name:'STARFALL REGENT',layout:'boss'}]
  ];

  // ---------- Materials, geometry helpers, and procedural character rigs ----------
  function mat(name,color,rough=.78,metal=.05,emissive=null){
    const m=new B.PBRMaterial(name,scene); m.albedoColor=c3(color); m.roughness=rough; m.metallic=metal;
    if(emissive)m.emissiveColor=c3(emissive); return m;
  }
  const M={
    skin:mat('Warm_Skin','#bd927a',.84), hair:mat('Dark_Hair','#211d21',.9), leather:mat('Deep_Leather','#31483c',.72,.08),
    cloth:mat('Burgundy_Cloak','#612d3b',.9), cloth2:mat('Cloak_Highlight','#8b4350',.85), bronze:mat('Aged_Bronze','#9d7a4a',.34,.72),
    gold:mat('Runic_Gold','#e3c16c',.3,.75,'#a77a32'), steel:mat('Blade_Steel','#b9c8c8',.2,.88), steelDark:mat('Dark_Steel','#39464a',.36,.7),
    enemyStone:mat('Root_Stone','#4c5b46',.88), enemyArmor:mat('Root_Iron','#3b4038',.56,.58), eye:mat('Ember_Eyes','#ff9a48',.22,.05,'#ff612d'),
    bone:mat('Old_Bone','#c3b28f',.9), aura:mat('Solar_Aura','#eab85e',.32,.1,'#e8a843'),
    white:mat('Mist_White','#c8e8eb',.2,.05,'#8bd8e9')
  };
  function addShadow(mesh,receive=true){if(!mesh)return;shadowGen.addShadowCaster(mesh);mesh.receiveShadows=receive;return mesh;}
  function node(name,parent=null,pos=null){const n=new B.TransformNode(name,scene);if(parent)n.parent=parent;if(pos)n.position.copyFrom(v3(...pos));return n;}
  function box(name,parent,pos,size,material,rotation=null){const m=B.MeshBuilder.CreateBox(name,{width:size[0],height:size[1],depth:size[2]},scene);m.parent=parent||null;m.position.copyFrom(v3(...pos));m.scaling.set(1,1,1);if(rotation)m.rotation.set(...rotation);m.material=material;addShadow(m);return m;}
  function sphere(name,parent,pos,scale,material,segments=18){const m=B.MeshBuilder.CreateSphere(name,{segments,diameter:1},scene);m.parent=parent||null;m.position.copyFrom(v3(...pos));m.scaling.set(...scale);m.material=material;addShadow(m);return m;}
  function cylinder(name,parent,pos,height,top,bottom,material,tess=12,rotation=null){const m=B.MeshBuilder.CreateCylinder(name,{height,diameterTop:top,diameterBottom:bottom,tessellation:tess},scene);m.parent=parent||null;m.position.copyFrom(v3(...pos));if(rotation)m.rotation.set(...rotation);m.material=material;addShadow(m);return m;}
  function torus(name,parent,pos,diameter,thickness,material){const m=B.MeshBuilder.CreateTorus(name,{diameter,thickness,tessellation:48},scene);m.parent=parent||null;m.position.copyFrom(v3(...pos));m.material=material;m.isPickable=false;return m;}
  function capsule(name,parent,length,radius,material){const m=B.MeshBuilder.CreateCapsule(name,{height:length+radius*2,radius, tessellation:12, subdivisions:4},scene);m.parent=parent;m.rotation.x=0;m.position.y=-length*.48;m.material=material;addShadow(m);return m;}
  function limbRig(parent,name,side,upper,lower,material,accent){
    const shoulder=node(name+'_shoulder',parent,[side*.36,1.85,0]);sphere(name+'_pauldron',shoulder,[0,0,0],[.31,.28,.33],accent||material,14);
    const upperNode=node(name+'_upper',shoulder,[0,-.08,0]);capsule(name+'_upper_mesh',upperNode,.48,.17,material);
    const elbow=node(name+'_elbow',upperNode,[0,-.55,.01]);sphere(name+'_elbow_joint',elbow,[0,0,0],[.18,.17,.18],accent||material,12);
    capsule(name+'_forearm',elbow,.43,.135,material);
    sphere(name+'_hand',elbow,[0,-.52,.05],[.16,.13,.17],M.skin,12);
    return {shoulder,upper:upperNode,elbow,side};
  }
  function makeSword(hand,owner='Lyra'){
    const sword=node(owner+'_Solar_Edge',hand,[0,-.52,.02]);
    cylinder(owner+'_sword_grip',sword,[0,-.13,0],.28,.075,.075,M.leather,10);
    box(owner+'_crossguard',sword,[0,-.28,0],[.46,.075,.1],M.gold);
    box(owner+'_blade',sword,[0,.37,.005],[.13,.92,.065],M.steel);
    const tip=B.MeshBuilder.CreateCylinder(owner+'_blade_tip',{height:.2,diameterTop:0,diameterBottom:.13,tessellation:4},scene);tip.parent=sword;tip.position.y=.93;tip.rotation.x=Math.PI/2;tip.material=M.steel;addShadow(tip);
    box(owner+'_blade_rune',sword,[0,.37,.042],[.025,.67,.012],M.gold);
    sphere(owner+'_pommel',sword,[0,-.31,0],[.09,.09,.09],M.gold,10);
    return sword;
  }
  function createHero(){
    const root=node('Lyra_Root',null,[0,0,-12]);
    const facing=node('Lyra_Skeleton_Root',root);
    sphere('Lyra_Pelvis',facing,[0,1.02,0],[.42,.3,.32],M.leather,20);
    // layered waist guards and skirt panels
    box('Lyra_Belt',facing,[0,1.12,.01],[.9,.14,.57],M.bronze);
    sphere('Lyra_Buckle',facing,[0,1.12,.32],[.12,.12,.045],M.gold,14);
    for(let s of [-1,1])box('Lyra_Skirt_Panel_'+s,facing,[s*.24,.82,-.02],[.32,.55,.43],M.cloth,[0,0,s*-.12]);
    sphere('Lyra_Chest',facing,[0,1.52,0],[.49,.59,.34],M.leather,24);
    sphere('Lyra_Breastplate',facing,[0,1.57,.255],[.42,.46,.12],M.bronze,20);
    box('Lyra_Chest_Rune',facing,[0,1.57,.375],[.07,.34,.025],M.gold);
    sphere('Lyra_Neck',facing,[0,1.98,0],[.16,.19,.16],M.skin,16);
    sphere('Lyra_Face',facing,[0,2.2,.035],[.25,.33,.23],M.skin,24);
    sphere('Lyra_Hair_Back',facing,[0,2.3,-.105],[.29,.4,.25],M.hair,18);
    sphere('Lyra_Hair_Cap',facing,[0,2.47,.035],[.28,.18,.24],M.hair,18);
    sphere('Lyra_Hair_Tail',facing,[0,2.07,-.29],[.13,.5,.13],M.hair,16).rotation.x=-.18;
    for(const s of [-1,1]){sphere('Lyra_Eye_'+s,facing,[s*.095,2.23,.24],[.026,.031,.014],M.steelDark,10);sphere('Lyra_Eyebrow_'+s,facing,[s*.095,2.29,.24],[.06,.018,.015],M.hair,10);}
    // asymmetric shoulder and forearm plates
    const left=limbRig(facing,'Lyra_Left_Arm',-1,.48,.43,M.leather,M.bronze);
    const right=limbRig(facing,'Lyra_Right_Arm',1,.48,.43,M.leather,M.bronze);
    sphere('Lyra_Left_Bracer',left.elbow,[0,-.27,.02],[.17,.23,.19],M.bronze,14);
    sphere('Lyra_Right_Bracer',right.elbow,[0,-.27,.02],[.17,.23,.19],M.bronze,14);
    const sword=makeSword(right.elbow,'Lyra');
    const legs=[];
    for(const s of [-1,1]){
      const hip=node('Lyra_Leg_Hip_'+s,facing,[s*.22,.94,0]);sphere('Lyra_Thigh_Guard_'+s,hip,[0,-.2,0],[.23,.36,.25],M.leather,16);capsule('Lyra_Thigh_'+s,hip,.52,.16,M.leather);
      const knee=node('Lyra_Knee_'+s,hip,[0,-.57,0]);sphere('Lyra_Knee_Plate_'+s,knee,[0,0,.05],[.19,.15,.21],M.bronze,14);capsule('Lyra_Shin_'+s,knee,.45,.135,M.leather);
      box('Lyra_Boot_'+s,knee,[0,-.46,.11],[.32,.2,.48],M.steelDark);legs.push({hip,knee,side:s});
    }
    // Cloth cape made from articulated overlapping strips rather than a flat billboard.
    const cape=node('Lyra_Cape_Rig',facing,[0,1.82,-.22]);
    for(let i=0;i<5;i++){const strip=box('Lyra_Cape_Strip_'+i,cape,[(i-2)*.13,-.48,-.04],[.19,1.05,.045],i%2?M.cloth:M.cloth2,[.16,0,(i-2)*.035]);strip.material.backFaceCulling=false;}
    const aura=sphere('Lyra_Hearth_Aura',facing,[0,1.15,-.02],[.82,1.16,.68],M.aura,20);aura.material.alpha=.08;aura.material.transparencyMode=B.Material.MATERIAL_ALPHABLEND;
    return {root,facing,left,right,sword,legs,cape,aura,walk:0,hitMeshes:facing.getChildMeshes()};
  }
  const hero=createHero();

  function makeEnemyModel(type,scale=1){
    const p=enemyProfiles[type]||enemyProfiles.thornling;
    const root=node(type+'_Root');root.scaling.setAll(scale);const facing=node(type+'_Facing',root);
    const bodyMat=mat(type+'_Body_'+Math.random().toString(36).slice(2),p.color,.82,.04);
    const darkMat=mat(type+'_Armor_'+Math.random().toString(36).slice(2),p.dark,.48,.56);
    const glowMat=mat(type+'_Core_'+Math.random().toString(36).slice(2),p.glow,.25,.08,p.glow);
    sphere(type+'_Pelvis',facing,[0,1.03,0],[.45,.32,.34],bodyMat,18);
    sphere(type+'_Torso',facing,[0,1.58,0],[.56,.63,.4],bodyMat,20);
    sphere(type+'_Chest_Armor',facing,[0,1.65,.3],[.48,.4,.13],darkMat,18);
    sphere(type+'_Core',facing,[0,1.62,.44],[.16,.19,.07],glowMat,14);
    const head=node(type+'_Head',facing,[0,2.32,0]);
    sphere(type+'_Skull',head,[0,.03,.02],[.32,.36,.3],bodyMat,18);
    sphere(type+'_Face_Mask',head,[0,-.035,.275],[.31,.18,.07],darkMat,14);
    for(const s of [-1,1]){
      sphere(type+'_Eye_'+s,head,[s*.12,.04,.34],[.055,.045,.035],glowMat,10);
      const horn=cylinder(type+'_Horn_'+s,head,[s*.24,.39,-.01],.65,.19,.025,M.bone,8,[0,0,s*-.48]);
    }
    const arms=[];
    for(const s of [-1,1]){
      const shoulder=node(type+'_Arm_'+s,facing,[s*.58,1.9,0]);sphere(type+'_Shoulder_'+s,shoulder,[0,0,0],[.3,.29,.31],darkMat,14);
      capsule(type+'_Upper_'+s,shoulder,.48,.16,bodyMat);
      const elbow=node(type+'_Elbow_'+s,shoulder,[s*.08,-.53,0]);sphere(type+'_Elbow_Joint_'+s,elbow,[0,0,0],[.17,.16,.17],darkMat,12);capsule(type+'_Forearm_'+s,elbow,.43,.14,bodyMat);sphere(type+'_Fist_'+s,elbow,[0,-.49,.05],[.18,.16,.19],darkMat,12);arms.push({shoulder,elbow,side:s});
    }
    const legs=[];
    for(const s of [-1,1]){
      const hip=node(type+'_Leg_'+s,facing,[s*.25,.9,0]);capsule(type+'_Thigh_'+s,hip,.52,.17,bodyMat);sphere(type+'_Knee_'+s,hip,[0,-.56,.02],[.18,.16,.18],darkMat,12);capsule(type+'_Shin_'+s,hip,.48,.13,bodyMat).position.y=-.82;box(type+'_Foot_'+s,hip,[0,-1.14,.12],[.31,.2,.43],darkMat);legs.push({hip,side:s});
    }
    if(type==='archer'||type==='assassin'||type==='sentinel'){
      // weapons in the right hand make ranged/elite silhouettes distinct.
      const weapon=node(type+'_Weapon',arms[1].elbow,[0,-.57,.05]);
      if(type==='archer'){
        const bow=torus(type+'_Bow',weapon,[0,.15,0],.8,.045,M.bone);bow.rotation.z=Math.PI/2;
        cylinder(type+'_Bow_Grip',weapon,[0,.15,0],.26,.06,.06,darkMat,8);
      }else{
        box(type+'_Short_Blade',weapon,[0,.18,.08],[.09,.64,.05],M.steel);box(type+'_Blade_Guard',weapon,[0,-.13,.08],[.31,.06,.07],M.gold);
      }
    }
    if(type==='brute'||type==='boss'){
      for(let i=0;i<3;i++){const barb=cylinder(type+'_Back_Spike_'+i,facing,[(i-1)*.27,2.04,-.34],.75,.24,.03,M.bone,7,[-.65,0,(i-1)*.15]);}
    }
    const aura=torus(type+'_Telegraph',root,[0,.06,0],2.35,.045,glowMat);aura.rotation.x=Math.PI/2;aura.isVisible=false;
    const meshes=facing.getChildMeshes();
    return {root,facing,arms,legs,head,aura,glowMat,bodyMat,darkMat,meshes,walk:0,scale};
  }

  // ---------- Realm architecture: 16 distinct combat spaces ----------
  let levelRoot=null, groundMat=null, portal=null, hazardMeshes=[];
  const obstacles=[];
  const realmMaterials={};
  function realmMat(stage,slot){
    const p=realms[stage];const key=stage+'_'+slot;
    if(realmMaterials[key])return realmMaterials[key];
    const colors={floor:[p.ground,.94,.02],stone:[p.stone,.9,.05],trim:[p.trim,.5,.34],glow:[p.glow,.25,.08],hot:[p.hot,.27,.14]};
    const d=colors[slot]||colors.stone;return realmMaterials[key]=mat('Realm_'+key,d[0],d[1],d[2],slot==='glow'||slot==='hot'?d[0]:null);
  }
  function addSolid(mesh,radius=1.1,height=2){obstacles.push({x:mesh.position.x,z:mesh.position.z,r:radius,h:height});return mesh;}
  function decorateTree(parent,x,z,s=1,stage=0){
    const bark=realmMat(stage,'stone'),leaf=mat('Canopy_'+stage+'_'+Math.random().toString(36).slice(2),stage===0?'#254b35':'#403f42',.96),top=mat('Canopy_Tip_'+Math.random().toString(36).slice(2),stage===0?'#486a44':'#6a4a3b',.98);
    const r=node('Realm_Tree',parent,[x,0,z]);cylinder('Tree_Trunk',r,[0,1.8*s,0],3.6*s,.35*s,.52*s,bark,9);
    for(let k=0;k<3;k++){const cone=cylinder('Tree_Crown_'+k,r,[0,(2.35+k*.82)*s,0],2.6*s,.04*s,(2.5-k*.48)*s,k===2?top:leaf,9);}
    addSolid(r,.65*s,4*s);return r;
  }
  function addPillar(parent,x,z,h=4,stage=0){const base=realmMat(stage,'stone'),trim=realmMat(stage,'trim');const r=node('Ancient_Pillar',parent,[x,0,z]);cylinder('Pillar_Base',r,[0,.16,0],.32,1.45,1.55,trim,10);cylinder('Pillar_Shaft',r,[0,h/2,0],h,1.02,.86,base,10);cylinder('Pillar_Cap',r,[0,h+.15,0],.3,1.38,1.38,trim,10);addSolid(r,.72,h+1);return r;}
  function addCrystal(parent,x,z,size,stage){const glow=realmMat(stage,'glow'),base=realmMat(stage,'stone');const c=cylinder('Realm_Crystal',parent,[x,size*.55,z],size*1.1,.04,size*.65,glow,6,[0,0,rand(-.12,.12)]);cylinder('Crystal_Root',parent,[x,.18,z],.36,.66,.72,base,8);addSolid({position:{x,z}},.45,size);return c;}
  function buildLevel(stage,room){
    if(levelRoot)levelRoot.dispose(); obstacles.length=0;hazardMeshes=[];portal=null;
    levelRoot=node('Realm_'+stage+'_Level_'+room);
    const p=realms[stage],cfg=levelConfigs[stage][room];scene.clearColor=c3(p.sky).toColor4?c3(p.sky).toColor4(1):new B.Color4(c3(p.sky).r,c3(p.sky).g,c3(p.sky).b,1);scene.fogColor=c3(p.fog);scene.fogDensity=stage===2?.012:.008;
    hemi.diffuse=c3(stage===0?'#b8d0b0':stage===1?'#d4a18a':stage===2?'#aebbe7':'#9bbbe7');sun.diffuse=c3(stage===1?'#ffad72':stage===2?'#c9d7ff':stage===3?'#a7dfff':'#ffe0ad');sun.intensity=stage===1?1.75:1.4;
    const floor=box('Battlefield_Floor',levelRoot,[0,-.28,0],[46,.55,46],realmMat(stage,'floor'));floor.receiveShadows=true;
    // Arena border and level-specific wall pieces.
    for(const s of [-1,1]){
      box('Arena_Wall_X_'+s,levelRoot,[s*22,1,0],[.9,2.3,45],realmMat(stage,'stone'));
      box('Arena_Wall_Z_'+s,levelRoot,[0,1,s*22],[45,2.3,.9],realmMat(stage,'stone'));
    }
    // Surface tile joints and floor inlays give the arena scale and readable traversal.
    for(let i=-4;i<=4;i++){
      const line=box('Floor_Inlay_X_'+i,levelRoot,[i*4.4,.005,0],[.045,.015,41],realmMat(stage,'trim'));line.isPickable=false;
      const line2=box('Floor_Inlay_Z_'+i,levelRoot,[0,.008,i*4.4],[41,.015,.045],realmMat(stage,'trim'));line2.isPickable=false;
    }
    const layout=cfg.layout;
    if(stage===0){
      for(const [x,z,s] of [[-18,-17,1.55],[18,-17,1.45],[-19,14,1.7],[19,13,1.5],[-14,20,1.25],[14,20,1.2]])decorateTree(levelRoot,x,z,s,stage);
      if(layout==='chapel'||layout==='boss'){
        for(const x of [-8,-4,4,8]){addPillar(levelRoot,x,7,5.5,stage);}
        box('Chapel_Altar',levelRoot,[0,.65,12],[5,1.3,2],realmMat(stage,'trim'));addCrystal(levelRoot,0,13,1.45,stage);
      }
      if(layout==='orchard'){
        for(let i=0;i<6;i++){const x=(i%2?1:-1)*(8+Math.floor(i/2)*2.2),z=-8+Math.floor(i/2)*7;const branch=box('Fallen_Root_Bridge_'+i,levelRoot,[x,1.4,z],[7,.35,1.05],realmMat(stage,'trim'),[0,0,(i%2?-.14:.14)]);addSolid({position:{x,z}},2.9,1.8);}
        for(const x of [-15,15])addPillar(levelRoot,x,-2,7,stage);
      }
    }else if(stage===1){
      // Furnace stacks, chain gantries and molten channels.
      for(let i=0;i<6;i++){const x=(i%2?1:-1)*(10+Math.floor(i/2)*2),z=-16+Math.floor(i/2)*12;const stack=box('Foundry_Furnace_'+i,levelRoot,[x,2.5,z],[3.2,5,3.3],realmMat(stage,'stone'));addSolid(stack,2,5);sphere('Furnace_Core_'+i,levelRoot,[x,2.4,z+1.7],[.45,.7,.2],realmMat(stage,'hot'),12);}
      for(let i=0;i<4;i++){const z=-13+i*8;box('Forge_Chain_Beam_'+i,levelRoot,[0,6.2,z],[28,.35,.4],realmMat(stage,'trim'));}
      for(const x of [-7,7]){box('Molten_Channel_'+x,levelRoot,[x,.02,0],[1.7,.06,38],realmMat(stage,'hot'));const glow=box('Molten_Glow_'+x,levelRoot,[x,.07,0],[.8,.025,37],realmMat(stage,'glow'));hazardMeshes.push({mesh:glow,x,z:0,damage:7,period:1.2,timer:0});}
      if(layout==='furnace'||layout==='boss')for(let i=0;i<4;i++)addPillar(levelRoot,(i%2?1:-1)*12,-8+Math.floor(i/2)*16,6,stage);
    }else if(stage===2){
      // Flooded archive: pale marble, water basins and mirror pillars.
      for(const [x,z] of [[-13,-12],[13,-12],[-13,12],[13,12]]){const pool=cylinder('Moonwell_Pool',levelRoot,[x,.04,z],.12,7,7,realmMat(stage,'glow'),48);pool.material.alpha=.3;pool.material.transparencyMode=B.Material.MATERIAL_ALPHABLEND;}
      for(let i=0;i<8;i++){const x=(i%2?1:-1)*(7+Math.floor(i/2)*2),z=-15+Math.floor(i/2)*10;addPillar(levelRoot,x,z,5.5+(i%3),stage);}
      for(const x of [-18,18])for(let i=0;i<4;i++)addCrystal(levelRoot,x,-12+i*8,1.4+(i%2)*.5,stage);
      box('Moonwell_Reflecting_Altar',levelRoot,[0,.2,8],[12,.38,5],realmMat(stage,'trim'));
    }else{
      // Starfall: fractured bridges, suspended monoliths and glowing astral crystals.
      for(let i=0;i<7;i++){const a=i*TAU/7,x=Math.cos(a)*15,z=Math.sin(a)*15;const ob=box('Floating_Monolith_'+i,levelRoot,[x,1.9,z],[2.4,4.8,2.2],realmMat(stage,'stone'),[rand(-.08,.08),a,rand(-.05,.05)]);addSolid({position:{x,z}},1.45,4.8);addCrystal(levelRoot,x, z,1.2,stage);}
      for(const [x,z,rx] of [[-9,-8,.18],[9,-8,-.18],[-9,10,-.18],[9,10,.18]]){const bridge=box('Star_Bridge',levelRoot,[x,.38,z],[9,.55,2.3],realmMat(stage,'trim'),[0,0,rx]);addSolid({position:{x,z}},4.4,1.2);}
      sphere('Starwell_Core',levelRoot,[0,4,4],[2.3,2.3,2.3],realmMat(stage,'glow'),20);
    }
    // Repeated room-specific cover pieces: pillars, broken walls, and climbable-looking raised dais.
    const patterns=[
      [[-8,0],[8,0],[-8,10],[8,10]],
      [[-12,-7],[12,-7],[-5,8],[5,8]],
      [[-10,-10],[10,-10],[-10,9],[10,9]],
      [[-13,0],[13,0],[0,12],[0,-11]]
    ];
    const pat=patterns[room];
    pat.forEach(([x,z],i)=>{
      if(stage===1&&Math.abs(x)===12)return;
      const h=room===2?2.1:1.6;const ob=box('Battle_Cover_'+i,levelRoot,[x,h/2,z],[2.4,h,2.1],realmMat(stage,'stone'),[0,rand(-.2,.2),rand(-.05,.05)]);addSolid({position:{x,z}},1.55,h);
      if(i%2===0)sphere('Cover_Rune_'+i,levelRoot,[x,h+.12,z],[.25,.14,.25],realmMat(stage,'glow'),12);
    });
    // Boundary lights and braziers.
    for(const s of [-1,1])for(let i=0;i<3;i++){
      const x=s*19,z=-13+i*13;const bowl=cylinder('Realm_Brazier_'+s+'_'+i,levelRoot,[x,.65,z],1.3,.38,.22,realmMat(stage,'trim'),10);sphere('Realm_Flame_'+s+'_'+i,levelRoot,[x,1.48,z],[.2,.45,.2],realmMat(stage,'hot'),12);
      const light=new B.PointLight('Realm_Firelight_'+s+'_'+i,new B.Vector3(x,1.8,z),scene);light.diffuse=c3(p.hot);light.intensity=1.0;light.range=9;light.parent=levelRoot;
    }
    // Entry structure is visible from the spawn and changes with each region.
    const entry=node('Realm_Entry_Arch',levelRoot,[0,0,-20.1]);
    box('Entry_Left',entry,[-4.2,3.1,0],[1.1,6.2,1.2],realmMat(stage,'trim'));box('Entry_Right',entry,[4.2,3.1,0],[1.1,6.2,1.2],realmMat(stage,'trim'));box('Entry_Lintel',entry,[0,6.35,0],[9.3,.85,1.4],realmMat(stage,'trim'));
    torus('Entry_Rune',entry,[0,3.25,.72],4.1,.12,realmMat(stage,'glow')).rotation.x=0;
    // Gate is closed until waves are defeated.
    const gateRoot=node('Exit_Gate',levelRoot,[0,0,20.2]);box('Exit_Gate_Left',gateRoot,[-4.1,3,0],[.85,6,1.2],realmMat(stage,'trim'));box('Exit_Gate_Right',gateRoot,[4.1,3,0],[.85,6,1.2],realmMat(stage,'trim'));box('Exit_Gate_Top',gateRoot,[0,6,0],[9,.7,1.3],realmMat(stage,'trim'));
    const portalMat=realmMat(stage,'glow');const disc=cylinder('Locked_Realm_Portal',gateRoot,[0,3,0],.18,6,6,portalMat,64,[Math.PI/2,0,0]);disc.material.alpha=.07;disc.material.transparencyMode=B.Material.MATERIAL_ALPHABLEND;
    const ring=torus('Realm_Portal_Ring',gateRoot,[0,3,.18],5.1,.15,realmMat(stage,'hot'));ring.rotation.x=0;ring.isVisible=false;
    portal={root:gateRoot,disc,ring,x:0,z:19.7,active:false};
    // Every level has an overhead landmark and four distant atmospheric lights.
    if(stage===0){for(let i=0;i<4;i++)decorateTree(levelRoot,(i%2?1:-1)*24,-18+Math.floor(i/2)*35,.9,stage);}
    updateCamera(0,true);
  }

  // ---------- Campaign, encounters, rewards and persistence ----------
  const campaign={stage:0,room:0,wave:0,waves:[],enemies:[],projectiles:[],particles:[],portalReady:false,elapsed:0,kills:0,lock:null,clearTimer:0,roomsCleared:0};
  const player={hp:160,maxHp:160,damage:31,speed:6.1,xp:0,xpNeed:120,level:1,gold:0,combo:0,comboWindow:0,attack:null,attackCd:0,dodgeCd:0,dashTime:0,dashDir:v3(0,0,1),invuln:0,jumpZ:0,jumpVy:0,solarCd:0,riftCd:0,snareCd:0,heavyCd:0,moveAmount:0,anim:0,regen:0};
  const input={keys:new Set(),mouseDown:false,drag:false,lastX:0,lastY:0,mobile:{x:0,z:0},stickId:null};
  let gameState='menu',cameraYaw=0,cameraPitch=.24,camPosition=v3(0,4,-8),camTarget=v3(0,1,0),time=0,hitStop=0,shake=0,toastTime=0,toastText='',activeProjectiles=[],runStart=0;
  function save(){try{localStorage.setItem(SAVE_KEY,JSON.stringify({stage:campaign.stage,room:campaign.room,roomsCleared:campaign.roomsCleared,bestKills:Math.max(saved.bestKills||0,campaign.kills),level:player.level,gold:player.gold,hp:player.hp}));}catch{}}
  function loadSaved(){try{const s=JSON.parse(localStorage.getItem(SAVE_KEY)||'{}');return Number.isFinite(s.stage)&&s.stage>=0?s:null;}catch{return null;}}
  function toast(message,duration=1.5){toastText=message;toastTime=duration;$('toast').textContent=message;$('toast').classList.add('show');}
  function updateHUD(){
    $('hero-level').textContent='LEVEL '+String(player.level).padStart(2,'0');$('health-text').textContent=Math.ceil(player.hp)+' / '+player.maxHp;$('health-fill').style.width=(player.hp/player.maxHp*100)+'%';$('xp-text').textContent=player.xp+' / '+player.xpNeed;$('xp-fill').style.width=(player.xp/player.xpNeed*100)+'%';
    const p=realms[campaign.stage],room=levelConfigs[campaign.stage][campaign.room];$('chapter-label').textContent=p.tag;$('realm-title').textContent=p.name;$('level-title').textContent=`${room.name} · AREA ${campaign.room+1}/4`;
    $('level-progress').innerHTML=levelConfigs[campaign.stage].map((_,i)=>`<i class="${i<campaign.room?'done':i===campaign.room?'active':''}"></i>`).join('');
    $('enemy-count').textContent='HOSTILES REMAINING · '+campaign.enemies.filter(e=>e.hp>0).length;
    $('hearth-text').textContent=player.solarCd<=0?'READY':player.solarCd.toFixed(1)+'s';
    $('dodge-state').textContent=player.dodgeCd<=0?'READY':player.dodgeCd.toFixed(1)+'s';$('solar-state').textContent=player.solarCd<=0?'READY':player.solarCd.toFixed(1)+'s';$('rift-state').textContent=player.riftCd<=0?'READY':player.riftCd.toFixed(1)+'s';$('snare-state').textContent=player.snareCd<=0?'READY':player.snareCd.toFixed(1)+'s';$('heavy-state').textContent=player.heavyCd<=0?'READY':player.heavyCd.toFixed(1)+'s';
    const live=campaign.enemies.filter(e=>e.hp>0);const target=campaign.lock&&campaign.lock.hp>0?campaign.lock:null;
    if(target){$('target-panel').classList.remove('hidden');$('target-name').textContent=target.profile.name;$('target-fill').style.width=(target.hp/target.maxHp*100)+'%';}else $('target-panel').classList.add('hidden');
    const boss=live.find(e=>e.type==='boss');if(boss){$('boss-panel').classList.remove('hidden');$('boss-name').textContent=boss.bossName;$('boss-fill').style.width=(boss.hp/boss.maxHp*100)+'%';}else $('boss-panel').classList.add('hidden');
    if(portal?.active)$('interaction-hint').classList.remove('hidden');else $('interaction-hint').classList.add('hidden');
  }
  function levelUp(){player.level++;player.maxHp+=18;player.hp=Math.min(player.maxHp,player.hp+35);player.damage+=4;player.xp-=player.xpNeed;player.xpNeed=Math.round(player.xpNeed*1.22);toast('LEVEL UP · LYRA GROWS STRONGER',2.1);burst(hero.root.position.add(v3(0,1.7,0)),'#ffe39a','#83dbba',60,.38,7);updateHUD();}
  function grantXP(amount){player.xp+=amount;while(player.xp>=player.xpNeed)levelUp();}
  function waveBlueprint(stage,room,wave){
    if(room===3){return wave===0?['boss','wisp','thornling']:['assassin','archer'];}
    const base=[
      [['thornling','thornling','archer'],['stalker','thornling','thornling','wisp'],['brute','archer','stalker','thornling']],
      [['archer','thornling','brute'],['stalker','archer','brute','thornling'],['brute','brute','assassin','archer']],
      [['wisp','stalker','archer'],['assassin','wisp','thornling','stalker'],['sentinel','assassin','wisp','archer']],
      [['sentinel','archer','assassin'],['assassin','sentinel','wisp','brute'],['sentinel','assassin','brute','wisp']]
    ];
    const arr=base[stage][Math.min(room,2)];
    if(wave===0)return arr.slice(0,Math.min(3,arr.length));
    return arr.concat(wave===1?['thornling']:['assassin']);
  }
  function spawnEnemy(type,x,z,elite=false){
    const raw=enemyProfiles[type]||enemyProfiles.thornling;const factor=1+campaign.stage*.18+campaign.room*.055+(elite?.65:0);const profile={...raw,hp:Math.round(raw.hp*factor),damage:Math.round(raw.damage*(1+campaign.stage*.12+(elite?.28:0))),speed:raw.speed*(1+campaign.stage*.045+(elite?.15:0))};
    const model=makeEnemyModel(type,raw.scale*(elite?1.13:1));model.root.position.set(x,0,z);model.facing.rotation.y=Math.atan2(hero.root.position.x-x,hero.root.position.z-z);
    const e={type,profile,model,root:model.root,facing:model.facing,arms:model.arms,legs:model.legs,hp:profile.hp,maxHp:profile.hp,damage:profile.damage,speed:profile.speed,state:'approach',stateTime:0,attackCd:rand(.25,1.5),stun:0,slow:0,elite,boss:type==='boss',phase:1,walk:0,projectileCd:rand(1.2,2.2),knock:v3(),seed:rand(0,TAU),bossName:['THE ROOTBOUND WARDEN','THE ASHEN COLOSSUS','THE HOLLOW CROWN','THE STARFALL REGENT'][campaign.stage]};
    if(type==='boss'){e.hp=e.maxHp=Math.round(1050*factor);e.damage=31+campaign.stage*4;e.profile={...profile,wind:1.0};e.model.root.scaling.setAll(1.9);}
    if(elite){e.hp=e.maxHp=Math.round(e.hp*1.5);e.damage=Math.round(e.damage*1.25);const halo=torus('Elite_Halo',e.root,[0,3.4,0],2.5,.075,realmMat(campaign.stage,'hot'));e.eliteHalo=halo;}
    if(type==='boss'){e.eliteHalo=torus('Boss_Halo',e.root,[0,4.2,0],4,.09,realmMat(campaign.stage,'hot'));}
    campaign.enemies.push(e);return e;
  }
  function addWave(){
    const list=waveBlueprint(campaign.stage,campaign.room,campaign.wave);campaign.wave++;
    const eliteEvery=campaign.stage>0&&campaign.room>0;
    list.forEach((kind,i)=>{
      const a=(i/Math.max(1,list.length))*TAU+rand(-.24,.24),r=rand(9,14);let x=Math.cos(a)*r,z=Math.sin(a)*r;
      if(Math.abs(x)<4&&z<0)z+=6;
      const elite=eliteEvery&&(i===list.length-1||kind==='assassin');spawnEnemy(kind,x,z,elite);
    });
    toast(campaign.wave===1?'HOSTILES APPROACH · ENGAGE':'REINFORCEMENTS · WAVE '+campaign.wave,1.8);updateHUD();
  }
  function beginLevel(){
    campaign.enemies.forEach(e=>e.model.root.dispose());campaign.enemies=[];campaign.projectiles.forEach(p=>p.mesh.dispose());campaign.projectiles=[];campaign.wave=0;campaign.portalReady=false;campaign.clearTimer=0;campaign.lock=null;player.attack=null;player.combo=0;player.hp=Math.min(player.maxHp,player.hp+18);hero.root.position.set(0,0,-12);hero.velX=0;hero.velZ=0;hero.facing.rotation.y=0;cameraYaw=0;cameraPitch=.24;buildLevel(campaign.stage,campaign.room);
    const cfg=levelConfigs[campaign.stage][campaign.room];$('objective-title').textContent=campaign.room===3?'DEFEAT THE GUARDIAN':'ELIMINATE ALL HOSTILES';$('objective-copy').textContent=campaign.room===3?'Survive the guardian phases and destroy its core.':'Clear both enemy waves to unlock the passage.';
    if(campaign.room===3){addWave();}else{addWave();}
    $('controls-hint').textContent='WASD MOVE · MOUSE LOOK · F LOCK ON · J COMBO · K HEAVY · SPACE DODGE';updateHUD();save();
  }
  function beginCampaign(continueRun=false){
    if(continueRun){const s=loadSaved();if(s){campaign.stage=clamp(s.stage||0,0,3);campaign.room=clamp(s.room||0,0,3);campaign.roomsCleared=s.roomsCleared||0;player.level=s.level||1;player.gold=s.gold||0;}}
    else{campaign.stage=0;campaign.room=0;campaign.roomsCleared=0;Object.assign(player,{hp:160,maxHp:160,damage:31,xp:0,xpNeed:120,level:1,gold:0,combo:0});}
    campaign.kills=0;runStart=performance.now();startAudio();$('menu-screen').classList.add('hidden');$('hud').classList.remove('hidden');$('mobile-ui').classList.add('active');$('pause-screen').classList.add('hidden');$('result-screen').classList.add('hidden');gameState='playing';canvas.focus();beginLevel();toast('THE LAST HEARTH CALLS',1.6);
  }
  function setPortalReady(){if(campaign.portalReady)return;campaign.portalReady=true;if(portal){portal.active=true;portal.ring.isVisible=true;portal.disc.material.alpha=.45;}$('objective-title').textContent='PASSAGE UNSEALED';$('objective-copy').textContent='Reach the gate and press E to enter the next battlefield.';toast(campaign.room===3?'THE GUARDIAN HAS FALLEN':'AREA CLEARED · THE WAY OPENS',2.1);player.hp=Math.min(player.maxHp,player.hp+22);player.gold+=22+campaign.stage*10;save();updateHUD();}
  function advanceLevel(){if(!campaign.portalReady||!portal)return;const d=dist2(hero.root.position,{x:0,z:19.5});if(d>5.1)return;
    campaign.roomsCleared++;if(campaign.room<3)campaign.room++;else if(campaign.stage<3){campaign.stage++;campaign.room=0;}else{finish(true);return;}beginLevel();toast('ENTERING '+realms[campaign.stage].name,2.1);
  }
  function finish(won){gameState='result';$('hud').classList.add('hidden');$('mobile-ui').classList.remove('active');$('result-screen').classList.remove('hidden');$('result-eyebrow').textContent=won?'THE LAST HEARTH ENDURES':'THE HEARTH FADES';$('result-title').textContent=won?'THE LAST FLAME STILL BURNS':'THE DARKNESS CLOSES IN';$('result-copy').textContent=won?`Lyra has crossed all sixteen battlefields. Hostiles defeated: ${campaign.kills}. The last hearth is safe — for now.`:`Lyra fell in ${levelConfigs[campaign.stage][campaign.room].name}. Your campaign progress is saved. Return and master the enemy attack windows.`;$('result-button').textContent=won?'RETURN TO THE REALMS':'TRY AGAIN';$('result-retry').textContent='RETRY THIS BATTLE';save();}

  // ---------- Combat effects and hit reactions ----------
  const particleTexture=(()=>{const tex=new B.DynamicTexture('Soft_Particle', {width:64,height:64},scene,false);const c=tex.getContext();const g=c.createRadialGradient(32,32,1,32,32,31);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.23,'rgba(255,255,255,.8)');g.addColorStop(.6,'rgba(255,255,255,.22)');g.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=g;c.fillRect(0,0,64,64);tex.update();return tex;})();
  function burst(pos,color1,color2,count=24,size=.3,power=5){const ps=new B.ParticleSystem('Combat_Burst',220,scene);ps.particleTexture=particleTexture;ps.emitter=pos.clone();ps.minEmitBox=v3(-.12,-.1,-.12);ps.maxEmitBox=v3(.12,.1,.12);ps.color1=new B.Color4(c3(color1).r,c3(color1).g,c3(color1).b,1);ps.color2=new B.Color4(c3(color2).r,c3(color2).g,c3(color2).b,1);ps.colorDead=new B.Color4(.08,.08,.08,0);ps.minSize=size*.3;ps.maxSize=size;ps.minLifeTime=.2;ps.maxLifeTime=.72;ps.emitRate=0;ps.manualEmitCount=count;ps.blendMode=B.ParticleSystem.BLENDMODE_ADD;ps.minEmitPower=power*.3;ps.maxEmitPower=power;ps.direction1=v3(-1,.15,-1);ps.direction2=v3(1,2.8,1);ps.gravity=v3(0,-6,0);ps.start();ps.targetStopDuration=.04;setTimeout(()=>ps.dispose(),1150);}
  function ringBurst(x,z,color,diameter=4){const r=torus('Impact_Ring',null,[x,.08,z],diameter,.08,mat('Impact_'+Math.random(),color,.3,.1,color));r.rotation.x=Math.PI/2;r.scaling.set(.25,1,.25);let age=0;const obs=scene.onBeforeRenderObservable.add(()=>{const dt=engine.getDeltaTime()/1000;age+=dt;r.scaling.setAll(lerp(.25,1.6,clamp(age/.45,0,1)));r.material.alpha=1-age/.45;if(age>.45){scene.onBeforeRenderObservable.remove(obs);r.dispose();}});}
  function soundTone(freq,duration=.12,type='triangle',end=null,amp=.18){if(stateMuted)return;try{const A=window.AudioContext||window.webkitAudioContext;if(!A)return;audioCtx=audioCtx||new A();if(audioCtx.state==='suspended')audioCtx.resume();const o=audioCtx.createOscillator(),g=audioCtx.createGain(),t=audioCtx.currentTime;o.type=type;o.frequency.setValueAtTime(freq,t);if(end)o.frequency.exponentialRampToValueAtTime(Math.max(25,end),t+duration);g.gain.setValueAtTime(amp,t);g.gain.exponentialRampToValueAtTime(.001,t+duration);o.connect(g).connect(audioCtx.destination);o.start();o.stop(t+duration+.02);}catch{}}
  let audioCtx=null,stateMuted=false;
  function startAudio(){if(audioCtx&&audioCtx.state==='suspended')audioCtx.resume();}
  function actorFacingPlayer(e){const to=hero.root.position.subtract(e.root.position);to.y=0;return Math.atan2(to.x,to.z);}
  function nearestEnemy(max=9){let best=null,bd=max;for(const e of campaign.enemies){if(e.hp<=0)continue;const d=dist2(hero.root.position,e.root.position);if(d<bd){bd=d;best=e;}}return best;}
  function damageEnemy(e,amount,knock=1.1,kind='blade'){
    if(!e||e.hp<=0)return;const hitPos=e.root.position.add(v3(0,e.type==='boss'?2.5:1.7,0));e.hp=Math.max(0,e.hp-amount);e.stun=Math.max(e.stun,kind==='heavy'?.48:.22);e.state='stunned';e.stateTime=e.stun;e.model.facing.rotation.y=actorFacingPlayer(e);const d=e.root.position.subtract(hero.root.position);d.y=0;if(d.lengthSquared()>0)d.normalize();e.root.position.addInPlace(d.scale(knock));
    burst(hitPos,kind==='solar'?'#fff0a9':'#f7d38b',kind==='snare'?'#8ee8d3':'#eb7650',kind==='heavy'?42:25,kind==='heavy'?.42:.27,kind==='heavy'?7:5);ringBurst(e.root.position.x,e.root.position.z,kind==='solar'?'#f7d98b':'#e9aa68',kind==='heavy'?4.8:2.6);soundTone(kind==='heavy'?120:190,.16,'sawtooth',48,.22);hitStop=Math.max(hitStop,.045);shake=Math.max(shake,kind==='heavy'?.33:.14);
    if(e.hp<=0){e.state='dead';e.root.setEnabled(false);if(e.eliteHalo)e.eliteHalo.dispose();campaign.kills++;player.gold+=e.elite?22:8;grantXP(e.profile.xp);burst(e.root.position.add(v3(0,1.8,0)),'#f5dfa0','#7ed9b1',e.boss?130:55,e.boss?.55:.34,e.boss?9:6);toast(e.boss?'REALM GUARDIAN DESTROYED':e.elite?'ELITE SLAIN':'HOSTILE SLAIN',1.0);if(campaign.lock===e)campaign.lock=null;}
    updateHUD();
  }
  function targetInFront(range=4){const fwd=forward(hero.facing.rotation.y);let best=null,bestD=range;for(const e of campaign.enemies){if(e.hp<=0)continue;const to=e.root.position.subtract(hero.root.position);to.y=0;const d=to.length();if(d>range||d<.01)continue;if(B.Vector3.Dot(to.normalize(),fwd)<.08)continue;if(d<bestD){best=e;bestD=d;}}return best;}
  function beginAttack(kind){if(gameState!=='playing'||player.attack||player.dashTime>0||player.attackCd>0)return;if(kind==='heavy'&&player.heavyCd>0)return;
    const target=campaign.lock&&campaign.lock.hp>0?campaign.lock:targetInFront(7);if(target){const to=target.root.position.subtract(hero.root.position);to.y=0;if(to.length()<8)hero.facing.rotation.y=Math.atan2(to.x,to.z);}
    if(kind==='light'){player.combo=player.comboWindow>0?player.combo%3+1:1;player.attack={kind:'light',time:0,duration:.48+(player.combo-1)*.045,applied:false};player.attackCd=.12;player.comboWindow=.82;soundTone(430,.1,'triangle',170,.12);}else{player.combo=0;player.attack={kind:'heavy',time:0,duration:.92,applied:false};player.heavyCd=2.1;soundTone(165,.22,'sawtooth',46,.21);}
  }
  function dodge(){if(gameState!=='playing'||player.dodgeCd>0||player.dashTime>0)return;const x=(input.keys.has('KeyD')?1:0)-(input.keys.has('KeyA')?1:0)+input.mobile.x;const z=(input.keys.has('KeyW')?1:0)-(input.keys.has('KeyS')?1:0)+input.mobile.z;let d=v3(x,0,z);if(d.lengthSquared()<.03)d=forward(hero.facing.rotation.y);else{const f=forward(cameraYaw),r=v3(Math.cos(cameraYaw),0,-Math.sin(cameraYaw));d=r.scale(d.x).add(f.scale(d.z));}d.normalize();player.dashDir.copyFrom(d);player.dashTime=.32;player.invuln=.58;player.dodgeCd=1.05;player.attack=null;soundTone(270,.16,'sine',760,.15);burst(hero.root.position.add(v3(0,1,0)),'#9ddfd3','#e6d3a2',24,.2,3.6);}
  function jump(){if(gameState!=='playing'||player.jumpZ>0||player.dashTime>0)return;player.jumpVy=7.4;}
  function solar(){if(gameState!=='playing'||player.solarCd>0)return;player.solarCd=10.5;const origin=hero.root.position.add(v3(0,1.25,0));burst(origin,'#ffeb9e','#e78b48',115,.5,8.5);ringBurst(hero.root.position.x,hero.root.position.z,'#f6c76d',5.5);for(const e of campaign.enemies)if(e.hp>0&&dist2(hero.root.position,e.root.position)<6.8)damageEnemy(e,74+campaign.stage*9,1.7,'solar');shake=.45;toast('SOLAR NOVA',1);}
  function riftStep(){if(gameState!=='playing'||player.riftCd>0||player.dashTime>0)return;player.riftCd=7.2;let target=nearestEnemy(14);let dir=target?target.root.position.subtract(hero.root.position):forward(hero.facing.rotation.y);dir.y=0;if(dir.lengthSquared()<.01)dir=forward(hero.facing.rotation.y);dir.normalize();const origin=hero.root.position.clone();if(target){const behind=target.root.position.subtract(dir.scale(2.1));hero.root.position.x=behind.x;hero.root.position.z=behind.z;hero.facing.rotation.y=actorFacingPlayer(target);damageEnemy(target,102+player.level*4,2.5,'heavy');}else{hero.root.position.addInPlace(dir.scale(8.5));}burst(origin.add(v3(0,1,0)),'#8ddce9','#c89cff',50,.34,7);burst(hero.root.position.add(v3(0,1,0)),'#8ddce9','#f6dfaa',38,.3,6);player.invuln=.48;soundTone(600,.24,'sine',130,.18);toast('RIFT STEP',.9);}
  function snare(){if(gameState!=='playing'||player.snareCd>0)return;player.snareCd=11;ringBurst(hero.root.position.x,hero.root.position.z,'#8fe7d6',7.5);burst(hero.root.position.add(v3(0,1,0)),'#8fe7d6','#d4b6ff',90,.42,4.5);for(const e of campaign.enemies){if(e.hp>0&&dist2(hero.root.position,e.root.position)<8){e.slow=3.2;damageEnemy(e,38+player.level*2,.45,'snare');if(e.hp>0){e.state='stunned';e.stateTime=.8;}}}soundTone(720,.4,'sine',180,.15);toast('AETHER SNARE',1);}
  function toggleLock(){if(campaign.lock&&campaign.lock.hp>0){campaign.lock=null;toast('LOCK-ON RELEASED',.8);return;}campaign.lock=nearestEnemy(24);if(campaign.lock){const e=campaign.lock;cameraYaw=Math.atan2(hero.root.position.x-e.root.position.x,hero.root.position.z-e.root.position.z);toast('TARGET LOCKED · '+e.profile.name,1);}else toast('NO TARGET IN RANGE',.9);updateHUD();}
  function playerTakeDamage(amount,from){if(player.invuln>0||gameState!=='playing')return;player.hp=Math.max(0,player.hp-amount);player.invuln=.72;const d=hero.root.position.subtract(from);d.y=0;if(d.lengthSquared()>0)d.normalize();hero.root.position.addInPlace(d.scale(1.4));burst(hero.root.position.add(v3(0,1.2,0)),'#e77a63','#e7d2a0',28,.28,4.8);shake=.3;soundTone(105,.22,'sawtooth',40,.2);toast('LYRA HIT · '+amount+' DAMAGE',.8);updateHUD();if(player.hp<=0)finish(false);}
  function tryAttackHit(kind){const range=kind==='heavy'?5.1:4.05;const f=forward(hero.facing.rotation.y);const hits=[];for(const e of campaign.enemies){if(e.hp<=0)continue;const to=e.root.position.subtract(hero.root.position);to.y=0;const d=to.length();if(d>range||d<.01)continue;const dot=B.Vector3.Dot(to.normalize(),f);if(dot>.05)hits.push({e,d});}hits.sort((a,b)=>a.d-b.d);const max=kind==='heavy'?3:player.combo===3?2:1;for(const {e} of hits.slice(0,max)){const dmg=kind==='heavy'?104+player.level*6:(player.damage+(player.combo-1)*13);damageEnemy(e,dmg,kind==='heavy'?2.1:1.0,kind);}}

  // ---------- Enemy combat brain: readable telegraphs, attacks, knockback and recovery ----------
  function addProjectile(owner,origin,target,speed=9,damage=15,color='#ff9b61',radius=.22){
    const material=mat('Projectile_'+Math.random().toString(36).slice(2),color,.2,.08,color);
    const mesh=sphere('Enemy_Projectile',null,[origin.x,origin.y,origin.z],[radius,radius,radius],material,12);
    const dir=target.subtract(origin);dir.y=0.2;if(dir.lengthSquared()<.01)dir.z=1;dir.normalize();
    campaign.projectiles.push({mesh,velocity:dir.scale(speed),damage,life:3.5,owner,color});
  }
  function enemyStartWindup(e){
    e.state='windup';e.stateTime=e.type==='boss'?(e.phase===3?.62:.9):(e.type==='brute'||e.type==='sentinel'?1.0:e.profile.wind);
    e.model.aura.isVisible=true;e.attackCd=e.type==='boss'?2.15:e.type==='assassin'?1.2:e.type==='brute'?2.35:rand(1.15,1.7);
    if(e.type==='boss')toast(e.phase===3?'REGENT · STARFALL VOLLEY':'GUARDIAN · HEAVY STRIKE',.9);
  }
  function enemyHitPlayer(e,range,damage){
    const d=dist2(e.root.position,hero.root.position);
    if(d<=range+player.jumpZ*.12&&player.invuln<=0)playerTakeDamage(damage,e.root.position);
  }
  function enemyPhaseStep(e){
    const f=forward(hero.facing.rotation.y);const side=v3(f.z,0,-f.x).scale(Math.random()<.5?1:-1);
    e.root.position.x=hero.root.position.x+f.x*1.9+side.x*2.1;e.root.position.z=hero.root.position.z+f.z*1.9+side.z*2.1;
    e.model.facing.rotation.y=actorFacingPlayer(e);burst(e.root.position.add(v3(0,1.1,0)),'#b48bf2','#dce8ff',26,.28,4.5);
  }
  function updateEnemy(e,dt){
    if(e.hp<=0||!e.root.isEnabled())return;
    e.attackCd=Math.max(0,e.attackCd-dt);e.slow=Math.max(0,e.slow-dt);e.walk+=dt;
    const to=hero.root.position.subtract(e.root.position);to.y=0;const d=Math.max(.001,to.length());const dir=to.scale(1/d);const yaw=Math.atan2(dir.x,dir.z);e.model.facing.rotation.y=dampAngle(e.model.facing.rotation.y,yaw,10,dt);
    if(e.eliteHalo)e.eliteHalo.rotation.y+=dt*.7;
    if(e.boss){const next=e.hp/e.maxHp<.34?3:e.hp/e.maxHp<.68?2:1;if(next!==e.phase){e.phase=next;toast('GUARDIAN PHASE '+next+' · '+(next===2?'THE VEIL BREAKS':'FINAL RAGE'),1.5);burst(e.root.position.add(v3(0,2.5,0)),'#f8d58c','#a58af2',78,.4,7);ringBurst(e.root.position.x,e.root.position.z,'#b58ff2',8);shake=.35;}}
    if(e.slow>0&&e.state!=='stunned')e.speed=e.profile.speed*.42;else e.speed=e.profile.speed*(e.boss&&e.phase===3?1.3:1);
    if(e.state==='stunned'){
      e.stateTime-=dt;e.model.arms.forEach(a=>{a.shoulder.rotation.z=a.side*.25;a.shoulder.rotation.x=.55;});
      if(e.stateTime<=0){e.state='recover';e.stateTime=.25;e.model.aura.isVisible=false;}return;
    }
    if(e.state==='approach'){
      if(e.profile.kind==='ranged'||e.profile.kind==='caster'||e.boss){
        if(d<5.5){const away=dir.scale(-1);e.root.position.addInPlace(away.scale(e.speed*.82*dt));}
        else if(d>8.8)e.root.position.addInPlace(dir.scale(e.speed*.8*dt));
        else {const side=v3(dir.z,0,-dir.x).scale(Math.sin(e.walk*1.5)*.75);e.root.position.addInPlace(side.scale(dt));}
        if(d<12.5&&e.attackCd<=0){e.state='windup';e.stateTime=e.type==='boss'?.95:e.profile.wind;e.model.aura.isVisible=true;e.attackCd=e.type==='boss'?2.9:rand(1.9,2.5);}
      }else if(e.profile.kind==='assassin'){
        if(d>3.2)e.root.position.addInPlace(dir.scale(e.speed*dt));
        if(d<10&&e.attackCd<=0){e.state='phase';e.stateTime=.43;e.attackCd=1.55;e.model.aura.isVisible=true;toast('SHADE ASSASSIN · PHASE STRIKE',.7);}
        else if(d<2.6&&e.attackCd<=0)enemyStartWindup(e);
      }else{
        if(d>(e.profile.range*.78))e.root.position.addInPlace(dir.scale(e.speed*(e.boss&&e.phase===3?1.25:1)*dt));
        else if(e.attackCd<=0)enemyStartWindup(e);
      }
    }else if(e.state==='phase'){
      e.stateTime-=dt;
      if(e.stateTime<=.18&& !e.phaseDone){enemyPhaseStep(e);e.phaseDone=true;}
      if(e.stateTime<=0){e.phaseDone=false;e.state='strike';e.stateTime=.28;enemyHitPlayer(e,3.5,e.damage);}
    }else if(e.state==='windup'){
      e.stateTime-=dt;
      if(e.stateTime<=0){e.model.aura.isVisible=false;e.state='strike';e.stateTime=e.profile.kind==='heavy'||e.boss?.52:.32;
        if(e.profile.kind==='ranged'||e.profile.kind==='caster'||e.boss){
          const n=e.boss&&e.phase>=2?5:1;for(let i=0;i<n;i++){const spread=(i-(n-1)/2)*.13;const target=hero.root.position.add(v3(spread*4,1,0));addProjectile(e,e.root.position.add(v3(0,2,0)),target,e.boss?10:8.3,e.damage,e.type==='wisp'?'#a8cfff':e.boss?'#d29aff':'#ff9d62',e.boss?.28:.2);}
          if(e.boss&&e.phase>=3){for(let i=0;i<4;i++){const a=i*TAU/4;const target=e.root.position.add(v3(Math.sin(a)*10,0,Math.cos(a)*10));addProjectile(e,e.root.position.add(v3(0,2.2,0)),target,8,e.damage*.75,'#d9a8ff',.23);}}
        }else{
          const dash= e.type==='brute'||e.type==='sentinel'||e.boss ? 4.4 : e.type==='assassin'?3.2:2.3;
          e.root.position.addInPlace(dir.scale(dash));enemyHitPlayer(e,e.boss?4.8:e.type==='brute'?3.6:2.8,e.damage*(e.boss&&e.phase===3?1.28:1));
          if(e.type==='brute'||e.type==='sentinel'||e.boss){ringBurst(e.root.position.x,e.root.position.z,e.boss?'#e29b73':'#d79b68',e.boss?7:4.8);shake=.3;}
        }
      }
    }else if(e.state==='strike'){
      e.stateTime-=dt;if(e.stateTime<=0){e.state='recover';e.stateTime=e.profile.recover*(e.boss&&e.phase===3?.72:1);e.model.aura.isVisible=false;}
    }else if(e.state==='recover'){
      e.stateTime-=dt;if(e.stateTime<=0)e.state='approach';
    }
    const bound=20.2;e.root.position.x=clamp(e.root.position.x,-bound,bound);e.root.position.z=clamp(e.root.position.z,-bound,bound);
    animateEnemy(e,dt);
  }
  function animateEnemy(e,dt){
    const m=e.model,t=e.walk;const walk=e.state==='approach'?Math.sin(t*7)*.42:0;
    m.legs.forEach(({hip,side})=>{hip.rotation.x=side===1?-walk:walk;});
    m.arms.forEach(({shoulder,elbow,side})=>{
      if(e.state==='windup'){shoulder.rotation.x=-1.15+Math.sin(t*18)*.08;shoulder.rotation.z=side*.24;elbow.rotation.x=-.6;}
      else if(e.state==='strike'||e.state==='phase'){shoulder.rotation.x=1.0;shoulder.rotation.z=side*-.18;elbow.rotation.x=.45;}
      else if(e.state==='stunned'){shoulder.rotation.x=.8;shoulder.rotation.z=side*.45;}
      else{shoulder.rotation.x=side===1?walk*.42:-walk*.42;shoulder.rotation.z=side*.05;elbow.rotation.x=.08;}
    });
    m.head.rotation.x=e.state==='windup'?.13+Math.sin(t*16)*.04:Math.sin(t*1.5)*.025;
    if(e.type==='wisp'){m.root.position.y=.45+Math.sin(t*3+e.seed)*.3;}else m.root.position.y=0;
    if(e.eliteHalo)e.eliteHalo.scaling.setAll(1+Math.sin(t*5)*.06);
  }
  function updateProjectiles(dt){
    for(let i=campaign.projectiles.length-1;i>=0;i--){const p=campaign.projectiles[i];p.life-=dt;p.mesh.position.addInPlace(p.velocity.scale(dt));p.mesh.rotation.x+=dt*4;p.mesh.rotation.y+=dt*5;
      if(dist2(p.mesh.position,hero.root.position)<.95&&Math.abs(p.mesh.position.y-(1.2+player.jumpZ))<1.8){playerTakeDamage(p.damage,p.mesh.position);burst(p.mesh.position,p.color,'#f7e4b6',15,.2,3.5);p.life=0;}
      if(p.life<=0||Math.abs(p.mesh.position.x)>28||Math.abs(p.mesh.position.z)>28){p.mesh.dispose();campaign.projectiles.splice(i,1);}
    }
  }
  function updatePlayer(dt){
    const x=(input.keys.has('KeyD')?1:0)-(input.keys.has('KeyA')?1:0)+input.mobile.x;const z=(input.keys.has('KeyW')?1:0)-(input.keys.has('KeyS')?1:0)+input.mobile.z;const len=Math.hypot(x,z);let desired=v3();
    if(len>.04){const ix=x/Math.max(1,len),iz=z/Math.max(1,len);const f=forward(cameraYaw),r=v3(Math.cos(cameraYaw),0,-Math.sin(cameraYaw));desired=r.scale(ix).add(f.scale(iz));if(desired.lengthSquared()>1)desired.normalize();}
    if(player.dashTime>0){player.dashTime=Math.max(0,player.dashTime-dt);hero.root.position.addInPlace(player.dashDir.scale(18*dt));}
    else{const speed=player.speed*(input.keys.has('ControlLeft')?.65:1);const target=desired.scale(speed);const smooth= len>.04?14:18;hero.velX=lerp(hero.velX||0,target.x,1-Math.exp(-smooth*dt));hero.velZ=lerp(hero.velZ||0,target.z,1-Math.exp(-smooth*dt));hero.root.position.x+=hero.velX*dt;hero.root.position.z+=hero.velZ*dt;}
    if(desired.lengthSquared()>.01&&!campaign.lock)hero.facing.rotation.y=dampAngle(hero.facing.rotation.y,Math.atan2(desired.x,desired.z),13,dt);
    if(campaign.lock&&campaign.lock.hp>0){const to=campaign.lock.root.position.subtract(hero.root.position);hero.facing.rotation.y=dampAngle(hero.facing.rotation.y,Math.atan2(to.x,to.z),9,dt);}
    // Simple swept circle resolution against cover; the arena has real walkable obstacles.
    for(const o of obstacles){const dx=hero.root.position.x-o.x,dz=hero.root.position.z-o.z,dd=Math.hypot(dx,dz),min=o.r+.48;if(dd<min&&dd>.001){const push=(min-dd)/dd;hero.root.position.x+=dx*push;hero.root.position.z+=dz*push;}}
    hero.root.position.x=clamp(hero.root.position.x,-20.1,20.1);hero.root.position.z=clamp(hero.root.position.z,-20.1,20.1);
    if(player.jumpZ>0||player.jumpVy>0){player.jumpVy-=19.5*dt;player.jumpZ+=player.jumpVy*dt;if(player.jumpZ<0){player.jumpZ=0;player.jumpVy=0;ringBurst(hero.root.position.x,hero.root.position.z,'#d9c38a',2.5);}}
    hero.root.position.y=player.jumpZ;player.moveAmount=clamp(len,0,1);player.anim+=dt;
    if(player.attack){player.attack.time+=dt;const p=player.attack.time/player.attack.duration;const impact=player.attack.kind==='heavy'?.62:player.combo===3?.46:.38;if(!player.attack.applied&&p>=impact){player.attack.applied=true;tryAttackHit(player.attack.kind);}if(p>=1){player.attack=null;player.comboWindow=.82;}}
    player.comboWindow=Math.max(0,player.comboWindow-dt);player.attackCd=Math.max(0,player.attackCd-dt);player.dodgeCd=Math.max(0,player.dodgeCd-dt);player.heavyCd=Math.max(0,player.heavyCd-dt);player.solarCd=Math.max(0,player.solarCd-dt);player.riftCd=Math.max(0,player.riftCd-dt);player.snareCd=Math.max(0,player.snareCd-dt);player.invuln=Math.max(0,player.invuln-dt);
    if(player.regen>0)player.hp=Math.min(player.maxHp,player.hp+player.regen*dt);
    animateHero(dt);
  }
  function animateHero(dt){
    const t=player.anim,walk=player.moveAmount>0.05&&player.dashTime<=0?Math.sin(t*9.5)*.58*player.moveAmount:0;
    hero.legs.forEach(({hip,knee,side})=>{hip.rotation.x=(side===1?-walk:walk)-(player.jumpZ>0?.17:0);knee.rotation.x=Math.max(0,Math.sin(t*9.5+(side===1?Math.PI:0)))*.5*player.moveAmount;});
    if(player.attack){const p=clamp(player.attack.time/player.attack.duration,0,1),s=Math.sin(p*Math.PI);hero.right.shoulder.rotation.x=player.attack.kind==='heavy'?-1.5*s-.2:-1.15*s;hero.right.shoulder.rotation.z=-.42*s;hero.right.elbow.rotation.x=-.75*s;hero.sword.rotation.z=player.attack.kind==='heavy'?-1.65*s:-1.2*s;hero.sword.rotation.x=.36*s;}
    else{hero.right.shoulder.rotation.x=-walk*.45;hero.right.shoulder.rotation.z=.05;hero.right.elbow.rotation.x=-.12;hero.sword.rotation.z=lerp(hero.sword.rotation.z,0,1-Math.exp(-13*dt));hero.sword.rotation.x=lerp(hero.sword.rotation.x,0,1-Math.exp(-13*dt));}
    hero.left.shoulder.rotation.x=walk*.45;hero.left.shoulder.rotation.z=-.04;hero.left.elbow.rotation.x=-.12;
    hero.cape.rotation.x=.12+Math.sin(t*3)*.06+player.moveAmount*.15;hero.cape.rotation.z=Math.sin(t*4)*.035;
    const aura=.98+Math.sin(t*2.3)*.035;hero.aura.scaling.set(.82*aura,1.16*aura,.68*aura);
    hero.facing.rotation.z=player.dashTime>0?-.08:player.jumpZ>0?-.08:0;
  }

  // ---------- Camera, hazards, and progression loop ----------
  function updateCamera(dt,snap=false){
    const f=forward(cameraYaw);const horiz=8.1*Math.cos(cameraPitch),vertical=2.8+8.1*Math.sin(cameraPitch);
    let target=hero.root.position.add(v3(0,1.35+player.jumpZ*.45,0)).add(f.scale(1.2));
    if(campaign.lock&&campaign.lock.hp>0){const mid=campaign.lock.root.position.add(hero.root.position).scale(.5);target=B.Vector3.Lerp(target,mid.add(v3(0,1.15,0)),.32);}
    const desired=hero.root.position.subtract(f.scale(horiz)).add(v3(0,vertical,0));
    if(snap){camPosition.copyFrom(desired);camTarget.copyFrom(target);}else{camPosition=B.Vector3.Lerp(camPosition,desired,1-Math.exp(-7.2*dt));camTarget=B.Vector3.Lerp(camTarget,target,1-Math.exp(-9.6*dt));}
    if(shake>0){camPosition.x+=rand(-shake,shake);camPosition.y+=rand(-shake,shake)*.5;shake=Math.max(0,shake-dt*.7);}
    camera.position.copyFrom(camPosition);camera.setTarget(camTarget);
  }
  function updateHazards(dt){for(const h of hazardMeshes){h.timer+=dt;if(h.timer>h.period){h.timer=0;if(Math.abs(hero.root.position.x-h.x)<1.2&&Math.abs(hero.root.position.z-h.z)<18)playerTakeDamage(h.damage,v3(h.mesh.position.x,0,h.mesh.position.z));}}}
  function updateCampaign(dt){
    const alive=campaign.enemies.filter(e=>e.hp>0);
    if(alive.length===0&&!campaign.portalReady){campaign.clearTimer+=dt;if(campaign.clearTimer>.8){const total=campaign.room===3?2:2;if(campaign.wave<total){campaign.clearTimer=0;addWave();}else setPortalReady();}}
    updateHazards(dt);
  }
  function updateUIClock(dt){if(toastTime>0){toastTime-=dt;if(toastTime<=0)$('toast').classList.remove('show');}if(Math.random()<dt*8)updateHUD();}
  function simulate(dt){time+=dt;updatePlayer(dt);campaign.enemies.forEach(e=>updateEnemy(e,dt));updateProjectiles(dt);updateCampaign(dt);updateCamera(dt);updateUIClock(dt);if(campaign.portalReady&&dist2(hero.root.position,{x:portal.x,z:portal.z})<5.1)$('interaction-hint').classList.remove('hidden');else $('interaction-hint').classList.add('hidden');}

  // ---------- Controls ----------
  const preventCodes=new Set(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','KeyJ','KeyK','KeyQ','KeyV','KeyT','KeyF','KeyE','Space','ShiftLeft','ShiftRight','Escape']);
  window.addEventListener('keydown',(e)=>{if(preventCodes.has(e.code))e.preventDefault();if(e.repeat)return;input.keys.add(e.code);if(gameState!=='playing')return;startAudio();
    if(e.code==='KeyJ')beginAttack('light');if(e.code==='KeyK')beginAttack('heavy');if(e.code==='Space')dodge();if(e.code==='ShiftLeft'||e.code==='ShiftRight')jump();if(e.code==='KeyQ')solar();if(e.code==='KeyV')riftStep();if(e.code==='KeyT')snare();if(e.code==='KeyF')toggleLock();if(e.code==='KeyE')advanceLevel();if(e.code==='Escape')pauseGame();
  },{passive:false});
  window.addEventListener('keyup',(e)=>input.keys.delete(e.code));window.addEventListener('blur',()=>{input.keys.clear();if(gameState==='playing')pauseGame();});
  canvas.addEventListener('contextmenu',e=>e.preventDefault());
  canvas.addEventListener('pointerdown',(e)=>{if(gameState!=='playing')return;startAudio();if(e.button===2||e.button===1){input.drag=true;input.lastX=e.clientX;input.lastY=e.clientY;canvas.setPointerCapture(e.pointerId);}else if(e.button===0)beginAttack('light');});
  canvas.addEventListener('pointermove',(e)=>{if(!input.drag||gameState!=='playing')return;const dx=e.clientX-input.lastX,dy=e.clientY-input.lastY;input.lastX=e.clientX;input.lastY=e.clientY;cameraYaw-=dx*.0042;cameraPitch=clamp(cameraPitch+dy*.0028,.10,.68);});
  function stopDrag(){input.drag=false;}canvas.addEventListener('pointerup',stopDrag);canvas.addEventListener('pointercancel',stopDrag);
  $('start-button').addEventListener('click',()=>beginCampaign(false));$('continue-button').addEventListener('click',()=>beginCampaign(true));
  $('resume-button').addEventListener('click',()=>{gameState='playing';$('pause-screen').classList.add('hidden');$('hud').classList.remove('hidden');$('mobile-ui').classList.add('active');startAudio();canvas.focus();});
  $('restart-button').addEventListener('click',()=>{gameState='playing';$('pause-screen').classList.add('hidden');$('hud').classList.remove('hidden');$('mobile-ui').classList.add('active');beginLevel();});
  $('menu-button').addEventListener('click',()=>{gameState='menu';$('pause-screen').classList.add('hidden');$('menu-screen').classList.remove('hidden');$('hud').classList.add('hidden');$('mobile-ui').classList.remove('active');});
  $('result-button').addEventListener('click',()=>{if(campaign.stage===3&&campaign.room===3){localStorage.removeItem(SAVE_KEY);gameState='menu';$('result-screen').classList.add('hidden');$('menu-screen').classList.remove('hidden');}else beginCampaign(true);});
  $('result-retry').addEventListener('click',()=>{gameState='playing';$('result-screen').classList.add('hidden');$('hud').classList.remove('hidden');$('mobile-ui').classList.add('active');beginLevel();});
  function pauseGame(){if(gameState!=='playing')return;gameState='paused';$('pause-screen').classList.remove('hidden');$('hud').classList.add('hidden');$('mobile-ui').classList.remove('active');}
  const stick=$('move-stick'),knob=$('stick-knob');
  stick.addEventListener('pointerdown',(e)=>{input.stickId=e.pointerId;stick.setPointerCapture(e.pointerId);updateStick(e);});stick.addEventListener('pointermove',(e)=>{if(e.pointerId===input.stickId)updateStick(e);});
  function updateStick(e){const r=stick.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2,max=r.width*.34,len=Math.hypot(dx,dy),nx=len>max?dx/len*max:dx,ny=len>max?dy/len*max:dy;knob.style.transform=`translate(calc(-50% + ${nx}px),calc(-50% + ${ny}px))`;input.mobile.x=nx/max;input.mobile.z=-ny/max;}
  function resetStick(){input.stickId=null;input.mobile.x=0;input.mobile.z=0;knob.style.transform='translate(-50%,-50%)';}stick.addEventListener('pointerup',resetStick);stick.addEventListener('pointercancel',resetStick);
  document.querySelectorAll('[data-action]').forEach(btn=>{const action=btn.dataset.action;const run=(e)=>{e.preventDefault();if(action==='light')beginAttack('light');else if(action==='heavy')beginAttack('heavy');else if(action==='dodge')dodge();else if(action==='jump')jump();else if(action==='solar')solar();else if(action==='rift')riftStep();else if(action==='snare')snare();};btn.addEventListener('pointerdown',run,{passive:false});});

  // ---------- Startup and render loop ----------
  const previous=loadSaved();if(previous)$('continue-button').classList.remove('hidden');
  if(previous){campaign.stage=clamp(previous.stage||0,0,3);campaign.room=clamp(previous.room||0,0,3);}
  hero.root.position.set(0,0,-12);hero.facing.rotation.y=0;buildLevel(0,0);updateCamera(0,true);
  const boot=()=>{if(engine.getCaps().drawBuffersExtension){}engine.runRenderLoop(()=>{const now=performance.now();let dt=Math.min((now-(simulate.last||now))/1000,.05);simulate.last=now;if(gameState==='playing'){if(hitStop>0)hitStop=Math.max(0,hitStop-dt);else simulate(dt);}else{time+=dt*.22;hero.cape.rotation.x=.12+Math.sin(time*2)*.05;}
      for(const h of hazardMeshes){if(h.mesh&&h.mesh.material)h.mesh.material.emissiveColor=c3(realms[campaign.stage].hot).scale(.45+.3*Math.sin(time*4));}
      scene.render();});};
  setTimeout(()=>{$('loading').style.opacity='0';setTimeout(()=>$('loading').classList.add('hidden'),750);},500);
  boot();window.addEventListener('resize',()=>engine.resize());
  window.Emberfall3D={scene,engine,hero,campaign,beginCampaign,beginLevel,getState:()=>gameState,version:'4.0.0'};
})();
