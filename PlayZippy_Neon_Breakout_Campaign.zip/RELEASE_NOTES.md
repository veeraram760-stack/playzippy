# PlayZippy Neon Breakout campaign release

## Replaces the previous flagship

The Nitro Rift kart prototype is no longer the featured flagship. The new featured game is Neon Breakout: Skyline Trials, a manual-skill platformer. There are no AI-controlled player movements and no automatic player steering.

## Gameplay

- 30 progressively harder stages across six themed worlds.
- Precise acceleration, braking through release/friction, jump buffering, coyote time, double-jump, wall-jump and dash cooldown.
- Moving and crumbling platforms, spike strips, timed lasers, patrol drones and checkpoints.
- Stomp drones to clear routes; collect at least two of three shards to unlock each portal.
- Bronze/silver/gold time medals, best time records, falls and campaign unlocks.
- Level select, continue campaign and daily seeded trial.
- Visible pointer controls on desktop and mobile, alongside keyboard input.

## Validation

- TypeScript JSX transpile/syntax checks passed for the new game component, application routes and game catalog.
- Runtime harness verified: the player x-coordinate remains unchanged without input; right movement moves the player; jump input produces upward movement; the animation loop renders.
- A full `npm run build` has not been executed in this authoring container because npm dependency installation could not complete. Cloudflare Pages must run the release build after the package is committed.

## Monetization

Ad scripts and SDKs remain disabled. This release is for gameplay evaluation only.
