# PlayZippy — Neon Breakout campaign update

This release replaces the previous Nitro Rift flagship with **Neon Breakout: Skyline Trials**, a player-controlled precision platformer.

## What is included

- 30 campaign stages arranged across six visual worlds.
- Manual movement, jump, double-jump, wall-jump and dash controls. The player character does not use AI/autopilot movement.
- Moving platforms, crumbling platforms, spike strips, timed laser gates and patrol drones.
- Drones can be defeated by landing on them.
- Three collectible shards per stage; collect at least two to activate the exit portal.
- Checkpoints, falls/death counter, completion times and bronze/silver/gold medals.
- Level select for every unlocked stage and a daily seeded trial.
- Local progress saving in the browser with `localStorage`.
- Keyboard controls and visible on-screen pointer controls for desktop and mobile.
- No advertising scripts or ad SDKs are enabled.

## Controls

| Action | Keyboard | On-screen controls |
|---|---|---|
| Move left/right | A / D or ← / → | ◀ / ▶ |
| Jump | Space / W / ↑ | JUMP |
| Double jump | Press jump again in the air | Tap JUMP again |
| Wall jump | Jump while touching a wall | JUMP near a wall |
| Dash | Shift or X | DASH |
| Restart level | R | RESTART LEVEL |
| Pause | Esc | Pause button |

## Run locally

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
```

Vite outputs the site to `dist/`.

## Cloudflare Pages

Project build command:

```bash
unzip -o PlayZippy_Neon_Breakout_Campaign.zip -d . && npm install --no-audit --no-fund && npm run build
```

Build output directory: `dist`.

## Save data

Campaign unlocks, best times, falls, clears and total shards are stored locally on the player's browser/device. This release does not include server accounts, online multiplayer or a cross-device leaderboard.
