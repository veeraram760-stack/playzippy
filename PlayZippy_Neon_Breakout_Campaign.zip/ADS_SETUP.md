# Advertising status

Advertising is intentionally disabled for this release. Do not add AdSense, H5 Games Ads or other advertising tags until the site owner has tested and approved gameplay and the website has completed the relevant ad-network review.
