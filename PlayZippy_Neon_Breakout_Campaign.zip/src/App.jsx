import React, { useMemo, useState } from "react";
import { Routes, Route, Link, useParams } from "react-router-dom";
import Header from "./components/Header.jsx";
import Footer from "./components/Footer.jsx";
import AdSlot from "./components/AdSlot.jsx";
import { games } from "./data/games.js";
import PandaDash from "./games/PandaDash.jsx";
import NeonDrift from "./games/NeonDrift.jsx";
import StarfallAssault from "./games/StarfallAssault.jsx";
import CrystalCascade from "./games/CrystalCascade.jsx";
import BlockMaster from "./games/BlockMaster.jsx";
import MemoryMatch from "./games/MemoryMatch.jsx";
import AstraReclaimer from "./games/AstraReclaimer.jsx";
import NeonBreakout from "./games/NeonBreakout.jsx";

const gameComponents = {
  "neon-breakout": NeonBreakout,
  "panda-dash": PandaDash,
  "neon-drift": NeonDrift,
  "starfall-assault": StarfallAssault,
  "crystal-cascade": CrystalCascade,
  "block-master": BlockMaster,
  "memory-match": MemoryMatch,
  "astra-reclaimer": AstraReclaimer
};

function GameArtwork({ game }) {
  return <div className={`game-artwork art-${game.color}`}>
    <div className="art-glow" />
    <div className="art-orbit orbit-a" />
    <div className="art-orbit orbit-b" />
    <span className="art-emoji">{game.emoji}</span>
    <span className="art-badge">{game.badge}</span>
    {game.id === "starfall-assault" && <><i className="art-star star-a">✦</i><i className="art-star star-b">✧</i><i className="art-star star-c">·</i></>}
    {game.id === "neon-drift" && <><i className="speed-line line-a"/><i className="speed-line line-b"/><i className="speed-line line-c"/></>}
    {game.id === "crystal-cascade" && <><i className="crystal-float crystal-one">◆</i><i className="crystal-float crystal-two">✦</i></>}
    {game.id === "panda-dash" && <><i className="leaf leaf-a">✦</i><i className="leaf leaf-b">✧</i></>}
  </div>;
}

function GameCard({ game, index = 0 }) {
  return <Link to={`/games/${game.id}`} className={`game-card game-card-${game.color}`} style={{ "--card-index": index }}>
    <GameArtwork game={game}/>
    <div className="game-card-copy">
      <div className="game-card-meta"><span>{game.category}</span><span>◷ {game.time}</span></div>
      <h3>{game.title}</h3>
      <p>{game.description}</p>
      <div className="game-card-bottom"><span className="play-link">PLAY GAME <b>↗</b></span><span className="card-arrow">→</span></div>
    </div>
  </Link>;
}

function Home() {
  const [category, setCategory] = useState("All games");
  const categories = ["All games", "Action", "Racing", "Arcade", "Puzzle", "Brain", "Adventure"];
  const filtered = useMemo(() => category === "All games" ? games : games.filter(g => g.category === category), [category]);
  const feature = games[0];
  return <>
    <main className="home-page">
      <section className="arcade-hero">
        <div className="hero-content">
          <div className="hero-kicker"><span className="live-dot"/> YOUR NEXT GAME IS ONE CLICK AWAY</div>
          <h1>One more run.<br/><em>One more legend.</em></h1>
          <p>Take on deeper campaigns, build powerful loadouts, unlock permanent upgrades and chase a new daily challenge. No downloads. Just play.</p>
          <div className="hero-button-row"><a className="hero-primary" href="#games">Explore games <span>↘</span></a><span className="hero-trust"><b>✦</b> Free to play · Browser ready</span></div>
          <div className="hero-metrics"><div><b>08</b><small>GAMES TO PLAY</small></div><i/><div><b>0</b><small>DOWNLOADS</small></div><i/><div><b>∞</b><small>REPLAY VALUE</small></div></div>
        </div>
        <div className="hero-stage" aria-hidden="true">
          <div className="hero-stage-grid"/><div className="hero-ring ring-one"/><div className="hero-ring ring-two"/><div className="hero-ring ring-three"/>
          <div className="hero-planet planet-back"/><div className="hero-planet planet-front"/>
          <div className="hero-ship">🚀</div><div className="hero-stage-chip chip-score"><span>✦</span><div><b>LEVEL UP</b><small>Every run counts</small></div></div><div className="hero-stage-chip chip-free"><span>⚡</span><div><b>INSTANT PLAY</b><small>No install needed</small></div></div>
          <span className="hero-star hero-star-a">✦</span><span className="hero-star hero-star-b">✧</span><span className="hero-star hero-star-c">·</span>
        </div>
      </section>

      <section className="spotlight-wrap">
        <div className="spotlight-label"><span className="spotlight-dot"/> FEATURED DROP</div>
        <Link to={`/games/${feature.id}`} className="spotlight-card">
          <div className="spotlight-art rift-spotlight-art breakout-spotlight-art"><div className="spotlight-planet"/><span>🏃</span><i>✦</i><b>NEON BREAKOUT</b></div>
          <div className="spotlight-copy"><span className="eyebrow">FLAGSHIP ORIGINAL · 30 SKILL TRIALS</span><h2>Every jump.<br/><em>Your decision.</em></h2><p>Run, leap, double-jump and dash through six worlds of rooftop gaps, moving platforms, timed lasers and patrolling drones. Find shards, hit checkpoints and earn bronze, silver or gold medals across a 30-level campaign.</p><span className="spotlight-cta">PLAY NEON BREAKOUT: SKYLINE TRIALS <b>→</b></span></div>
          <div className="spotlight-index">01 <i>/ 07</i></div>
        </Link>
      </section>

      <AdSlot className="ad-wide"/>

      <section id="games" className="games-section">
        <div className="games-heading"><div><span className="eyebrow">THE PLAYGROUND</span><h2>Pick your <em>next obsession.</em></h2><p>Skill games, longer expeditions, upgrades and challenges worth coming back for.</p></div><span className="games-count">{filtered.length.toString().padStart(2,"0")} GAMES AVAILABLE</span></div>
        <div className="category-row">{categories.map(c=><button key={c} className={category===c?"category-pill active":"category-pill"} onClick={()=>setCategory(c)}>{c}</button>)}</div>
        <div className="games-grid">{filtered.map((g,i)=><GameCard key={g.id} game={g} index={i}/>)}</div>
      </section>

      <section className="play-promise"><div className="promise-icon">🎮</div><div><span className="eyebrow">MADE FOR YOUR BREAK</span><h2>Easy to start.<em> Worth mastering.</em></h2><p>Get into the action quickly, then build skill, discover synergies and make progress across repeatable runs.</p></div><a href="#games" className="promise-link">Find a game <b>↗</b></a></section>
      <section className="seo-copy"><h2>Free online games to play in your browser</h2><p>PlayZippy is a growing collection of free browser games, including roguelite expeditions, arcade action, endless racing, match-three puzzles, memory challenges and block puzzles. Play instantly on desktop, tablet or mobile with no download or account required. Discover a new challenge, beat your personal best and come back for another round.</p></section>
    </main>
  </>;
}

function GamePage() {
  const { id } = useParams(); const game = games.find(g => g.id === id); const Component = gameComponents[id];
  if (!game || !Component) return <NotFound/>;
  return <main className="game-page">
    <div className="breadcrumbs"><Link to="/">PLAYGROUND</Link><span>/</span><span>{game.category.toUpperCase()}</span><span>/</span><b>{game.title.toUpperCase()}</b></div>
    <div className="game-page-head"><div><span className="eyebrow">{game.badge}</span><h1>{game.title}</h1><p>{game.description}</p></div><Link className="back-link" to="/">← ALL GAMES</Link></div>
    <AdSlot className="ad-wide"/>
    <Component/>
    <section className="game-how"><div><span className="eyebrow">GET IN THE GAME</span><h2>How to <em>play</em></h2></div><p>{game.description}<br/><b>Controls:</b> {game.controls}. Your expedition progress and commendations are saved locally on this device.</p></section>
    <div className="more-games-head"><div><span className="eyebrow">KEEP THE FUN GOING</span><h2>More games to <em>try.</em></h2></div><Link to="/">Browse all →</Link></div>
    <div className="games-grid compact">{games.filter(g=>g.id!==id).slice(0,3).map((g,i)=><GameCard key={g.id} game={g} index={i}/>)}</div>
  </main>;
}
function StaticPage({title,children}){return <main className="static-page"><span className="eyebrow">PLAYZIPPY</span><h1>{title}</h1>{children}</main>}
function About(){return <StaticPage title="About PlayZippy"><p>PlayZippy is an independent browser gaming playground built around quick, colourful and replayable games. Our goal is to make it easy to enjoy original casual games on desktop and mobile without downloads.</p><p>We are continuously improving our games and adding new challenges. Have an idea or feedback? Contact us.</p></StaticPage>}
function Privacy(){return <StaticPage title="Privacy policy"><p><b>Last updated: November 2026</b></p><p>PlayZippy aims to collect as little personal information as possible. The games currently run locally in your browser and may store game scores and progress in local storage on your device.</p><h2>Analytics and advertising</h2><p>When analytics or advertising services are enabled, those providers may use cookies or similar technologies to measure visits, deliver ads, prevent fraud and support their services. This policy must be updated with the exact providers, data practices, consent mechanism and contact details before enabling any third-party services.</p><h2>Children</h2><p>This website is not specifically directed to children under the age applicable in their location. Do not submit personal information through the site. If the audience or features change, additional child privacy requirements may apply.</p><h2>Your choices</h2><p>You can clear local storage and cookies through your browser settings. For privacy questions, use the contact page.</p><p><b>Publisher contact:</b> Replace this text with your business contact email before launch.</p></StaticPage>}
function Terms(){return <StaticPage title="Terms of use"><p><b>Last updated: November 2026</b></p><p>PlayZippy games are provided for entertainment. Use the website lawfully and do not attempt to disrupt, exploit or interfere with the service.</p><h2>Game content</h2><p>Unless stated otherwise, PlayZippy game code, names and original artwork are owned by the site operator. Do not copy, redistribute or commercially exploit the games without permission.</p><h2>Availability</h2><p>Games and website features may change or become unavailable. The website is provided without a guarantee of uninterrupted service.</p><h2>Contact</h2><p>Replace this section with your business contact email before launch.</p></StaticPage>}
function Contact(){return <StaticPage title="Contact"><p>Have feedback, found a bug or want to suggest a game? We'd love to hear from you.</p><p>Before launch, replace this placeholder with a monitored business email address.</p></StaticPage>}
function NotFound(){return <StaticPage title="Game not found"><p>That page may have moved. Browse our available games instead.</p><Link className="hero-primary" to="/">Explore games</Link></StaticPage>}
export default function App(){return <><Header/><Routes><Route path="/" element={<Home/>}/><Route path="/games/:id" element={<GamePage/>}/><Route path="/about" element={<About/>}/><Route path="/privacy" element={<Privacy/>}/><Route path="/terms" element={<Terms/>}/><Route path="/contact" element={<Contact/>}/><Route path="*" element={<NotFound/>}/></Routes><Footer/></>}
