# Emberfall: The Last Hearth — Combat VFX Update 1.2

This release focuses on readable, satisfying combat feedback while preserving the painted realm backgrounds, character artwork, encounters, relic progression, save format, and overall balance from visual upgrade 1.1.

## Combat presentation changes
- Three distinct animated sword-combo sweeps with an independently animated, luminous blade path.
- Anticipation, forward lunge, follow-through and recovery body motion.
- Hit-stop on landed strikes, impact frames, directional impact bursts, floating damage, enemy knockback and hit-stun.
- Heavy enemies now telegraph their charge lane and target point; archers telegraph their aimed shot; the Warden's shard storm has a radial warning pattern.
- Dodge after-images, ground motes and directional dash effects.
- Solar Burst has layered shockwave rings, rays, light pulse and stronger impact feedback.
- Distinct audio accents for combo strikes.
- Keyboard `J` attack added alongside mouse/touch attack.

## Controls
- `WASD` / arrow keys: move
- Mouse 1 / `J`: blade combo
- `Space`: dodge
- `Q`: Solar Burst
- `E`: interact with gate
- `Esc` / `P`: pause

## Build
Run `npm run build`. The static production site is generated in `dist/`.

No advertising or AdSense integration is included.
