// Discrete raised terraces and gentle ramps sit on top of the oblique 2.5D ground plane.
// Coordinates are in the same logical 1280x720 world used by the main Canvas simulation.
const verdant = [
  {
    title: 'Moss Gate · The Lower Court',
    platforms: [
      { x: 205, y: 268, w: 245, h: 118, z: 24, tint: '#60754b' },
      { x: 850, y: 232, w: 250, h: 142, z: 42, tint: '#6f8150' }
    ],
    ramps: [
      { x: 380, y: 360, w: 145, h: 92, from: 0, to: 24, axis: 'x' },
      { x: 805, y: 335, w: 120, h: 105, from: 0, to: 42, axis: 'x' }
    ],
    plants: [ { x: 548, y: 355, kind: 'volatile' }, { x: 1010, y: 475, kind: 'healing' } ]
  },
  {
    title: 'Rootbound Chapel · The Nave',
    platforms: [
      { x: 170, y: 228, w: 300, h: 145, z: 30, tint: '#66764d' },
      { x: 835, y: 240, w: 275, h: 130, z: 38, tint: '#748253' },
      { x: 525, y: 170, w: 205, h: 82, z: 58, tint: '#84905c' }
    ],
    ramps: [
      { x: 420, y: 350, w: 135, h: 90, from: 0, to: 30, axis: 'x' },
      { x: 730, y: 315, w: 155, h: 105, from: 0, to: 38, axis: 'x' },
      { x: 590, y: 245, w: 105, h: 145, from: 0, to: 58, axis: 'y' }
    ],
    plants: [ { x: 300, y: 480, kind: 'volatile' }, { x: 930, y: 460, kind: 'healing' }, { x: 650, y: 420, kind: 'volatile' } ]
  },
  {
    title: 'Hanging Orchard · The Canopy',
    platforms: [
      { x: 155, y: 248, w: 250, h: 130, z: 28, tint: '#657d4d' },
      { x: 880, y: 228, w: 260, h: 132, z: 54, tint: '#80905b' },
      { x: 535, y: 300, w: 180, h: 92, z: 78, tint: '#8b9861' }
    ],
    ramps: [
      { x: 355, y: 350, w: 185, h: 120, from: 0, to: 28, axis: 'x' },
      { x: 700, y: 345, w: 230, h: 110, from: 0, to: 54, axis: 'x' },
      { x: 580, y: 375, w: 100, h: 110, from: 0, to: 78, axis: 'y' }
    ],
    plants: [ { x: 275, y: 465, kind: 'volatile' }, { x: 990, y: 435, kind: 'healing' }, { x: 630, y: 520, kind: 'volatile' } ]
  },
  {
    title: "The Warden's Cradle · Root Pit",
    platforms: [
      { x: 170, y: 218, w: 260, h: 140, z: 34, tint: '#6b7950' },
      { x: 850, y: 210, w: 260, h: 145, z: 54, tint: '#87905d' },
      { x: 475, y: 170, w: 325, h: 105, z: 26, tint: '#75834e' }
    ],
    ramps: [
      { x: 365, y: 340, w: 145, h: 112, from: 0, to: 34, axis: 'x' },
      { x: 765, y: 330, w: 150, h: 112, from: 0, to: 54, axis: 'x' }
    ],
    plants: [ { x: 305, y: 485, kind: 'healing' }, { x: 975, y: 470, kind: 'volatile' } ]
  }
];

const ashen = [
  { platforms: [{ x: 200, y: 235, w: 270, h: 140, z: 36, tint: '#845844' }, { x: 835, y: 245, w: 270, h: 130, z: 50, tint: '#a06649' }], ramps: [{ x: 405, y: 345, w: 150, h: 115, from: 0, to: 36, axis: 'x' }, { x: 780, y: 340, w: 145, h: 110, from: 0, to: 50, axis: 'x' }], plants: [{ x: 570, y: 390, kind: 'volatile' }, { x: 1005, y: 500, kind: 'healing' }] },
  { platforms: [{ x: 160, y: 230, w: 275, h: 128, z: 30, tint: '#935d43' }, { x: 885, y: 215, w: 245, h: 138, z: 55, tint: '#a86b4c' }, { x: 510, y: 165, w: 250, h: 92, z: 66, tint: '#9a6648' }], ramps: [{ x: 375, y: 340, w: 165, h: 112, from: 0, to: 30, axis: 'x' }, { x: 750, y: 320, w: 175, h: 115, from: 0, to: 55, axis: 'x' }], plants: [{ x: 320, y: 475, kind: 'volatile' }, { x: 940, y: 470, kind: 'volatile' }] },
  { platforms: [{ x: 180, y: 220, w: 265, h: 140, z: 36, tint: '#985f45' }, { x: 850, y: 225, w: 260, h: 140, z: 58, tint: '#a66c4d' }, { x: 495, y: 170, w: 290, h: 110, z: 28, tint: '#87563f' }], ramps: [{ x: 380, y: 340, w: 150, h: 120, from: 0, to: 36, axis: 'x' }, { x: 750, y: 335, w: 160, h: 115, from: 0, to: 58, axis: 'x' }], plants: [{ x: 300, y: 490, kind: 'healing' }, { x: 1000, y: 480, kind: 'volatile' }] }
];

const moonwell = [
  { platforms: [{ x: 180, y: 236, w: 260, h: 132, z: 34, tint: '#626d91' }, { x: 850, y: 225, w: 255, h: 138, z: 50, tint: '#747fa4' }], ramps: [{ x: 380, y: 342, w: 155, h: 115, from: 0, to: 34, axis: 'x' }, { x: 770, y: 335, w: 145, h: 110, from: 0, to: 50, axis: 'x' }], plants: [{ x: 330, y: 485, kind: 'healing' }, { x: 955, y: 490, kind: 'volatile' }] },
  { platforms: [{ x: 155, y: 228, w: 280, h: 138, z: 32, tint: '#626c91' }, { x: 880, y: 222, w: 250, h: 136, z: 58, tint: '#7b87ad' }, { x: 505, y: 162, w: 255, h: 100, z: 70, tint: '#838eb1' }], ramps: [{ x: 380, y: 342, w: 160, h: 115, from: 0, to: 32, axis: 'x' }, { x: 755, y: 325, w: 165, h: 120, from: 0, to: 58, axis: 'x' }], plants: [{ x: 305, y: 480, kind: 'healing' }, { x: 980, y: 465, kind: 'healing' }] },
  { platforms: [{ x: 170, y: 216, w: 265, h: 138, z: 36, tint: '#69759b' }, { x: 855, y: 218, w: 265, h: 140, z: 62, tint: '#8794bc' }, { x: 485, y: 165, w: 300, h: 108, z: 30, tint: '#737fa8' }], ramps: [{ x: 370, y: 342, w: 165, h: 118, from: 0, to: 36, axis: 'x' }, { x: 770, y: 330, w: 155, h: 122, from: 0, to: 62, axis: 'x' }], plants: [{ x: 295, y: 490, kind: 'healing' }, { x: 995, y: 490, kind: 'volatile' }] }
];

export function getChamberLayout(stage, room) {
  const groups = [verdant, ashen, moonwell];
  const rows = groups[stage] || verdant;
  return rows[Math.min(room, rows.length - 1)];
}

export function surfaceHeightAt(x, y, layout) {
  if (!layout) return 0;
  let height = 0;
  for (const ramp of layout.ramps || []) {
    if (x < ramp.x || x > ramp.x + ramp.w || y < ramp.y || y > ramp.y + ramp.h) continue;
    const t = ramp.axis === 'y' ? (y - ramp.y) / ramp.h : (x - ramp.x) / ramp.w;
    height = Math.max(height, ramp.from + (ramp.to - ramp.from) * t);
  }
  for (const platform of layout.platforms || []) {
    if (x >= platform.x && x <= platform.x + platform.w && y >= platform.y && y <= platform.y + platform.h) height = Math.max(height, platform.z);
  }
  return height;
}
