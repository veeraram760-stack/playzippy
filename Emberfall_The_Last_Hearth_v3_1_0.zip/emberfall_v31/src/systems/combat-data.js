export const LIGHT_CHAIN = [
  { name: 'EMBER CUT', duration: 0.42, activeAt: 0.42, cooldown: 0.29, range: 104, arc: 1.02, damage: 1.00, lunge: 8, hitstop: 0.052, knockback: 18 },
  { name: 'CROSSING FLAME', duration: 0.44, activeAt: 0.44, cooldown: 0.30, range: 116, arc: 1.20, damage: 1.24, lunge: 12, hitstop: 0.055, knockback: 26 },
  { name: 'RISING ASH', duration: 0.48, activeAt: 0.46, cooldown: 0.32, range: 128, arc: 1.38, damage: 1.52, lunge: 15, hitstop: 0.064, knockback: 42 },
  { name: 'HEARTHFALL', duration: 0.58, activeAt: 0.52, cooldown: 0.38, range: 148, arc: 1.54, damage: 2.08, lunge: 20, hitstop: 0.085, knockback: 74 }
];

export const HEAVY_MOVE = {
  name: 'SUNBREAKER', duration: 0.74, activeAt: 0.58, cooldown: 0.72,
  range: 126, arc: 1.42, baseDamage: 1.72, chargeDamage: 1.12,
  baseKnockback: 92, chargeKnockback: 98, hitstop: 0.10
};

export const AIR_MOVES = {
  light: { name: 'SKY REND', duration: 0.46, activeAt: 0.45, cooldown: 0.34, range: 118, arc: 1.32, damage: 1.32, knockback: 34, hitstop: 0.06 },
  slam: { name: 'FALLING STAR', duration: 0.68, activeAt: 0.60, cooldown: 0.66, range: 154, arc: Math.PI, damage: 2.25, knockback: 112, hitstop: 0.11 }
};

export const SOLAR_MODES = [
  { id: 'nova', name: 'NOVA', hint: 'A full-circle blast', cooldown: 8.5, damage: 1.00 },
  { id: 'lance', name: 'LANCE', hint: 'A piercing line of fire', cooldown: 7.2, damage: 1.62 },
  { id: 'rupture', name: 'RUPTURE', hint: 'A close-range ground breaker', cooldown: 9.6, damage: 2.05 }
];

export function nextChainIndex(previous, remainingWindow) {
  return remainingWindow > 0 ? (previous % LIGHT_CHAIN.length) + 1 : 1;
}

export function getStyleRank(score) {
  if (score >= 1800) return 'S';
  if (score >= 1250) return 'A';
  if (score >= 800) return 'B';
  if (score >= 400) return 'C';
  return 'D';
}
