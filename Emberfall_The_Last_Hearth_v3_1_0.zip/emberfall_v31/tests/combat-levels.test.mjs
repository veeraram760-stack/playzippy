import assert from 'node:assert/strict';
import { AIR_MOVES, HEAVY_MOVE, LIGHT_CHAIN, SOLAR_MODES, getStyleRank, nextChainIndex } from '../src/systems/combat-data.js';
import { getChamberLayout, surfaceHeightAt } from '../src/systems/chambers.js';

assert.equal(LIGHT_CHAIN.length, 4, 'the light chain must have four authored hits');
assert.deepEqual([1, 2, 3, 4].map(v => nextChainIndex(v, 0)), [1, 1, 1, 1], 'expired chain resets to hit one');
assert.deepEqual([1, 2, 3, 4].map(v => nextChainIndex(v, 1)), [2, 3, 4, 1], 'active chain advances and wraps after hit four');
assert.ok(HEAVY_MOVE.chargeDamage > 0.8, 'heavy attack should scale with charge');
assert.ok(AIR_MOVES.light && AIR_MOVES.slam, 'both aerial moves should be authored');
assert.deepEqual(SOLAR_MODES.map(mode => mode.id), ['nova', 'lance', 'rupture']);
assert.equal(getStyleRank(1800), 'S');
assert.equal(getStyleRank(900), 'B');

const orchard = getChamberLayout(0, 2);
assert.ok(orchard.platforms.length >= 3, 'Hanging Orchard needs multiple elevations');
assert.ok(orchard.ramps.length >= 2, 'raised surfaces need ramp links');
assert.ok(orchard.plants.some(plant => plant.kind === 'volatile'), 'orchard needs a reactive explosive bloom');
assert.ok(orchard.plants.some(plant => plant.kind === 'healing'), 'orchard needs a healing plant');
const top = orchard.platforms[0];
assert.equal(surfaceHeightAt(top.x + top.w / 2, top.y + top.h / 2, orchard), top.z, 'platform footprint resolves its elevated surface');
assert.equal(surfaceHeightAt(40, 620, orchard), 0, 'open ground remains at base elevation');
console.log('Combat and chamber checks passed: four-hit chain, heavy/aerial moves, Solar aspects, ranks, raised platforms, ramps, and reactive plants.');
