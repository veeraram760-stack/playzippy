import assert from 'node:assert/strict';
import fs from 'node:fs';
import { getEnemyProfile } from '../src/systems/enemy-data.js';

const enemies = ['stalker', 'archer', 'brute', 'wisp'].map(kind => getEnemyProfile(kind));
const basicLight = 18;
const maxLightCritical = 18 * 2.08 * 2.05;
const maxHeavyCritical = 18 * (1.72 + 1.12) * 2.05;
for (const enemy of enemies) {
  assert.ok(enemy.hp > basicLight, `${enemy.hp} HP must survive one basic light hit`);
  assert.ok(enemy.hp > maxLightCritical, `${enemy.hp} HP must survive one critical light finisher`);
  assert.ok(enemy.hp > maxHeavyCritical, `${enemy.hp} HP must survive one fully charged critical heavy`);
}
assert.ok(getEnemyProfile('stalker', 1).hp > getEnemyProfile('stalker').hp, 'later realm scaling should increase enemy health');
assert.ok(getEnemyProfile('stalker', 0, 1).hp > getEnemyProfile('stalker').hp, 'mid-chamber scaling should remain active');
assert.ok(getEnemyProfile('stalker', 0, 0, true).hp > getEnemyProfile('stalker').hp, 'Risk Mode should remain tougher');

const main = fs.readFileSync('./src/main.js', 'utf8');
assert.match(main, /player\.attackCd>0\|\|player\.attackTime>0/, 'held attack must not restart before current swing recovers');
const world = main.slice(main.indexOf('function drawWorld(){'), main.indexOf('function drawSprite('));
assert.doesNotMatch(world, /drawPlatforms\(\)/, 'placeholder platform slabs must not cover the authored scene');
console.log('Combat tuning checks passed: enemies survive single light/finisher/heavy hits; progression scaling stays enabled; swing overlap and platform-overlay regressions are blocked.');
