import assert from 'node:assert/strict';
import { getEncounterWaves } from '../src/systems/encounter-data.js';

const validKinds = new Set(['stalker', 'archer', 'wisp', 'brute']);
for (const stage of [0, 1, 2]) {
  const rooms = stage === 0 ? 4 : 3;
  for (let room = 0; room < rooms; room++) {
    const waves = getEncounterWaves(stage, room, false);
    assert.equal(waves.length, 3, `stage ${stage}, room ${room} should have three waves`);
    for (const wave of waves) {
      assert.ok(wave.length >= 2, 'each wave should contain multiple enemies');
      for (const enemy of wave) {
        assert.ok(validKinds.has(enemy.kind), `unknown enemy kind: ${enemy.kind}`);
        assert.equal(typeof enemy.elite, 'boolean');
      }
    }
    assert.ok(waves[2].some(enemy => enemy.elite), 'final wave should include an elite enemy');
    const riskWaves = getEncounterWaves(stage, room, true);
    assert.ok(riskWaves.every((wave, i) => wave.length >= waves[i].length), 'risk mode should add enemies');
  }
}
console.log('Encounter wave checks passed: three waves, supported enemies, elite capstones and risk-mode additions across all realms.');
