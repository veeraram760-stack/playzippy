import assert from 'node:assert/strict';
import { readFileSync, existsSync, statSync } from 'node:fs';

const root = new URL('../', import.meta.url).pathname;
const source = readFileSync(`${root}src/main.js`, 'utf8');
for (const name of ['thornling', 'archer', 'brute', 'boss']) {
  const path = `${root}public/art/${name}-atlas.png`;
  assert.ok(existsSync(path), `missing ${name} frame atlas`);
  const png = readFileSync(path);
  assert.equal(png.subarray(0, 8).toString('hex'), '89504e470d0a1a0a', `${name} atlas must be PNG`);
  assert.equal(png.readUInt32BE(16), 1024, `${name} atlas width`);
  assert.equal(png.readUInt32BE(20), 1024, `${name} atlas height`);
  assert.ok(statSync(path).size > 100_000, `${name} atlas unexpectedly small`);
}
assert.match(source, /function projectPoint\(/, 'missing oblique camera projection');
assert.match(source, /function unprojectPoint\(/, 'missing inverse input projection');
assert.match(source, /function enemyFrame\(/, 'missing enemy frame-state selector');
assert.match(source, /drawAtlasFrame\(atlas,row,col/, 'enemy renderer must use authored frame atlas');
assert.match(source, /projectPoint\(e\.x,e\.y,e\.elevation\|\|0\)\.y/, 'actors must depth-sort in projected elevated screen space');
const enemyDraw = source.slice(source.indexOf('function drawEnemy(e){'), source.indexOf('\nfunction drawHeroRig'));
assert.ok(!enemyDraw.includes('ctx.rotate(lean)'), 'enemy renderer must not rotate a single still to fake locomotion');
console.log('Presentation checks passed: oblique projection, inverse pointer mapping, 4 enemy animation atlases, frame-state selection, and projected depth sorting.');

assert.doesNotMatch(readFileSync(`${root}index.html`, 'utf8'), /class=\"combat-action-guide\"/, 'duplicate large control-preview strip should not sit below the arena');
